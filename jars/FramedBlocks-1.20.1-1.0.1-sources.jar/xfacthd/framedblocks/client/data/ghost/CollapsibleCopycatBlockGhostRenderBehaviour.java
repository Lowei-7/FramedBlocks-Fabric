package xfacthd.framedblocks.client.data.ghost;

import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import net.minecraftforge.client.model.data.ModelData;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.ghost.GhostRenderBehaviour;
import xfacthd.framedblocks.api.model.data.FramedBlockData;
import xfacthd.framedblocks.common.blockentity.special.FramedCollapsibleCopycatBlockEntity;
import xfacthd.framedblocks.common.data.PropertyHolder;

public final class CollapsibleCopycatBlockGhostRenderBehaviour implements GhostRenderBehaviour
{
    @Override
    @Nullable
    public class_2680 getRenderState(
            class_1799 stack,
            @Nullable class_1799 proxiedStack,
            class_3965 hit,
            class_1750 ctx,
            class_2680 hitState,
            boolean secondPass
    )
    {
        class_2680 state = GhostRenderBehaviour.super.getRenderState(stack, proxiedStack, hit, ctx, hitState, secondPass);
        //noinspection ConstantConditions
        if (state != null && stack.method_7985() && stack.method_7969().method_10545("BlockEntityTag"))
        {
            int offsets = stack.method_7969().method_10562("BlockEntityTag").method_10550("offsets");
            int solidFaces = FramedCollapsibleCopycatBlockEntity.computeSolidFaces(offsets);
            state = state.method_11657(PropertyHolder.SOLID_FACES, solidFaces);
        }
        return state;
    }

    @Override
    public ModelData appendModelData(
            class_1799 stack,
            @Nullable class_1799 proxiedStack,
            class_1750 ctx,
            class_2680 renderState,
            boolean secondPass,
            ModelData data
    )
    {
        //noinspection ConstantConditions
        if (stack.method_7985() && stack.method_7969().method_10545("BlockEntityTag"))
        {
            int offsets = stack.method_7969().method_10562("BlockEntityTag").method_10550("offsets");
            FramedBlockData frame = data.get(FramedBlockData.PROPERTY);
            if (frame != null)
            {
                frame.setPackedOffsets(offsets);
            }
        }
        return data;
    }
}
