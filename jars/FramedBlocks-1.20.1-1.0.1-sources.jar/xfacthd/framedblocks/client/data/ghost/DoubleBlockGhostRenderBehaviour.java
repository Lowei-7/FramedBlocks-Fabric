package xfacthd.framedblocks.client.data.ghost;

import net.minecraft.class_1799;
import net.minecraft.class_2487;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.camo.CamoContainer;
import xfacthd.framedblocks.api.camo.EmptyCamoContainer;
import xfacthd.framedblocks.api.ghost.CamoPair;
import xfacthd.framedblocks.api.ghost.GhostRenderBehaviour;

public sealed class DoubleBlockGhostRenderBehaviour implements GhostRenderBehaviour
        permits DoublePanelGhostRenderBehaviour, AdjustableDoubleBlockGhostRenderBehaviour
{
    @Override
    public CamoPair readCamo(class_1799 stack, @Nullable class_1799 proxiedStack, boolean secondPass)
    {
        return readDoubleCamo(stack);
    }

    public static CamoPair readDoubleCamo(class_1799 stack)
    {
        //noinspection ConstantConditions
        if (stack.method_7985() && stack.method_7969().method_10545("BlockEntityTag"))
        {
            class_2487 blockEntityTag = stack.method_7969().method_10562("BlockEntityTag");
            CamoContainer camo = EmptyCamoContainer.EMPTY;
            CamoContainer camoTwo = EmptyCamoContainer.EMPTY;
            if (blockEntityTag.method_10545("camo"))
            {
                camo = CamoContainer.load(blockEntityTag.method_10562("camo"));
            }
            if (blockEntityTag.method_10545("camo_two"))
            {
                camoTwo = CamoContainer.load(blockEntityTag.method_10562("camo_two"));
            }

            return new CamoPair(camo.getState(), camoTwo.getState());
        }
        return CamoPair.EMPTY;
    }
}
