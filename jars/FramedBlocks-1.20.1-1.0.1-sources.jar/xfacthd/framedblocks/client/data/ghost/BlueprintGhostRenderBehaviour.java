package xfacthd.framedblocks.client.data.ghost;

import net.minecraftforge.client.model.data.ModelData;
import net.minecraftforge.client.model.data.ModelProperty;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import net.minecraft.world.item.*;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.camo.CamoContainer;
import xfacthd.framedblocks.api.ghost.CamoPair;
import xfacthd.framedblocks.api.ghost.GhostRenderBehaviour;
import xfacthd.framedblocks.client.render.special.GhostBlockRenderer;
import xfacthd.framedblocks.common.item.FramedBlueprintItem;

import java.util.Iterator;
import java.util.Set;

public final class BlueprintGhostRenderBehaviour implements GhostRenderBehaviour
{
    @Override
    @Nullable
    public class_1799 getProxiedStack(class_1799 stack)
    {
        class_1792 item = FramedBlueprintItem.getTargetBlock(stack).method_8389();
        if (item instanceof class_1747)
        {
            class_1799 proxied = new class_1799(item);
            //noinspection ConstantConditions
            if (stack.method_7985() && stack.method_7969().method_10545("blueprint_data"))
            {
                proxied.method_7948().method_10566(
                        "BlockEntityTag",
                        stack.method_7969().method_10562("blueprint_data").method_10562("camo_data")
                );
            }
            return proxied;
        }
        return null;
    }

    @Override
    public boolean mayRender(class_1799 stack, @Nullable class_1799 proxiedStack)
    {
        return proxiedStack != null && proxyBehaviour(proxiedStack).mayRender(proxiedStack, null);
    }

    @Override
    public boolean hasSecondBlock(class_1799 stack, @Nullable class_1799 proxiedStack)
    {
        return proxiedStack != null && proxyBehaviour(proxiedStack).hasSecondBlock(proxiedStack, null);
    }

    @Override
    @Nullable
    public class_2680 getRenderState(
            class_1799 stack,
            @Nullable class_1799 proxiedStack,
            class_3965 hit,
            class_1750 ctx,
            class_2680 hitState,
            boolean secondPass
    )
    {
        if (proxiedStack == null)
        {
            return null;
        }
        return proxyBehaviour(proxiedStack).getRenderState(proxiedStack, null, hit, ctx, hitState, secondPass);
    }

    @Override
    public class_2338 getRenderPos(
            class_1799 stack,
            @Nullable class_1799 proxiedStack,
            class_3965 hit,
            class_1750 ctx,
            class_2680 hitState,
            class_2338 defaultPos,
            boolean secondPass
    )
    {
        if (proxiedStack == null)
        {
            return null;
        }
        return proxyBehaviour(proxiedStack).getRenderPos(proxiedStack, null, hit, ctx, hitState, defaultPos, secondPass);
    }

    @Override
    public boolean canRenderAt(
            class_1799 stack,
            @Nullable class_1799 proxiedStack,
            class_3965 hit,
            class_1750 ctx,
            class_2680 hitState,
            class_2680 renderState,
            class_2338 renderPos
    )
    {
        if (proxiedStack == null)
        {
            return false;
        }
        return proxyBehaviour(proxiedStack).canRenderAt(proxiedStack, null, hit, ctx, hitState, renderState, renderPos);
    }

    @Override
    public CamoPair readCamo(class_1799 stack, @Nullable class_1799 proxiedStack, boolean secondPass)
    {
        //noinspection ConstantConditions
        if (proxiedStack != null && stack.method_7985() && stack.method_7969().method_10545("blueprint_data"))
        {
            class_2487 tag = stack.method_7911("blueprint_data");
            Set<CamoContainer> camos = FramedBlueprintItem.getCamoContainers((class_1747) proxiedStack.method_7909(), tag);

            Iterator<CamoContainer> it = camos.iterator();
            class_2680 camoState = it.next().getState();
            class_2680 camoStateTwo = null;
            if (it.hasNext())
            {
                camoStateTwo = it.next().getState();
            }
            return new CamoPair(camoState, camoStateTwo);
        }
        return CamoPair.EMPTY;
    }

    @Override
    public CamoPair postProcessCamo(
            class_1799 stack,
            @Nullable class_1799 proxiedStack,
            class_1750 ctx,
            class_2680 renderState,
            boolean secondPass,
            CamoPair camo
    )
    {
        if (proxiedStack == null)
        {
            return CamoPair.EMPTY;
        }
        return proxyBehaviour(proxiedStack).postProcessCamo(proxiedStack, null, ctx, renderState, secondPass, camo);
    }

    @Override
    public ModelData appendModelData(
            class_1799 stack,
            @Nullable class_1799 proxiedStack,
            class_1750 ctx,
            class_2680 renderState,
            boolean secondPass,
            ModelData data
    )
    {
        if (proxiedStack == null)
        {
            return data;
        }
        return proxyBehaviour(proxiedStack).appendModelData(proxiedStack, null, ctx, renderState, secondPass, data);
    }

    private static GhostRenderBehaviour proxyBehaviour(class_1799 proxiedStack)
    {
        return GhostBlockRenderer.getBehaviour(proxiedStack.method_7909());
    }
}
