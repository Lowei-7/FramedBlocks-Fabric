package xfacthd.framedblocks.client.data.ghost;

import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import net.minecraftforge.client.model.data.ModelData;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.ghost.GhostRenderBehaviour;
import xfacthd.framedblocks.api.model.data.FramedBlockData;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.NullableDirection;

public final class CollapsibleBlockGhostRenderBehaviour implements GhostRenderBehaviour
{
    @Override
    @Nullable
    public class_2680 getRenderState(
            class_1799 stack,
            @Nullable class_1799 proxiedStack,
            class_3965 hit,
            class_1750 ctx,
            class_2680 hitState,
            boolean secondPass
    )
    {
        class_2680 state = GhostRenderBehaviour.super.getRenderState(stack, proxiedStack, hit, ctx, hitState, secondPass);
        //noinspection ConstantConditions
        if (state != null && stack.method_7985() && stack.method_7969().method_10545("BlockEntityTag"))
        {
            int faceIdx = stack.method_7969().method_10562("BlockEntityTag").method_10550("face");
            class_2350 face = faceIdx == -1 ? null : class_2350.method_10143(faceIdx);
            state = state.method_11657(PropertyHolder.NULLABLE_FACE, NullableDirection.fromDirection(face));
        }
        return state;
    }

    @Override
    public ModelData appendModelData(
            class_1799 stack,
            @Nullable class_1799 proxiedStack,
            class_1750 ctx,
            class_2680 renderState,
            boolean secondPass,
            ModelData data
    )
    {
        //noinspection ConstantConditions
        if (stack.method_7985() && stack.method_7969().method_10545("BlockEntityTag"))
        {
            int offsets = stack.method_7969().method_10562("BlockEntityTag").method_10550("offsets");
            FramedBlockData frame = data.get(FramedBlockData.PROPERTY);
            if (frame != null)
            {
                frame.setPackedOffsets(offsets);
            }
        }
        return data;
    }
}
