package xfacthd.framedblocks.client.render.util;

import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.client.model.FramedDoubleBlockModel;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1087;
import net.minecraft.class_1920;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_324;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5253;
import net.minecraft.class_5819;
import net.minecraft.class_777;

/**
 * Fabric renderer API has no concept of per-model render data like Forge's {@code ModelData}. Instead the framed
 * models read their render data from the {@code RenderAttachmentBlockEntity} at the rendered position. For special
 * renderers (ghost blocks, chest lids, debug outlines, ...) the data has to be injected manually by querying the
 * quads through the internal {@code getQuads(...)} overloads and writing them into the vertex consumer directly.
 */
public final class ModelRenderUtils
{
    private static final class_2350[] DIRECTIONS = class_2350.values();

    public static Set<class_1921> getRenderTypes(class_1087 model, class_2680 state, class_5819 random, Object data)
    {
        if (model instanceof FramedBlockModel fbm)
        {
            return fbm.getRenderTypes(state, random, data);
        }
        if (model instanceof FramedDoubleBlockModel fdm)
        {
            return fdm.getRenderTypes(state, random, data);
        }
        return Set.of(class_1921.method_23581());
    }

    public static void emitModelQuads(
            class_4587 poseStack,
            class_4588 consumer,
            class_2680 state,
            class_2338 pos,
            class_1920 level,
            class_5819 random,
            class_1087 model,
            Object data,
            int packedLight,
            int packedOverlay,
            class_1921 layer
    )
    {
        List<class_777> quads = new ArrayList<>();
        if (model instanceof FramedBlockModel fbm)
        {
            for (class_2350 dir : DIRECTIONS)
            {
                quads.addAll(fbm.getQuads(state, dir, random, data, layer));
            }
            quads.addAll(fbm.getQuads(state, null, random, data, layer));
        }
        else if (model instanceof FramedDoubleBlockModel fdm)
        {
            for (class_2350 dir : DIRECTIONS)
            {
                quads.addAll(fdm.getQuads(state, dir, random, data, layer));
            }
            quads.addAll(fdm.getQuads(state, null, random, data, layer));
        }
        else
        {
            for (class_2350 dir : DIRECTIONS)
            {
                quads.addAll(model.method_4707(state, dir, random));
            }
            quads.addAll(model.method_4707(state, null, random));
        }

        class_324 blockColors = class_310.method_1551().method_1505();
        class_4587.class_4665 pose = poseStack.method_23760();
        for (class_777 quad : quads)
        {
            float red = 1F, green = 1F, blue = 1F;
            if (quad.method_3360())
            {
                int tint = blockColors.method_1697(state, level, pos, quad.method_3359());
                red = class_5253.class_5254.method_27765(tint) / 255F;
                green = class_5253.class_5254.method_27766(tint) / 255F;
                blue = class_5253.class_5254.method_27767(tint) / 255F;
            }
            consumer.method_22919(pose, quad, red, green, blue, packedLight, packedOverlay);
        }
    }



    private ModelRenderUtils() { }
}
