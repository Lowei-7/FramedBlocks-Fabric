package xfacthd.framedblocks.client.render.item;

import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_5272;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;

public final class BlueprintPropertyOverride
{
    public static final class_2960 HAS_DATA = Utils.rl("blueprint_override");

    private BlueprintPropertyOverride() { }

    public static void register()
    {
        class_5272.method_27879(
                FBContent.ITEM_FRAMED_BLUEPRINT.get(),
                HAS_DATA,
                (stack, level, entity, seed) ->
                {
                    class_2487 tag = stack.method_7941("blueprint_data");
                    return tag != null && !tag.method_33133() ? 1 : 0;
                }
        );
    }
}