package xfacthd.framedblocks.client.screen;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.class_1087;
import net.minecraft.class_124;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_308;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3728;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5244;
import net.minecraft.class_5819;
import net.minecraft.class_765;
import net.minecraft.class_776;
import net.minecraft.class_7833;
import net.minecraft.class_8242;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.texture.*;
import net.minecraft.network.chat.*;
import net.minecraftforge.client.RenderTypeHelper;
import org.joml.Matrix4f;
import org.lwjgl.glfw.GLFW;
import xfacthd.framedblocks.FramedBlocks;
import xfacthd.framedblocks.api.render.Quaternions;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.client.render.util.ModelRenderUtils;
import xfacthd.framedblocks.common.block.sign.AbstractFramedSignBlock;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.net.SignUpdatePacket;
import xfacthd.framedblocks.common.blockentity.special.FramedSignBlockEntity;

import java.util.stream.IntStream;

public class FramedSignScreen extends class_437
{
    public static final class_2561 TITLE = Utils.translate("title", "sign.edit");

    private final AbstractFramedSignBlock signBlock;
    private final FramedSignBlockEntity sign;
    private final boolean front;
    private final int textYOffset;
    private class_8242 text;
    private final String[] lines;
    private int blinkCounter = 0;
    private int currLine = 0;
    private class_3728 inputUtil;

    public FramedSignScreen(FramedSignBlockEntity sign, boolean front)
    {
        super(TITLE);
        this.signBlock = (AbstractFramedSignBlock) sign.method_11010().method_26204();
        this.sign = sign;
        this.front = front;
        this.text = sign.getText(front);
        boolean filtered = class_310.method_1551().method_33883();
        this.lines = IntStream.range(0, 4)
                .mapToObj(idx -> text.method_49859(idx, filtered))
                .map(class_2561::getString)
                .toArray(String[]::new);
        this.textYOffset = switch ((BlockType) sign.getBlockType())
        {
            case FRAMED_SIGN -> 67;
            case FRAMED_WALL_SIGN -> 30;
            case FRAMED_HANGING_SIGN, FRAMED_WALL_HANGING_SIGN -> 6;
            default -> throw new IllegalArgumentException("Invalid block type: " + sign.getBlockType());
        };
    }

    @Override
    protected void method_25426()
    {
        method_37063(class_4185.method_46430(class_5244.field_24334, btn -> class_310.method_1551().method_1507(null))
                .method_46433(field_22789 / 2 - 100, field_22790 / 2 + 60)
                .method_46437(200, 20)
                .method_46431()
        );

        //noinspection ConstantConditions
        inputUtil = new class_3728(
                () -> lines[currLine],
                this::setLine,
                class_3728.method_27550(field_22787), class_3728.method_27561(field_22787),
                (line) -> field_22787.field_1772.method_1727(line) <= signBlock.getMaxTextLineWidth()
        );
    }

    private void setLine(String line)
    {
        lines[currLine] = line;
        text = text.method_49857(currLine, class_2561.method_43470(line));
        sign.setText(text, front);
    }

    @Override
    public void method_25432()
    {
        xfacthd.framedblocks.common.net.NetworkingHandler.sendSignUpdate(sign.method_11016(), front, lines);
    }

    @Override
    public void method_25393()
    {
        blinkCounter++;

        if (field_22787 != null && field_22787.field_1724 != null && !sign.method_11015() && sign.isTooFarAwayToEdit(field_22787.field_1724))
        {
            class_310.method_1551().method_1507(null);
        }
    }

    @Override
    public boolean method_25421()
    {
        return false;
    }

    @Override
    public boolean method_25400(char character, int modifiers)
    {
        inputUtil.method_16199(character);
        return true;
    }

    @Override
    public boolean method_25404(int key, int scanCode, int modifiers)
    {
        if (key == GLFW.GLFW_KEY_UP)
        {
            currLine = currLine - 1 & 3;
            inputUtil.method_16204();
            return true;
        }
        else if (key == GLFW.GLFW_KEY_DOWN || key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER)
        {
            currLine = currLine + 1 & 3;
            inputUtil.method_16204();
            return true;
        }
        else
        {
            return inputUtil.method_16202(key) || super.method_25404(key, scanCode, modifiers);
        }
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTicks)
    {
        class_308.method_34742();

        method_25420(graphics);
        //noinspection ConstantConditions
        graphics.method_27534(field_22793, field_22785, field_22789 / 2, 40, class_124.field_1068.method_532());

        drawSignBlock(graphics);

        drawText(graphics);

        class_308.method_24211();
        super.method_25394(graphics, mouseX, mouseY, partialTicks);
    }

    private void drawSignBlock(class_332 graphics)
    {
        class_2680 state = sign.method_11010();

        class_4587 poseStack = graphics.method_51448();
        poseStack.method_22903();
        poseStack.method_46416(field_22789 / 2F, field_22790 / 2F, 100);
        poseStack.method_22907(class_7833.field_40715.rotationDegrees(signBlock.getYRotationDegrees(state)));
        poseStack.method_22907(Quaternions.ZP_180);
        poseStack.method_22905(112, 112, 112);
        poseStack.method_22904(-.5, -.25, -.5);

        //noinspection ConstantConditions
        class_776 renderer = field_22787.method_1541();
        class_4597.class_4598 buffer = graphics.method_51450();
        class_1087 model = renderer.method_3349(state);
        Object modelData = sign.getRenderAttachmentData();

        for (class_1921 renderType : xfacthd.framedblocks.client.render.util.ModelRenderUtils.getRenderTypes(
                model, state, class_5819.method_43049(42), modelData
        ))
        {
            class_4588 consumer = buffer.getBuffer(RenderTypeHelper.getEntityRenderType(renderType, false));
            xfacthd.framedblocks.client.render.util.ModelRenderUtils.emitModelQuads(
                    poseStack,
                    consumer,
                    state,
                    sign.method_11016(),
                    field_22787.field_1687,
                    class_5819.method_43049(42),
                    model,
                    modelData,
                    class_765.field_32767,
                    class_4608.field_21444,
                    renderType
            );
        }

        buffer.method_22993();
        poseStack.method_22909();
    }

    private void drawText(class_332 graphics)
    {
        graphics.method_51448().method_22903();
        graphics.method_51448().method_22904(field_22789 / 2D, field_22790 / 2D - textYOffset, 110);
        graphics.method_51448().method_22905(1.2F, 1.2F, 1F);

        //noinspection ConstantConditions
        class_4597.class_4598 buffer = field_22787.method_22940().method_23000();

        drawLines(graphics.method_51448().method_23760().method_23761(), buffer, lines);
        drawCursor(graphics, buffer, lines);

        graphics.method_51448().method_22909();
    }

    private void drawLines(Matrix4f matrix, class_4597.class_4598 buffer, String[] lines)
    {
        int color = text.method_49872().method_16357();

        for(int line = 0; line < lines.length; line++)
        {
            String text = lines[line];
            if (text != null)
            {
                if (field_22793.method_1726()) { text = field_22793.method_1721(text); }

                float textX = -field_22793.method_1727(text) / 2F;
                field_22793.method_27521(text, textX, line * 10 - 20, color, false, matrix, buffer, class_327.class_6415.field_33993, 0, 0xF000F0);
            }
        }

        buffer.method_22993();
    }

    private void drawCursor(class_332 graphics, class_4597.class_4598 buffer, String[] lines)
    {
        Matrix4f matrix = graphics.method_51448().method_23760().method_23761();
        int color = text.method_49872().method_16357();
        boolean blink = blinkCounter / 6 % 2 == 0;
        int dir = field_22793.method_1726() ? -1 : 1;
        int y = currLine * 10 - 20;

        for(int i = 0; i < lines.length; ++i)
        {
            String line = lines[i];
            if (line != null && i == currLine && inputUtil.method_16201() >= 0)
            {
                int hw = field_22793.method_1727(line) / 2;
                int selectionEnd = field_22793.method_1727(line.substring(0, Math.max(Math.min(inputUtil.method_16201(), line.length()), 0)));
                int cursorX = (selectionEnd - hw) * dir;

                if (blink)
                {
                    if (inputUtil.method_16201() < line.length())
                    {
                        graphics.method_25294(cursorX, y - 1, cursorX + 1, y + 9, 0xFF000000 | color);
                    }
                    else
                    {
                        field_22793.method_27521("_", cursorX, y, color, false, matrix, buffer, class_327.class_6415.field_33993, 0, 0xF000F0);
                        buffer.method_22993();
                    }
                }

                if (inputUtil.method_16203() != inputUtil.method_16201())
                {
                    int x1 = (field_22793.method_1727(line.substring(0, inputUtil.method_16203())) - hw) * dir;
                    int x2 =   (field_22793.method_1727(line.substring(0, inputUtil.method_16201()  )) - hw) * dir;
                    int xStart = Math.min(x1, x2);
                    int xEnd = Math.max(x1, x2);

                    class_289 tessellator = class_289.method_1348();
                    class_287 tessBuffer = tessellator.method_1349();

                    RenderSystem.enableColorLogicOp();
                    RenderSystem.logicOp(GlStateManager.class_1030.field_5110);

                    tessBuffer.method_1328(class_293.class_5596.field_27382, class_290.field_1576);
                    tessBuffer.method_22918(matrix, xStart, y + 9F, 0.0F).method_1336(0, 0, 255, 255).method_1344();
                    tessBuffer.method_22918(matrix,   xEnd, y + 9F, 0.0F).method_1336(0, 0, 255, 255).method_1344();
                    tessBuffer.method_22918(matrix,   xEnd, y - 1F, 0.0F).method_1336(0, 0, 255, 255).method_1344();
                    tessBuffer.method_22918(matrix, xStart, y - 1F, 0.0F).method_1336(0, 0, 255, 255).method_1344();
                    class_286.method_43433(tessBuffer.method_1326());

                    RenderSystem.disableColorLogicOp();
                }
            }
        }
    }
}