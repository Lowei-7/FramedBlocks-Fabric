package xfacthd.framedblocks.client.screen;

import net.minecraft.class_1041;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_312;
import net.minecraft.class_332;
import net.minecraft.class_465;
import net.minecraft.class_5250;
import net.minecraft.class_5632;
import net.minecraft.class_768;
import net.minecraft.network.chat.*;
import xfacthd.framedblocks.FramedBlocks;
import xfacthd.framedblocks.api.util.ClientUtils;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.client.util.RecipeViewer;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.blockentity.special.PoweredFramingSawBlockEntity;
import xfacthd.framedblocks.common.crafting.*;
import xfacthd.framedblocks.common.menu.FramingSawMenu;
import xfacthd.framedblocks.common.menu.PoweredFramingSawMenu;
import xfacthd.framedblocks.common.net.SelectFramingSawRecipePacket;
import xfacthd.framedblocks.common.net.NetworkingHandler;

import java.util.*;

public class PoweredFramingSawScreen extends class_465<PoweredFramingSawMenu>
{
    private static final class_2960 BACKGROUND = Utils.rl("textures/gui/powered_framing_saw.png");
    public static final class_2561 TITLE_TARGETBLOCK = Utils.translate("title", "powered_saw.target_block");
    public static final class_5250 MSG_STATUS = Utils.translate("msg", "powered_saw.status");
    public static final class_2561 MSG_STATUS_NO_RECIPE = Utils.translate("msg", "powered_saw.status.no_recipe")
            .method_27696(class_2583.field_24360.method_36139(0xDD7700));
    public static final class_2561 MSG_STATUS_NO_MATCH = Utils.translate("msg", "powered_saw.status.no_match")
            .method_27696(class_2583.field_24360.method_36139(0xDD0000));
    public static final class_2561 MSG_STATUS_READY = Utils.translate("msg", "powered_saw.status.ready")
            .method_27696(class_2583.field_24360.method_36139(0x00DD00));
    public static final class_2561 TOOLTIP_STATUS_NO_RECIPE = Utils.translate("tooltip", "powered_saw.status.no_recipe");
    public static final String TOOLTIP_ENERGY = Utils.translationKey("tooltip", "powered_saw.energy");
    private static final int TITLE_TARGETBLOCK_X = 88;
    private static final int TITLE_TARGETBLOCK_Y = 24;
    private static final int TARGET_STACK_X = 92;
    private static final int TARGET_STACK_Y = 20;
    private static final int STATUS_X = 8;
    private static final int STATUS_Y = 62;
    private static final int ENERGY_X = 8;
    private static final int ENERGY_Y = 18;
    private static final int ENERGY_WIDTH = 14;
    private static final int ENERGY_HEIGHT = 48;
    private static final int ENERGY_U = 176;
    private static final int ENERGY_V = 16;
    public static final int PROGRESS_X = 115;
    public static final int PROGRESS_Y = 46;
    public static final int PROGRESS_WIDTH = 22;
    public static final int PROGRESS_HEIGHT = 16;
    private static final int PROGRESS_U = 176;
    private static final int PROGRESS_V = 0;
    private static final int CROSS_SIZE = 16;
    private static final int CROSS_U = 176;
    private static final int CROSS_V = 64;
    private static final class_768 EMPTY = new class_768(0, 0, 0, 0);
    private static final RecipeViewer RECIPE_VIEWER = RecipeViewer.get();

    private final FramingSawRecipeCache cache = FramingSawRecipeCache.get(true);
    private final class_1799 cubeStack = new class_1799(FBContent.BLOCK_FRAMED_CUBE.get());
    private int targetStackX;
    private int targetStackY;
    private class_768 statusTooltipArea = EMPTY;
    private List<class_2561> statusTooltip = List.of();

    public PoweredFramingSawScreen(PoweredFramingSawMenu menu, class_1661 inv, class_2561 title)
    {
        super(menu, inv, title);
        field_2779 = 182;
        field_25270 = field_2779 - 94;
    }

    @Override
    protected void method_25426()
    {
        super.method_25426();

        targetStackX = field_2776 + TARGET_STACK_X;
        targetStackY = field_2800 + TARGET_STACK_Y;
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick)
    {
        super.method_25394(graphics, mouseX, mouseY, partialTick);
        method_2380(graphics, mouseX, mouseY);
    }

    @Override
    protected void method_2389(class_332 graphics, float partialTick, int mouseX, int mouseY)
    {
        method_25420(graphics);

        graphics.method_25302(BACKGROUND, field_2776, field_2800, 0, 0, field_2792, field_2779);

        int tx = field_2776 + TITLE_TARGETBLOCK_X - field_22793.method_27525(TITLE_TARGETBLOCK);
        int ty = field_2800 + TITLE_TARGETBLOCK_Y;
        graphics.method_51439(field_22793, TITLE_TARGETBLOCK, tx, ty, 0x404040, false);

        FramingSawRecipe recipe = field_2797.getSelectedRecipe();
        FramingSawRecipeMatchResult match = field_2797.getMatchResult();

        drawRecipeInfo(graphics, recipe, match);
        drawStatus(graphics, recipe, match);
        drawEnergyBar(graphics, mouseX, mouseY);
    }

    private void drawRecipeInfo(class_332 graphics, FramingSawRecipe recipe, FramingSawRecipeMatchResult match)
    {
        class_1735 inputSlot = field_2797.method_7611(FramingSawMenu.SLOT_INPUT);
        if (!inputSlot.method_7681())
        {
            int ix = field_2776 + inputSlot.field_7873;
            int iy = field_2800 + inputSlot.field_7872;
            ClientUtils.renderTransparentFakeItem(graphics, cubeStack, ix, iy);
        }

        if (recipe != null)
        {
            class_1799 result = recipe.getResult();
            ClientUtils.renderTransparentFakeItem(graphics, result, targetStackX, targetStackY);

            List<FramingSawRecipeAdditive> additives = recipe.getAdditives();
            for (int i = 0; i < FramingSawRecipe.MAX_ADDITIVE_COUNT; i++)
            {
                class_1735 additiveSlot = field_2797.method_7611(FramingSawMenu.SLOT_ADDITIVE_FIRST + i);
                if (i >= additives.size())
                {
                    int ax = field_2776 + additiveSlot.field_7873;
                    int ay = field_2800 + additiveSlot.field_7872;
                    graphics.method_25302(BACKGROUND, ax, ay, CROSS_U, CROSS_V, CROSS_SIZE, CROSS_SIZE);
                }
                else if (!additiveSlot.method_7681())
                {
                    class_1799[] items = additives.get(i).ingredient().method_8105();
                    if (items.length == 0)
                    {
                        // Additive ingredient resolves to no items on this side; nothing to display
                        continue;
                    }
                    int t = (int) (System.currentTimeMillis() / 1700) % items.length;
                    int ax = field_2776 + additiveSlot.field_7873;
                    int ay = field_2800 + additiveSlot.field_7872;
                    ClientUtils.renderTransparentFakeItem(graphics, items[t], ax, ay);
                }
            }

            if (match != null && match.success())
            {
                float progress = (float) field_2797.getProgress() / (float) PoweredFramingSawBlockEntity.MAX_PROGRESS;
                if (progress > 0F)
                {
                    int width = Math.round(PROGRESS_WIDTH * progress);
                    graphics.method_25302(BACKGROUND, field_2776 + PROGRESS_X, field_2800 + PROGRESS_Y, PROGRESS_U, PROGRESS_V, width, PROGRESS_HEIGHT);
                }
            }
        }
    }

    private void drawStatus(class_332 graphics, FramingSawRecipe recipe, FramingSawRecipeMatchResult match)
    {
        class_5250 status = MSG_STATUS.method_27661();
        int width = -1;
        if (recipe == null)
        {
            status = status.method_10852(MSG_STATUS_NO_RECIPE);
            statusTooltip = List.of(TOOLTIP_STATUS_NO_RECIPE);
            width = field_22793.method_27525(MSG_STATUS_NO_RECIPE);
        }
        else if (match != null && !match.success())
        {
            status = status.method_10852(MSG_STATUS_NO_MATCH);
            statusTooltip = FramingSawScreen.appendRecipeFailure(new ArrayList<>(), cache, field_2797.getSelectedRecipe(), match, field_2797);
            width = field_22793.method_27525(MSG_STATUS_NO_MATCH);
        }
        else
        {
            status = status.method_10852(MSG_STATUS_READY);
        }
        int sx = field_2776 + STATUS_X;
        int sy = field_2800 + STATUS_Y + field_22793.field_2000;
        graphics.method_51439(field_22793, status, sx, sy, 0x404040, false);
        statusTooltipArea = width == -1 ? EMPTY : new class_768(sx + field_22793.method_27525(MSG_STATUS), sy, width, field_22793.field_2000);
    }

    private void drawEnergyBar(class_332 graphics, int mouseX, int mouseY)
    {
        float energy = (float) field_2797.getEnergy() / (float) PoweredFramingSawBlockEntity.ENERGY_CAPACITY;
        int height = (int) (energy * ENERGY_HEIGHT);
        int y = field_2800 + ENERGY_Y + (ENERGY_HEIGHT - height);
        graphics.method_25302(BACKGROUND, field_2776 + ENERGY_X, y, ENERGY_U, ENERGY_V + (ENERGY_HEIGHT - height), ENERGY_WIDTH, height);

        int minX = field_2776 + ENERGY_X;
        int minY = field_2800 + ENERGY_Y;
        if (mouseX >= minX && mouseX < minX + ENERGY_WIDTH && mouseY >= minY && mouseY < minY + ENERGY_HEIGHT)
        {
            method_47415(class_2561.method_43469(
                    TOOLTIP_ENERGY, field_2797.getEnergy(), PoweredFramingSawBlockEntity.ENERGY_CAPACITY
            ));
        }
    }

    @Override
    protected void method_2380(class_332 graphics, int mouseX, int mouseY)
    {
        if (field_2797.method_34255().method_7960() && field_2787 != null && field_2787.method_7681())
        {
            renderHoveredItemTooltip(graphics, mouseX, mouseY, field_2787.method_7677());
            return;
        }

        if (statusTooltipArea.method_3318(mouseX, mouseY))
        {
            graphics.method_51437(field_22793, statusTooltip, Optional.empty(), mouseX, mouseY);
            statusTooltipArea = EMPTY;
            statusTooltip = List.of();
        }
    }

    private void renderHoveredItemTooltip(class_332 graphics, int mouseX, int mouseY, class_1799 stack)
    {
        //noinspection ConstantConditions
        List<class_2561> components = new ArrayList<>(method_25408(field_22787, stack));
        Optional<class_5632> tooltip = stack.method_32347();

        int material = cache.getMaterialValue(stack.method_7909());
        if (material > 0)
        {
            components.add(class_2561.method_43469(FramingSawScreen.TOOLTIP_MATERIAL, material));
        }

        graphics.method_51437(field_22793, components, tooltip, mouseX, mouseY);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int btn)
    {
        if (mouseX >= targetStackX && mouseX < targetStackX + 18 && mouseY >= targetStackY && mouseY < targetStackY + 18)
        {
            selectRecipe(field_2797.method_34255());
            return true;
        }
        return super.method_25402(mouseX, mouseY, btn);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers)
    {
        RecipeViewer.LookupTarget target;
        if (RECIPE_VIEWER != null && (target = RECIPE_VIEWER.isShowRecipePressed(keyCode, scanCode)) != null)
        {
            class_1041 window = Objects.requireNonNull(field_22787).method_22683();
            class_312 mouseHandler = field_22787.field_1729;
            double mouseX = mouseHandler.method_1603() * (double) window.method_4486() / (double) window.method_4480();
            double mouseY = mouseHandler.method_1604() * (double) window.method_4502() / (double) window.method_4507();

            FramingSawRecipe recipe = field_2797.getSelectedRecipe();
            if (recipe != null && isMouseOverRecipeSlot(mouseX, mouseY) && RECIPE_VIEWER.handleShowRecipeRequest(recipe.getResult(), target))
            {
                return true;
            }
        }

        return super.method_25404(keyCode, scanCode, modifiers);
    }

    public boolean isMouseOverRecipeSlot(double mouseX, double mouseY)
    {
        return mouseX >= targetStackX && mouseX < targetStackX + 18 && mouseY >= targetStackY && mouseY < targetStackY + 18;
    }

    public void selectRecipe(class_1799 cursorStack)
    {
        if (cursorStack.method_7960() || cache.getMaterialValue(cursorStack.method_7909()) != -1)
        {
            FramingSawRecipe recipe = cache.findRecipeFor(cursorStack);
            if (recipe == field_2797.getSelectedRecipe())
            {
                return;
            }

            int id = recipe == null ? -1 : cache.getRecipes().indexOf(recipe);
            //noinspection ConstantConditions
            if (field_2797.method_7604(field_22787.field_1724, id))
            {
                NetworkingHandler.sendSelectFramingSawRecipe(field_2797.field_7763, id);
            }
        }
    }

    public int getTargetStackX()
    {
        return targetStackX;
    }

    public int getTargetStackY()
    {
        return targetStackY;
    }
}
