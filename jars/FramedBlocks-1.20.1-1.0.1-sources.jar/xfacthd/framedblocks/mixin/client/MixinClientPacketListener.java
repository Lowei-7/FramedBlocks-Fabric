package xfacthd.framedblocks.mixin.client;

import net.minecraft.class_2487;
import net.minecraft.class_2535;
import net.minecraft.class_2586;
import net.minecraft.class_2622;
import net.minecraft.class_2788;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import xfacthd.framedblocks.api.block.FramedBlockEntity;
import xfacthd.framedblocks.common.crafting.FramingSawRecipeCache;

@Mixin(class_634.class)
public abstract class MixinClientPacketListener
{
    @Inject(method = "handleUpdateRecipes", at = @At("RETURN"))
    private void framedblocks$onRecipesUpdated(class_2788 packet, CallbackInfo ci)
    {
        class_634 self = (class_634) (Object) this;
        FramingSawRecipeCache.get(true).update(self.method_2877());
    }

    @Redirect(
            method = "method_38542",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/level/block/entity/BlockEntity;load(Lnet/minecraft/nbt/CompoundTag;)V"
            )
    )
    private void framedblocks$redirectLoad(class_2586 blockEntity, class_2487 tag, class_2622 packet)
    {
        if (blockEntity instanceof FramedBlockEntity framedBe)
        {
            class_2535 conn = ((class_634) (Object) this).method_48296();
            framedBe.onDataPacket(conn, packet);
        }
        else
        {
            blockEntity.method_11014(tag);
        }
    }
}