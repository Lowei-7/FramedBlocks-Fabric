package xfacthd.framedblocks.common.block.pillar;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2544;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_4778;
import net.minecraft.class_8567;
import net.minecraft.world.level.*;
import net.minecraft.world.phys.shapes.*;
import net.fabricmc.loader.api.FabricLoader;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.block.IFramedBlock;
import xfacthd.framedblocks.api.shapes.*;
import xfacthd.framedblocks.common.data.BlockType;

import javax.annotation.Nullable;
import java.util.List;
import java.util.Map;

@SuppressWarnings("deprecation")
public class FramedWallBlock extends class_2544 implements IFramedBlock
{
    private final ShapeProvider shapes = makeShapeProvider(states -> generateShapes(states, 14F, 16F));
    private final ShapeProvider collisionShapes = makeShapeProvider(states -> generateShapes(states, 24F, 24F));

    public FramedWallBlock()
    {
        super(IFramedBlock.createProperties(BlockType.FRAMED_WALL));
        method_9590(method_9564()
                .method_11657(FramedProperties.STATE_LOCKED, false)
                .method_11657(FramedProperties.GLOWING, false)
                .method_11657(FramedProperties.PROPAGATES_SKYLIGHT, false)
        );
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(FramedProperties.STATE_LOCKED, FramedProperties.GLOWING, FramedProperties.PROPAGATES_SKYLIGHT);
    }

    @Override
    public final class_1269 method_9534(
            class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit
    )
    {
        return handleUse(state, level, pos, player, hand, hit);
    }

    @Override
    public void method_9567(class_1937 level, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 stack)
    {
        tryApplyCamoImmediately(level, pos, placer, stack);
    }

    @Override
    public class_2680 method_9559(
            class_2680 state,
            class_2350 facing,
            class_2680 facingState,
            class_1936 level,
            class_2338 currentPos,
            class_2338 facingPos
    )
    {
        class_2680 newState = updateShapeLockable(
                state, level, currentPos,
                () -> super.method_9559(state, facing, facingState, level, currentPos, facingPos)
        );

        if (newState == state)
        {
            updateCulling(level, currentPos);
        }
        return newState;
    }

    @Override
    public void method_9612(
            class_2680 state, class_1937 level, class_2338 pos, class_2248 block, class_2338 fromPos, boolean isMoving
    )
    {
        updateCulling(level, pos);
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 ctx)
    {
        return shapes.get(state);
    }

    @Override
    public class_265 method_9549(class_2680 state, class_1922 level, class_2338 pos, class_3726 ctx)
    {
        return collisionShapes.get(state);
    }

    @Override
    public float method_9575(class_2680 state, class_1922 level, class_2338 pos)
    {
        return getCamoShadeBrightness(state, level, pos, super.method_9575(state, level, pos));
    }

    @Override
    public boolean method_9579(class_2680 state, class_1922 level, class_2338 pos)
    {
        return state.method_11654(FramedProperties.PROPAGATES_SKYLIGHT);
    }

    @Override
    public List<class_1799> method_9560(class_2680 state, class_8567.class_8568 builder)
    {
        return getCamoDrops(super.method_9560(state, builder), builder);
    }

    @Override
    public boolean doesBlockOccludeBeaconBeam(class_2680 state, class_4538 level, class_2338 pos)
    {
        return true;
    }

    @Override
    public BlockType getBlockType()
    {
        return BlockType.FRAMED_WALL;
    }

    protected Map<class_2680, class_265> method_24420(float pWidth, float pDepth, float pWallPostHeight, float pWallMinY, float pWallLowHeight, float pWallTallHeight)
    {
        // Effectively NO-OP to conserve memory, the shape building is taken over below
        return Map.of();
    }

    private ShapeProvider makeShapeProvider(ShapeGenerator generator)
    {
        ImmutableList<class_2680> states = field_10647.method_11662();
        if (FabricLoader.getInstance().isDevelopmentEnvironment())
        {
            return new ReloadableShapeProvider(generator, states);
        }
        return generator.generate(states);
    }



    private static ShapeProvider generateShapes(
            ImmutableList<class_2680> states,
            float lowHeight,
            float tallHeight
    )
    {
        boolean sameHeight = lowHeight == tallHeight;

        class_265 centerLowShape = method_9541(5F, 0F, 5F, 11F, lowHeight, 11F);
        class_265 centerTallShape = sameHeight ? centerLowShape : method_9541(5F, 0F, 5F, 11F, tallHeight, 11F);
        class_265 postShape = method_9541(4F, 0F, 4F, 12F, tallHeight, 12F);
        class_265 wallLowShape = method_9541(5F, 0F, 0F, 11F, lowHeight, 5F);
        class_265 wallTallShape = sameHeight ? wallLowShape : method_9541(5F, 0F, 0F, 11F, tallHeight, 5F);

        class_265[] wallLowShapes = ShapeUtils.makeHorizontalRotations(wallLowShape, class_2350.field_11043);
        class_265[] wallTallShapes = sameHeight ? wallLowShapes : ShapeUtils.makeHorizontalRotations(wallTallShape, class_2350.field_11043);

        class_265[] shapes = new class_265[512];
        for (class_4778 north : field_22157.method_11898())
        {
            for (class_4778 east : field_22156.method_11898())
            {
                for (class_4778 south : field_22158.method_11898())
                {
                    for (class_4778 west : field_22159.method_11898())
                    {
                        int noUpKey = makeShapeKey(false, north, east, south, west);
                        int upKey = makeShapeKey(true, north, east, south, west);

                        boolean anyTall = north == class_4778.field_22180 || east == class_4778.field_22180 || south == class_4778.field_22180 || west == class_4778.field_22180;
                        shapes[noUpKey] = ShapeUtils.or(
                                anyTall ? centerTallShape : centerLowShape,
                                getWallShape(north, class_2350.field_11043, wallLowShapes, wallTallShapes),
                                getWallShape(east, class_2350.field_11034, wallLowShapes, wallTallShapes),
                                getWallShape(south, class_2350.field_11035, wallLowShapes, wallTallShapes),
                                getWallShape(west, class_2350.field_11039, wallLowShapes, wallTallShapes)
                        );

                        shapes[upKey] = ShapeUtils.or(
                                postShape,
                                getWallShape(north, class_2350.field_11043, wallLowShapes, wallTallShapes),
                                getWallShape(east, class_2350.field_11034, wallLowShapes, wallTallShapes),
                                getWallShape(south, class_2350.field_11035, wallLowShapes, wallTallShapes),
                                getWallShape(west, class_2350.field_11039, wallLowShapes, wallTallShapes)
                        );
                    }
                }
            }
        }
        shapes[0] = class_259.method_1077();

        ImmutableMap.Builder<class_2680, class_265> builder = ImmutableMap.builder();
        for (class_2680 state : states)
        {
            int key = makeShapeKey(
                    state.method_11654(field_11717),
                    state.method_11654(field_22157),
                    state.method_11654(field_22156),
                    state.method_11654(field_22158),
                    state.method_11654(field_22159)
            );
            builder.put(state, shapes[key]);
        }
        return ShapeProvider.of(builder.build());
    }

    private static class_265 getWallShape(class_4778 side, class_2350 dir, class_265[] lowShapes, class_265[] tallShapes)
    {
        return switch (side)
        {
            case field_22178 -> class_259.method_1073();
            case field_22179 -> lowShapes[dir.method_10161()];
            case field_22180 -> tallShapes[dir.method_10161()];
        };
    }

    private static int makeShapeKey(boolean up, class_4778 north, class_4778 east, class_4778 south, class_4778 west)
    {
        return ((up ? 1 : 0) << 8) | (north.ordinal() << 6) | (east.ordinal() << 4) | (south.ordinal() << 2) | west.ordinal();
    }
}