package xfacthd.framedblocks.common.block.slab;

import net.minecraft.class_10;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2470;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_3419;
import net.minecraft.class_3486;
import net.minecraft.class_3965;
import net.minecraft.world.level.block.*;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.block.PlacementStateBuilder;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.FramedBlock;
import xfacthd.framedblocks.common.data.BlockType;

@SuppressWarnings("deprecation")
public class FramedSlabBlock extends FramedBlock
{
    public FramedSlabBlock()
    {
        super(BlockType.FRAMED_SLAB);
        method_9590(method_9564().method_11657(FramedProperties.TOP, false));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(FramedProperties.TOP, class_2741.field_12508, FramedProperties.SOLID);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return PlacementStateBuilder.of(this, ctx)
                .withTop()
                .withWater()
                .build();
    }

    @Override
    public class_1269 method_9534(
            class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit
    )
    {
        class_1799 stack = player.method_5998(hand);
        if (stack.method_7909() == FBContent.BLOCK_FRAMED_SLAB.get().method_8389())
        {
            boolean top = state.method_11654(FramedProperties.TOP);
            class_2350 face = hit.method_17780();
            if ((face == class_2350.field_11036 && !top) || (face == class_2350.field_11033 && top))
            {
                if (!level.method_8608())
                {
                    Utils.wrapInStateCopy(level, pos, player, stack, top, true, () ->
                            level.method_8501(pos, FBContent.BLOCK_FRAMED_DOUBLE_SLAB.get().method_9564())
                    );

                    class_2498 sound = FBContent.BLOCK_FRAMED_CUBE.get().method_9573(FBContent.BLOCK_FRAMED_CUBE.get().method_9564());
                    level.method_8396(null, pos, sound.method_10598(), class_3419.field_15245, (sound.method_10597() + 1.0F) / 2.0F, sound.method_10599() * 0.8F);
                }
                return class_1269.method_29236(level.method_8608());
            }
        }
        return super.method_9534(state, level, pos, player, hand, hit);
    }

    @Override
    public boolean method_9516(class_2680 state, class_1922 level, class_2338 pos, class_10 type)
    {
        return type == class_10.field_48 && level.method_8316(pos).method_15767(class_3486.field_15517);
    }

    @Override
    public class_2680 rotate(class_2680 state, class_2350 side, class_2470 rot)
    {
        if (rot != class_2470.field_11467)
        {
            return state.method_28493(FramedProperties.TOP);
        }
        return state;
    }
}