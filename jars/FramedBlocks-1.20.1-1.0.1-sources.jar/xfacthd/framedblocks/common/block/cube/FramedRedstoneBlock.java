package xfacthd.framedblocks.common.block.cube;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2436;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_8567;
import net.minecraft.world.level.*;
import net.minecraft.world.phys.shapes.*;
import net.minecraftforge.client.extensions.common.IClientBlockExtensions;
import net.minecraftforge.common.IPlantable;
import xfacthd.framedblocks.api.block.*;
import xfacthd.framedblocks.api.block.render.FramedBlockRenderProperties;
import xfacthd.framedblocks.api.type.IBlockType;
import xfacthd.framedblocks.common.data.BlockType;

import javax.annotation.Nullable;
import java.util.List;
import java.util.function.Consumer;

@SuppressWarnings("deprecation")
public class FramedRedstoneBlock extends class_2436 implements IFramedBlock
{
    public FramedRedstoneBlock()
    {
        super(IFramedBlock.createProperties(BlockType.FRAMED_REDSTONE_BLOCK));
        method_9590(method_9564()
                .method_11657(FramedProperties.SOLID, true)
                .method_11657(FramedProperties.GLOWING, false)
                .method_11657(FramedProperties.PROPAGATES_SKYLIGHT, false)
        );
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        builder.method_11667(FramedProperties.SOLID, FramedProperties.GLOWING, FramedProperties.PROPAGATES_SKYLIGHT);
    }

    @Override
    public final class_1269 method_9534(
            class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit
    )
    {
        return handleUse(state, level, pos, player, hand, hit);
    }

    @Override
    public void method_9567(class_1937 level, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 stack)
    {
        tryApplyCamoImmediately(level, pos, placer, stack);
    }

    @Override
    public class_2680 method_9559(
            class_2680 state,
            class_2350 direction,
            class_2680 neighborState,
            class_1936 level,
            class_2338 currentPos,
            class_2338 neighborPos
    )
    {
        updateCulling(level, currentPos);
        return super.method_9559(state, direction, neighborState, level, currentPos, neighborPos);
    }

    @Override
    public void method_9612(
            class_2680 state, class_1937 level, class_2338 pos, class_2248 block, class_2338 fromPos, boolean isMoving
    )
    {
        updateCulling(level, pos);
    }

    @Override
    public boolean method_9526(class_2680 state)
    {
        return useCamoOcclusionShapeForLightOcclusion(state);
    }

    @Override
    public class_265 method_9571(class_2680 state, class_1922 level, class_2338 pos)
    {
        return getCamoOcclusionShape(state, level, pos, null);
    }

    @Override
    public class_265 method_26159(class_2680 state, class_1922 level, class_2338 pos, class_3726 ctx)
    {
        return getCamoVisualShape(state, level, pos, ctx);
    }

    @Override
    public float method_9575(class_2680 state, class_1922 level, class_2338 pos)
    {
        return getCamoShadeBrightness(state, level, pos, super.method_9575(state, level, pos));
    }

    @Override
    public boolean method_9579(class_2680 state, class_1922 level, class_2338 pos)
    {
        return state.method_11654(FramedProperties.PROPAGATES_SKYLIGHT);
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 ctx)
    {
        if (isIntangible(state, level, pos, ctx))
        {
            return class_259.method_1073();
        }
        return super.method_9530(state, level, pos, ctx);
    }

    @Override
    public List<class_1799> method_9560(class_2680 state, class_8567.class_8568 builder)
    {
        return getCamoDrops(super.method_9560(state, builder), builder);
    }

    public boolean canSustainPlant(class_2680 state, class_1922 level, class_2338 pos, class_2350 side, IPlantable plant)
    {
        return canCamoSustainPlant(state, level, pos, side, plant);
    }

    @Override
    public boolean doesBlockOccludeBeaconBeam(class_2680 state, class_4538 level, class_2338 pos)
    {
        return true;
    }

    public void initializeClient(Consumer<IClientBlockExtensions> consumer)
    {
        consumer.accept(FramedBlockRenderProperties.INSTANCE);
    }

    @Override
    public IBlockType getBlockType()
    {
        return BlockType.FRAMED_REDSTONE_BLOCK;
    }
}
