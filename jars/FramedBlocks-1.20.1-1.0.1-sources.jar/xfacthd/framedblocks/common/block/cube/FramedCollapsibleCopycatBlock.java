package xfacthd.framedblocks.common.block.cube;

import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import net.minecraft.world.level.*;
import net.minecraft.world.phys.shapes.*;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.block.IFramedBlock;
import xfacthd.framedblocks.api.block.PlacementStateBuilder;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.FramedBlock;
import xfacthd.framedblocks.common.blockentity.special.FramedCollapsibleCopycatBlockEntity;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.data.PropertyHolder;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class FramedCollapsibleCopycatBlock extends FramedBlock
{
    private static final int UP = class_2350.field_11036.ordinal();
    private static final int DOWN = class_2350.field_11033.ordinal();
    private static final int NORTH = class_2350.field_11043.ordinal();
    private static final int EAST = class_2350.field_11034.ordinal();
    private static final int SOUTH = class_2350.field_11035.ordinal();
    private static final int WEST = class_2350.field_11039.ordinal();
    private static final Map<Integer, class_265> SHAPE_CACHE = new ConcurrentHashMap<>();
    public static final int ALL_SOLID = 0b00111111;

    public FramedCollapsibleCopycatBlock()
    {
        super(BlockType.FRAMED_COLLAPSIBLE_COPYCAT_BLOCK, IFramedBlock.createProperties(BlockType.FRAMED_COLLAPSIBLE_COPYCAT_BLOCK).method_9624());
        method_9590(method_9564().method_11657(PropertyHolder.SOLID_FACES, ALL_SOLID));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(PropertyHolder.SOLID_FACES, class_2741.field_12508);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return PlacementStateBuilder.of(this, ctx).withWater().build();
    }

    @Override
    public boolean handleBlockLeftClick(class_2680 state, class_1937 level, class_2338 pos, class_1657 player)
    {
        if (player.method_6047().method_7909() == FBContent.ITEM_FRAMED_HAMMER.get())
        {
            if (level.method_8321(pos) instanceof FramedCollapsibleCopycatBlockEntity be)
            {
                if (!level.method_8608())
                {
                    be.handleDeform(player);
                }
                return true;
            }
        }
        return false;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 ctx)
    {
        if (isIntangible(state, level, pos, ctx))
        {
            return class_259.method_1073();
        }

        int solid = state.method_11654(PropertyHolder.SOLID_FACES);
        if (solid != ALL_SOLID && level.method_8321(pos) instanceof FramedCollapsibleCopycatBlockEntity be)
        {
            return SHAPE_CACHE.computeIfAbsent(be.getPackedOffsets(state), key ->
            {
                byte[] offsets = FramedCollapsibleCopycatBlockEntity.unpackOffsets(key);
                return method_9541(
                        offsets[WEST],
                        offsets[DOWN],
                        offsets[NORTH],
                        16 - offsets[EAST],
                        16 - offsets[UP],
                        16 - offsets[SOUTH]
                );
            });
        }
        return class_259.method_1077();
    }

    @Override
    public class_265 method_9571(class_2680 state, class_1922 level, class_2338 pos)
    {
        return getCamoOcclusionShape(state, level, pos, null);
    }

    @Override
    public void method_9567(class_1937 level, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 stack)
    {
        super.method_9567(level, pos, state, placer, stack);

        //noinspection ConstantConditions
        if (!level.method_8608() && stack.method_7985() && stack.method_7969().method_10545("BlockEntityTag"))
        {
            //Properly set face solidity when placed from a stack with BE NBT data
            if (level.method_8321(pos) instanceof FramedCollapsibleCopycatBlockEntity be)
            {
                be.updateFaceSolidity();
            }
        }
    }

    @Override
    public boolean doesBlockOccludeBeaconBeam(class_2680 state, class_4538 level, class_2338 pos)
    {
        if (level.method_8321(pos) instanceof FramedCollapsibleCopycatBlockEntity be)
        {
            return be.doesOccludeBeaconBeam();
        }
        return false;
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state)
    {
        return new FramedCollapsibleCopycatBlockEntity(pos, state);
    }
}
