package xfacthd.framedblocks.common.block.slopeslab;

import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_243;
import net.minecraft.class_2470;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_3965;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.block.*;
import xfacthd.framedblocks.api.util.*;
import xfacthd.framedblocks.common.block.FramedBlock;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.data.PropertyHolder;

import java.util.List;

public class FramedFlatSlopeSlabCornerBlock extends FramedBlock
{
    public FramedFlatSlopeSlabCornerBlock(BlockType type)
    {
        super(type);
        method_9590(method_9564()
                .method_11657(FramedProperties.TOP, false)
                .method_11657(PropertyHolder.TOP_HALF, false)
                .method_11657(FramedProperties.Y_SLOPE, true)
        );
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(
                FramedProperties.FACING_HOR, FramedProperties.TOP, PropertyHolder.TOP_HALF, FramedProperties.SOLID,
                class_2741.field_12508, FramedProperties.Y_SLOPE
        );
    }

    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return PlacementStateBuilder.of(this, ctx)
                .withHalfFacing()
                .withTop(PropertyHolder.TOP_HALF)
                .withCustom((state, modCtx) ->
                        state.method_11657(FramedProperties.TOP, ctx.method_8036() != null && ctx.method_8036().method_5715())
                )
                .withWater()
                .build();
    }

    @Override
    public boolean handleBlockLeftClick(class_2680 state, class_1937 level, class_2338 pos, class_1657 player)
    {
        return IFramedBlock.toggleYSlope(state, level, pos, player);
    }

    @Override
    public class_2680 rotate(class_2680 state, class_3965 hit, class_2470 rot)
    {
        class_2350 face = hit.method_17780();

        class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
        if (face == dir.method_10153() || face == dir.method_10170())
        {
            if (getBlockType() == BlockType.FRAMED_FLAT_SLOPE_SLAB_CORNER)
            {
                face = class_2350.field_11036;
            }
            else //FRAMED_FLAT_INNER_SLOPE_SLAB_CORNER
            {
                class_243 vec = Utils.fraction(hit.method_17784());

                class_2350 perpDir = face == dir.method_10170() ? dir : dir.method_10160();
                double hor = Utils.isX(perpDir) ? vec.method_10216() : vec.method_10215();
                if (!Utils.isPositive(perpDir))
                {
                    hor = 1D - hor;
                }

                double y = vec.method_10214();
                if (state.method_11654(PropertyHolder.TOP_HALF))
                {
                    y -= .5;
                }
                if (state.method_11654(FramedProperties.TOP))
                {
                    y = .5 - y;
                }
                if ((y * 2D) >= hor)
                {
                    face = class_2350.field_11036;
                }
            }
        }

        return rotate(state, face, rot);
    }

    @Override
    public class_2680 rotate(class_2680 state, class_2350 face, class_2470 rot)
    {
        if (Utils.isY(face))
        {
            class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
            return state.method_11657(FramedProperties.FACING_HOR, rot.method_10503(dir));
        }
        else if (rot != class_2470.field_11467)
        {
            return state.method_28493(PropertyHolder.TOP_HALF);
        }
        return state;
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9598(class_2680 state, class_2470 rot)
    {
        return rotate(state, class_2350.field_11036, rot);
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9569(class_2680 state, class_2415 mirror)
    {
        return Utils.mirrorCornerBlock(state, mirror);
    }

    @Override
    public void method_9568(class_1799 stack, @Nullable class_1922 level, List<class_2561> lines, class_1836 flag)
    {
        lines.add(FramedSlopeSlabBlock.PLACE_UPSIDE_DOWN);
        super.method_9568(stack, level, lines, flag);
    }
}
