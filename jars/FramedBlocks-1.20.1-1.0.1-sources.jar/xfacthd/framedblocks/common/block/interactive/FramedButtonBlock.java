package xfacthd.framedblocks.common.block.interactive;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2269;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2470;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2738;
import net.minecraft.class_3619;
import net.minecraft.class_3965;
import net.minecraft.class_8177;
import net.minecraft.class_8567;
import net.minecraft.world.level.block.*;
import net.minecraftforge.client.extensions.common.IClientBlockExtensions;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.block.IFramedBlock;
import xfacthd.framedblocks.api.block.render.FramedBlockRenderProperties;
import xfacthd.framedblocks.common.data.BlockType;

import javax.annotation.Nullable;
import java.util.List;
import java.util.function.Consumer;

@SuppressWarnings("deprecation")
public class FramedButtonBlock extends class_2269 implements IFramedBlock
{
    private final BlockType type;

    protected FramedButtonBlock(BlockType type, int pressTime, boolean arrowsCanPress, class_8177 blockSet)
    {
        super(class_2251.method_9637()
                .method_50012(class_3619.field_15971)
                .method_9634()
                .method_9632(0.5F)
                .method_9626(class_2498.field_11547)
                .method_22488(),
                blockSet,
                pressTime,
                arrowsCanPress
        );
        this.type = type;
        method_9590(method_9564()
                .method_11657(FramedProperties.GLOWING, false)
                .method_11657(FramedProperties.PROPAGATES_SKYLIGHT, false)
        );
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(FramedProperties.GLOWING, FramedProperties.PROPAGATES_SKYLIGHT);
    }

    @Override
    public final class_1269 method_9534(
            class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit
    )
    {
        class_1269 result = handleUse(state, level, pos, player, hand, hit);
        return result.method_23665() ? result : super.method_9534(state, level, pos, player, hand, hit);
    }

    @Override
    public void method_9567(class_1937 level, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 stack)
    {
        tryApplyCamoImmediately(level, pos, placer, stack);
    }

    @Override
    public float method_9575(class_2680 state, class_1922 level, class_2338 pos)
    {
        return getCamoShadeBrightness(state, level, pos, super.method_9575(state, level, pos));
    }

    @Override
    public boolean method_9579(class_2680 state, class_1922 level, class_2338 pos)
    {
        return state.method_11654(FramedProperties.PROPAGATES_SKYLIGHT);
    }

    @Override
    public List<class_1799> method_9560(class_2680 state, class_8567.class_8568 builder)
    {
        return getCamoDrops(super.method_9560(state, builder), builder);
    }

    @Override
    public class_2680 rotate(class_2680 state, class_2350 face, class_2470 rot)
    {
        if (state.method_11654(field_11007) != class_2738.field_12471)
        {
            return method_9598(state, rot);
        }
        return state;
    }

    @Override
    public BlockType getBlockType()
    {
        return type;
    }

    public void initializeClient(Consumer<IClientBlockExtensions> consumer)
    {
        consumer.accept(FramedBlockRenderProperties.INSTANCE);
    }



    public static FramedButtonBlock wood()
    {
        return new FramedButtonBlock(
                BlockType.FRAMED_BUTTON,
                30,
                true,
                class_8177.field_42823
        );
    }

    public static FramedButtonBlock stone()
    {
        return new FramedButtonBlock(
                BlockType.FRAMED_STONE_BUTTON,
                20,
                false,
                class_8177.field_42821
        );
    }
}