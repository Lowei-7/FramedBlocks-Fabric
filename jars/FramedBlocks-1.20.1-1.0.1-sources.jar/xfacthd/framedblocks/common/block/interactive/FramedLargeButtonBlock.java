package xfacthd.framedblocks.common.block.interactive;

import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2738;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import net.minecraft.class_8177;
import xfacthd.framedblocks.api.shapes.ShapeUtils;
import xfacthd.framedblocks.common.data.BlockType;

public class FramedLargeButtonBlock extends FramedButtonBlock
{
    private static final class_265 SHAPE_BOTTOM = method_9541(1, 0, 1, 15, 2, 15);
    private static final class_265 SHAPE_BOTTOM_PRESSED = method_9541(1, 0, 1, 15, 1, 15);
    private static final class_265 SHAPE_TOP = method_9541(1, 14, 1, 15, 16, 15);
    private static final class_265 SHAPE_TOP_PRESSED = method_9541(1, 15, 1, 15, 16, 15);
    private static final class_265[] SHAPES_HORIZONTAL = makeHorizontalShapes();

    private FramedLargeButtonBlock(BlockType type, int pressTime, boolean arrowsCanPress, class_8177 blockSet)
    {
        super(type, pressTime, arrowsCanPress, blockSet);
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context)
    {
        return getShape(state);
    }

    @Override
    public boolean doesBlockOccludeBeaconBeam(class_2680 state, class_4538 level, class_2338 pos)
    {
        return state.method_11654(field_11007) != class_2738.field_12471;
    }



    public static class_265 getShape(class_2680 state)
    {
        boolean pressed = state.method_11654(field_10729);
        return switch (state.method_11654(field_11007))
        {
            case field_12475 -> pressed ? SHAPE_BOTTOM_PRESSED : SHAPE_BOTTOM;
            case field_12473 -> pressed ? SHAPE_TOP_PRESSED : SHAPE_TOP;
            case field_12471 ->
            {
                int idx = state.method_11654(field_11177).method_10161() + (pressed ? 4 : 0);
                yield SHAPES_HORIZONTAL[idx];
            }
        };
    }

    private static class_265[] makeHorizontalShapes()
    {
        class_265 shape = method_9541(1, 1, 0, 15, 15, 2);
        class_265 shapePressed = method_9541(1, 1, 0, 15, 15, 1);

        return ShapeUtils.makeHorizontalRotationsWithFlag(shape, shapePressed, class_2350.field_11035);
    }

    public static FramedLargeButtonBlock wood()
    {
        return new FramedLargeButtonBlock(
                BlockType.FRAMED_LARGE_BUTTON,
                30,
                true,
                class_8177.field_42823
        );
    }

    public static FramedLargeButtonBlock stone()
    {
        return new FramedLargeButtonBlock(
                BlockType.FRAMED_LARGE_STONE_BUTTON,
                20,
                false,
                class_8177.field_42821
        );
    }
}
