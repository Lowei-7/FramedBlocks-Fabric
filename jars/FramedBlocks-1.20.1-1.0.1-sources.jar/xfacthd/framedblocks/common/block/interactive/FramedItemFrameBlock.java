package xfacthd.framedblocks.common.block.interactive;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5558;
import net.minecraft.class_702;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.*;
import net.minecraftforge.client.extensions.common.IClientBlockExtensions;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.block.IFramedBlock;
import xfacthd.framedblocks.api.block.PlacementStateBuilder;
import xfacthd.framedblocks.api.block.render.FramedBlockRenderProperties;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.FramedBlock;
import xfacthd.framedblocks.common.blockentity.special.FramedItemFrameBlockEntity;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.data.PropertyHolder;

import java.util.function.Consumer;

@SuppressWarnings("deprecation")
public class FramedItemFrameBlock extends FramedBlock
{
    private static final class_2498 NORMAL_SOUND = new class_2498(
            1F, 1F, class_3417.field_14585, class_3417.field_42593, class_3417.field_14844, class_3417.field_16506, class_3417.field_42593
    );
    private static final class_2498 GLOWING_SOUND = new class_2498(
            1F, 1F, class_3417.field_29189, class_3417.field_42593, class_3417.field_29190, class_3417.field_16506, class_3417.field_42593
    );

    public FramedItemFrameBlock(BlockType type)
    {
        super(type, IFramedBlock.createProperties(type)
                .method_9618()
                .method_9634()
                .method_26243((s, l, p) -> false)
                .method_26245((s, l, p) -> false)
                .method_9626(type == BlockType.FRAMED_ITEM_FRAME ? NORMAL_SOUND : GLOWING_SOUND)
        );
        method_9590(method_9564()
                .method_11657(PropertyHolder.LEATHER, false)
                .method_11657(PropertyHolder.MAP_FRAME, false)
        );
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(class_2741.field_12525, PropertyHolder.LEATHER, PropertyHolder.MAP_FRAME);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return PlacementStateBuilder.of(this, ctx)
                .withTargetFacing()
                .validate((state, modCtx) -> method_9558(state, modCtx.method_8045(), modCtx.method_8037()))
                .build();
    }

    @Override
    public class_2680 method_9559(
            class_2680 state,
            class_2350 direction,
            class_2680 neighborState,
            class_1936 level,
            class_2338 currentPos,
            class_2338 neighborPos
    )
    {
        if (!method_9558(state, level, currentPos))
        {
            return class_2246.field_10124.method_9564();
        }
        return super.method_9559(state, direction, neighborState, level, currentPos, neighborPos);
    }

    @Override
    public boolean method_9558(class_2680 state, class_4538 level, class_2338 pos)
    {
        class_2350 dir = state.method_11654(class_2741.field_12525);
        return class_2248.method_16361(level, pos.method_10093(dir));
    }

    @Override
    public class_1269 method_9534(
            class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit
    )
    {
        class_1269 result = super.method_9534(state, level, pos, player, hand, hit);
        if (result.method_23665()) { return result; }

        if (level.method_8321(pos) instanceof FramedItemFrameBlockEntity be)
        {
            return be.handleFrameInteraction(player, hand);
        }
        return class_1269.field_5811;
    }

    @Override
    public boolean handleBlockLeftClick(class_2680 state, class_1937 level, class_2338 pos, class_1657 player)
    {
        if (player.method_6047().method_31574(FBContent.ITEM_FRAMED_HAMMER.get()))
        {
            if (!level.method_8608())
            {
                level.method_8501(pos, state.method_28493(PropertyHolder.LEATHER));
            }
            return true;
        }
        else if (level.method_8321(pos) instanceof FramedItemFrameBlockEntity be && be.hasItem())
        {
            if (!level.method_8608())
            {
                be.removeItem(player);
            }
            return true;
        }
        return false;
    }

    @Override
    public class_2498 getSoundType(class_2680 state, class_4538 level, class_2338 pos, class_1297 entity)
    {
        //No camo sounds here
        return method_9573(state);
    }

    @Override
    public boolean addLandingEffects(
            class_2680 state1,
            class_3218 level,
            class_2338 pos,
            class_2680 state2,
            class_1309 entity,
            int numberOfParticles
    )
    {
        //Suppress landing impact particles
        return true;
    }

    @Override
    public boolean addRunningEffects(class_2680 state, class_1937 level, class_2338 pos, class_1297 entity)
    {
        //Suppress sprinting particles
        return true;
    }

    public class_1799 getCloneItemStack(class_2680 state, class_239 target, class_1922 level, class_2338 pos, class_1657 player)
    {
        if (level.method_8321(pos) instanceof FramedItemFrameBlockEntity be && be.hasItem())
        {
            return be.getCloneItem();
        }
        return super.method_9574(level, pos, state);
    }

    @Override
    public class_2680 rotate(class_2680 state, class_2350 face, class_2470 rot)
    {
        //Not rotatable by wrench
        return state;
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rot)
    {
        class_2350 dir = state.method_11654(class_2741.field_12525);
        return state.method_11657(class_2741.field_12525, rot.method_10503(dir));
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9569(class_2680 state, class_2415 mirror)
    {
        return Utils.mirrorFaceBlock(state, class_2741.field_12525, mirror);
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state)
    {
        return new FramedItemFrameBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 level, class_2680 state, class_2591<T> type)
    {
        if (!level.method_8608() && state.method_11654(PropertyHolder.MAP_FRAME))
        {
            return Utils.createBlockEntityTicker(
                    type, FBContent.BE_TYPE_FRAMED_ITEM_FRAME.get(), (l, p, s, be) -> be.tickWithMap()
            );
        }
        return null;
    }

    public void initializeClient(Consumer<IClientBlockExtensions> consumer)
    {
        //Suppress hit and destroy particles
        consumer.accept(new FramedBlockRenderProperties()
        {
            @Override
            public boolean addHitEffects(class_2680 state, class_1937 level, class_239 target, class_702 manager)
            {
                return true;
            }

            @Override
            public boolean addDestroyEffects(class_2680 state, class_1937 Level, class_2338 pos, class_702 manager)
            {
                return true;
            }
        });
    }
}
