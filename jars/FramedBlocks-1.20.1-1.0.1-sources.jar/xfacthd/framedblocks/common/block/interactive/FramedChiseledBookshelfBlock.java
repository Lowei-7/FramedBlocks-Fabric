package xfacthd.framedblocks.common.block.interactive;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_241;
import net.minecraft.class_2415;
import net.minecraft.class_243;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_3489;
import net.minecraft.class_3965;
import net.minecraft.class_5712;
import net.minecraft.class_7714;
import net.minecraft.sounds.*;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.block.PlacementStateBuilder;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.block.FramedBlock;
import xfacthd.framedblocks.common.blockentity.special.FramedChiseledBookshelfBlockEntity;
import xfacthd.framedblocks.common.data.BlockType;

import java.util.Optional;

@SuppressWarnings("deprecation")
public class FramedChiseledBookshelfBlock extends FramedBlock
{
    public FramedChiseledBookshelfBlock()
    {
        super(BlockType.FRAMED_CHISELED_BOOKSHELF);
        class_2680 state = method_9564();
        for (class_2746 prop : class_7714.field_41308)
        {
            state = state.method_11657(prop, false);
        }
        method_9590(state);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(FramedProperties.FACING_HOR, FramedProperties.SOLID);
        class_7714.field_41308.forEach(builder::method_11667);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return PlacementStateBuilder.of(this, ctx).withHorizontalFacing(true).build();
    }

    @Override
    public void method_9567(class_1937 level, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 stack)
    {
        super.method_9567(level, pos, state, placer, stack);

        //noinspection ConstantConditions
        if (level.method_8608() || !stack.method_7985() || !stack.method_7969().method_10545("BlockEntityTag"))
        {
            return;
        }

        if (level.method_8321(pos) instanceof FramedChiseledBookshelfBlockEntity be)
        {
            be.forceStateUpdate();
        }
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit)
    {
        class_1269 result = super.method_9534(state, level, pos, player, hand, hit);
        if (result != class_1269.field_5811)
        {
            return result;
        }

        if (level.method_8321(pos) instanceof FramedChiseledBookshelfBlockEntity be)
        {
            class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
            Optional<class_241> optional = getRelativeHitCoordinatesForBlockFace(hit, dir);
            if (optional.isEmpty())
            {
                return class_1269.field_5811;
            }

            int slot = getHitSlot(optional.get());
            if (state.method_11654(class_7714.field_41308.get(slot)))
            {
                takeBook(level, pos, player, be, slot);
                return class_1269.method_29236(level.method_8608());
            }

            class_1799 stack = player.method_5998(hand);
            if (!stack.method_31573(class_3489.field_40109))
            {
                return class_1269.field_21466;
            }

            placeBook(level, pos, player, be, stack, slot);
            return class_1269.method_29236(level.method_8608());
        }
        return class_1269.field_5811;
    }

    private static void placeBook(
            class_1937 level, class_2338 pos, class_1657 player, FramedChiseledBookshelfBlockEntity be, class_1799 stack, int slot
    )
    {
        if (level.method_8608())
        {
            return;
        }

        be.placeBook(stack.method_7971(1), slot);
        if (player.method_7337())
        {
            stack.method_7933(1);
        }

        class_3414 sound = stack.method_31574(class_1802.field_8598) ? class_3417.field_40971 : class_3417.field_40970;
        level.method_8396(null, pos, sound, class_3419.field_15245, 1F, 1F);

        player.method_7259(class_3468.field_15372.method_14956(stack.method_7909()));
        level.method_33596(player, class_5712.field_28733, pos);
    }

    private static void takeBook(class_1937 level, class_2338 pos, class_1657 player, FramedChiseledBookshelfBlockEntity be, int slot)
    {
        if (level.method_8608())
        {
            return;
        }

        class_1799 stack = be.takeBook(slot);
        if (!player.method_31548().method_7394(stack))
        {
            player.method_7328(stack, false);
        }

        class_3414 sound = stack.method_31574(class_1802.field_8598) ? class_3417.field_40974 : class_3417.field_40973;
        level.method_8396(null, pos, sound, class_3419.field_15245, 1.0F, 1.0F);

        level.method_33596(player, class_5712.field_28733, pos);
    }

    @Override
    public void method_9536(class_2680 state, class_1937 level, class_2338 pos, class_2680 newState, boolean isMoving)
    {
        if (newState.method_26204() != state.method_26204() && level.method_8321(pos) instanceof FramedChiseledBookshelfBlockEntity be)
        {
            be.getDrops().forEach(stack -> method_9577(level, pos, stack));
            be.clearContents();
            level.method_8455(pos, this);
        }

        super.method_9536(state, level, pos, newState, isMoving);
    }

    @Override
    @SuppressWarnings("deprecation")
    public boolean method_9498(class_2680 state)
    {
        return true;
    }

    @Override
    @SuppressWarnings("deprecation")
    public int method_9572(class_2680 state, class_1937 level, class_2338 pos)
    {
        if (level.method_8321(pos) instanceof FramedChiseledBookshelfBlockEntity be)
        {
            return be.getAnalogOutputSignal();
        }
        return 0;
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rot)
    {
        class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
        return state.method_11657(FramedProperties.FACING_HOR, rot.method_10503(dir));
    }

    @Override
    public class_2680 method_9569(class_2680 state, class_2415 mirror)
    {
        return Utils.mirrorFaceBlock(state, mirror);
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state)
    {
        return new FramedChiseledBookshelfBlockEntity(pos, state);
    }

    private static Optional<class_241> getRelativeHitCoordinatesForBlockFace(class_3965 hit, class_2350 face)
    {
        if (face == class_2350.field_11036 || face == class_2350.field_11033) return Optional.empty();
        class_243 hitLoc = hit.method_17784();
        class_2338 relativePos = hit.method_17777().method_10093(face);
        double d = Math.abs(relativePos.method_10263() - hitLoc.method_10216());
        double e = Math.abs(relativePos.method_10260() - hitLoc.method_10215());
        return Optional.of(new class_241((float) d, (float) e));
    }

    private static int getHitSlot(class_241 relativeHit)
    {
        int i = relativeHit.field_1343 < 0.375F ? 0 : (relativeHit.field_1343 < 0.625F ? 1 : 2);
        int j = relativeHit.field_1342 < 0.5F ? 1 : 0;
        return j * 3 + i;
    }
}
