package xfacthd.framedblocks.common.blockentity;

import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_1920;
import net.minecraft.class_1927;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3545;
import net.minecraft.class_3610;
import net.minecraft.class_3620;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_7923;
import net.minecraft.world.level.*;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.FramedBlocks;
import xfacthd.framedblocks.api.block.FramedBlockEntity;
import xfacthd.framedblocks.api.block.IFramedDoubleBlockEntity;
import xfacthd.framedblocks.api.camo.EmptyCamoContainer;
import xfacthd.framedblocks.api.camo.CamoContainer;
import xfacthd.framedblocks.api.internal.InternalAPI;
import xfacthd.framedblocks.api.model.data.FramedBlockData;
import xfacthd.framedblocks.api.model.data.FramedDoubleBlockData;
import xfacthd.framedblocks.api.util.ClientUtils;
import xfacthd.framedblocks.common.block.*;
import xfacthd.framedblocks.common.data.doubleblock.DoubleBlockStateCache;
import xfacthd.framedblocks.common.util.DoubleBlockSoundType;
import xfacthd.framedblocks.common.util.DoubleBlockTopInteractionMode;

import java.util.List;

public abstract class FramedDoubleBlockEntity extends FramedBlockEntity implements IFramedDoubleBlockEntity
{
    public static final FramedBlockData.Property<Object> DATA_LEFT = new FramedBlockData.Property<>();
    public static final FramedBlockData.Property<Object> DATA_RIGHT = new FramedBlockData.Property<>();

    private final FramedBlockData modelData = new FramedBlockData();
    private final DoubleBlockSoundType soundType = new DoubleBlockSoundType(this);
    private CamoContainer camoContainer = EmptyCamoContainer.EMPTY;

    public FramedDoubleBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state)
    {
        super(type, pos, state);
        this.modelData.setUseAltModel(true);
    }

    @Override
    public void setCamo(CamoContainer camo, boolean secondary)
    {
        if (secondary)
        {
            int light = getLightValue();

            this.camoContainer = camo;

            method_5431();
            if (getLightValue() != light)
            {
                doLightUpdate();
            }

            if (!updateDynamicStates(true, true, true))
            {
                //noinspection ConstantConditions
                field_11863.method_8413(field_11867, method_11010(), method_11010(), class_2248.field_31036);
            }
        }
        else
        {
            super.setCamo(camo, false);
        }
    }

    @Override
    public CamoContainer getCamo(class_2680 state)
    {
        class_3545<class_2680, class_2680> blockPair = getStateCache().getBlockPair();
        if (state == blockPair.method_15442())
        {
            return getCamo();
        }
        if (state == blockPair.method_15441())
        {
            return getCamoTwo();
        }
        return EmptyCamoContainer.EMPTY;
    }

    @Override
    protected CamoContainer getCamo(boolean secondary)
    {
        return secondary ? camoContainer : getCamo();
    }

    @Override
    public final CamoContainer getCamoTwo()
    {
        return camoContainer;
    }

    @Override
    @SuppressWarnings("deprecation")
    public int getLightValue()
    {
        return Math.max(camoContainer.getState().method_26213(), super.getLightValue());
    }

    @Override
    public IFramedDoubleBlock getBlock()
    {
        return (IFramedDoubleBlock) super.getBlock();
    }

    @Override
    public DoubleBlockStateCache getStateCache()
    {
        return (DoubleBlockStateCache) super.getStateCache();
    }

    @Override
    public boolean canAutoApplyCamoOnPlacement()
    {
        return false;
    }

    @Override
    public void addAdditionalDrops(List<class_1799> drops, boolean dropCamo)
    {
        super.addAdditionalDrops(drops, dropCamo);
        if (dropCamo && !camoContainer.isEmpty())
        {
            drops.add(camoContainer.toItemStack(class_1799.field_8037));
        }
    }

    @Override
    public class_3620 getMapColor()
    {
        return switch (getStateCache().getTopInteractionMode())
        {
            case FIRST -> super.getMapColor();
            case SECOND -> camoContainer.getMapColor(field_11863, field_11867);
            case EITHER ->
            {
                class_3620 color = super.getMapColor();
                if (color != null)
                {
                    yield color;
                }
                yield camoContainer.getMapColor(field_11863, field_11867);
            }
        };
    }

    @Override
    public float[] getCamoBeaconColorMultiplier(class_4538 level, class_2338 pos, class_2338 beaconPos)
    {
        float[] superMult = super.getCamoBeaconColorMultiplier(level, pos, beaconPos);
        float[] localMult = camoContainer.isEmpty() ? null : camoContainer.getBeaconColorMultiplier(level, pos, beaconPos);

        if (superMult == null)
        {
            return localMult;
        }
        if (localMult == null)
        {
            return superMult;
        }

        return new float[] {
                (superMult[0] + localMult[0]) / 2F,
                (superMult[1] + localMult[1]) / 2F,
                (superMult[2] + localMult[2]) / 2F
        };
    }

    @Override
    public boolean shouldCamoDisplayFluidOverlay(class_1920 level, class_2338 pos, class_3610 fluid)
    {
        if (camoContainer.isEmpty())
        {
            return true;
        }
        return false;
    }

    @Override
    public float getCamoFriction(class_2680 state, @Nullable class_1297 entity)
    {
        return switch (getStateCache().getTopInteractionMode())
        {
            case FIRST -> getFriction(this, getCamo(), state, entity);
            case SECOND -> getFriction(this, getCamoTwo(), state, entity);
            case EITHER -> Math.max(
                    getFriction(this, getCamo(), state, entity),
                    getFriction(this, getCamoTwo(), state, entity)
            );
        };
    }

    public boolean canCamoSustainPlant(class_2350 side, Object plant)
    {
        return false; // Placeholder
    }

    @Override
    public boolean doesCamoPreventDestructionByEntity(class_1297 entity)
    {
        if (super.doesCamoPreventDestructionByEntity(entity))
        {
            return true;
        }
        return doesCamoPreventDestructionByEntity(this, camoContainer, entity);
    }

    @Override
    protected boolean isCamoSolid()
    {
        if (camoContainer.isEmpty())
        {
            return false;
        }

        //noinspection ConstantConditions
        return super.isCamoSolid() && camoContainer.getState().method_26216(field_11863, field_11867);
    }

    @Override
    protected boolean doesCamoPropagateSkylightDown()
    {
        //noinspection ConstantConditions
        if (!camoContainer.getState().method_26167(field_11863, field_11867))
        {
            return false;
        }
        return super.doesCamoPropagateSkylightDown();
    }

    @Override
    public float getCamoExplosionResistance(class_1927 explosion)
    {
        return Math.max(
                super.getCamoExplosionResistance(explosion),
                camoContainer.isEmpty() ? 0 : camoContainer.getState().method_26204().method_9520()
        );
    }

    @Override
    public boolean isCamoFlammable(class_2350 face)
    {
        return false;
    }

    @Override
    public int getCamoFlammability(class_2350 face)
    {
        return -1;
    }

    @Override
    public int getCamoFireSpreadSpeed(class_2350 face)
    {
        return -1;
    }

    @Override
    public float getCamoShadeBrightness(float ownShade)
    {
        if (!getCamo().isEmpty())
        {
            //noinspection ConstantConditions
            ownShade = Math.max(ownShade, getCamo().getState().method_26210(field_11863, field_11867));
        }
        if (!camoContainer.isEmpty())
        {
            //noinspection ConstantConditions
            ownShade = Math.max(ownShade, camoContainer.getState().method_26210(field_11863, field_11867));
        }
        return ownShade;
    }

    public final DoubleBlockSoundType getSoundType()
    {
        return soundType;
    }

    @Override
    protected abstract boolean hitSecondary(class_3965 hit);

    public final DoubleBlockTopInteractionMode getTopInteractionMode()
    {
        return getStateCache().getTopInteractionMode();
    }

    @Override
    public final CamoContainer getCamo(class_2350 side)
    {
        return getCamo(side, null);
    }

    @Override
    public final CamoContainer getCamo(class_2350 side, @Nullable class_2350 edge)
    {
        return getStateCache().getCamoGetter(side, edge).getCamo(this);
    }

    @Override
    public final boolean isSolidSide(class_2350 side)
    {
        return getStateCache().getSolidityCheck(side).isSolid(this);
    }

    @Override
    public boolean updateCulling(class_2350 side, boolean rerender)
    {
        class_3545<class_2680, class_2680> blockPair = getStateCache().getBlockPair();
        boolean changed = updateCulling(getModelDataInternal(), blockPair.method_15442(), side, rerender);
        changed |= updateCulling(modelData, blockPair.method_15441(), side, rerender);
        return changed;
    }

    public class_3545<class_2680, class_2680> getBlockPair()
    {
        return getStateCache().getBlockPair();
    }

    /*
     * Sync
     */

    @Override
    protected void writeToDataPacket(class_2487 nbt)
    {
        super.writeToDataPacket(nbt);

        nbt.method_10566("camo_two", CamoContainer.writeToNetwork(camoContainer));
    }

    @Override
    protected boolean readFromDataPacket(class_2487 nbt)
    {
        boolean needUpdate = false;
        CamoContainer newCamo = CamoContainer.readFromNetwork(nbt.method_10562("camo_two"));
        if (!newCamo.equals(camoContainer))
        {
            int oldLight = getLightValue();
            camoContainer = newCamo;
            if (oldLight != getLightValue()) { doLightUpdate(); }

            modelData.setCamoState(camoContainer.getState());

            needUpdate = true;
            updateCulling(true, false);
        }

        byte flags = nbt.method_10571("flags");

        boolean newReinforced = readFlag(flags, FLAG_REINFORCED);
        if (isReinforced() != newReinforced)
        {
            modelData.setReinforced(newReinforced);
            needUpdate = true;
        }

        return super.readFromDataPacket(nbt) || needUpdate;
    }

    @Override
    public class_2487 method_16887()
    {
        class_2487 nbt = super.method_16887();

        nbt.method_10566("camo_two", CamoContainer.writeToNetwork(camoContainer));

        return nbt;
    }

    @Override
    public void handleUpdateTag(class_2487 nbt)
    {
        super.handleUpdateTag(nbt);

        CamoContainer newCamo = CamoContainer.readFromNetwork(nbt.method_10562("camo_two"));
        if (!newCamo.equals(camoContainer))
        {
            camoContainer = newCamo;

            modelData.setCamoState(camoContainer.getState());

            ClientUtils.enqueueClientTask(() -> updateCulling(true, true));
        }

        byte flags = nbt.method_10571("flags");

        boolean newReinforced = readFlag(flags, FLAG_REINFORCED);
        if (isReinforced() != newReinforced)
        {
            modelData.setReinforced(newReinforced);
        }
    }

    /*
     * Model data
     */

    @Override
    public Object getRenderAttachmentData()
    {
        return new FramedDoubleBlockData(getModelDataInternal(), modelData);
    }

    @Override
    protected void initModelData()
    {
        super.initModelData();
        modelData.setCamoState(camoContainer.getState());
    }

    /*
     * NBT stuff
     */

    @Override
    public void method_11007(class_2487 nbt)
    {
        nbt.method_10566("camo_two", CamoContainer.save(camoContainer));

        super.method_11007(nbt);
    }

    @Override
    public void method_11014(class_2487 nbt)
    {
        super.method_11014(nbt);

        InternalAPI.INSTANCE.updateCamoNbt(nbt, "camo_state_two", "camo_stack_two", "camo_two");

        CamoContainer camo = CamoContainer.load(nbt.method_10562("camo_two"));
        if (camo.isEmpty() || isValidBlock(camo.getState(), null))
        {
            camoContainer = camo;
        }
        else
        {
            FramedBlocks.LOGGER.warn(
                    "Framed Block of type \"{}\" at position {} contains an invalid camo of type \"{}\", removing camo! This might be caused by a config or tag change!",
                    class_7923.field_41175.method_10221(method_11010().method_26204()),
                    field_11867,
                    class_7923.field_41175.method_10221(camo.getState().method_26204())
            );
        }
    }
}