package xfacthd.framedblocks.common.blockentity.special;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.class_1657;
import net.minecraft.class_1767;
import net.minecraft.class_1937;
import net.minecraft.class_2165;
import net.minecraft.class_2168;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2564;
import net.minecraft.class_2583;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2682;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3532;
import net.minecraft.class_5837;
import net.minecraft.class_8242;
import net.minecraft.network.chat.*;
import net.minecraft.world.phys.*;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.FramedBlocks;
import xfacthd.framedblocks.api.block.FramedBlockEntity;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.sign.AbstractFramedSignBlock;

import java.util.List;
import java.util.UUID;
import java.util.function.UnaryOperator;

public final class FramedSignBlockEntity extends FramedBlockEntity
{
    @Nullable
    private UUID editingPlayer;
    private class_8242 frontText = new class_8242();
    private class_8242 backText = new class_8242();
    private boolean waxed;
    private class_238 renderBounds;

    private FramedSignBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state)
    {
        super(type, pos, state);
        this.renderBounds = state.method_26218(class_2682.field_12294, pos).method_1107().method_996(pos);
    }

    public boolean isFacingFrontText(class_1657 player)
    {
        if (method_11010().method_26204() instanceof AbstractFramedSignBlock signblock)
        {
            class_243 center = signblock.getSignHitboxCenterPosition(method_11010());
            double dX = player.method_23317() - ((double) method_11016().method_10263() + center.field_1352);
            double dY = player.method_23321() - ((double) method_11016().method_10260() + center.field_1350);
            float blockAngle = signblock.getYRotationDegrees(method_11010());
            float playerAngle = (float)(class_3532.method_15349(dY, dX) * (double)(180F / (float) Math.PI)) - 90.0F;
            return class_3532.method_15356(blockAngle, playerAngle) <= 90.0F;
        }
        return false;
    }

    public class_8242 getText(boolean front)
    {
        return front ? frontText : backText;
    }

    public class_8242 getFrontText()
    {
        return frontText;
    }

    public class_8242 getBackText()
    {
        return backText;
    }

    public void updateTextFromPacket(class_1657 player, boolean front, List<class_5837> filteredText)
    {
        if (field_11863 == null)
        {
            return;
        }

        if (isWaxed() || !player.method_5667().equals(editingPlayer))
        {
            FramedBlocks.LOGGER.warn(
                    "Player {} just tried to change non-editable sign at", player.method_5477().getString(), field_11867
            );
            return;
        }

        updateText(text ->
        {
            boolean filter = player.method_33793();
            for (int idx = 0; idx < filteredText.size(); idx++)
            {
                class_5837 filteredtext = filteredText.get(idx);
                class_2583 style = text.method_49859(idx, filter).method_10866();
                class_2561 filteredLine = class_2561.method_43470(filteredtext.method_45061()).method_10862(style);
                class_2561 line = filter ? filteredLine : class_2561.method_43470(filteredtext.comp_841()).method_10862(style);
                text = text.method_49858(idx, line, filteredLine);
            }

            return text;
        }, front);
        setEditingPlayer(null);
        field_11863.method_8413(method_11016(), method_11010(), method_11010(), class_2248.field_31036);
    }

    public boolean updateText(UnaryOperator<class_8242> modifier, boolean front)
    {
        return setText(modifier.apply(getText(front)), front);
    }

    public boolean setText(class_8242 text, boolean front)
    {
        return front ? setFrontText(text) : setBackText(text);
    }

    public boolean setFrontText(class_8242 text)
    {
        if (text != this.frontText) {
            frontText = text;

            //noinspection ConstantConditions
            field_11863.method_8413(method_11016(), method_11010(), method_11010(), class_2248.field_31036);
            method_5431();

            return true;
        }
        return false;
    }

    public boolean setBackText(class_8242 text)
    {
        if (text != backText)
        {
            backText = text;

            //noinspection ConstantConditions
            field_11863.method_8413(method_11016(), method_11010(), method_11010(), class_2248.field_31036);
            method_5431();

            return true;
        }
        return false;
    }

    public boolean isWaxed()
    {
        return waxed;
    }

    public boolean setWaxed(boolean waxed)
    {
        if (this.waxed != waxed)
        {
            this.waxed = waxed;

            //noinspection ConstantConditions
            field_11863.method_8413(method_11016(), method_11010(), method_11010(), class_2248.field_31036);
            method_5431();

            return true;
        }
        return false;
    }

    public boolean canExecuteCommands(boolean front, class_1657 pPlayer)
    {
        return isWaxed() && getText(front).method_49874(pPlayer);
    }

    public boolean tryExecuteCommands(class_1657 player, class_1937 level, class_2338 pos, boolean front)
    {
        boolean executed = false;

        for (class_2561 line : getText(front).method_49877(player.method_33793()))
        {
            class_2558 event = line.method_10866().method_10970();
            if (event != null && event.method_10845() == class_2558.class_2559.field_11750)
            {
                //noinspection ConstantConditions
                player.method_5682().method_3734().method_44252(
                        getCommandSource((class_3222) player, (class_3218) level, pos),
                        event.method_10844()
                );
                executed = true;
            }
        }

        return executed;
    }

    private static class_2168 getCommandSource(class_3222 player, class_3218 level, class_2338 pos)
    {
        String nameString = player == null ? "Sign" : player.method_5477().getString();
        class_2561 name = player == null ? class_2561.method_43470("Sign") : player.method_5476();
        class_243 posVec = class_243.method_24953(pos);

        //noinspection ConstantConditions
        return new class_2168(class_2165.field_17395, posVec, class_241.field_1340, level, 2, nameString, name, level.method_8503(), player);
    }

    @Nullable
    public UUID getEditingPlayer()
    {
        return editingPlayer;
    }

    public void setEditingPlayer(@Nullable UUID player)
    {
        this.editingPlayer = player;
    }

    @Override
    public boolean method_11011()
    {
        return true;
    }

    @SuppressWarnings("unused")
    public static void tick(class_1937 level, class_2338 pos, class_2680 state, FramedSignBlockEntity be)
    {
        if (be.editingPlayer != null)
        {
            //noinspection ConstantConditions
            class_1657 player = level.method_18470(be.editingPlayer);
            if (be.isTooFarAwayToEdit(player))
            {
                be.editingPlayer = null;
            }
        }
    }

    public boolean isTooFarAwayToEdit(class_1657 player)
    {
        return player == null || player.method_5649(field_11867.method_10263(), field_11867.method_10264(), field_11867.method_10260()) > 64.0D;
    }

    @Override
    @SuppressWarnings("deprecation")
    public void method_31664(class_2680 state)
    {
        super.method_31664(state);
        //noinspection ConstantConditions
        renderBounds = state.method_26218(field_11863, field_11867).method_1107().method_996(field_11867);
    }

    public class_238 getRenderBoundingBox()
    {
        return renderBounds;
    }

    @Override
    protected void writeToDataPacket(class_2487 nbt)
    {
        super.writeToDataPacket(nbt);
        writeToNbt(nbt);
    }

    @Override
    protected boolean readFromDataPacket(class_2487 nbt)
    {
        readFromNbt(nbt);
        return super.readFromDataPacket(nbt);
    }

    @Override
    public class_2487 method_16887()
    {
        class_2487 nbt = super.method_16887();
        writeToNbt(nbt);
        return nbt;
    }

    @Override
    public void handleUpdateTag(class_2487 nbt)
    {
        super.handleUpdateTag(nbt);
        readFromNbt(nbt);
    }

    private void writeToNbt(class_2487 nbt)
    {
        class_8242.field_43298.encodeStart(class_2509.field_11560, frontText)
                .resultOrPartial(FramedBlocks.LOGGER::error)
                .ifPresent(tag -> nbt.method_10566("front_text", tag));
        class_8242.field_43298.encodeStart(class_2509.field_11560, backText)
                .resultOrPartial(FramedBlocks.LOGGER::error)
                .ifPresent(tag -> nbt.method_10566("back_text", tag));

        nbt.method_10556("waxed", waxed);
    }

    private void readFromNbt(class_2487 nbt)
    {
        if (nbt.method_10545("front_text"))
        {
            class_8242.field_43298.parse(class_2509.field_11560, nbt.method_10562("front_text"))
                    .resultOrPartial(FramedBlocks.LOGGER::error)
                    .ifPresent(tag -> frontText = loadLines(field_11863, field_11867, tag));
        }

        if (nbt.method_10545("back_text"))
        {
            class_8242.field_43298.parse(class_2509.field_11560, nbt.method_10562("back_text"))
                    .resultOrPartial(FramedBlocks.LOGGER::error)
                    .ifPresent(tag -> backText = loadLines(field_11863, field_11867, tag));
        }

        waxed = nbt.method_10577("waxed");
    }

    private static class_8242 loadLines(class_1937 level, class_2338 pos, class_8242 text)
    {
        for (int i = 0; i < 4; ++i)
        {
            class_2561 line = loadLine(level, pos, text.method_49859(i, false));
            class_2561 lineFiltered = loadLine(level, pos, text.method_49859(i, true));
            text = text.method_49858(i, line, lineFiltered);
        }

        return text;
    }

    private static class_2561 loadLine(class_1937 level, class_2338 pos, class_2561 line)
    {
        if (level instanceof class_3218 serverlevel)
        {
            try
            {
                return class_2564.method_10881(getCommandSource(null, serverlevel, pos), line, null, 0);
            }
            catch (CommandSyntaxException ignored) { }
        }

        return line;
    }

    @Override //Prevent writing sign data
    public class_2487 writeToBlueprint()
    {
        class_2487 tag = method_38244();
        tag.method_10551("front_text");
        tag.method_10551("back_text");
        tag.method_10551("waxed");
        return tag;
    }

    @Override
    public void method_11007(class_2487 nbt)
    {
        writeToNbt(nbt);
        super.method_11007(nbt);
    }

    @Override
    public void method_11014(class_2487 nbt)
    {
        super.method_11014(nbt);

        if (nbt.method_10545("text0") || nbt.method_10545("text1") || nbt.method_10545("text2") || nbt.method_10545("text3") || nbt.method_10545("glowingText") || nbt.method_10545("color"))
        {
            for (int i = 0; i < 4; i++)
            {
                String text = nbt.method_10558("text" + i);
                class_2561 line = class_2561.class_2562.method_10877(text.isEmpty() ? "\"\"" : text);
                if (line != null)
                {
                    frontText.method_49857(i, line);
                }
            }

            frontText.method_49867(nbt.method_10577("glowingText"));
            frontText.method_49862(class_1767.method_7793(nbt.method_10558("color"), class_1767.field_7963));
            return;
        }
        readFromNbt(nbt);
    }



    public static FramedSignBlockEntity normalSign(class_2338 pos, class_2680 state)
    {
        return new FramedSignBlockEntity(FBContent.BE_TYPE_FRAMED_SIGN.get(), pos, state);
    }

    public static FramedSignBlockEntity hangingSign(class_2338 pos, class_2680 state)
    {
        return new FramedSignBlockEntity(FBContent.BE_TYPE_FRAMED_HANGING_SIGN.get(), pos, state);
    }
}
