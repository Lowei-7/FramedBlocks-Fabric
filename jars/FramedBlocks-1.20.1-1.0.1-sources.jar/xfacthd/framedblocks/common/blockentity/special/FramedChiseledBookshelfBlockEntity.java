package xfacthd.framedblocks.common.blockentity.special;

import xfacthd.framedblocks.api.block.FramedBlockEntity;
import xfacthd.framedblocks.common.FBContent;

import org.jetbrains.annotations.Nullable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_2746;
import net.minecraft.class_7714;
import net.minecraft.class_7716;

public class FramedChiseledBookshelfBlockEntity extends FramedBlockEntity
{
    public static final String INVENTORY_NBT_KEY = "inventory";
    public static final String LAST_SLOT_NBT_KEY = "last_slot";

    private class_1799[] inventory;
    private int lastInteractedSlot = -1;

    public FramedChiseledBookshelfBlockEntity(class_2338 pos, class_2680 state)
    {
        super(FBContent.BE_TYPE_FRAMED_CHISELED_BOOKSHELF.get(), pos, state);
        inventory = createInventory();
    }

    private static class_1799[] createInventory()
    {
        class_1799[] inventory = new class_1799[class_7716.field_40331];
        Arrays.fill(inventory, class_1799.field_8037);
        return inventory;
    }

    public void placeBook(class_1799 stack, int slot)
    {
        inventory[slot] = stack;
        updateState(slot);
        method_5431();
    }

    public class_1799 takeBook(int slot)
    {
        class_1799 stack = inventory[slot];
        inventory[slot] = class_1799.field_8037;
        updateState(slot);
        method_5431();
        return stack;
    }

    private void updateState(int slot)
    {
        lastInteractedSlot = slot;

        class_2680 state = method_11010();
        for (int i = 0; i < class_7716.field_40331; i++)
        {
            class_2746 prop = class_7714.field_41308.get(i);
            state = state.method_11657(prop, !inventory[i].method_7960());
        }
        //noinspection ConstantConditions
        field_11863.method_8501(field_11867, state);
    }

    public void forceStateUpdate()
    {
        updateState(lastInteractedSlot);
    }

    @Override
    public void onLoad()
    {
        super.onLoad();
    }

    public List<class_1799> getDrops()
    {
        List<class_1799> drops = new ArrayList<>();
        for (int i = 0; i < inventory.length; i++)
        {
            class_1799 stack = inventory[i];
            if (!stack.method_7960())
            {
                drops.add(stack);
            }
        }
        return drops;
    }

    public void clearContents()
    {
        for (int i = 0; i < inventory.length; i++)
        {
            inventory[i] = class_1799.field_8037;
        }
    }

    public int getAnalogOutputSignal()
    {
        return lastInteractedSlot + 1;
    }

    @Override //Prevent writing inventory contents
    public class_2487 writeToBlueprint()
    {
        class_2487 tag = method_38244();
        tag.method_10551(INVENTORY_NBT_KEY);
        tag.method_10551(LAST_SLOT_NBT_KEY);
        return tag;
    }

    @Override
    public void method_11007(class_2487 nbt)
    {
        class_2487 inventoryTag = new class_2487();
        for (int i = 0; i < inventory.length; i++)
        {
            if (!inventory[i].method_7960())
            {
                inventoryTag.method_10566("Slot" + i, inventory[i].method_7953(new class_2487()));
            }
        }
        nbt.method_10566(INVENTORY_NBT_KEY, inventoryTag);
        nbt.method_10569(LAST_SLOT_NBT_KEY, lastInteractedSlot);
        super.method_11007(nbt);
    }

    @Override
    public void method_11014(class_2487 nbt)
    {
        super.method_11014(nbt);
        class_2487 inventoryTag = nbt.method_10562(INVENTORY_NBT_KEY);
        for (int i = 0; i < inventory.length; i++)
        {
            if (inventoryTag.method_10545("Slot" + i))
            {
                inventory[i] = class_1799.method_7915(inventoryTag.method_10562("Slot" + i));
            }
            else
            {
                inventory[i] = class_1799.field_8037;
            }
        }
        lastInteractedSlot = nbt.method_10550(LAST_SLOT_NBT_KEY);
    }
}
