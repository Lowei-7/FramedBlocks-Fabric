package xfacthd.framedblocks.common.blockentity.special;

import net.minecraft.class_1657;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.core.*;
import net.minecraft.world.phys.*;
// Removed Forge model data imports
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.block.FramedBlockEntity;
import xfacthd.framedblocks.api.model.data.FramedBlockData;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.data.property.NullableDirection;
import xfacthd.framedblocks.common.data.PropertyHolder;

public class FramedCollapsibleBlockEntity extends FramedBlockEntity
{
    // Replaced ModelProperty with simple int - Fabric uses RenderAttachmentBlockEntity
    private static final int DIRECTIONS = class_2350.values().length;
    private static final int VERTEX_COUNT = 4;
    private static final NeighborVertex[][] VERTEX_MAPPINGS = makeVertexMapping();

    @Nullable
    private class_2350 collapsedFace = null;
    private int packedOffsets = 0;
    private byte[] vertexOffsets = new byte[4];

    public FramedCollapsibleBlockEntity(class_2338 pos, class_2680 state)
    {
        super(FBContent.BE_TYPE_FRAMED_COLLAPSIBLE_BLOCK.get(), pos, state);
    }

    public void handleDeform(class_1657 player)
    {
        class_239 hit = player.method_5745(10D, 0, false);
        if (!(hit instanceof class_3965 blockHit))
        {
            return;
        }

        class_2350 faceHit = blockHit.method_17780();
        class_243 hitLoc = Utils.fraction(hit.method_17784());

        if (collapsedFace != null && faceHit != collapsedFace)
        {
            return;
        }

        int vert = vertexFromHit(faceHit, hitLoc);
        if (vert == 4)
        {
            for (int i = 0; i < 4; i++)
            {
                handleDeformOfVertex(player, faceHit, i);
            }
        }
        else
        {
            handleDeformOfVertex(player, faceHit, vert);
        }
    }

    private void handleDeformOfVertex(class_1657 player, class_2350 faceHit, int vert)
    {
        if (player.method_5715() && collapsedFace != null && vertexOffsets[vert] > 0)
        {
            byte target = (byte) (vertexOffsets[vert] - 1);

            applyDeformation(vert, target, faceHit);
            deformNeighbors(faceHit, vert, target);
        }
        else if (!player.method_5715() && vertexOffsets[vert] < 16)
        {
            byte target = (byte) (vertexOffsets[vert] + 1);

            applyDeformation(vert, target, faceHit);
            deformNeighbors(faceHit, vert, target);
        }
    }

    @SuppressWarnings("ConstantConditions")
    private void applyDeformation(int vertex, byte offset, class_2350 faceHit)
    {
        offset = (byte) class_3532.method_15340(offset, (byte) 0, (byte) 16);

        if (offset == vertexOffsets[vertex])
        {
            return;
        }

        vertexOffsets[vertex] = offset;
        packedOffsets = packOffsets(vertexOffsets);

        if (offset == 0)
        {
            boolean noOffsets = true;
            for (int i = 0; i < 4; i++)
            {
                if (vertexOffsets[i] > 0)
                {
                    noOffsets = false;
                    break;
                }
            }

            if (noOffsets)
            {
                collapsedFace = null;
                field_11863.method_8652(field_11867, method_11010().method_11657(PropertyHolder.NULLABLE_FACE, NullableDirection.NONE), class_2248.field_31036);
            }
            else
            {
                field_11863.method_8413(field_11867, method_11010(), method_11010(), 3);
            }
        }
        else if (collapsedFace == null)
        {
            collapsedFace = faceHit;
            field_11863.method_8652(field_11867, method_11010().method_11657(PropertyHolder.NULLABLE_FACE, NullableDirection.fromDirection(collapsedFace)), class_2248.field_31036);
        }
        else
        {
            field_11863.method_8413(field_11867, method_11010(), method_11010(), 3);
        }

        method_5431();
    }

    private void deformNeighbors(class_2350 faceHit, int srcVert, byte offset)
    {
        NeighborVertex[] verts = VERTEX_MAPPINGS[getMappingIndex(faceHit, srcVert)];
        for (int i = 0; i < 3; i++)
        {
            NeighborVertex vert = verts[i];
            class_2338 pos = field_11867.method_10081(vert.offset);
            //noinspection ConstantConditions
            if (field_11863.method_8321(pos) instanceof FramedCollapsibleBlockEntity be)
            {
                if (be.collapsedFace == null || be.collapsedFace == faceHit)
                {
                    be.applyDeformation(vert.targetVert, offset, faceHit);
                }
            }
        }
    }

    public static int vertexFromHit(class_2350 faceHit, class_243 loc)
    {
        if (Utils.isY(faceHit))
        {
            double ax = Math.abs((loc.field_1352 - .5) * 4D);
            double az = Math.abs((loc.field_1350 - .5) * 4D);
            if (ax >= 0D && ax <= 1D && az >= 0D && az <= 1D && az <= (1D - ax))
            {
                return 4;
            }

            if ((loc.field_1350 < .5F) == (faceHit == class_2350.field_11036))
            {
                return loc.field_1352 < .5F ? 0 : 3;
            }
            else
            {
                return loc.field_1352 < .5F ? 1 : 2;
            }
        }
        else
        {
            double xz = Utils.isX(faceHit) ? loc.field_1350 : loc.field_1352;
            double axz = Math.abs((xz - .5) * 4D);
            double ay = Math.abs((loc.field_1351 - .5D) * 4D);
            if (axz >= 0D && axz <= 1D && ay >= 0D && ay <= 1D && ay <= (1D - axz))
            {
                return 4;
            }

            boolean positive = faceHit == class_2350.field_11035 || faceHit == class_2350.field_11039;
            if (loc.field_1351 < .5F)
            {
                return (xz < .5F) == positive ? 1 : 2;
            }
            else
            {
                return (xz < .5F) == positive ? 0 : 3;
            }
        }
    }

    public class_2350 getCollapsedFace()
    {
        return collapsedFace;
    }

    public byte[] getVertexOffsets()
    {
        return vertexOffsets;
    }

    public int getPackedOffsets()
    {
        return packedOffsets;
    }

    @Override
    public Object getRenderAttachmentData()
    {
        getModelDataInternal().setPackedOffsets(packedOffsets);
        return super.getRenderAttachmentData();
    }

    @Override
    protected void writeToDataPacket(class_2487 nbt)
    {
        super.writeToDataPacket(nbt);
        nbt.method_10569("offsets", packOffsets(vertexOffsets));
        nbt.method_10567("face", (byte) (collapsedFace == null ? -1 : collapsedFace.method_10146()));
    }

    @Override
    protected boolean readFromDataPacket(class_2487 nbt)
    {
        boolean needUpdate = super.readFromDataPacket(nbt);

        int packed = nbt.method_10550("offsets");
        if (packed != packedOffsets)
        {
            packedOffsets = packed;
            vertexOffsets = unpackOffsets(packedOffsets);

            needUpdate = true;
        }

        int faceIdx = nbt.method_10571("face");
        class_2350 face = faceIdx == -1 ? null : class_2350.method_10143(faceIdx);
        if (collapsedFace != face)
        {
            collapsedFace = face;

            needUpdate = true;
        }

        return needUpdate;
    }

    @Override
    public class_2487 method_16887()
    {
        class_2487 nbt = super.method_16887();
        nbt.method_10569("offsets", packedOffsets);
        nbt.method_10567("face", (byte) (collapsedFace == null ? -1 : collapsedFace.method_10146()));
        return nbt;
    }

    @Override
    public void handleUpdateTag(class_2487 nbt)
    {
        packedOffsets = nbt.method_10550("offsets");
        vertexOffsets = unpackOffsets(packedOffsets);

        int face = nbt.method_10571("face");
        collapsedFace = face == -1 ? null : class_2350.method_10143(face);

        super.handleUpdateTag(nbt);
    }

    @Override
    public void method_11007(class_2487 nbt)
    {
        super.method_11007(nbt);
        nbt.method_10569("offsets", packedOffsets);
        nbt.method_10569("face", collapsedFace == null ? -1 : collapsedFace.method_10146());
    }

    @Override
    public void method_11014(class_2487 nbt)
    {
        super.method_11014(nbt);
        packedOffsets = nbt.method_10550("offsets");
        vertexOffsets = unpackOffsets(packedOffsets);
        int face = nbt.method_10550("face");
        collapsedFace = face == -1 ? null : class_2350.method_10143(face);
    }



    public static int packOffsets(byte[] offsets)
    {
        int result = 0;

        for (int i = 0; i < 4; i++)
        {
            result |= (offsets[i] << (i * 5));
        }

        return result;
    }

    public static byte[] unpackOffsets(int packed)
    {
        byte[] offsets = new byte[4];

        for (int i = 0; i < 4; i++)
        {
            offsets[i] = (byte) (packed >> (i * 5) & 0x1F);
        }

        return offsets;
    }

    private static int getMappingIndex(class_2350 face, int srcVert)
    {
        return face.ordinal() * VERTEX_COUNT + srcVert;
    }

    private static NeighborVertex[][] makeVertexMapping()
    {
        NeighborVertex[][] mappings = new NeighborVertex[DIRECTIONS * VERTEX_COUNT][];

        putMapping(mappings, class_2350.field_11036, 0, new NeighborVertex(new class_2382(-1, 0,  0), 3), new NeighborVertex(new class_2382( 0, 0, -1), 1), new NeighborVertex(new class_2382(-1, 0, -1), 2));
        putMapping(mappings, class_2350.field_11036, 1, new NeighborVertex(new class_2382(-1, 0,  0), 2), new NeighborVertex(new class_2382( 0, 0,  1), 0), new NeighborVertex(new class_2382(-1, 0,  1), 3));
        putMapping(mappings, class_2350.field_11036, 2, new NeighborVertex(new class_2382( 1, 0,  0), 1), new NeighborVertex(new class_2382( 0, 0,  1), 3), new NeighborVertex(new class_2382( 1, 0,  1), 0));
        putMapping(mappings, class_2350.field_11036, 3, new NeighborVertex(new class_2382( 1, 0,  0), 0), new NeighborVertex(new class_2382( 0, 0, -1), 2), new NeighborVertex(new class_2382( 1, 0, -1), 1));

        putMapping(mappings, class_2350.field_11033, 0, new NeighborVertex(new class_2382(-1, 0,  0), 3), new NeighborVertex(new class_2382( 0, 0,  1), 1), new NeighborVertex(new class_2382(-1, 0,  1), 2));
        putMapping(mappings, class_2350.field_11033, 1, new NeighborVertex(new class_2382(-1, 0,  0), 2), new NeighborVertex(new class_2382( 0, 0, -1), 0), new NeighborVertex(new class_2382(-1, 0, -1), 3));
        putMapping(mappings, class_2350.field_11033, 2, new NeighborVertex(new class_2382( 1, 0,  0), 1), new NeighborVertex(new class_2382( 0, 0, -1), 3), new NeighborVertex(new class_2382( 1, 0, -1), 0));
        putMapping(mappings, class_2350.field_11033, 3, new NeighborVertex(new class_2382( 1, 0,  0), 0), new NeighborVertex(new class_2382( 0, 0,  1), 2), new NeighborVertex(new class_2382( 1, 0,  1), 1));

        putMapping(mappings, class_2350.field_11043, 0, new NeighborVertex(new class_2382( 1,  0, 0), 3), new NeighborVertex(new class_2382( 0,  1, 0), 1), new NeighborVertex(new class_2382( 1,  1, 0), 2));
        putMapping(mappings, class_2350.field_11043, 1, new NeighborVertex(new class_2382( 1,  0, 0), 2), new NeighborVertex(new class_2382( 0, -1, 0), 0), new NeighborVertex(new class_2382( 1, -1, 0), 3));
        putMapping(mappings, class_2350.field_11043, 2, new NeighborVertex(new class_2382(-1,  0, 0), 1), new NeighborVertex(new class_2382( 0, -1, 0), 3), new NeighborVertex(new class_2382(-1, -1, 0), 0));
        putMapping(mappings, class_2350.field_11043, 3, new NeighborVertex(new class_2382(-1,  0, 0), 0), new NeighborVertex(new class_2382( 0,  1, 0), 2), new NeighborVertex(new class_2382(-1,  1, 0), 1));

        putMapping(mappings, class_2350.field_11035, 0, new NeighborVertex(new class_2382(-1,  0, 0), 3), new NeighborVertex(new class_2382( 0,  1, 0), 1), new NeighborVertex(new class_2382(-1,  1, 0), 2));
        putMapping(mappings, class_2350.field_11035, 1, new NeighborVertex(new class_2382(-1,  0, 0), 2), new NeighborVertex(new class_2382( 0, -1, 0), 0), new NeighborVertex(new class_2382(-1, -1, 0), 3));
        putMapping(mappings, class_2350.field_11035, 2, new NeighborVertex(new class_2382( 1,  0, 0), 1), new NeighborVertex(new class_2382( 0, -1, 0), 3), new NeighborVertex(new class_2382( 1, -1, 0), 0));
        putMapping(mappings, class_2350.field_11035, 3, new NeighborVertex(new class_2382( 1,  0, 0), 0), new NeighborVertex(new class_2382( 0,  1, 0), 2), new NeighborVertex(new class_2382( 1,  1, 0), 1));

        putMapping(mappings, class_2350.field_11034, 0, new NeighborVertex(new class_2382(0,  0,  1), 3), new NeighborVertex(new class_2382( 0,  1, 0), 1), new NeighborVertex(new class_2382(0,  1,  1), 2));
        putMapping(mappings, class_2350.field_11034, 1, new NeighborVertex(new class_2382(0,  0,  1), 2), new NeighborVertex(new class_2382( 0, -1, 0), 0), new NeighborVertex(new class_2382(0, -1,  1), 3));
        putMapping(mappings, class_2350.field_11034, 2, new NeighborVertex(new class_2382(0,  0, -1), 1), new NeighborVertex(new class_2382( 0, -1, 0), 3), new NeighborVertex(new class_2382(0, -1, -1), 0));
        putMapping(mappings, class_2350.field_11034, 3, new NeighborVertex(new class_2382(0,  0, -1), 0), new NeighborVertex(new class_2382( 0,  1, 0), 2), new NeighborVertex(new class_2382(0,  1, -1), 1));

        putMapping(mappings, class_2350.field_11039, 0, new NeighborVertex(new class_2382(0,  0, -1), 3), new NeighborVertex(new class_2382( 0,  1, 0), 1), new NeighborVertex(new class_2382(0,  1, -1), 2));
        putMapping(mappings, class_2350.field_11039, 1, new NeighborVertex(new class_2382(0,  0, -1), 2), new NeighborVertex(new class_2382( 0, -1, 0), 0), new NeighborVertex(new class_2382(0, -1, -1), 3));
        putMapping(mappings, class_2350.field_11039, 2, new NeighborVertex(new class_2382(0,  0,  1), 1), new NeighborVertex(new class_2382( 0, -1, 0), 3), new NeighborVertex(new class_2382(0, -1,  1), 0));
        putMapping(mappings, class_2350.field_11039, 3, new NeighborVertex(new class_2382(0,  0,  1), 0), new NeighborVertex(new class_2382( 0,  1, 0), 2), new NeighborVertex(new class_2382(0,  1,  1), 1));

        return mappings;
    }

    private static void putMapping(
            NeighborVertex[][] mappings,
            class_2350 face,
            int srcVert,
            NeighborVertex vertOne,
            NeighborVertex vertTwo,
            NeighborVertex vertBoth
    )
    {
        mappings[getMappingIndex(face, srcVert)] = new NeighborVertex[] { vertOne, vertTwo, vertBoth };
    }

    private record NeighborVertex(class_2382 offset, int targetVert) { }
}