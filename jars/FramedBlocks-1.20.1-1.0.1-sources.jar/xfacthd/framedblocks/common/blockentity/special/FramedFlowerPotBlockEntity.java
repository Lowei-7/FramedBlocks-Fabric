package xfacthd.framedblocks.common.blockentity.special;

import xfacthd.framedblocks.api.model.data.FramedBlockData;
import xfacthd.framedblocks.api.block.FramedBlockEntity;
import xfacthd.framedblocks.common.FBContent;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_2960;

public class FramedFlowerPotBlockEntity extends FramedBlockEntity
{
    public static final FramedBlockData.Property<class_2248> FLOWER_BLOCK = new FramedBlockData.Property<>();

    private class_2248 flowerBlock = class_2246.field_10124;

    public FramedFlowerPotBlockEntity(class_2338 pos, class_2680 state)
    {
        super(FBContent.BE_TYPE_FRAMED_FLOWER_POT.get(), pos, state);
    }

    public void setFlowerBlock(class_2248 flowerBlock)
    {
        if (flowerBlock != this.flowerBlock)
        {
            this.flowerBlock = flowerBlock;

            method_5431();

            //noinspection ConstantConditions
            field_11863.method_8413(field_11867, method_11010(), method_11010(), 3);
        }
    }

    public boolean hasFlowerBlock()
    {
        return flowerBlock != class_2246.field_10124;
    }

    public class_2248 getFlowerBlock()
    {
        return flowerBlock;
    }

    @Override
    public void addAdditionalDrops(List<class_1799> drops, boolean dropCamo)
    {
        super.addAdditionalDrops(drops, dropCamo);
        if (flowerBlock != class_2246.field_10124)
        {
            drops.add(new class_1799(flowerBlock));
        }
    }

    @Override
    public Object getRenderAttachmentData()
    {
        return super.getRenderAttachmentData();
    }

    @Override
    protected void writeToDataPacket(class_2487 nbt)
    {
        super.writeToDataPacket(nbt);
        //noinspection ConstantConditions
        nbt.method_10582("flower", net.minecraft.class_7923.field_41175.method_10221(flowerBlock).toString());
    }

    @Override
    protected boolean readFromDataPacket(class_2487 nbt)
    {
        class_2248 flower = net.minecraft.class_7923.field_41175.method_10223(new class_2960(nbt.method_10558("flower")));

        boolean update = flower != flowerBlock;
        if (update)
        {
            flowerBlock = flower;
        }

        return super.readFromDataPacket(nbt) || update;
    }

    @Override
    public class_2487 method_16887()
    {
        class_2487 nbt = super.method_16887();

        //noinspection ConstantConditions
        nbt.method_10582("flower", net.minecraft.class_7923.field_41175.method_10221(flowerBlock).toString());

        return nbt;
    }

    @Override
    public class_2487 writeToBlueprint()
    {
        class_2487 tag = method_38244();
        tag.method_10551("flower");
        return tag;
    }

    @Override
    public void handleUpdateTag(class_2487 nbt)
    {
        super.handleUpdateTag(nbt);

        class_2248 flower = net.minecraft.class_7923.field_41175.method_10223(new class_2960(nbt.method_10558("flower")));
        if (flower != flowerBlock)
        {
            flowerBlock = flower;
        }
    }

    @Override
    public void method_11007(class_2487 nbt)
    {
        //noinspection ConstantConditions
        nbt.method_10582("flower", net.minecraft.class_7923.field_41175.method_10221(flowerBlock).toString());
        super.method_11007(nbt);
    }

    @Override
    public void method_11014(class_2487 nbt)
    {
        super.method_11014(nbt);
        flowerBlock = net.minecraft.class_7923.field_41175.method_10223(new class_2960(nbt.method_10558("flower")));
    }
}