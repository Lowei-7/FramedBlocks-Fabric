package xfacthd.framedblocks.common.blockentity.special;

import xfacthd.framedblocks.api.block.FramedBlockEntity;
import xfacthd.framedblocks.common.FBContent;

import java.util.UUID;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2512;
import net.minecraft.class_2591;
import net.minecraft.class_2680;

public class FramedOwnableBlockEntity extends FramedBlockEntity
{
    private UUID owner;

    protected FramedOwnableBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state)
    {
        super(type, pos, state);
    }

    public FramedOwnableBlockEntity(class_2338 pos, class_2680 state)
    {
        this(FBContent.BE_TYPE_FRAMED_OWNABLE_BLOCK.get(), pos, state);
    }

    public void setOwner(UUID owner, boolean forceSync)
    {
        this.owner = owner;
        method_5431();

        if (forceSync)
        {
            //noinspection ConstantConditions
            field_11863.method_8413(field_11867, method_11010(), method_11010(), class_2248.field_31036);
        }
    }

    public UUID getOwner()
    {
        return owner;
    }

    @Override
    protected void writeToDataPacket(class_2487 nbt)
    {
        super.writeToDataPacket(nbt);
        if (owner != null)
        {
            nbt.method_10566("owner", class_2512.method_25929(owner));
        }
    }

    @Override
    protected boolean readFromDataPacket(class_2487 nbt)
    {
        if (nbt.method_10545("owner"))
        {
            //noinspection ConstantConditions
            owner = class_2512.method_25930(nbt.method_10580("owner"));
        }
        return super.readFromDataPacket(nbt);
    }

    @Override
    public class_2487 method_16887()
    {
        class_2487 tag = super.method_16887();
        if (owner != null)
        {
            tag.method_25927("owner", owner);
        }
        return tag;
    }

    @Override
    public void handleUpdateTag(class_2487 nbt)
    {
        super.handleUpdateTag(nbt);
        if (nbt.method_10545("owner"))
        {
            //noinspection ConstantConditions
            owner = nbt.method_25926("owner");
        }
    }

    @Override
    public void method_11007(class_2487 tag)
    {
        super.method_11007(tag);
        if (owner != null)
        {
            tag.method_25927("owner", owner);
        }
    }

    @Override
    public void method_11014(class_2487 tag)
    {
        super.method_11014(tag);
        if (tag.method_10545("owner"))
        {
            //noinspection ConstantConditions
            owner = tag.method_25926("owner");
        }
    }
}
