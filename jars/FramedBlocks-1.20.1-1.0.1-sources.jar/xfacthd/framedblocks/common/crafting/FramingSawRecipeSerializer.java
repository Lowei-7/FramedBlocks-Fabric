package xfacthd.framedblocks.common.crafting;

import com.google.gson.*;
import xfacthd.framedblocks.api.block.IFramedBlock;
import xfacthd.framedblocks.api.type.IBlockType;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3518;

public final class FramingSawRecipeSerializer implements class_1865<FramingSawRecipe>
{
    @Override
    public FramingSawRecipe method_8121(class_2960 recipeId, JsonObject json)
    {
        boolean disabled = class_3518.method_15258(json, "disabled", false);

        int material = class_3518.method_15260(json, "material");
        if (material <= 0)
        {
            throw new JsonSyntaxException("Value of 'material' must be greater than 0");
        }

        List<FramingSawRecipeAdditive> additives = new ArrayList<>();
        if (json.has("additives"))
        {
            JsonArray additiveArr = class_3518.method_15261(json, "additives");
            if (additiveArr.size() > FramingSawRecipe.MAX_ADDITIVE_COUNT)
            {
                throw new JsonSyntaxException("More than 3 additives are not supported");
            }

            for (JsonElement additiveElem : additiveArr)
            {
                JsonObject additiveObj = additiveElem.getAsJsonObject();
                class_1856 additive = class_1856.method_52177(additiveObj.get("ingredient"));
                int additiveCount = class_3518.method_15260(additiveObj, "count");
                if (additiveCount <= 0)
                {
                    throw new JsonSyntaxException("Value of 'additive_count' must be greater than 0");
                }
                additives.add(new FramingSawRecipeAdditive(additive, additiveCount));
            }
        }

        JsonObject resultObj = class_3518.method_15296(json, "result");
        class_1799 result = net.minecraft.class_1869.method_35228(resultObj);
        IBlockType resultType = findResultType(result);

        return new FramingSawRecipe(recipeId, material, additives, result, resultType, disabled);
    }

    @Override
    public FramingSawRecipe method_8122(class_2960 recipeId, class_2540 buffer)
    {
        int material = buffer.readInt();

        int count = buffer.readInt();
        List<FramingSawRecipeAdditive> additives = new ArrayList<>(count);
        for (int i = 0; i < count; i++)
        {
            class_1856 additive = class_1856.method_8086(buffer);
            int additiveCount = buffer.readInt();
            additives.add(new FramingSawRecipeAdditive(additive, additiveCount));
        }

        class_1799 result = buffer.method_10819();
        IBlockType resultType = findResultType(result);
        boolean disabled = buffer.readBoolean();

        return new FramingSawRecipe(recipeId, material, additives, result, resultType, disabled);
    }

    @Override
    public void toNetwork(class_2540 buffer, FramingSawRecipe recipe)
    {
        buffer.writeInt(recipe.getMaterialAmount());

        List<FramingSawRecipeAdditive> additives = recipe.getAdditives();
        buffer.writeInt(additives.size());
        for (FramingSawRecipeAdditive additive : additives)
        {
            additive.ingredient().method_8088(buffer);
            buffer.writeInt(additive.count());
        }

        buffer.method_10793(recipe.getResult());
        buffer.writeBoolean(recipe.isDisabled());
    }

    private static IBlockType findResultType(class_1799 result)
    {
        if (!(result.method_7909() instanceof class_1747 item))
        {
            throw new JsonSyntaxException("Result items must be BlockItems");
        }
        if (!(item.method_7711() instanceof IFramedBlock block))
        {
            throw new JsonSyntaxException("Block of result items must be IFramedBlocks");
        }
        return block.getBlockType();
    }
}
