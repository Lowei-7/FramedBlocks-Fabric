package xfacthd.framedblocks.common.crafting;

import com.google.common.base.Preconditions;
import net.minecraft.class_1792;
import net.minecraft.class_1856;
import net.minecraft.class_1935;
import net.minecraft.class_6862;

public record FramingSawRecipeAdditive(class_1856 ingredient, int count)
{
    public FramingSawRecipeAdditive
    {
        Preconditions.checkArgument(ingredient != null, "Additive ingredient must be non-null");
        Preconditions.checkArgument(count > 0, "Additive count must be greater than 0");
    }

    public static FramingSawRecipeAdditive of(class_6862<class_1792> tag)
    {
        return of(tag, 1);
    }

    public static FramingSawRecipeAdditive of(class_6862<class_1792> tag, int count)
    {
        return new FramingSawRecipeAdditive(class_1856.method_8106(tag), count);
    }

    public static FramingSawRecipeAdditive of(class_1935 item)
    {
        return of(item, 1);
    }

    public static FramingSawRecipeAdditive of(class_1935 item, int count)
    {
        return new FramingSawRecipeAdditive(class_1856.method_8091(item), count);
    }
}
