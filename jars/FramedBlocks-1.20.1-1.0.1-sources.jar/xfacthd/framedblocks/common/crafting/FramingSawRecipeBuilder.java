package xfacthd.framedblocks.common.crafting;

import com.google.common.base.Preconditions;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.minecraft.advancements.*;
import net.minecraft.class_1792;
import net.minecraft.class_184;
import net.minecraft.class_1865;
import net.minecraft.class_1935;
import net.minecraft.class_2444;
import net.minecraft.class_2960;
import net.minecraft.class_5797;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.util.fabric.RegistryObject;

import java.util.*;
import java.util.function.Consumer;

public final class FramingSawRecipeBuilder implements class_5797
{
    private final class_1792 result;
    private final int count;
    private int material = 0;
    private List<FramingSawRecipeAdditive> additives = null;
    private boolean disabled = false;

    private FramingSawRecipeBuilder(class_1935 result, int count)
    {
        this.result = result.method_8389();
        this.count = count;
    }

    public static <T extends class_1935> FramingSawRecipeBuilder builder(RegistryObject<T> result)
    {
        return builder(result.get());
    }

    public static FramingSawRecipeBuilder builder(class_1935 result)
    {
        return builder(result, 1);
    }

    public static <T extends class_1935> FramingSawRecipeBuilder builder(RegistryObject<T> result, int count)
    {
        return builder(result.get(), count);
    }

    public static FramingSawRecipeBuilder builder(class_1935 result, int count)
    {
        Preconditions.checkNotNull(result, "Result must be non-null");
        Preconditions.checkArgument(count > 0, "Result count must be greater than 0");
        return new FramingSawRecipeBuilder(result, count);
    }

    public FramingSawRecipeBuilder material(int material)
    {
        Preconditions.checkArgument(material > 0, "Material value must be greater than 0");
        this.material = material;
        return this;
    }

    public FramingSawRecipeBuilder additive(FramingSawRecipeAdditive additive)
    {
        this.additives = additive != null ? List.of(additive) : null;
        return this;
    }

    public FramingSawRecipeBuilder additives(List<FramingSawRecipeAdditive> additives)
    {
        this.additives = additives;
        return this;
    }

    public FramingSawRecipeBuilder disabled()
    {
        this.disabled = true;
        return this;
    }

    @Override
    public class_5797 method_33530(String criterionName, class_184 criterionTrigger)
    {
        throw new UnsupportedOperationException("Advancements are not supported");
    }

    @Override
    public class_5797 method_33529(@Nullable String groupName)
    {
        throw new UnsupportedOperationException("Recipe groups are not supported");
    }

    @Override
    public class_1792 method_36441()
    {
        return result;
    }

    @Override
    public void method_17972(Consumer<class_2444> finishedRecipeConsumer, class_2960 recipeId)
    {
        Preconditions.checkState(material > 0, "Material value not set");
        Preconditions.checkState(material / count * count == material, "Material value not divisible by result size");

        recipeId = recipeId.method_45138("framing_saw/");
        finishedRecipeConsumer.accept(new Result(recipeId, result, count, material, additives, disabled));
    }



    private record Result(
            class_2960 id,
            class_1792 result,
            int count,
            int material,
            List<FramingSawRecipeAdditive> additives,
            boolean disabled
    ) implements class_2444
    {
        @Override
        public void method_10416(JsonObject json)
        {
            json.addProperty("material", material);

            if (additives != null)
            {
                JsonArray additiveArr = new JsonArray();
                additives.forEach(add ->
                {
                    JsonObject additive = new JsonObject();
                    additive.add("ingredient", add.ingredient().method_8089());
                    additive.addProperty("count", add.count());
                    additiveArr.add(additive);
                });
                json.add("additives", additiveArr);
            }

            JsonObject resultObj = new JsonObject();
            resultObj.addProperty("item", Objects.requireNonNull(net.minecraft.class_7923.field_41178.method_10221(result)).toString());
            if (count > 1)
            {
                resultObj.addProperty("count", count);
            }
            json.add("result", resultObj);

            if (disabled)
            {
                json.addProperty("disabled", true);
            }
        }

        @Override
        public JsonObject method_10415()
        {
            return null;
        }

        @Override
        public class_2960 method_10417()
        {
            return id;
        }

        @Override
        public class_2960 method_10418()
        {
            return null;
        }

        @Override
        public class_1865<?> method_17800()
        {
            return FBContent.RECIPE_SERIALIZER_FRAMING_SAW_RECIPE.get();
        }
    }
}
