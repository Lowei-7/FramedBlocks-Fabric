package xfacthd.framedblocks.common.crafting;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenCustomHashMap;
import net.minecraft.class_156;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1863;
import net.minecraft.class_8786;
import net.minecraft.world.item.*;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.type.IBlockType;
import xfacthd.framedblocks.api.util.FramedConstants;
import xfacthd.framedblocks.common.FBContent;

import java.util.*;

public final class FramingSawRecipeCache
{
    private static final FramingSawRecipeCache SERVER_INSTANCE = new FramingSawRecipeCache();
    private static final FramingSawRecipeCache CLIENT_INSTANCE = new FramingSawRecipeCache();

    private final List<FramingSawRecipe> recipes = new ArrayList<>();
    private final Map<class_1792, FramingSawRecipe> recipesByResult = new IdentityHashMap<>();
    private final Map<class_1792, FramingSawRecipe> recipesWithAdditives = new IdentityHashMap<>();
    private final Object2IntMap<class_1792> materialValues = new Object2IntOpenCustomHashMap<>(class_156.method_655());

    public void update(class_1863 recipeManager)
    {
        clear();

        recipes.addAll(recipeManager.method_30027(FBContent.RECIPE_TYPE_FRAMING_SAW_RECIPE.get())
                .stream()
                .peek(holder -> holder.comp_1933().setId(holder.comp_1932()))
                .map(class_8786::comp_1933)
                .toList());
        recipes.sort(FramingSawRecipeCache::sortRecipes);

        recipes.forEach(recipe ->
        {
            class_1799 result = recipe.getResult();

            int materialValue = recipe.getMaterialAmount();
            materialValues.put(result.method_7909(), materialValue / result.method_7947());
        });

        // Remove disabled recipes after extracting material values
        recipes.removeIf(FramingSawRecipe::isDisabled);

        recipes.forEach(recipe ->
        {
            class_1799 result = recipe.getResult();

            recipesByResult.put(result.method_7909(), recipe);

            if (!recipe.getAdditives().isEmpty())
            {
                recipesWithAdditives.put(result.method_7909(), recipe);
            }
        });
    }

    public void clear()
    {
        recipes.clear();
        recipesByResult.clear();
        recipesWithAdditives.clear();
        materialValues.clear();
    }

    public List<FramingSawRecipe> getRecipes()
    {
        return Collections.unmodifiableList(recipes);
    }

    @Nullable
    public FramingSawRecipe findRecipeFor(class_1799 result)
    {
        return recipesByResult.get(result.method_7909());
    }

    public Set<class_1792> getKnownItems()
    {
        return materialValues.keySet();
    }

    public int getMaterialValue(class_1792 item)
    {
        return materialValues.getOrDefault(item, -1);
    }

    public boolean containsAdditive(class_1792 item)
    {
        return recipesWithAdditives.containsKey(item);
    }

    public List<FramingSawRecipe> getRecipesWithAdditive(class_1799 additive)
    {
        return recipesWithAdditives.values()
                .stream()
                .filter(recipe -> recipe.getAdditives()
                        .stream()
                        .map(FramingSawRecipeAdditive::ingredient)
                        .anyMatch(ing -> ing.method_8093(additive))
                )
                .toList();
    }



    public static FramingSawRecipeCache get(boolean client)
    {
        return client ? CLIENT_INSTANCE : SERVER_INSTANCE;
    }

    private static int sortRecipes(FramingSawRecipe r1, FramingSawRecipe r2)
    {
        return sortRecipes(r1.getResult(), r2.getResult(), r1.getResultType(), r2.getResultType());
    }

    public static int sortRecipes(class_1799 resultOne, class_1799 resultTwo, IBlockType typeOne, IBlockType typeTwo)
    {
        //noinspection ConstantConditions
        String ns1 = net.minecraft.class_7923.field_41178.method_10221(resultOne.method_7909()).method_12836();
        //noinspection ConstantConditions
        String ns2 = net.minecraft.class_7923.field_41178.method_10221(resultTwo.method_7909()).method_12836();

        if (!ns1.equals(ns2))
        {
            if (ns1.equals(FramedConstants.MOD_ID))
            {
                return -1;
            }
            if (ns2.equals(FramedConstants.MOD_ID))
            {
                return 1;
            }
            return ns1.compareTo(ns2);
        }

        // Assume that items from the same namespace use the same IBlockType implementation and are therefore comparable
        return typeOne.compareTo(typeTwo);
    }




}
