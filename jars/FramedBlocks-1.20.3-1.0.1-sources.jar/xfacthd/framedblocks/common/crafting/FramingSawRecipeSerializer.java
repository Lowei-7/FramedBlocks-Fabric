package xfacthd.framedblocks.common.crafting;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import xfacthd.framedblocks.api.block.IFramedBlock;
import xfacthd.framedblocks.api.type.IBlockType;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_2540;

public final class FramingSawRecipeSerializer implements class_1865<FramingSawRecipe>
{
    public static final Codec<FramingSawRecipe> CODEC = RecordCodecBuilder.create(inst -> inst.group(
            Codec.INT.fieldOf("material").forGetter(FramingSawRecipe::getMaterialAmount),
            FramingSawRecipeAdditive.LIST_CODEC.optionalFieldOf("additives", List.of()).forGetter(FramingSawRecipe::getAdditives),
            class_1799.field_24671.fieldOf("result").forGetter(FramingSawRecipe::getResult),
            Codec.BOOL.optionalFieldOf("disabled", false).forGetter(FramingSawRecipe::isDisabled)
    ).apply(inst, FramingSawRecipe::new));

    @Override
    public Codec<FramingSawRecipe> method_53736()
    {
        return CODEC;
    }

    @Override
    public FramingSawRecipe method_8122(class_2540 buffer)
    {
        int material = buffer.readInt();

        int count = buffer.readInt();
        List<FramingSawRecipeAdditive> additives = new ArrayList<>(count);
        for (int i = 0; i < count; i++)
        {
            class_1856 additive = class_1856.method_8086(buffer);
            int additiveCount = buffer.readInt();
            additives.add(new FramingSawRecipeAdditive(additive, additiveCount));
        }

        class_1799 result = buffer.method_10819();
        boolean disabled = buffer.readBoolean();

        return new FramingSawRecipe(material, additives, result, disabled);
    }

    @Override
    public void toNetwork(class_2540 buffer, FramingSawRecipe recipe)
    {
        buffer.method_53002(recipe.getMaterialAmount());

        List<FramingSawRecipeAdditive> additives = recipe.getAdditives();
        buffer.method_53002(additives.size());
        for (FramingSawRecipeAdditive additive : additives)
        {
            additive.ingredient().method_8088(buffer);
            buffer.method_53002(additive.count());
        }

        buffer.method_10793(recipe.getResult());
        buffer.method_52964(recipe.isDisabled());
    }

    static IBlockType findResultType(class_1799 result)
    {
        if (!(result.method_7909() instanceof class_1747 item))
        {
            throw new IllegalArgumentException("Result items must be BlockItems");
        }
        if (!(item.method_7711() instanceof IFramedBlock block))
        {
            throw new IllegalArgumentException("Block of result items must be IFramedBlocks");
        }
        return block.getBlockType();
    }
}
