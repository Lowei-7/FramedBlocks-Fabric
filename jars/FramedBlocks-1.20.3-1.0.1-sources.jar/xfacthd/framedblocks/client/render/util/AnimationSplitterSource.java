package xfacthd.framedblocks.client.render.util;

import com.google.common.base.Preconditions;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_1011;
import net.minecraft.class_1047;
import net.minecraft.class_1079;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_5699;
import net.minecraft.class_7368;
import net.minecraft.class_7764;
import net.minecraft.class_7771;
import net.minecraft.class_7948;
import net.minecraft.class_7951;
import net.minecraft.class_7958;
import net.minecraft.class_8684;
import net.minecraft.client.renderer.texture.atlas.*;
import net.minecraft.client.resources.metadata.animation.*;
import xfacthd.framedblocks.FramedBlocks;
import xfacthd.framedblocks.api.util.FramedConstants;
import xfacthd.framedblocks.mixin.SpriteSourcesAccessor;

import java.util.List;
import java.util.Optional;

public class AnimationSplitterSource implements class_7948
{
    private static class_7951 TYPE = null;
    private static final Codec<AnimationSplitterSource> CODEC = RecordCodecBuilder.create(inst -> inst.group(
            class_2960.field_25139.fieldOf("resource").forGetter(s -> s.resource),
            class_5699.method_36973(Frame.CODEC.listOf()).fieldOf("frames").forGetter(s -> s.frames)
    ).apply(inst, AnimationSplitterSource::new));

    private final class_2960 resource;
    private final List<Frame> frames;

    public AnimationSplitterSource(class_2960 resource, List<Frame> frames)
    {
        this.resource = resource;
        this.frames = frames;
    }

    @Override
    public void method_47673(class_3300 mgr, class_7949 out)
    {
        class_2960 texPath = field_42075.method_45112(resource);
        Optional<class_3298> optResource = mgr.method_14486(texPath);
        if (optResource.isPresent())
        {
            class_3298 res = optResource.get();
            class_7958 image = new class_7958(texPath, res, frames.size());
            frames.forEach(frame -> out.method_47670(frame.outLoc, createFrameInstance(res, texPath, image, frame)));
        }
        else
        {
            FramedBlocks.LOGGER.warn("Missing sprite: {}", texPath);
        }
    }

    FrameInstance createFrameInstance(class_3298 res, class_2960 texPath, class_7958 image, Frame frame)
    {
        return new FrameInstance(res, texPath, image, frame);
    }

    @Override
    public class_7951 method_47672()
    {
        Preconditions.checkNotNull(TYPE, "SpriteSourceType not registered");
        return TYPE;
    }



    public record Frame(int frameIdx, class_2960 outLoc)
    {
        private static final Codec<Frame> CODEC = RecordCodecBuilder.create(inst -> inst.group(
                Codec.intRange(0, Integer.MAX_VALUE).fieldOf("frame_idx").forGetter(Frame::frameIdx),
                class_2960.field_25139.fieldOf("sprite").forGetter(Frame::outLoc)
        ).apply(inst, Frame::new));
    }

    static class FrameInstance implements class_7950
    {
        final class_3298 resource;
        private final class_2960 texPath;
        private final class_7958 lazyImage;
        private final Frame frame;

        FrameInstance(class_3298 resource, class_2960 texPath, class_7958 lazyImage, Frame frame)
        {
            this.resource = resource;
            this.texPath = texPath;
            this.lazyImage = lazyImage;
            this.frame = frame;
        }

        @Override
        public class_7764 apply(class_8684 spriteResourceLoader)
        {
            try
            {
                Optional<class_1079> optAnim = resource.method_14481().method_43041(class_1079.field_5337);
                if (optAnim.isEmpty())
                {
                    throw new IllegalArgumentException("Texture '%s' is not an animated texture".formatted(texPath));
                }

                class_1011 image = lazyImage.method_47697();
                int imgW = image.method_4307();
                int imgH = image.method_4323();

                class_1079 anim = optAnim.get();
                class_7771 size = anim.method_24143(imgW, imgH);
                int frameW = size.comp_1049();
                int frameH = size.comp_1050();

                int rowSize = (imgW / frameW) * (imgH / frameH);
                checkFrameExists(texPath, anim, frame.frameIdx, rowSize);
                int srcX = (frame.frameIdx % rowSize) * frameW;
                int srcY = (frame.frameIdx / rowSize) * frameH;

                class_1011 imageOut = new class_1011(class_1011.class_1012.field_4997, frameW, frameH, false);
                image.method_47594(imageOut, srcX, srcY, 0, 0, frameW, frameH, false, false);
                return postProcess(new class_7764(frame.outLoc, new class_7771(frameW, frameH), imageOut, class_7368.field_38688));
            }
            catch (Exception e)
            {
                FramedBlocks.LOGGER.error("Failed to split out frame {}", frame, e);
            }
            finally
            {
                lazyImage.method_47698();
            }
            return class_1047.method_45805();
        }

        class_7764 postProcess(class_7764 contents)
        {
            return contents;
        }

        private static void checkFrameExists(
                class_2960 texPath, class_1079 anim, int frameIdx, int rowSize
        )
        {
            boolean[] frameFound = new boolean[1];
            int[] maxIdx = new int[] { -1 };
            anim.method_33460((idx, time) ->
            {
                maxIdx[0] = Math.max(maxIdx[0], idx);
                if (idx == frameIdx)
                {
                    frameFound[0] = true;
                }
            });
            if (!frameFound[0] && (maxIdx[0] != -1 || frameIdx >= rowSize))
            {
                int max = maxIdx[0] != -1 ? maxIdx[0] : rowSize;
                throw new IllegalArgumentException("Texture '%s' has no frame with index %d, max index is %d".formatted(
                        texPath, frameIdx, max
                ));
            }
        }

        @Override
        public void method_47676()
        {
            lazyImage.method_47698();
        }
    }



    // TODO: replace with dedicated event when switching to Neo and the event is merged
    public static void register()
    {
        String name = FramedConstants.MOD_ID + ":anim_splitter";
        TYPE = SpriteSourcesAccessor.register(name, CODEC);
    }
}
