package xfacthd.framedblocks.client.screen;

import com.mojang.blaze3d.systems.RenderSystem;
import org.lwjgl.glfw.GLFW;
import xfacthd.framedblocks.FramedBlocks;
import xfacthd.framedblocks.api.util.ClientUtils;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.crafting.*;
import xfacthd.framedblocks.common.menu.FramingSawMenu;
import xfacthd.framedblocks.common.menu.IFramingSawMenu;
import xfacthd.framedblocks.common.net.SelectFramingSawRecipePacket;
import xfacthd.framedblocks.common.net.NetworkingHandler;
import xfacthd.framedblocks.common.util.RecipeUtils;

import java.util.*;
import net.minecraft.class_1041;
import net.minecraft.class_1109;
import net.minecraft.class_124;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_312;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_465;
import net.minecraft.class_5250;
import net.minecraft.class_5632;
import net.minecraft.class_6862;
import net.minecraft.class_757;

public class FramingSawScreen extends class_465<FramingSawMenu>
{
    public static final String TOOLTIP_MATERIAL = Utils.translationKey("tooltip", "framing_saw.material");
    public static final class_2561 TOOLTIP_LOOSE_ADDITIVE = Utils.translate("tooltip", "framing_saw.loose_additive");
    public static final String TOOLTIP_HAVE_X_BUT_NEED_Y_ITEM = Utils.translationKey("tooltip", "framing_saw.have_x_but_need_y_item");
    public static final String TOOLTIP_HAVE_X_BUT_NEED_Y_TAG = Utils.translationKey("tooltip", "framing_saw.have_x_but_need_y_tag");
    public static final String TOOLTIP_HAVE_X_BUT_NEED_Y_ITEM_COUNT = Utils.translationKey("tooltip", "framing_saw.have_x_but_need_y_item_count");
    public static final String TOOLTIP_HAVE_X_BUT_NEED_Y_MATERIAL_COUNT = Utils.translationKey("tooltip", "framing_saw.have_x_but_need_y_material_count");
    public static final String TOOLTIP_OUTPUT_COUNT = Utils.translationKey("tooltip", "framing_saw.output_count");
    public static final class_2561 TOOLTIP_HAVE_ITEM_NONE = Utils.translate("tooltip", "framing_saw.have_item_none").method_27692(class_124.field_1065);
    public static final String TOOLTIP_PRESS_TO_SHOW = Utils.translationKey("tooltip", "framing_saw.press_to_show");
    private static final class_2960 BACKGROUND = Utils.rl("textures/gui/framing_saw.png");
    public static final class_2960 WARNING_ICON = new class_2960("forge", "textures/gui/experimental_warning.png");
    private static final int IMAGE_WIDTH = 256;
    private static final int IMAGE_HEIGHT = 233;
    private static final int RECIPES_X = 48;
    private static final int RECIPES_Y = 18;
    private static final int RECIPE_ROWS = 6;
    private static final int RECIPE_COLS = 8;
    private static final int RECIPE_COUNT = RECIPE_ROWS * RECIPE_COLS;
    private static final int RECIPE_WIDTH = 18;
    private static final int RECIPE_HEIGHT = 18;
    private static final int SCROLL_BAR_X = 195;
    private static final int SCROLL_BAR_Y = 18;
    private static final int SCROLL_BTN_WIDTH = 12;
    private static final int SCROLL_BTN_HEIGHT = 15;
    private static final int SCROLL_BTN_TEX_X = RECIPE_WIDTH * 3;
    private static final int SCROLL_BAR_HEIGHT = 108;
    private static final int WARNING_X = 20;
    private static final int WARNING_Y = 46;
    // Recipe viewer disabled for Fabric

    private final FramingSawRecipeCache cache = FramingSawRecipeCache.get(true);
    private final class_1799 cubeStack = new class_1799(FBContent.BLOCK_FRAMED_CUBE.get());
    private int firstIndex = 0;
    private boolean scrolling = false;
    private float scrollOffset = 0F;

    public FramingSawScreen(FramingSawMenu menu, class_1661 inv, class_2561 title)
    {
        super(menu, inv, title);
        field_25268 -= 1;
        field_25269 = 47;
        field_25270 = 139;
        field_2792 = IMAGE_WIDTH;
        field_2779 = IMAGE_HEIGHT;
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick)
    {
        super.method_25394(graphics, mouseX, mouseY, partialTick);
        method_2380(graphics, mouseX, mouseY);
    }

    @Override
    protected void method_2389(class_332 graphics, float partialTick, int mouseX, int mouseY)
    {
        method_25420(graphics, mouseX, mouseY, partialTick);

        RenderSystem.setShader(class_757::method_34542);
        RenderSystem.setShaderColor(1F, 1F, 1F, 1F);

        graphics.method_25302(BACKGROUND, field_2776, field_2800, 0, 0, field_2792, field_2779);
        int offset = (int) ((SCROLL_BAR_HEIGHT - SCROLL_BTN_HEIGHT) * scrollOffset);
        int scrollU = SCROLL_BTN_TEX_X + (isScrollBarActive() ? 0 : SCROLL_BTN_WIDTH);
        graphics.method_25302(BACKGROUND, field_2776 + SCROLL_BAR_X, field_2800 + SCROLL_BAR_Y + offset, scrollU, field_2779, SCROLL_BTN_WIDTH, SCROLL_BTN_HEIGHT);

        class_1799 input = field_2797.getInputStack();
        if (!input.method_7960() && cache.containsAdditive(input.method_7909()))
        {
            graphics.method_25290(WARNING_ICON, field_2776 + WARNING_X, field_2800 + WARNING_Y, 8, 8, 24, 24, 32, 32);
        }

        int idx = field_2797.getSelectedRecipeIndex();
        if (field_2797.hasRecipeChanged())
        {
            tryScrollToRecipe(idx);
        }

        int recX = field_2776 + RECIPES_X;
        int recY = field_2800 + RECIPES_Y;
        int lastIndex = firstIndex + RECIPE_COUNT;
        renderButtons(graphics, mouseX, mouseY, recX, recY, lastIndex);
        renderRecipes(graphics, recX, recY, lastIndex);

        List<FramingSawRecipe> recipes = cache.getRecipes();
        if (idx >= 0 && idx < recipes.size())
        {
            FramingSawRecipe recipe = recipes.get(idx);
            if (input.method_7960())
            {
                ClientUtils.renderTransparentFakeItem(graphics, cubeStack, field_2776 + 20, field_2800 + 28);
            }

            List<FramingSawRecipeAdditive> additives = recipe.getAdditives();
            for (int i = 0; i < additives.size(); i++)
            {
                if (!field_2797.getAdditiveStack(i).method_7960())
                {
                    continue;
                }

                class_1799[] items = additives.get(i).ingredient().method_8105();
                if (items.length == 0)
                {
                    // Additive ingredient resolves to no items on this side; nothing to display
                    continue;
                }
                int t = (int) (System.currentTimeMillis() / 1700) % items.length;
                int y = field_2800 + 64 + (18 * i);
                ClientUtils.renderTransparentFakeItem(graphics, items[t], field_2776 + 20, y);
            }
        }
    }

    private void tryScrollToRecipe(int idx)
    {
        if (idx != -1 && (idx < firstIndex || idx >= firstIndex + RECIPE_COUNT))
        {
            int row = (idx / RECIPE_COLS) - 2; // Center the selected recipe if possible
            int hidden = getHiddenRows();
            scrollOffset = (float) row / (float) hidden;
            scrollOffset = class_3532.method_15363(scrollOffset, 0, 1);
            firstIndex = calculateFirstIndex(hidden);
        }
    }

    @Override
    protected void method_2380(class_332 graphics, int mouseX, int mouseY)
    {
        if (field_2797.method_34255().method_7960() && field_2787 != null && field_2787.method_7681())
        {
            renderItemTooltip(graphics, mouseX, mouseY, field_2787.method_7677(), null);
            return;
        }

        class_1799 input = field_2797.getInputStack();
        if (!input.method_7960() && method_2378(WARNING_X, WARNING_Y, 16, 16, mouseX, mouseY) && cache.containsAdditive(input.method_7909()))
        {
            graphics.method_51438(field_22793, TOOLTIP_LOOSE_ADDITIVE, mouseX, mouseY);
            return;
        }

        int x = field_2776 + RECIPES_X;
        int y = field_2800 + RECIPES_Y;
        int last = firstIndex + RECIPE_COUNT;
        List<FramingSawMenu.RecipeHolder> recipes = field_2797.getRecipes();

        for (int idx = firstIndex; idx < last && idx < recipes.size(); idx++)
        {
            int relIdx = idx - firstIndex;
            int recX = x + relIdx % RECIPE_COLS * RECIPE_WIDTH;
            int recY = y + relIdx / RECIPE_COLS * RECIPE_HEIGHT;
            if (mouseX >= recX && mouseX < recX + RECIPE_WIDTH && mouseY >= recY && mouseY < recY + RECIPE_HEIGHT)
            {
                FramingSawMenu.RecipeHolder recipe = recipes.get(idx);
                class_1799 result = recipe.getRecipe().getResult();
                renderItemTooltip(graphics, mouseX, mouseY, result, recipe);
            }
        }
    }

    private void renderItemTooltip(class_332 graphics, int mouseX, int mouseY, class_1799 stack, FramingSawMenu.RecipeHolder recipeHolder)
    {
        //noinspection ConstantConditions
        List<class_2561> components = new ArrayList<>(method_25408(field_22787, stack));
        Optional<class_5632> tooltip = stack.method_32347();

        int material = cache.getMaterialValue(stack.method_7909());
        if (material > 0)
        {
            components.add(class_2561.method_43469(TOOLTIP_MATERIAL, material));
        }

        if (recipeHolder != null)
        {
            appendRecipeFailure(components, recipeHolder);
        }

        graphics.method_51437(field_22793, components, tooltip, mouseX, mouseY);
    }

    private void appendRecipeFailure(List<class_2561> components, FramingSawMenu.RecipeHolder recipeHolder)
    {
        appendRecipeFailure(components, cache, recipeHolder.getRecipe(), recipeHolder.getMatchResult(), field_2797);
    }

    public static List<class_2561> appendRecipeFailure(
            List<class_2561> components,
            FramingSawRecipeCache cache,
            FramingSawRecipe recipe,
            FramingSawRecipeMatchResult matchResult,
            IFramingSawMenu menu
    )
    {
        if (!matchResult.success())
        {
            components.add(matchResult.translation());

            class_1799 input = menu.getInputStack();
            int listAdditives = -1;
            class_5250 detail = switch (matchResult)
            {
                case MATERIAL_VALUE ->
                {
                    int matIn = input.method_7960() ? 0 : cache.getMaterialValue(input.method_7909()) * input.method_7947();
                    int matReq = recipe.getMaterialAmount();
                    yield class_2561.method_43469(
                            TOOLTIP_HAVE_X_BUT_NEED_Y_MATERIAL_COUNT,
                            class_2561.method_43470(Integer.toString(matIn)).method_27692(class_124.field_1065),
                            class_2561.method_43470(Integer.toString(matReq)).method_27692(class_124.field_1065)
                    );
                }
                case MATERIAL_LCM ->
                {
                    if (input.method_7960()) yield class_2561.method_43473();

                    FramingSawRecipeCalculation calc = recipe.makeCraftingCalculation(
                            menu.getInputContainer(), true
                    );
                    yield class_2561.method_43469(
                            TOOLTIP_HAVE_X_BUT_NEED_Y_ITEM_COUNT,
                            class_2561.method_43470(Integer.toString(input.method_7947())).method_27692(class_124.field_1065),
                            class_2561.method_43470(Integer.toString(calc.getInputCount())).method_27692(class_124.field_1065)
                    );
                }
                case OUTPUT_SIZE ->
                {
                    if (input.method_7960()) yield class_2561.method_43473();

                    FramingSawRecipeCalculation calc = recipe.makeCraftingCalculation(
                            menu.getInputContainer(), true
                    );
                    int maxSize = recipe.getResult().method_7914();
                    yield class_2561.method_43469(TOOLTIP_OUTPUT_COUNT, calc.getOutputCount(), maxSize);
                }
                case MISSING_ADDITIVE_0, MISSING_ADDITIVE_1, MISSING_ADDITIVE_2 ->
                {
                    listAdditives = matchResult.additiveSlot();
                    class_1856 additive = recipe.getAdditives().get(matchResult.additiveSlot()).ingredient();
                    yield makeHaveButNeedTooltip(TOOLTIP_HAVE_ITEM_NONE, additive);
                }
                case UNEXPECTED_ADDITIVE_0, UNEXPECTED_ADDITIVE_1, UNEXPECTED_ADDITIVE_2 ->
                {
                    class_1792 itemIn = menu.getAdditiveStack(matchResult.additiveSlot()).method_7909();
                    yield class_2561.method_43469(
                            TOOLTIP_HAVE_X_BUT_NEED_Y_ITEM,
                            class_2561.method_43471(itemIn.method_7876()).method_27692(class_124.field_1065),
                            TOOLTIP_HAVE_ITEM_NONE
                    );
                }
                case INCORRECT_ADDITIVE_0, INCORRECT_ADDITIVE_1, INCORRECT_ADDITIVE_2 ->
                {
                    listAdditives = matchResult.additiveSlot();
                    class_1792 itemIn = menu.getAdditiveStack(matchResult.additiveSlot()).method_7909();
                    class_1856 additive = recipe.getAdditives().get(matchResult.additiveSlot()).ingredient();
                    yield makeHaveButNeedTooltip(
                            class_2561.method_43471(itemIn.method_7876()).method_27692(class_124.field_1065),
                            additive
                    );
                }
                case INSUFFICIENT_ADDITIVE_0, INSUFFICIENT_ADDITIVE_1, INSUFFICIENT_ADDITIVE_2 ->
                {
                    if (input.method_7960()) yield class_2561.method_43473();

                    FramingSawRecipeCalculation calc = recipe.makeCraftingCalculation(
                            menu.getInputContainer(), true
                    );
                    int cntIn = menu.getAdditiveStack(matchResult.additiveSlot()).method_7947();
                    int cntReq = calc.getAdditiveCount(matchResult.additiveSlot());
                    yield class_2561.method_43469(
                            TOOLTIP_HAVE_X_BUT_NEED_Y_ITEM_COUNT,
                            class_2561.method_43470(Integer.toString(cntIn)).method_27692(class_124.field_1065),
                            class_2561.method_43470(Integer.toString(cntReq)).method_27692(class_124.field_1065)
                    );
                }
                case SUCCESS -> throw new IllegalStateException("Unreachable");
            };
            components.add(detail.method_27692(class_124.field_1061));

            if (listAdditives > -1)
            {
                appendAdditiveItemOptions(components, recipe, listAdditives);
            }
        }
        return components;
    }

    private static void appendAdditiveItemOptions(List<class_2561> components, FramingSawRecipe recipe, int additiveSlot)
    {
        class_1856 additive = recipe.getAdditives().get(additiveSlot).ingredient();
        if (additive.method_8105().length <= 1)
        {
            return;
        }

        if (method_25442())
        {
            for (class_1799 option : additive.method_8105())
            {
                components.add(class_2561.method_43470("- ").method_10852(option.method_7909().method_7848()).method_27692(class_124.field_1065));
            }
        }
        else
        {
            class_2561 keyName = class_3675.method_15985(GLFW.GLFW_KEY_LEFT_SHIFT, -1).method_27445();
            components.add(class_2561.method_43469(
                    TOOLTIP_PRESS_TO_SHOW,
                    class_2561.method_43470("").method_10852(keyName).method_27692(class_124.field_1065)
            ).method_27692(class_124.field_1061));
        }
    }

    private static class_5250 makeHaveButNeedTooltip(class_2561 present, class_1856 additive)
    {
        class_1799[] options = additive.method_8105();
        if (options.length == 0)
        {
            // Ingredient resolves to no items on this side (e.g. the matching item
            // isn't available on the client) so there is no item name to show
            return class_2561.method_43469(TOOLTIP_HAVE_X_BUT_NEED_Y_ITEM, present, TOOLTIP_HAVE_ITEM_NONE);
        }
        Object singleValue = RecipeUtils.getSingleIngredientValue(additive);
        if (options.length > 1 && singleValue != null)
        {
            class_6862<class_1792> tag = RecipeUtils.getItemTagFromValue(singleValue);
            return class_2561.method_43469(
                    TOOLTIP_HAVE_X_BUT_NEED_Y_TAG,
                    present,
                    class_2561.method_43470("#" + tag.comp_327()).method_27692(class_124.field_1065)
            );
        }
        else
        {
            return class_2561.method_43469(
                    TOOLTIP_HAVE_X_BUT_NEED_Y_ITEM,
                    present,
                    class_2561.method_43471(options[0].method_7909().method_7876()).method_27692(class_124.field_1065)
            );
        }
    }

    private void renderButtons(class_332 graphics, int mouseX, int mouseY, int x, int y, int lastIdx)
    {
        List<FramingSawMenu.RecipeHolder> recipes = field_2797.getRecipes();
        for (int idx = firstIndex; idx < lastIdx && idx < recipes.size(); ++idx)
        {
            int relIdx = idx - firstIndex;
            int recX = x + relIdx % RECIPE_COLS * RECIPE_WIDTH;
            int recY = y + relIdx / RECIPE_COLS * RECIPE_HEIGHT;

            int u = 0;
            boolean hovered = false;
            if (idx == field_2797.getSelectedRecipeIndex())
            {
                u += RECIPE_WIDTH;
            }
            else if (mouseX >= recX && mouseY >= recY && mouseX < recX + RECIPE_WIDTH && mouseY < recY + RECIPE_HEIGHT)
            {
                u += (RECIPE_WIDTH * 2);
                hovered = true;
            }

            if (!hovered && !recipes.get(idx).getMatchResult().success())
            {
                RenderSystem.setShaderColor(.9F, .3F, .3F, 1F);
            }
            else
            {
                RenderSystem.setShaderColor(1F, 1F, 1F, 1F);
            }

            graphics.method_25302(BACKGROUND, recX, recY, u, field_2779, RECIPE_WIDTH, RECIPE_HEIGHT);
        }
    }

    private void renderRecipes(class_332 graphics, int pLeft, int pTop, int lastIndex)
    {
        List<FramingSawMenu.RecipeHolder> recipes = field_2797.getRecipes();

        RenderSystem.setShaderColor(1F, 1F, 1F, 1F);
        for (int idx = firstIndex; idx < lastIndex && idx < recipes.size(); idx++)
        {
            int relIdx = idx - firstIndex;
            int x = pLeft + relIdx % RECIPE_COLS * RECIPE_WIDTH + 1;
            int y = pTop + relIdx / RECIPE_COLS * RECIPE_HEIGHT + 1;

            class_1799 stack = recipes.get(idx).getRecipe().getResult();
            graphics.method_51428(stack, x, y, x * y * field_2792);
            graphics.method_51431(field_22793, stack, x, y);
        }
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button)
    {
        scrolling = false;

        int x = field_2776 + RECIPES_X;
        int y = field_2800 + RECIPES_Y;
        int lastIdx = firstIndex + RECIPE_COUNT;

        for (int idx = firstIndex; idx < lastIdx; ++idx)
        {
            int relIdx = idx - firstIndex;
            double recRelX = mouseX - (double)(x + relIdx % RECIPE_COLS * RECIPE_WIDTH);
            double recRelY = mouseY - (double)(y + relIdx / RECIPE_COLS * RECIPE_HEIGHT);
            if (recRelX < 0 || recRelY < 0 || recRelX > RECIPE_WIDTH || recRelY > RECIPE_HEIGHT)
            {
                continue;
            }

            //noinspection ConstantConditions
            if (field_2797.method_7604(field_22787.field_1724, idx))
            {
                class_310.method_1551().method_1483().method_4873(class_1109.method_4758(class_3417.field_17711, 1.0F));
                NetworkingHandler.sendSelectFramingSawRecipe(field_2797.field_7763, idx);
                return true;
            }
        }

        if (isScrollBarActive())
        {
            x = field_2776 + SCROLL_BAR_X;
            y = field_2800 + SCROLL_BAR_Y;
            if (mouseX >= (double) x && mouseX < (double) (x + SCROLL_BTN_WIDTH) && mouseY >= (double) y && mouseY < (double) (y + SCROLL_BAR_HEIGHT))
            {
                scrolling = true;
            }
        }

        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY)
    {
        if (scrolling && isScrollBarActive())
        {
            float topY = field_2800 + RECIPES_Y;
            float botY = topY + SCROLL_BAR_HEIGHT;
            float freeScrollHeight = botY - topY - SCROLL_BTN_HEIGHT;

            scrollOffset = ((float) mouseY - topY - (SCROLL_BTN_HEIGHT / 2F)) / freeScrollHeight;
            scrollOffset = class_3532.method_15363(scrollOffset, 0F, 1F);
            firstIndex = calculateFirstIndex(getHiddenRows());

            return true;
        }

        return super.method_25403(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double delta, double deltaX)
    {
        if (isScrollBarActive())
        {
            int hiddenRows = getHiddenRows();
            float offset = (float) delta / (float) hiddenRows;
            scrollOffset = class_3532.method_15363(scrollOffset - offset, 0F, 1F);
            firstIndex = calculateFirstIndex(hiddenRows);
        }

        return true;
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers)
    {
        // RecipeViewer.LookupTarget target;
        if (false) // Recipe viewer disabled for Fabric
        {
            class_1041 window = Objects.requireNonNull(field_22787).method_22683();
            class_312 mouseHandler = field_22787.field_1729;
            double mouseX = mouseHandler.method_1603() * (double)window.method_4486() / (double)window.method_4480();
            double mouseY = mouseHandler.method_1604() * (double)window.method_4502() / (double)window.method_4507();

            FramingSawRecipe recipe = getRecipeAt(mouseX, mouseY);
            if (false)
            {
                return true;
            }
        }

        return super.method_25404(keyCode, scanCode, modifiers);
    }

    public FramingSawRecipe getRecipeAt(double mouseX, double mouseY)
    {
        double x = field_2776 + RECIPES_X;
        double y = field_2800 + RECIPES_Y;

        if (mouseX >= x && mouseX <= x + (RECIPE_WIDTH * RECIPE_COLS) && mouseY >= y && mouseY <= y + (RECIPE_HEIGHT * RECIPE_ROWS))
        {
            int col = (int) ((mouseX - x) / RECIPE_WIDTH);
            int row = (int) ((mouseY - y) / RECIPE_HEIGHT);
            int idx = (row * RECIPE_COLS) + col + firstIndex;

            List<FramingSawRecipe> recipes = cache.getRecipes();
            if (idx > 0 && idx < recipes.size())
            {
                return cache.getRecipes().get(idx);
            }
        }
        return null;
    }

    private boolean isScrollBarActive()
    {
        return field_2797.getRecipes().size() > RECIPE_COUNT;
    }

    private int getHiddenRows()
    {
        return (field_2797.getRecipes().size() + RECIPE_COLS - 1) / RECIPE_COLS - RECIPE_ROWS;
    }

    private int calculateFirstIndex(int hiddenRows)
    {
        return (int) ((double) (scrollOffset * (float) hiddenRows) + .5D) * RECIPE_COLS;
    }
}
