package xfacthd.framedblocks.client.screen.overlay;

import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.client.util.ClientConfig;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.data.PropertyHolder;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

public final class SplitLineOverlay extends BlockInteractOverlay
{
    public static final class_2561 SPLIT_LINE_FALSE = Utils.translate("tooltip", "split_line.false");
    public static final class_2561 SPLIT_LINE_TRUE = Utils.translate("tooltip", "split_line.true");
    public static final class_2561 MSG_SWITCH_SPLIT_LINE = Utils.translate("msg", "split_line.switch");
    private static final List<class_2561> LINES_FALSE = List.of(SPLIT_LINE_FALSE, MSG_SWITCH_SPLIT_LINE);
    private static final List<class_2561> LINES_TRUE = List.of(SPLIT_LINE_TRUE, MSG_SWITCH_SPLIT_LINE);

    private static final class_2960 SYMBOL_TEXTURE = Utils.rl("textures/overlay/split_line_symbols.png");
    private static final Texture TEXTURE_FALSE = new Texture(SYMBOL_TEXTURE, 0, 0, 20, 20, 40, 20);
    private static final Texture TEXTURE_TRUE = new Texture(SYMBOL_TEXTURE, 20, 0, 20, 20, 40, 20);

    public SplitLineOverlay()
    {
        super(LINES_FALSE, LINES_TRUE, TEXTURE_FALSE, TEXTURE_TRUE, () -> ClientConfig.splitLineMode);
    }

    @Override
    protected boolean isValidTool(class_1799 stack)
    {
        return stack.method_7909() == FBContent.ITEM_FRAMED_WRENCH.get();
    }

    @Override
    protected boolean isValidTarget(Target target)
    {
        return target.state().method_26204() == FBContent.BLOCK_FRAMED_COLLAPSIBLE_BLOCK.get();
    }

    @Override
    protected boolean getState(Target target)
    {
        return target.state().method_11654(PropertyHolder.ROTATE_SPLIT_LINE);
    }
}
