package xfacthd.framedblocks.client.screen.overlay;

import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.client.util.ClientConfig;
import xfacthd.framedblocks.common.FBContent;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

public final class PrismOffsetOverlay extends BlockInteractOverlay
{
    public static final class_2561 PRISM_OFFSET_FALSE = Utils.translate("tooltip", "prism_offset.false");
    public static final class_2561 PRISM_OFFSET_TRUE = Utils.translate("tooltip", "prism_offset.true");
    public static final class_2561 MSG_SWITCH_OFFSET = Utils.translate("msg", "prism_offset.switch");
    private static final List<class_2561> LINES_FALSE = List.of(PRISM_OFFSET_FALSE, MSG_SWITCH_OFFSET);
    private static final List<class_2561> LINES_TRUE = List.of(PRISM_OFFSET_TRUE, MSG_SWITCH_OFFSET);

    private static final class_2960 SYMBOL_TEXTURE = Utils.rl("textures/overlay/prism_offset_symbols.png");
    private static final Texture TEXTURE_FALSE = new Texture(SYMBOL_TEXTURE, 0, 0, 19, 19, 38, 19);
    private static final Texture TEXTURE_TRUE = new Texture(SYMBOL_TEXTURE, 19, 0, 19, 19, 38, 19);

    public PrismOffsetOverlay()
    {
        super(LINES_FALSE, LINES_TRUE, TEXTURE_FALSE, TEXTURE_TRUE, () -> ClientConfig.prismOffsetMode);
    }

    @Override
    protected boolean isValidTool(class_1799 stack)
    {
        return stack.method_7909() == FBContent.ITEM_FRAMED_HAMMER.get();
    }

    @Override
    protected boolean isValidTarget(Target target)
    {
        return target.state().method_28498(FramedProperties.OFFSET);
    }

    @Override
    protected boolean getState(Target target)
    {
        return target.state().method_11654(FramedProperties.OFFSET);
    }
}
