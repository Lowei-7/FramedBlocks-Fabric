package xfacthd.framedblocks.client.screen.overlay;

import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_3300;
import net.minecraft.class_332;
import net.minecraft.class_3965;
import net.minecraft.class_8002;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;
import net.minecraftforge.common.util.ConcatenatedListView;

import java.util.*;
import java.util.function.Supplier;

public abstract class BlockInteractOverlay implements IGuiOverlay
{
    private static final int LINE_DIST = 3;
    private static final Target NO_TARGET = new Target(class_2338.field_10980, class_2246.field_10124.method_9564(), class_2350.field_11043);
    private static final List<BlockInteractOverlay> OVERLAYS = new ArrayList<>();

    private final List<class_2561> linesFalse;
    private final List<class_2561> linesTrue;
    private final Texture textureFalse;
    private final Texture textureTrue;
    private final Supplier<Mode> modeGetter;
    private int textWidth = 0;
    private boolean textWidthValid = false;

    BlockInteractOverlay(
            List<class_2561> linesFalse,
            List<class_2561> linesTrue,
            Texture textureFalse,
            Texture textureTrue,
            Supplier<Mode> modeGetter
    )
    {
        this.linesFalse = linesFalse;
        this.linesTrue = linesTrue;
        this.textureFalse = textureFalse;
        this.textureTrue = textureTrue;
        this.modeGetter = modeGetter;
        OVERLAYS.add(this);
    }

    @Override
    public void render(ForgeGui gui, class_332 graphics, float partialTick, int screenWidth, int screenHeight)
    {
        Mode mode = modeGetter.get();
        if (mode == Mode.HIDDEN || player().method_7325() || class_310.method_1551().field_1690.field_1842)
        {
            return;
        }

        class_1799 stack = player().method_6047();
        if (!isValidTool(stack))
        {
            return;
        }

        Target target = getTargettedBlock();
        if (!isValidTarget(target))
        {
            return;
        }

        boolean state = getState(target);
        int centerX = screenWidth / 2;
        int centerY = screenHeight / 2;

        Texture tex = getTexture(target, state, textureFalse, textureTrue);
        int texX = centerX + 20;
        int texY = centerY - (tex.height / 2);
        tex.draw(gui, graphics, texX, texY);
        renderAfterIcon(gui, graphics, tex, texX, texY, target);

        if (mode == Mode.DETAILED)
        {
            List<class_2561> lines = getLines(target, state, linesFalse, linesTrue);
            renderDetailed(gui, graphics, tex, lines, centerX, screenHeight, target);
        }
    }

    private void renderDetailed(
            ForgeGui gui,
            class_332 graphics,
            Texture tex,
            List<class_2561> lines,
            int centerX,
            int screenHeight,
            Target target
    )
    {
        class_327 font = gui.method_1756();
        if (!textWidthValid)
        {
            updateTextWidth(font);
        }

        int lineHeight = font.field_2000 + LINE_DIST;
        int count = lines.size();
        int contentHeight = count * lineHeight - LINE_DIST;

        int width = textWidth + tex.width + 10;
        int height = Math.max(contentHeight, tex.height);
        int x = centerX - (width / 2);
        int y = screenHeight - 80 - height;
        drawTooltipBackground(graphics, x, y, width, height);

        int textX = x + tex.width + 10;
        int yBaseOff = tex.height > contentHeight ? ((tex.height - contentHeight) / 2) : 0;
        for (int i = 0; i < count; i++)
        {
            class_2561 text = lines.get(i);
            int yOff = yBaseOff + lineHeight * i;
            graphics.method_27535(font, text, textX, y + yOff, -1);
        }

        int texY = y + (height / 2) - (tex.height / 2);
        tex.draw(gui, graphics, x, texY);
        renderAfterIcon(gui, graphics, tex, x, texY, target);
    }

    protected abstract boolean isValidTool(class_1799 stack);

    protected abstract boolean isValidTarget(Target target);

    protected abstract boolean getState(Target target);

    protected Texture getTexture(Target target, boolean state, Texture texFalse, Texture texTrue)
    {
        return state ? texTrue : texFalse;
    }

    protected List<class_2561> getLines(Target target, boolean state, List<class_2561> linesFalse, List<class_2561> linesTrue)
    {
        return state ? linesTrue : linesFalse;
    }

    protected void renderAfterIcon(ForgeGui gui, class_332 graphics, Texture tex, int texX, int texY, Target target) { }

    private void updateTextWidth(class_327 font)
    {
        textWidth = 0;
        for (class_2561 line : ConcatenatedListView.of(linesFalse, linesTrue))
        {
            textWidth = Math.max(textWidth, font.method_27525(line));
        }
        textWidthValid = true;
    }



    public static void onResourceReload(@SuppressWarnings("unused") class_3300 manager)
    {
        OVERLAYS.forEach(overlay -> overlay.textWidthValid = false);
    }

    protected static class_1922 level()
    {
        return Objects.requireNonNull(class_310.method_1551().field_1687);
    }

    protected static class_1657 player()
    {
        return Objects.requireNonNull(class_310.method_1551().field_1724);
    }

    protected static Target getTargettedBlock()
    {
        class_239 hit = class_310.method_1551().field_1765;
        if (hit instanceof class_3965 blockHit)
        {
            class_2338 pos = blockHit.method_17777();
            return new Target(pos, level().method_8320(pos), blockHit.method_17780());
        }
        return NO_TARGET;
    }

    @SuppressWarnings("deprecation")
    private static void drawTooltipBackground(class_332 graphics, int x, int y, int width, int height)
    {
        graphics.method_51741(() -> class_8002.method_47946(
                graphics,
                x - 2, y - 2, width + 4, height + 4, 0
        ));
    }

    protected record Texture(
            class_2960 location, int xOff, int yOff, int width, int height, int texWidth, int texHeight
    )
    {
        public void draw(ForgeGui gui, class_332 graphics, int x, int y)
        {
            gui.setupOverlayRenderState(true, false);
            graphics.method_25291(location, x, y, 0, xOff, yOff, width, height, texWidth, texHeight);
        }
    }

    protected record Target(class_2338 pos, class_2680 state, class_2350 side) { }

    public enum Mode
    {
        HIDDEN,
        ICON,
        DETAILED
    }
}
