package xfacthd.framedblocks.client.screen.overlay;

import xfacthd.framedblocks.api.block.FramedBlockEntity;
import xfacthd.framedblocks.api.block.IFramedBlock;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.client.util.ClientConfig;
import xfacthd.framedblocks.common.FBContent;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_239;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3965;

public final class CamoRotationOverlay extends BlockInteractOverlay
{
    public static final class_2561 ROTATEABLE_FALSE = Utils.translate("tooltip", "camo_rotation.false");
    public static final class_2561 ROTATEABLE_TRUE = Utils.translate("tooltip", "camo_rotation.true");

    private static final class_2960 SYMBOL_TEXTURE = Utils.rl("textures/overlay/camo_rotation_symbols.png");
    private static final Texture TEXTURE_FALSE = new Texture(SYMBOL_TEXTURE, 0, 0, 22, 22, 44, 22);
    private static final Texture TEXTURE_TRUE = new Texture(SYMBOL_TEXTURE, 22, 0, 22, 22, 44, 22);

    public CamoRotationOverlay()
    {
        super(List.of(ROTATEABLE_FALSE), List.of(ROTATEABLE_TRUE), TEXTURE_FALSE, TEXTURE_TRUE, () -> ClientConfig.camoRotationMode);
    }

    @Override
    protected boolean isValidTool(class_1799 stack)
    {
        return stack.method_7909() == FBContent.ITEM_FRAMED_SCREWDRIVER.get();
    }

    @Override
    protected boolean isValidTarget(Target target)
    {
        return target.state().method_26204() instanceof IFramedBlock;
    }

    @Override
    protected boolean getState(Target target)
    {
        if (level().method_8321(target.pos()) instanceof FramedBlockEntity be)
        {
            class_239 hit = class_310.method_1551().field_1765;
            if (hit instanceof class_3965 blockHit)
            {
                return be.getCamo(blockHit).canRotateCamo();
            }
        }
        return false;
    }
}
