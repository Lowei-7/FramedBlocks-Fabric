package xfacthd.framedblocks.client.screen.overlay;

import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.client.util.ClientConfig;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.interactive.FramedPressurePlateBlock;
import xfacthd.framedblocks.common.block.interactive.FramedWeightedPressurePlateBlock;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_2741;
import net.minecraft.class_2960;

public final class ToggleWaterloggableOverlay extends BlockInteractOverlay
{
    public static final class_2561 MSG_IS_WATERLOGGABLE = Utils.translate("tooltip", "is_waterloggable.true");
    public static final class_2561 MSG_IS_NOT_WATERLOGGABLE = Utils.translate("tooltip", "is_waterloggable.false");
    public static final class_2561 MSG_MAKE_WATERLOGGABLE = Utils.translate("tooltip", "make_waterloggable.true");
    public static final class_2561 MSG_MAKE_NOT_WATERLOGGABLE = Utils.translate("tooltip", "make_waterloggable.false");
    private static final List<class_2561> LINES_FALSE = List.of(MSG_IS_NOT_WATERLOGGABLE, MSG_MAKE_WATERLOGGABLE);
    private static final List<class_2561> LINES_TRUE = List.of(MSG_IS_WATERLOGGABLE, MSG_MAKE_NOT_WATERLOGGABLE);

    private static final class_2960 SYMBOL_TEXTURE = Utils.rl("textures/overlay/waterloggable_symbols.png");
    private static final Texture TEXTURE_FALSE = new Texture(SYMBOL_TEXTURE, 0, 0, 20, 20, 40, 20);
    private static final Texture TEXTURE_TRUE = new Texture(SYMBOL_TEXTURE, 20, 0, 20, 20, 40, 20);

    public ToggleWaterloggableOverlay()
    {
        super(LINES_FALSE, LINES_TRUE, TEXTURE_FALSE, TEXTURE_TRUE, () -> ClientConfig.toggleWaterlogMode);
    }

    @Override
    protected boolean isValidTool(class_1799 stack)
    {
        return stack.method_31574(FBContent.ITEM_FRAMED_HAMMER.get());
    }

    @Override
    protected boolean isValidTarget(Target target)
    {
        class_2248 block = target.state().method_26204();
        return block instanceof FramedPressurePlateBlock || block instanceof FramedWeightedPressurePlateBlock;
    }

    @Override
    protected boolean getState(Target target)
    {
        return target.state().method_28498(class_2741.field_12508);
    }
}
