package xfacthd.framedblocks.client.screen.overlay;

import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.client.util.ClientConfig;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.cube.FramedOneWayWindowBlock;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.NullableDirection;

import java.util.*;

public final class OneWayWindowOverlay extends BlockInteractOverlay
{
    private static final class_2960 SYMBOL_TEXTURE = Utils.rl("textures/overlay/one_way_window_symbols.png");
    private static final class_2960 EYE_TEXTURE = new class_2960("textures/item/ender_eye.png");
    private static final Texture TEXTURE_BG = new Texture(SYMBOL_TEXTURE, 0, 0, 22, 38, 37, 38);
    private static final Texture TEXTURE_CROSS = new Texture(SYMBOL_TEXTURE, 22, 0, 15, 15, 37, 38);
    private static final Texture TEXTURE_EYE = new Texture(EYE_TEXTURE, 0, 0, 16, 16, 16, 16);

    public static final String LINE_CURR_FACE = Utils.translationKey("tooltip", "one_way_window.curr_face");
    public static final String LINE_SET_FACE = Utils.translationKey("tooltip", "one_way_window.set_face");
    public static final class_2561 LINE_CLEAR_FACE = Utils.translate("tooltip", "one_way_window.clear_face");
    public static final class_2561[] DIR_VALUE_LINES = Utils.buildEnumTranslations("tooltip", "one_way_window.dir", class_2350.values(), class_124.field_1065);
    public static final class_2561[] FACE_VALUE_LINES = Utils.buildEnumTranslations("tooltip", "one_way_window.face", NullableDirection.values(), class_124.field_1065);
    public static final class_2561[] FACE_VALUE_ABBRS = Utils.buildEnumTranslations("tooltip", "one_way_window.face_abbr", NullableDirection.values());
    private static final class_2561[] CURR_FACE_LINES = Utils.bindEnumTranslation(LINE_CURR_FACE, NullableDirection.values(), FACE_VALUE_LINES);
    private static final class_2561[] SET_FACE_LINES = Utils.bindEnumTranslation(LINE_SET_FACE, class_2350.values(), DIR_VALUE_LINES);
    private static final List<class_2561> LINES = packLineList();

    public OneWayWindowOverlay()
    {
        super(LINES, List.of(), null, null, () -> ClientConfig.oneWayWindowMode);
    }

    @Override
    protected boolean isValidTool(class_1799 stack)
    {
        return stack.method_31574(FBContent.ITEM_FRAMED_WRENCH.get());
    }

    @Override
    protected boolean isValidTarget(Target target)
    {
        if (target.state().method_26204() != FBContent.BLOCK_FRAMED_ONE_WAY_WINDOW.get())
        {
            return false;
        }

        return FramedOneWayWindowBlock.isOwnedBy(level(), target.pos(), player());
    }

    @Override
    protected boolean getState(Target target)
    {
        return false;
    }

    @Override
    protected Texture getTexture(Target target, boolean state, Texture texFalse, Texture texTrue)
    {
        return TEXTURE_BG;
    }

    @Override
    protected List<class_2561> getLines(Target target, boolean state, List<class_2561> linesFalse, List<class_2561> linesTrue)
    {
        NullableDirection face = target.state().method_11654(PropertyHolder.NULLABLE_FACE);

        return List.of(
                CURR_FACE_LINES[face.ordinal()],
                SET_FACE_LINES[target.side().ordinal()],
                LINE_CLEAR_FACE
        );
    }

    @Override
    protected void renderAfterIcon(ForgeGui gui, class_332 graphics, Texture tex, int texX, int texY, Target target)
    {
        NullableDirection face = target.state().method_11654(PropertyHolder.NULLABLE_FACE);

        graphics.method_51448().method_22903();
        graphics.method_51448().method_22904(-.5, -.5, 0);

        TEXTURE_EYE.draw(gui, graphics, texX + 3, texY + 3);
        if (face == NullableDirection.NONE)
        {
            TEXTURE_CROSS.draw(gui, graphics, texX + 4, texY + 4);
        }

        graphics.method_51448().method_22909();

        int x = texX + (tex.width() / 2);
        int y = texY + (tex.height() * 3 / 4) - (gui.method_1756().field_2000 / 2);
        graphics.method_27534(gui.method_1756(), FACE_VALUE_ABBRS[face.ordinal()], x, y, -1/*0x555555*/);
    }



    private static List<class_2561> packLineList()
    {
        List<class_2561> lines = new ArrayList<>();

        lines.add(LINE_CLEAR_FACE);
        lines.addAll(Arrays.asList(CURR_FACE_LINES));
        lines.addAll(Arrays.asList(SET_FACE_LINES));

        return lines;
    }
}
