package xfacthd.framedblocks.client.screen.overlay;

import xfacthd.framedblocks.api.block.IFramedBlock;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.client.util.ClientConfig;
import xfacthd.framedblocks.common.FBContent;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

public final class StateLockOverlay extends BlockInteractOverlay
{
    public static final String LOCK_MESSAGE = Utils.translationKey("tooltip", "lock_state");
    private static final List<class_2561> LINES_FALSE = List.of(
            class_2561.method_43469(LOCK_MESSAGE, IFramedBlock.STATE_UNLOCKED)
    );
    private static final List<class_2561> LINES_TRUE = List.of(
            class_2561.method_43469(LOCK_MESSAGE, IFramedBlock.STATE_LOCKED)
    );

    private static final class_2960 SYMBOL_TEXTURE = Utils.rl("textures/overlay/state_lock_symbols.png");
    private static final Texture TEXTURE_FALSE = new Texture(SYMBOL_TEXTURE, 0, 0, 22, 22, 44, 22);
    private static final Texture TEXTURE_TRUE = new Texture(SYMBOL_TEXTURE, 22, 0, 22, 22, 44, 22);

    public StateLockOverlay()
    {
        super(LINES_FALSE, LINES_TRUE, TEXTURE_FALSE, TEXTURE_TRUE, () -> ClientConfig.stateLockMode);
    }

    @Override
    protected boolean isValidTool(class_1799 stack)
    {
        return stack.method_31574(FBContent.ITEM_FRAMED_KEY.get());
    }

    @Override
    protected boolean isValidTarget(Target target)
    {
        return target.state().method_26204() instanceof IFramedBlock block && block.getBlockType().canLockState();
    }

    @Override
    protected boolean getState(Target target)
    {
        return target.state().method_11654(FramedProperties.STATE_LOCKED);
    }
}
