package xfacthd.framedblocks.client.screen.overlay;

import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.client.util.ClientConfig;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.interactive.FramedItemFrameBlock;
import xfacthd.framedblocks.common.data.PropertyHolder;

import java.util.List;

public final class FrameBackgroundOverlay extends BlockInteractOverlay
{
    private static final class_2960 SYMBOL_TEXTURE = Utils.rl("textures/overlay/frame_background_symbols.png");
    private static final class_2960 LEATHER_TEXTURE = new class_2960("textures/item/leather.png");
    private static final Texture TEXTURE_BG = new Texture(SYMBOL_TEXTURE, 0, 0, 22, 22, 38, 22);
    private static final Texture TEXTURE_CROSS = new Texture(SYMBOL_TEXTURE, 22, 0, 16, 16, 38, 22);
    private static final Texture TEXTURE_LEATHER = new Texture(LEATHER_TEXTURE, 0, 0, 16, 16, 16, 16);
    public static final class_2561 LINE_USE_CAMO_BG = Utils.translate("tooltip", "frame_bg.use_camo");
    public static final class_2561 LINE_USE_LEATHER_BG = Utils.translate("tooltip", "frame_bg.use_leather");
    public static final class_2561 LINE_SET_CAMO_BG = Utils.translate("tooltip", "frame_bg.set_camo");
    public static final class_2561 LINE_SET_LEATHER_BG = Utils.translate("tooltip", "frame_bg.set_leather");
    private static final List<class_2561> LINES_FALSE = List.of(LINE_USE_CAMO_BG, LINE_SET_LEATHER_BG);
    private static final List<class_2561> LINES_TRUE = List.of(LINE_USE_LEATHER_BG, LINE_SET_CAMO_BG);

    public FrameBackgroundOverlay()
    {
        super(LINES_FALSE, LINES_TRUE, null, null, () -> ClientConfig.frameBackgroundMode);
    }

    @Override
    protected boolean isValidTool(class_1799 stack)
    {
        return stack.method_31574(FBContent.ITEM_FRAMED_HAMMER.get());
    }

    @Override
    protected boolean isValidTarget(Target target)
    {
        return target.state().method_26204() instanceof FramedItemFrameBlock;
    }

    @Override
    protected boolean getState(Target target)
    {
        return target.state().method_11654(PropertyHolder.LEATHER);
    }

    @Override
    protected Texture getTexture(Target target, boolean state, Texture texFalse, Texture texTrue)
    {
        return TEXTURE_BG;
    }

    @Override
    protected void renderAfterIcon(ForgeGui gui, class_332 graphics, Texture tex, int texX, int texY, Target target)
    {
        TEXTURE_LEATHER.draw(gui, graphics, texX + 3, texY + 3);
        if (!target.state().method_11654(PropertyHolder.LEATHER))
        {
            TEXTURE_CROSS.draw(gui, graphics, texX + 3, texY + 3);
        }
    }
}
