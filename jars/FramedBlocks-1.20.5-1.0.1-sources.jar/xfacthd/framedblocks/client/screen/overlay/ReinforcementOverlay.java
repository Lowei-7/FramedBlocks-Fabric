package xfacthd.framedblocks.client.screen.overlay;

import xfacthd.framedblocks.api.block.FramedBlockEntity;
import xfacthd.framedblocks.api.block.IFramedBlock;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.client.util.ClientConfig;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

public final class ReinforcementOverlay extends BlockInteractOverlay
{
    public static final String REINFORCE_MESSAGE = Utils.translationKey("tooltip", "reinforce_state");
    public static final class_2561 STATE_NOT_REINFORCED = Utils.translate("tooltip", "reinforce_state.false")
            .method_27692(class_124.field_1061);
    public static final class_2561 STATE_REINFORCED = Utils.translate("tooltip", "reinforce_state.true")
            .method_27692(class_124.field_1060);
    private static final List<class_2561> LIST_FALSE = List.of(
            class_2561.method_43469(REINFORCE_MESSAGE, STATE_NOT_REINFORCED)
    );
    private static final List<class_2561> LIST_TRUE = List.of(
            class_2561.method_43469(REINFORCE_MESSAGE, STATE_REINFORCED)
    );

    private static final class_2960 SYMBOL_TEXTURE = Utils.rl("textures/overlay/reinforcement_symbols.png");
    private static final Texture TEXTURE_FALSE = new Texture(SYMBOL_TEXTURE, 0, 0, 22, 22, 44, 22);
    private static final Texture TEXTURE_TRUE = new Texture(SYMBOL_TEXTURE, 22, 0, 22, 22, 44, 22);

    public ReinforcementOverlay()
    {
        super(LIST_FALSE, LIST_TRUE, TEXTURE_FALSE, TEXTURE_TRUE, () -> ClientConfig.reinforcementMode);
    }

    @Override
    protected boolean isValidTool(class_1799 stack)
    {
        return stack.method_31574(Utils.framedReinforcement());
    }

    @Override
    protected boolean isValidTarget(Target target)
    {
        return target.state().method_26204() instanceof IFramedBlock;
    }

    @Override
    protected boolean getState(Target target)
    {
        if (level().method_8321(target.pos()) instanceof FramedBlockEntity be)
        {
            return be.isReinforced();
        }
        return false;
    }
}
