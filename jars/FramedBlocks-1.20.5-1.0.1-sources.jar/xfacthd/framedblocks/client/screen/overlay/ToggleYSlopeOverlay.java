package xfacthd.framedblocks.client.screen.overlay;

import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraftforge.common.util.ConcatenatedListView;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.client.util.ClientConfig;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.IComplexSlopeSource;

import java.util.List;

public final class ToggleYSlopeOverlay extends BlockInteractOverlay
{
    public static final String SLOPE_MESSAGE = Utils.translationKey("tooltip", "y_slope");
    public static final String TOGGLE_MESSAGE = Utils.translationKey("tooltip", "y_slope.toggle");
    public static final String SLOPE_MESSAGE_ALT = Utils.translationKey("tooltip", "y_slope.alt");
    public static final String TOGGLE_MESSAGE_ALT = Utils.translationKey("tooltip", "y_slope.alt.toggle");
    public static final class_2561 SLOPE_HOR = Utils.translate("tooltip", "y_slope.horizontal");
    public static final class_2561 SLOPE_VERT = Utils.translate("tooltip", "y_slope.vertical");
    public static final class_2561 SLOPE_FRONT = Utils.translate("tooltip", "y_slope.front");
    public static final class_2561 SLOPE_SIDE = Utils.translate("tooltip", "y_slope.side");
    private static final List<class_2561> LINES_FALSE = List.of(
            class_2561.method_43469(SLOPE_MESSAGE, SLOPE_HOR),
            class_2561.method_43469(TOGGLE_MESSAGE, SLOPE_VERT)
    );
    private static final List<class_2561> LINES_TRUE = List.of(
            class_2561.method_43469(SLOPE_MESSAGE, SLOPE_VERT),
            class_2561.method_43469(TOGGLE_MESSAGE, SLOPE_HOR)
    );
    private static final List<class_2561> LINES_FALSE_ALT = List.of(
            class_2561.method_43469(SLOPE_MESSAGE_ALT, SLOPE_FRONT),
            class_2561.method_43469(TOGGLE_MESSAGE_ALT, SLOPE_SIDE)
    );
    private static final List<class_2561> LINES_TRUE_ALT = List.of(
            class_2561.method_43469(SLOPE_MESSAGE_ALT, SLOPE_SIDE),
            class_2561.method_43469(TOGGLE_MESSAGE_ALT, SLOPE_FRONT)
    );
    private static final List<class_2561> LINES_FALSE_ALL = ConcatenatedListView.of(LINES_FALSE, LINES_FALSE_ALT);
    private static final List<class_2561> LINES_TRUE_ALL = ConcatenatedListView.of(LINES_TRUE, LINES_TRUE_ALT);

    private static final class_2960 SYMBOL_TEXTURE = Utils.rl("textures/overlay/yslope_symbols.png");
    private static final Texture TEXTURE_FALSE = new Texture(SYMBOL_TEXTURE, 0, 0, 20, 40, 80, 40);
    private static final Texture TEXTURE_TRUE = new Texture(SYMBOL_TEXTURE, 20, 0, 20, 40, 80, 40);
    private static final Texture TEXTURE_ALT_FALSE = new Texture(SYMBOL_TEXTURE, 40, 0, 20, 40, 80, 40);
    private static final Texture TEXTURE_ALT_TRUE = new Texture(SYMBOL_TEXTURE, 60, 0, 20, 40, 80, 40);

    public ToggleYSlopeOverlay()
    {
        super(LINES_FALSE_ALL, LINES_TRUE_ALL, TEXTURE_FALSE, TEXTURE_TRUE, () -> ClientConfig.toggleYSlopeMode);
    }

    @Override
    protected boolean isValidTool(class_1799 stack)
    {
        return stack.method_7909() == FBContent.ITEM_FRAMED_WRENCH.get();
    }

    @Override
    protected boolean isValidTarget(Target target)
    {
        return target.state().method_28498(FramedProperties.Y_SLOPE);
    }

    @Override
    protected boolean getState(Target target)
    {
        return target.state().method_11654(FramedProperties.Y_SLOPE);
    }

    @Override
    protected Texture getTexture(Target target, boolean state, Texture texFalse, Texture texTrue)
    {
        if (target.state().method_26204() instanceof IComplexSlopeSource src && src.isHorizontalSlope(target.state()))
        {
            return state ? TEXTURE_ALT_TRUE : TEXTURE_ALT_FALSE;
        }
        return super.getTexture(target, state, texFalse, texTrue);
    }

    @Override
    protected List<class_2561> getLines(Target target, boolean state, List<class_2561> linesFalse, List<class_2561> linesTrue)
    {
        if (target.state().method_26204() instanceof IComplexSlopeSource src && src.isHorizontalSlope(target.state()))
        {
            return state ? LINES_TRUE_ALT : LINES_FALSE_ALT;
        }
        else
        {
            return state ? LINES_TRUE : LINES_FALSE;
        }
    }
}
