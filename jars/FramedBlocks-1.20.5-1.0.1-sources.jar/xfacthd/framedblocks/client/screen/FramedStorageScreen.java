package xfacthd.framedblocks.client.screen;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;
import xfacthd.framedblocks.common.menu.FramedStorageMenu;

public class FramedStorageScreen extends class_465<FramedStorageMenu>
{
    private static final class_2960 CHEST_GUI_TEXTURE = new class_2960("textures/gui/container/generic_54.png");

    public FramedStorageScreen(FramedStorageMenu container, class_1661 inv, class_2561 title)
    {
        super(container, inv, title);

        this.field_2779 = 168;
        this.field_25270 = this.field_2779 - 94;
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTicks)
    {
        this.method_25420(graphics, mouseX, mouseY, partialTicks);
        super.method_25394(graphics, mouseX, mouseY, partialTicks);
        this.method_2380(graphics, mouseX, mouseY);
    }

    @Override
    protected void method_2389(class_332 graphics, float partialTicks, int x, int y)
    {
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);

        int left = (this.field_22789 - this.field_2792) / 2;
        int top = (this.field_22790 - this.field_2779) / 2;

        graphics.method_25302(CHEST_GUI_TEXTURE, left, top, 0, 0, field_2792, 71);
        graphics.method_25302(CHEST_GUI_TEXTURE, left, top + 71, 0, 126, field_2792, 96);
    }
}