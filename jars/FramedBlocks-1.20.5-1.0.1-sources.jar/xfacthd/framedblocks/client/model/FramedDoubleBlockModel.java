package xfacthd.framedblocks.client.model;

import net.fabricmc.fabric.api.renderer.v1.material.BlendMode;
import net.fabricmc.fabric.api.renderer.v1.material.RenderMaterial;
import net.fabricmc.fabric.api.renderer.v1.RendererAccess;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadEmitter;
import net.fabricmc.fabric.api.renderer.v1.model.FabricBakedModel;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.fabricmc.fabric.api.rendering.data.v1.RenderAttachmentBlockEntity;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1920;
import net.minecraft.class_1921;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3545;
import net.minecraft.class_4587;
import net.minecraft.class_5819;
import net.minecraft.class_776;
import net.minecraft.class_777;
import net.minecraft.class_811;
import xfacthd.framedblocks.api.model.BakedModelProxy;
import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.data.FramedBlockData;
import xfacthd.framedblocks.api.model.data.FramedDoubleBlockData;
import xfacthd.framedblocks.api.model.util.ModelUtils;
import xfacthd.framedblocks.common.data.doubleblock.DoubleBlockStateCache;
import xfacthd.framedblocks.common.block.IFramedDoubleBlock;
import xfacthd.framedblocks.common.util.DoubleBlockTopInteractionMode;

import org.jetbrains.annotations.Nullable;
import java.util.*;
import java.util.function.Supplier;

public class FramedDoubleBlockModel extends BakedModelProxy implements FabricBakedModel
{
    private static final FramedBlockData EMPTY_FRAME = new FramedBlockData.Immutable(
            class_2246.field_10124.method_9564(), new boolean[6], false
    );
    private static final FramedBlockData EMPTY_ALT_FRAME = new FramedBlockData.Immutable(
            class_2246.field_10124.method_9564(), new boolean[6], true
    );
    private static final java.util.concurrent.ConcurrentMap<BlendMode, RenderMaterial> RENDER_MATERIALS =
            new java.util.concurrent.ConcurrentHashMap<>();
    private static RenderMaterial renderMaterial(BlendMode blendMode)
    {
        return RENDER_MATERIALS.computeIfAbsent(blendMode, mode -> RendererAccess.INSTANCE
                .getRenderer().materialFinder()
                .blendMode(mode)
                .find());
    }

    private final boolean specialItemModel;
    private final DoubleBlockTopInteractionMode particleMode;
    private final class_243 handTransform;
    private final class_3545<class_2680, class_2680> dummyStates;
    private class_3545<class_1087, class_1087> models = null;

    public FramedDoubleBlockModel(
            class_2680 state,
            class_1087 baseModel,
            class_243 handTransform,
            boolean specialItemModel
    )
    {
        super(baseModel);
        DoubleBlockStateCache cache = ((IFramedDoubleBlock) state.method_26204()).getCache(state);
        this.dummyStates = cache.getBlockPair();
        this.particleMode = cache.getTopInteractionMode();
        this.handTransform = handTransform;
        this.specialItemModel = specialItemModel;
    }

    @Override
    public boolean isVanillaAdapter()
    {
        return false;
    }

    public void emitBlockQuads(
            class_1920 blockView, class_2680 state, class_2338 pos,
            Supplier<class_5819> randomSupplier, RenderContext context
    )
    {
        FramedDoubleBlockData doubleData;
        Object extraData = null;
        class_2586 be = blockView.method_8321(pos);
        if (be instanceof RenderAttachmentBlockEntity rabe)
        {
            extraData = rabe.getRenderAttachmentData();
        }
        if (extraData instanceof FramedDoubleBlockData data)
        {
            doubleData = data;
        }
        else
        {
            doubleData = new FramedDoubleBlockData(EMPTY_FRAME, EMPTY_ALT_FRAME);
        }

        QuadEmitter emitter = context.getEmitter();
        for (class_1921 renderType : getRenderTypes(state, randomSupplier.get(), doubleData))
        {
            context.pushTransform(q -> true);
            for (class_2350 dir : class_2350.values())
            {
                List<class_777> quads = getQuads(state, dir, randomSupplier.get(), doubleData, renderType);
                for (class_777 quad : quads)
                {
                    emitter.fromVanilla(quad.method_3357(), 0, false);
                    emitter.cullFace(quad.method_3358());
                    emitter.colorIndex(quad.method_3359());
                    emitter.material(renderMaterial(BlendMode.fromRenderLayer(renderType)));
                    emitter.emit();
                }
            }
            List<class_777> nullQuads = getQuads(state, null, randomSupplier.get(), doubleData, renderType);
            for (class_777 quad : nullQuads)
            {
                emitter.fromVanilla(quad.method_3357(), 0, false);
                emitter.cullFace(quad.method_3358());
                emitter.colorIndex(quad.method_3359());
                emitter.material(renderMaterial(BlendMode.fromRenderLayer(renderType)));
                emitter.emit();
            }
            context.popTransform();
        }
    }

    public List<class_777> getQuads(
            @Nullable class_2680 state, @Nullable class_2350 side, class_5819 rand,
            Object extraData, class_1921 layer
    )
    {
        FramedDoubleBlockData doubleData = (extraData instanceof FramedDoubleBlockData d) ? d : null;
        FramedBlockData dataLeft = doubleData != null ? doubleData.getLeft() : EMPTY_FRAME;
        FramedBlockData dataRight = doubleData != null ? doubleData.getRight() : EMPTY_ALT_FRAME;

        class_3545<class_1087, class_1087> models = getModels();

        List<class_777> quads = new ArrayList<>();
        quads.addAll(getHalfQuads(models.method_15442(), dummyStates.method_15442(), side, rand, dataLeft, layer));
        quads.addAll(invertTintIndizes(getHalfQuads(models.method_15441(), dummyStates.method_15441(), side, rand, dataRight, layer)));
        return quads;
    }

    private static List<class_777> getHalfQuads(
            class_1087 model, class_2680 state, class_2350 side, class_5819 rand,
            FramedBlockData data, class_1921 layer
    )
    {
        if (model instanceof FramedBlockModel framed)
        {
            return framed.getQuads(state, side, rand, data, layer);
        }
        if (layer == null || layer == class_1921.method_23577())
        {
            return model.method_4707(state, side, rand);
        }
        return List.of();
    }

    @Override
    public List<class_777> method_4707(class_2680 state, class_2350 side, class_5819 rand)
    {
        if (specialItemModel)
        {
            return getQuads(state, side, rand, null, class_1921.method_23581());
        }
        return super.method_4707(state, side, rand);
    }

    public Set<class_1921> getRenderTypes(class_2680 state, class_5819 rand, Object data)
    {
        FramedDoubleBlockData doubleData = (data instanceof FramedDoubleBlockData d) ? d : null;
        FramedBlockData dataLeft = doubleData != null ? doubleData.getLeft() : EMPTY_FRAME;
        FramedBlockData dataRight = doubleData != null ? doubleData.getRight() : EMPTY_ALT_FRAME;

        class_3545<class_1087, class_1087> models = getModels();
        return ModelUtils.union(
                getHalfRenderTypes(models.method_15442(), dummyStates.method_15442(), rand, dataLeft),
                getHalfRenderTypes(models.method_15441(), dummyStates.method_15441(), rand, dataRight)
        );
    }

    private static Set<class_1921> getHalfRenderTypes(
            class_1087 model, class_2680 state, class_5819 rand, FramedBlockData data
    )
    {
        if (model instanceof FramedBlockModel framed)
        {
            return framed.getRenderTypes(state, rand, data);
        }
        return ModelUtils.CUTOUT;
    }

    public class_1058 getParticleIcon(Object data)
    {
        return switch (particleMode)
        {
            case FIRST -> getSpriteOrDefault(data, false);
            case SECOND -> getSpriteOrDefault(data, true);
            case EITHER ->
            {
                class_1058 sprite = getSprite(data, false);
                if (sprite != null)
                {
                    yield sprite;
                }

                sprite = getSprite(data, true);
                if (sprite != null)
                {
                    yield sprite;
                }

                //noinspection deprecation
                yield baseModel.method_4711();
            }
        };
    }

    @Override
    protected void applyInHandTransformation(class_4587 poseStack, class_811 ctx)
    {
        if (handTransform != null)
        {
            poseStack.method_22904(handTransform.field_1352, handTransform.field_1351, handTransform.field_1350);
        }
    }



    protected final class_3545<class_1087, class_1087> getModels()
    {
        if (models == null)
        {
            class_776 dispatcher = class_310.method_1551().method_1541();
            models = new class_3545<>(
                    dispatcher.method_3349(dummyStates.method_15442()),
                    dispatcher.method_3349(dummyStates.method_15441())
            );
        }
        return models;
    }

    /**
     * Returns the camo-dependent particle texture of the side given by {@code key} when the camo is not air,
     * else returns the basic "framed block" sprite
     */
    protected final class_1058 getSpriteOrDefault(Object data, boolean secondary)
    {
        class_1058 sprite = getSprite(data, secondary);
        //noinspection deprecation
        return sprite != null ? sprite : baseModel.method_4711();
    }

    protected final class_1058 getSprite(Object data, boolean secondary)
    {
        FramedDoubleBlockData doubleData = (data instanceof FramedDoubleBlockData d) ? d : null;
        FramedBlockData halfData = doubleData != null ? (secondary ? doubleData.getRight() : doubleData.getLeft()) : null;
        if (halfData == null)
        {
            return null;
        }
        class_1087 halfModel = secondary ? getModels().method_15441() : getModels().method_15442();
        if (halfModel instanceof FramedBlockModel framed)
        {
            return framed.getParticleIcon(halfData);
        }
        return null;
    }

    private static List<class_777> invertTintIndizes(List<class_777> quads)
    {
        List<class_777> inverted = new ArrayList<>(quads.size());
        for (class_777 quad : quads)
        {
            inverted.add(ModelUtils.invertTintIndex(quad));
        }
        return inverted;
    }
}
