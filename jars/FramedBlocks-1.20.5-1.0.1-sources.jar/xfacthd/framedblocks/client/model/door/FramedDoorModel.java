package xfacthd.framedblocks.client.model.door;

import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.util.Utils;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2750;
import net.minecraft.class_777;

public class FramedDoorModel extends FramedBlockModel
{
    private final class_2350 dir;
    private final boolean hingeRight;
    private final boolean open;

    public FramedDoorModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        dir = state.method_11654(class_2741.field_12481);
        hingeRight = state.method_11654(class_2741.field_12520) == class_2750.field_12586;
        open = state.method_11654(class_2741.field_12537);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 faceDir = dir;
        if (open) { faceDir = hingeRight ? faceDir.method_10160() : faceDir.method_10170(); }

        class_2350 quadDir = quad.method_3358();
        if (Utils.isY(quadDir))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(faceDir, 3F/16F))
                    .export(quadMap.get(quadDir));
        }
        else
        {
            if (quadDir == faceDir)
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.setPosition(3F/16F))
                        .export(quadMap.get(null));
            }
            else
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(faceDir, 3F/16F))
                        .export(quadMap.get(quadDir));
            }
        }
    }
}