package xfacthd.framedblocks.client.model.door;

import net.minecraft.class_1087;
import net.minecraft.class_2680;

public class FramedIronTrapDoorModel extends FramedTrapDoorModel
{
    public FramedIronTrapDoorModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
    }

    @Override
    protected boolean useBaseModel()
    {
        return true;
    }
}