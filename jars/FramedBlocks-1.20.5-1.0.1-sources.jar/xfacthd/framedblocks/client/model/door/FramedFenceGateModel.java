package xfacthd.framedblocks.client.model.door;

import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.util.Utils;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_777;

public class FramedFenceGateModel extends FramedBlockModel
{
    private final class_2350 dir;
    private final boolean inWall;
    private final boolean open;

    public FramedFenceGateModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        dir = state.method_11654(class_2741.field_12481);
        inWall = state.method_11654(class_2741.field_12491);
        open = state.method_11654(class_2741.field_12537);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();
        float yOff = inWall ? 3F/16F : 0F;
        if (Utils.isY(quadDir))
        {
            float quadInset = quadDir == class_2350.field_11036 ? 1F - yOff : 11F/16F + yOff;

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir.method_10170(), 2F/16F))
                    .apply(Modifiers.cutTopBottom(dir, 9F/16F))
                    .apply(Modifiers.cutTopBottom(dir.method_10153(), 9F/16F))
                    .apply(Modifiers.setPosition(quadInset))
                    .export(quadMap.get(inWall || quadDir == class_2350.field_11033 ? null : quadDir));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir.method_10160(), 2F/16F))
                    .apply(Modifiers.cutTopBottom(dir, 9F/16F))
                    .apply(Modifiers.cutTopBottom(dir.method_10153(), 9F/16F))
                    .apply(Modifiers.setPosition(quadInset))
                    .export(quadMap.get(inWall || quadDir == class_2350.field_11033 ? null : quadDir));
        }
        else if (quadDir == dir || quadDir == dir.method_10153())
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(dir.method_10170(), 2F/16F))
                    .apply(Modifiers.cutSideUpDown(true, 11F/16F + yOff))
                    .apply(Modifiers.cutSideUpDown(false, 1F - yOff))
                    .apply(Modifiers.setPosition(9F/16F))
                    .export(quadMap.get(null));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(dir.method_10160(), 2F/16F))
                    .apply(Modifiers.cutSideUpDown(true, 11F/16F + yOff))
                    .apply(Modifiers.cutSideUpDown(false, 1F - yOff))
                    .apply(Modifiers.setPosition(9F/16F))
                    .export(quadMap.get(null));
        }
        else if (quadDir == dir.method_10170() || quadDir == dir.method_10160())
        {
            QuadModifier mod = QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSide(7F/16F, 5F/16F - yOff, 9F/16F, 1F - yOff));

            mod.export(quadMap.get(quadDir));

            mod.apply(Modifiers.setPosition(2F/16F))
                    .export(quadMap.get(null));
        }

        if (open)
        {
            createGateOpen(quadMap, quad, yOff);
        }
        else
        {
            createGateClosed(quadMap.get(null), quad, yOff);
        }
    }

    private void createGateClosed(List<class_777> quadList, class_777 quad, float yOff)
    {
        class_2350 quadDir = quad.method_3358();
        if (quadDir == dir || quadDir == dir.method_10153())
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSide(2F/16F, 12F/16F - yOff, 14F/16F, 15F/16F - yOff))
                    .apply(Modifiers.setPosition(9F/16F))
                    .export(quadList);

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSide(2F/16F, 6F/16F - yOff, 14F/16F, 9F/16F - yOff))
                    .apply(Modifiers.setPosition(9F/16F))
                    .export(quadList);

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSide(6F/16F, 9F/16F - yOff, 10F/16F, 12F/16F - yOff))
                    .apply(Modifiers.setPosition(9F/16F))
                    .export(quadList);
        }
        else if (Utils.isY(quadDir))
        {
            QuadModifier mod = QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir, 9F/16F))
                    .apply(Modifiers.cutTopBottom(dir.method_10153(), 9F/16F))
                    .apply(Modifiers.cutTopBottom(dir.method_10170(), 14F/16F))
                    .apply(Modifiers.cutTopBottom(dir.method_10160(), 14F/16F));

            if (mod.hasFailed())
            {
                return;
            }

            boolean up = quadDir == class_2350.field_11036;
            float height = up ? 9F / 16F - yOff : 4F / 16F + yOff;

            mod.derive().apply(Modifiers.setPosition(up ? 15F/16F - yOff : 10F/16F + yOff))
                    .export(quadList);

            mod.derive().apply(Modifiers.cutTopBottom(dir.method_10170(), 6F/16F))
                    .apply(Modifiers.setPosition(height))
                    .export(quadList);

            mod.apply(Modifiers.cutTopBottom(dir.method_10160(), 6F/16F))
                    .apply(Modifiers.setPosition(height))
                    .export(quadList);
        }
        else if (quadDir == dir.method_10170() || quadDir == dir.method_10160())
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSide(7F/16F, 9F/16F - yOff, 9F/16F, 12F/16F - yOff))
                    .apply(Modifiers.setPosition(10F/16F))
                    .export(quadList);
        }
    }

    private void createGateOpen(Map<class_2350, List<class_777>> quadMap, class_777 quad, float yOff)
    {
        class_2350 quadDir = quad.method_3358();
        if (quadDir == dir.method_10170() || quadDir == dir.method_10160())
        {
            QuadModifier mod = QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(dir.method_10153(), 7F/16F))
                    .apply(Modifiers.cutSideLeftRight(dir, 15F/16F))
                    .apply(Modifiers.cutSideUpDown(false, 15F/16F - yOff))
                    .apply(Modifiers.cutSideUpDown(true, 10F/16F + yOff));

            QuadModifier topMod = mod.derive()
                    .apply(Modifiers.cutSideUpDown(true, 4F/16F + yOff));

            topMod.export(quadMap.get(null));
            topMod.apply(Modifiers.setPosition(2F/16F))
                    .export(quadMap.get(null));

            QuadModifier botMod = mod.derive()
                    .apply(Modifiers.cutSideUpDown(false, 9F/16F - yOff));

            botMod.export(quadMap.get(null));
            botMod.apply(Modifiers.setPosition(2F/16F))
                    .export(quadMap.get(null));

            mod.apply(Modifiers.cutSideUpDown(false, 12F/16F - yOff))
                    .apply(Modifiers.cutSideUpDown(true, 7F/16F + yOff))
                    .apply(Modifiers.cutSideLeftRight(dir.method_10153(), 3F/16F))
                    .export(quadMap.get(null));

            mod.apply(Modifiers.setPosition(2F/16F))
                    .export(quadMap.get(null));
        }
        else if (Utils.isY(quadDir))
        {
            boolean up = quadDir == class_2350.field_11036;
            float heightOuter = up ? 15F/16F - yOff : 10F/16F + yOff;
            float heightInner = up ? 9F/16F - yOff : 4F/16F + yOff;

            QuadModifier mod = QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir, 15F/16F))
                    .apply(Modifiers.cutTopBottom(dir.method_10153(), 7F/16F));

            QuadModifier leftMod = mod.derive()
                    .apply(Modifiers.cutTopBottom(dir.method_10170(), 2F/16F))
                    .apply(Modifiers.setPosition(heightOuter));

            leftMod.export(quadMap.get(null));
            leftMod.apply(Modifiers.cutTopBottom(dir, 13F/16F))
                    .apply(Modifiers.setPosition(heightInner))
                    .export(quadMap.get(null));

            QuadModifier rightMod = mod
                    .apply(Modifiers.cutTopBottom(dir.method_10160(), 2F/16F))
                    .apply(Modifiers.setPosition(heightOuter));

            rightMod.export(quadMap.get(null));
            rightMod.apply(Modifiers.cutTopBottom(dir, 13F/16F))
                    .apply(Modifiers.setPosition(heightInner))
                    .export(quadMap.get(null));
        }
        else if (quadDir == dir)
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSide(0F, 6F/16F - yOff, 2F/16F, 15F/16F - yOff))
                    .apply(Modifiers.setPosition(15F/16F))
                    .export(quadMap.get(null));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSide(14F/16F, 6F/16F - yOff, 1F, 15F/16F - yOff))
                    .apply(Modifiers.setPosition(15F/16F))
                    .export(quadMap.get(null));
        }
        else if (quadDir == dir.method_10153())
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSide(0F, 9F/16F - yOff, 2F/16F, 12F/16F - yOff))
                    .apply(Modifiers.setPosition(3F/16F))
                    .export(quadMap.get(null));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSide(14F/16F, 9F/16F - yOff, 1F, 12F/16F - yOff))
                    .apply(Modifiers.setPosition(3F/16F))
                    .export(quadMap.get(null));
        }
    }

    @Override
    public boolean useSolidNoCamoModel()
    {
        return true;
    }
}