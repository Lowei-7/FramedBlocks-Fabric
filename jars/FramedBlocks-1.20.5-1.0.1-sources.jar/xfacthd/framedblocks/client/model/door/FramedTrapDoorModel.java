package xfacthd.framedblocks.client.model.door;

import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.util.Utils;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2760;
import net.minecraft.class_777;

public class FramedTrapDoorModel extends FramedBlockModel
{
    private static final float DEPTH = 3F/16F;

    private final class_2350 dir;
    private final boolean top;
    private final boolean open;

    public FramedTrapDoorModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        dir = state.method_11654(class_2741.field_12481);
        top = state.method_11654(class_2741.field_12518) == class_2760.field_12619;
        open = state.method_11654(class_2741.field_12537);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();
        if (open)
        {
            if (quadDir == dir)
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.setPosition(DEPTH))
                        .export(quadMap.get(null));
            }
            else if (Utils.isY(quadDir))
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(dir, DEPTH))
                        .export(quadMap.get(quadDir));
            }
            else
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(dir, DEPTH))
                        .export(quadMap.get(quadDir));
            }
        }
        else
        {
            if ((top && quad.method_3358() == class_2350.field_11033) || (!top && quad.method_3358() == class_2350.field_11036))
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.setPosition(DEPTH))
                        .export(quadMap.get(null));
            }
            else if (!Utils.isY(quad.method_3358()))
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideUpDown(top, DEPTH))
                        .export(quadMap.get(quadDir));
            }
        }
    }
}