package xfacthd.framedblocks.client.model.slopepanel;

import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.HorizontalRotation;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_777;
import net.minecraft.class_811;

public class FramedFlatSlopePanelCornerModel extends FramedBlockModel
{
    private final class_2350 facing;
    private final HorizontalRotation rotation;
    private final HorizontalRotation rotRotation;
    private final class_2350 orientation;
    private final class_2350 rotOrientation;
    private final boolean front;
    private final boolean ySlope;

    public FramedFlatSlopePanelCornerModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        this.facing = state.method_11654(FramedProperties.FACING_HOR);
        this.rotation = state.method_11654(PropertyHolder.ROTATION);
        this.rotRotation = rotation.rotate(class_2470.field_11465);
        this.orientation = rotation.withFacing(facing);
        this.rotOrientation = rotRotation.withFacing(facing);
        this.front = state.method_11654(PropertyHolder.FRONT);
        this.ySlope = state.method_11654(FramedProperties.Y_SLOPE);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 face = quad.method_3358();
        if (face == orientation.method_10153())
        {
            createSideTriangle(quadMap, quad, facing, rotRotation, front, false);
        }
        else if (face == rotOrientation.method_10153())
        {
            createSideTriangle(quadMap, quad, facing, rotation, front, false);
        }
        else if (face == facing.method_10153())
        {
            if (!ySlope || !Utils.isY(orientation))
            {
                QuadModifier.geometry(quad)
                        .apply(createSlopeTriangle(facing, orientation, false))
                        .apply(FramedSlopePanelModel.createSlope(facing, orientation))
                        .applyIf(Modifiers.offset(facing, .5F), !front)
                        .export(quadMap.get(null));
            }

            if (!ySlope || !Utils.isY(rotOrientation))
            {
                QuadModifier.geometry(quad)
                        .apply(createSlopeTriangle(facing, rotOrientation, true))
                        .apply(FramedSlopePanelModel.createSlope(facing, rotOrientation))
                        .applyIf(Modifiers.offset(facing, .5F), !front)
                        .export(quadMap.get(null));
            }
        }
        else if (ySlope && Utils.isY(orientation) && face == orientation)
        {
            QuadModifier.geometry(quad)
                    .apply(createVerticalSlopeTriangle(facing, orientation, false))
                    .apply(FramedSlopePanelModel.createVerticalSlope(facing, orientation))
                    .applyIf(Modifiers.offset(facing.method_10153(), .5F), front)
                    .export(quadMap.get(null));
        }
        else if (ySlope && Utils.isY(rotOrientation) && face == rotOrientation)
        {
            QuadModifier.geometry(quad)
                    .apply(createVerticalSlopeTriangle(facing, rotOrientation, true))
                    .apply(FramedSlopePanelModel.createVerticalSlope(facing, rotOrientation))
                    .applyIf(Modifiers.offset(facing.method_10153(), .5F), front)
                    .export(quadMap.get(null));
        }
        else if (face == facing && front)
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.setPosition(.5F))
                    .export(quadMap.get(null));
        }
    }

    public static QuadModifier.Modifier createSlopeTriangle(class_2350 facing, class_2350 orientation, boolean second)
    {
        if (Utils.isY(orientation))
        {
            boolean down = orientation == class_2350.field_11036;
            float right = (down != second) ? 0 : 1;
            float left  = (down != second) ? 1 : 0;
            return Modifiers.cutSideUpDown(down, right, left);
        }
        else
        {
            boolean right = orientation == facing.method_10170();
            float top = (right != second) ? 0 : 1;
            float bot = (right != second) ? 1 : 0;
            return Modifiers.cutSideLeftRight(right, top, bot);
        }
    }

    public static QuadModifier.Modifier createVerticalSlopeTriangle(
            class_2350 facing, class_2350 orientation, boolean second
    )
    {
        boolean down = orientation == class_2350.field_11033;
        float right = (second == down) ? 0 : 1;
        float left  = (second == down) ? 1 : 0;
        return Modifiers.cutTopBottom(facing.method_10153(), right, left);
    }

    public static void createSideTriangle(
            Map<class_2350, List<class_777>> quadMap,
            class_777 quad,
            class_2350 facing,
            HorizontalRotation rotation,
            boolean front,
            boolean extended
    )
    {
        class_2350 face = quad.method_3358();
        class_2350 orientation = rotation.withFacing(facing);
        boolean yAxis = Utils.isY(orientation);

        if (yAxis)
        {
            boolean up = orientation == class_2350.field_11036;
            float top =    up ? (front ? .5F :  0F) : (front ?  1F : .5F);
            float bottom = up ? (front ?  1F : .5F) : (front ? .5F :  0F);
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(facing.method_10153(), top, bottom))
                    .applyIf(Modifiers.cutSideLeftRight(facing, .5F), front && !extended)
                    .export(quadMap.get(face));
        }
        else
        {
            boolean rightRot = rotation == HorizontalRotation.RIGHT;
            float right = rightRot ? (front ?  1F : .5F) : (front ? .5F :  0F);
            float left =  rightRot ? (front ? .5F :  0F) : (front ?  1F : .5F);
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(facing.method_10153(), right, left))
                    .applyIf(Modifiers.cutTopBottom(facing, .5F), front && !extended)
                    .export(quadMap.get(face));
        }
    }

    @Override
    protected void applyInHandTransformation(class_4587 poseStack, class_811 ctx)
    {
        poseStack.method_22904(0, .5, 0);
    }



    public static class_2680 itemSource()
    {
        return FBContent.BLOCK_FRAMED_FLAT_SLOPE_PANEL_CORNER.get()
                .method_9564()
                .method_11657(FramedProperties.FACING_HOR, class_2350.field_11035)
                .method_11657(PropertyHolder.ROTATION, HorizontalRotation.RIGHT);
    }
}
