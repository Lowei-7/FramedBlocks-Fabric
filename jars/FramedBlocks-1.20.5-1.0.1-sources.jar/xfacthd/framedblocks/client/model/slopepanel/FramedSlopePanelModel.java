package xfacthd.framedblocks.client.model.slopepanel;

import com.google.common.base.Preconditions;
import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.HorizontalRotation;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_777;
import net.minecraft.class_811;

public class FramedSlopePanelModel extends FramedBlockModel
{
    public static final float SLOPE_ANGLE = (float) Math.toDegrees(Math.atan(.5));
    public static final float SLOPE_ANGLE_VERT = (float) (90D - Math.toDegrees(Math.atan(.5)));

    private final class_2350 facing;
    private final HorizontalRotation rotation;
    private final class_2350 orientation;
    private final class_2350.class_2351 triangleAxis;
    private final boolean front;
    private final boolean ySlope;

    public FramedSlopePanelModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        this.facing = state.method_11654(FramedProperties.FACING_HOR);
        this.rotation = state.method_11654(PropertyHolder.ROTATION);
        this.orientation = rotation.withFacing(facing);
        this.triangleAxis = rotation.rotate(class_2470.field_11463).withFacing(facing).method_10166();
        this.front = state.method_11654(PropertyHolder.FRONT);
        this.ySlope = state.method_11654(FramedProperties.Y_SLOPE);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 face = quad.method_3358();
        boolean yAxis = Utils.isY(orientation);
        if (face == orientation.method_10153())
        {
            class_2350 cutDir = front ? facing : facing.method_10153();
            if (Utils.isY(orientation))
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(cutDir, .5F))
                        .export(quadMap.get(face));
            }
            else
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(cutDir, .5F))
                        .export(quadMap.get(face));
            }
        }
        else if ((!rotation.isVertical() || !ySlope) && face == facing.method_10153())
        {
            QuadModifier.geometry(quad)
                    .apply(createSlope(facing, orientation))
                    .applyIf(Modifiers.offset(facing, .5F), !front)
                    .export(quadMap.get(null));
        }
        else if (ySlope && isVerticalSlopeQuad(rotation, face))
        {
            QuadModifier.geometry(quad)
                    .apply(createVerticalSlope(facing, orientation))
                    .applyIf(Modifiers.offset(facing.method_10153(), .5F), front)
                    .export(quadMap.get(null));
        }
        else if (face == facing)
        {
            if (front)
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.setPosition(.5F))
                        .export(quadMap.get(null));
            }
        }
        else if (face.method_10166() == triangleAxis)
        {
            if (yAxis)
            {
                boolean up = orientation == class_2350.field_11036;
                float top =    up ? (front ? .5F :  0F) : (front ?  1F : .5F);
                float bottom = up ? (front ?  1F : .5F) : (front ? .5F :  0F);
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(facing.method_10153(), top, bottom))
                        .applyIf(Modifiers.cutSideLeftRight(facing, .5F), front)
                        .export(quadMap.get(face));
            }
            else
            {
                boolean rightRot = rotation == HorizontalRotation.RIGHT;
                float right = rightRot ? (front ?  1F : .5F) : (front ? .5F :  0F);
                float left =  rightRot ? (front ? .5F :  0F) : (front ?  1F : .5F);
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(facing.method_10153(), right, left))
                        .applyIf(Modifiers.cutTopBottom(facing, .5F), front)
                        .export(quadMap.get(face));
            }
        }
    }

    @Override
    protected void applyInHandTransformation(class_4587 poseStack, class_811 ctx)
    {
        poseStack.method_22904(0, .5, 0);
    }



    public static boolean isVerticalSlopeQuad(HorizontalRotation rotation, class_2350 face)
    {
        return switch (rotation)
                {
                    case DOWN -> face == class_2350.field_11033;
                    case UP -> face == class_2350.field_11036;
                    default -> false;
                };
    }

    public static QuadModifier.Modifier createSlope(class_2350 facing, class_2350 orientation)
    {
        Preconditions.checkArgument(facing.method_10166() != orientation.method_10166(), "Directions must be perpendicular");

        if (Utils.isY(orientation))
        {
            return Modifiers.makeVerticalSlope(orientation == class_2350.field_11036, SLOPE_ANGLE);
        }
        else
        {
            return Modifiers.makeHorizontalSlope(orientation == facing.method_10160(), SLOPE_ANGLE);
        }
    }

    public static QuadModifier.Modifier createVerticalSlope(class_2350 facing, class_2350 orientation)
    {
        Preconditions.checkArgument(facing.method_10166() != orientation.method_10166(), "Directions must be perpendicular");
        return Modifiers.makeVerticalSlope(facing.method_10153(), SLOPE_ANGLE_VERT);
    }

    public static class_2680 itemSource()
    {
        return FBContent.BLOCK_FRAMED_SLOPE_PANEL.get()
                .method_9564()
                .method_11657(FramedProperties.FACING_HOR, class_2350.field_11035);
    }
}
