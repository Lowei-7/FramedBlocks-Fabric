package xfacthd.framedblocks.client.model.slopepanel;

import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.HorizontalRotation;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_777;

public class FramedExtendedSlopePanelModel extends FramedBlockModel
{
    private final class_2350 facing;
    private final HorizontalRotation rotation;
    private final class_2350 orientation;
    private final boolean ySlope;

    public FramedExtendedSlopePanelModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        this.facing = state.method_11654(FramedProperties.FACING_HOR);
        this.rotation = state.method_11654(PropertyHolder.ROTATION);
        this.orientation = rotation.withFacing(facing);
        this.ySlope = state.method_11654(FramedProperties.Y_SLOPE);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 face = quad.method_3358();
        boolean yAxis = Utils.isY(orientation);
        if (face == orientation)
        {
            if (Utils.isY(orientation))
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(facing.method_10153(), .5F))
                        .export(quadMap.get(face));

                if (ySlope)
                {
                    QuadModifier.geometry(quad)
                            .apply(FramedSlopePanelModel.createVerticalSlope(facing, orientation))
                            .apply(Modifiers.offset(facing.method_10153(), .5F))
                            .export(quadMap.get(null));
                }
            }
            else
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(facing.method_10153(), .5F))
                        .export(quadMap.get(face));
            }
        }
        else if ((!rotation.isVertical() || !ySlope) && face == facing.method_10153())
        {
            QuadModifier.geometry(quad)
                    .apply(FramedSlopePanelModel.createSlope(facing, orientation))
                    .export(quadMap.get(null));
        }
        else if (face.method_10166() != facing.method_10166() && face.method_10166() != orientation.method_10166())
        {
            if (yAxis)
            {
                boolean up = orientation == class_2350.field_11036;
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(facing.method_10153(), up ? .5F :  1F, up ?  1F : .5F))
                        .export(quadMap.get(face));
            }
            else
            {
                boolean rightRot = rotation == HorizontalRotation.RIGHT;
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(facing.method_10153(), rightRot ?  1F : .5F, rightRot ? .5F :  1F))
                        .export(quadMap.get(face));
            }
        }
    }



    public static class_2680 itemSource()
    {
        return FBContent.BLOCK_FRAMED_EXTENDED_SLOPE_PANEL.get()
                .method_9564()
                .method_11657(FramedProperties.FACING_HOR, class_2350.field_11035);
    }
}
