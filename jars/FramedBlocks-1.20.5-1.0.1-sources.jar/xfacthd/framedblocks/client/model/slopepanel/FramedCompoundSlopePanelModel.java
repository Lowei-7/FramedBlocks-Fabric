package xfacthd.framedblocks.client.model.slopepanel;

import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.HorizontalRotation;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_777;

public class FramedCompoundSlopePanelModel extends FramedBlockModel
{
    private final class_2350 dir;
    private final HorizontalRotation rot;
    private final class_2350 orientation;
    private final class_2350.class_2351 triangleAxis;
    private final boolean ySlope;

    public FramedCompoundSlopePanelModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        this.dir = state.method_11654(FramedProperties.FACING_HOR);
        this.rot = state.method_11654(PropertyHolder.ROTATION);
        this.orientation = rot.withFacing(dir);
        this.triangleAxis = rot.rotate(class_2470.field_11463).withFacing(dir).method_10166();
        this.ySlope = state.method_11654(FramedProperties.Y_SLOPE);
    }

    @Override
    public void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();
        if (quadDir == orientation)
        {
            if (Utils.isY(quadDir))
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(dir.method_10153(), .5F))
                        .export(quadMap.get(quadDir));
            }
            else
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(dir.method_10153(), .5F))
                        .export(quadMap.get(quadDir));
            }
        }
        else if (quadDir == orientation.method_10153())
        {
            if (Utils.isY(quadDir))
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(dir, .5F))
                        .export(quadMap.get(quadDir));
            }
            else
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(dir, .5F))
                        .export(quadMap.get(quadDir));
            }
        }
        else if (quadDir == dir)
        {
            if (!Utils.isY(orientation))
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.makeHorizontalSlope(rot == HorizontalRotation.LEFT, FramedSlopePanelModel.SLOPE_ANGLE))
                        .export(quadMap.get(null));
            }
            else if (!ySlope)
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.makeVerticalSlope(rot == HorizontalRotation.DOWN, FramedSlopePanelModel.SLOPE_ANGLE))
                        .export(quadMap.get(null));
            }
        }
        else if (quadDir == dir.method_10153())
        {
            if (!Utils.isY(orientation))
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.makeHorizontalSlope(rot == HorizontalRotation.LEFT, FramedSlopePanelModel.SLOPE_ANGLE))
                        .export(quadMap.get(null));
            }
            else if (!ySlope)
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.makeVerticalSlope(rot == HorizontalRotation.UP, FramedSlopePanelModel.SLOPE_ANGLE))
                        .export(quadMap.get(null));
            }
        }
        else if (triangleAxis == class_2350.class_2351.field_11052 && Utils.isY(quadDir))
        {
            boolean right = rot == HorizontalRotation.RIGHT;
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir, right ? 1F : .5F, right ? .5F : 1F))
                    .apply(Modifiers.cutTopBottom(dir.method_10153(), right ? 1F : .5F, right ? .5F : 1F))
                    .export(quadMap.get(quadDir));
        }
        else if (triangleAxis != class_2350.class_2351.field_11052 && quadDir.method_10166() == triangleAxis)
        {
            boolean up = rot == HorizontalRotation.UP;
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(dir, up ? 1F : .5F, up ? .5F : 1F))
                    .apply(Modifiers.cutSideLeftRight(dir.method_10153(), up ? .5F : 1F, up ? 1F : .5F))
                    .export(quadMap.get(quadDir));
        }
    }
}
