package xfacthd.framedblocks.client.model.slope;

import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.CornerType;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_777;

public class FramedInnerCornerSlopeModel extends FramedBlockModel
{
    private final class_2350 dir;
    private final CornerType type;
    private final boolean ySlope;

    public FramedInnerCornerSlopeModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        this.dir = state.method_11654(FramedProperties.FACING_HOR);
        this.type = state.method_11654(PropertyHolder.CORNER_TYPE);
        this.ySlope = state.method_11654(FramedProperties.Y_SLOPE);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        if (type.isHorizontal())
        {
            createHorizontalCorner(quadMap, quad);
        }
        else
        {
            createVerticalCorner(quadMap, quad);
        }
    }

    private void createHorizontalCorner(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();
        boolean top = type.isTop();
        boolean right = type.isRight();

        if ((quadDir == class_2350.field_11036 && !top) || (quadDir == class_2350.field_11033 && top))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir.method_10153(), right ? 0 : 1, right ? 1 : 0))
                    .export(quadMap.get(quadDir));

            if (ySlope)
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(dir, right ? 0 : 1, right ? 1 : 0))
                        .apply(Modifiers.makeVerticalSlope(dir.method_10153(), 45))
                        .export(quadMap.get(null));
            }
        }
        else if (quadDir == dir.method_10153())
        {
            class_2350 cutDir = right ? dir.method_10160() : dir.method_10170();
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(cutDir, top ? 0 : 1, top ? 1 : 0))
                    .apply(Modifiers.makeHorizontalSlope(right, 45))
                    .export(quadMap.get(null));

            if (!ySlope)
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideUpDown(top, right ? 1 : 0, right ? 0 : 1))
                        .apply(Modifiers.makeVerticalSlope(!top, 45))
                        .export(quadMap.get(null));
            }
        }
        else if ((quadDir == dir.method_10170() && !right) || (quadDir == dir.method_10160() && right))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(dir.method_10153(), top ? 1 : 0, top ? 0 : 1))
                    .export(quadMap.get(quadDir));
        }
    }

    private void createVerticalCorner(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();
        boolean top = type.isTop();

        if (quadDir == dir.method_10170())
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(dir.method_10153(), top ? 1 : 0, top ? 0 : 1))
                    .export(quadMap.get(quadDir));

            if (!ySlope)
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(dir, top ? 0 : 1, top ? 1 : 0))
                        .apply(Modifiers.makeVerticalSlope(!top, 45))
                        .export(quadMap.get(null));
            }
        }
        else if (quadDir == dir.method_10153())
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(dir.method_10170(), top ? 1 : 0, top ? 0 : 1))
                    .export(quadMap.get(quadDir));

            if (!ySlope)
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(dir.method_10160(), top ? 0 : 1, top ? 1 : 0))
                        .apply(Modifiers.makeVerticalSlope(!top, 45))
                        .export(quadMap.get(null));
            }
        }
        else if (ySlope && ((!top && quadDir == class_2350.field_11036) || (top && quadDir == class_2350.field_11033)))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir.method_10170(), 1, 0))
                    .apply(Modifiers.makeVerticalSlope(dir.method_10170(), 45))
                    .export(quadMap.get(null));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir.method_10153(), 0, 1))
                    .apply(Modifiers.makeVerticalSlope(dir.method_10153(), 45))
                    .export(quadMap.get(null));
        }
    }



    public static class_2680 itemSource()
    {
        return FBContent.BLOCK_FRAMED_INNER_CORNER_SLOPE.get()
                .method_9564()
                .method_11657(FramedProperties.FACING_HOR, class_2350.field_11035);
    }
}