package xfacthd.framedblocks.client.model.slope;

import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.data.PropertyHolder;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_777;

public class FramedHalfSlopeModel extends FramedBlockModel
{
    private final class_2350 dir;
    private final boolean top;
    private final boolean right;
    private final boolean ySlope;

    public FramedHalfSlopeModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        this.dir = state.method_11654(FramedProperties.FACING_HOR);
        this.top = state.method_11654(FramedProperties.TOP);
        this.right = state.method_11654(PropertyHolder.RIGHT);
        this.ySlope = state.method_11654(FramedProperties.Y_SLOPE);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();

        class_2350 cutDir = right ? dir.method_10160() : dir.method_10170();

        if (!ySlope && quadDir == dir.method_10153())
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.makeVerticalSlope(!top, 45))
                    .apply(Modifiers.cutSideLeftRight(cutDir, .5F))
                    .export(quadMap.get(null));
        }
        else if (ySlope && ((!top && quadDir == class_2350.field_11036) || (top && quadDir == class_2350.field_11033)))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(cutDir, .5F))
                    .apply(Modifiers.makeVerticalSlope(dir.method_10153(), 45))
                    .export(quadMap.get(null));
        }
        else if (quadDir == dir.method_10170() || quadDir == dir.method_10160())
        {
            boolean needOffset = right == (quadDir == dir.method_10160());

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(dir.method_10153(), top ? 1 : 0, top ? 0 : 1))
                    .applyIf(Modifiers.setPosition(.5F), needOffset)
                    .export(quadMap.get(needOffset ? null : quadDir));
        }
        else if ((!top && quadDir == class_2350.field_11033) || (top && quadDir == class_2350.field_11036))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(cutDir, .5F))
                    .export(quadMap.get(quadDir));
        }
        else if (quadDir == dir)
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(cutDir, .5F))
                    .export(quadMap.get(quadDir));
        }
    }



    public static class_2680 itemSource()
    {
        return FBContent.BLOCK_FRAMED_HALF_SLOPE.get()
                .method_9564()
                .method_11657(FramedProperties.FACING_HOR, class_2350.field_11035);
    }
}
