package xfacthd.framedblocks.client.model.slope;

import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.CornerType;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_777;

public class FramedCornerSlopeModel extends FramedBlockModel
{
    private final class_2350 dir;
    private final CornerType type;
    private final boolean ySlope;

    public FramedCornerSlopeModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        this.dir = state.method_11654(FramedProperties.FACING_HOR);
        this.type = state.method_11654(PropertyHolder.CORNER_TYPE);
        this.ySlope = state.method_11654(FramedProperties.Y_SLOPE);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        if (type.isHorizontal())
        {
            createHorizontalCornerSlope(quadMap, quad);
        }
        else
        {
            createVerticalCornerSlope(quadMap, quad);
        }
    }

    @SuppressWarnings("ConstantConditions")
    private void createHorizontalCornerSlope(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();
        boolean top = type.isTop();
        boolean right = type.isRight();

        if ((quadDir == dir.method_10170() && right) || (quadDir == dir.method_10160() && !right))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(dir.method_10153(), top ? 1 : 0, top ? 0 : 1))
                    .export(quadMap.get(quadDir));
        }
        else if ((quadDir == class_2350.field_11036 && top) || (quadDir == class_2350.field_11033 && !top))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir.method_10153(), right ? 0 : 1, right ? 1 : 0))
                    .export(quadMap.get(quadDir));
        }
        else if ((quadDir == dir.method_10160() && right) || (quadDir == dir.method_10170() && !right))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(dir.method_10153(), top ? 1 : 0, top ? 0 : 1))
                    .apply(Modifiers.makeHorizontalSlope(!right, 45))
                    .export(quadMap.get(null));
        }
        else if (!ySlope && quadDir == dir.method_10153())
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideUpDown(!top, right ? 0 : 1, right ? 1 : 0))
                    .apply(Modifiers.makeVerticalSlope(!top, 45))
                    .export(quadMap.get(null));
        }
        else if (ySlope && ((!top && quadDir == class_2350.field_11036) || (top && quadDir == class_2350.field_11033)))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir.method_10153(), right ? 0 : 1, right ? 1 : 0))
                    .apply(Modifiers.makeVerticalSlope(dir.method_10153(), 45))
                    .export(quadMap.get(null));
        }
    }

    private void createVerticalCornerSlope(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();
        boolean yQuad = Utils.isY(quadDir);
        if (!ySlope && yQuad)
        {
            return;
        }

        boolean top = type.isTop();
        class_2350 cutDir = quadDir.method_10166() == dir.method_10166() ? dir.method_10170() : dir.method_10153();
        boolean slope = quadDir == dir.method_10153() || quadDir == dir.method_10170();

        if ((!slope && !yQuad) || !ySlope)
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(cutDir, top ? 1 : 0, top ? 0 : 1))
                    .applyIf(Modifiers.makeVerticalSlope(!top, 45), slope)
                    .export(quadMap.get(slope ? null : quadDir));
        }
        else if (yQuad)
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir.method_10153(), 0, 1))
                    .apply(Modifiers.makeVerticalSlope(dir.method_10170(), 45))
                    .export(quadMap.get(null));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir.method_10170(), 1, 0))
                    .apply(Modifiers.makeVerticalSlope(dir.method_10153(), 45))
                    .export(quadMap.get(null));
        }
    }



    public static class_2680 itemSource()
    {
        return FBContent.BLOCK_FRAMED_CORNER_SLOPE.get()
                .method_9564()
                .method_11657(FramedProperties.FACING_HOR, class_2350.field_11035);
    }
}