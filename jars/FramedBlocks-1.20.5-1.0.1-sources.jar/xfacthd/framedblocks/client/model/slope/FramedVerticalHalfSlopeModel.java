package xfacthd.framedblocks.client.model.slope;

import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_777;
import net.minecraft.class_811;

public class FramedVerticalHalfSlopeModel extends FramedBlockModel
{
    private final class_2350 dir;
    private final boolean top;
    private final boolean ySlope;

    public FramedVerticalHalfSlopeModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        this.dir = state.method_11654(FramedProperties.FACING_HOR);
        this.top = state.method_11654(FramedProperties.TOP);
        this.ySlope = state.method_11654(FramedProperties.Y_SLOPE);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();

        if (!ySlope && quadDir == dir.method_10153())
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.makeHorizontalSlope(false, 45))
                    .apply(Modifiers.cutSideUpDown(top, .5F))
                    .export(quadMap.get(null));
        }
        else if (ySlope && quadDir == dir.method_10170())
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.makeHorizontalSlope(true, 45))
                    .apply(Modifiers.cutSideUpDown(top, .5F))
                    .export(quadMap.get(null));
        }
        else if (Utils.isY(quadDir))
        {
            boolean needOffset = top == (quadDir == class_2350.field_11033);

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir.method_10153(), 1, 0))
                    .applyIf(Modifiers.setPosition(.5F), needOffset)
                    .export(quadMap.get(needOffset ? null : quadDir));
        }
        else if (quadDir == dir || quadDir == dir.method_10160())
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideUpDown(top, .5F))
                    .export(quadMap.get(quadDir));
        }
    }

    @Override
    protected void applyInHandTransformation(class_4587 poseStack, class_811 ctx)
    {
        poseStack.method_22904(0, .5, 0);
    }
}
