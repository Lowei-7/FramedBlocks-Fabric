package xfacthd.framedblocks.client.model.slope;

import org.joml.Vector3f;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_4587;
import net.minecraft.class_777;
import net.minecraft.class_811;

public class FramedPyramidSlabModel extends FramedBlockModel
{
    private static final Vector3f ZERO = new Vector3f();

    private final class_2350 facing;
    private final boolean ySlope;

    public FramedPyramidSlabModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        this.facing = state.method_11654(class_2741.field_12525);
        this.ySlope = state.method_11654(FramedProperties.Y_SLOPE);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();
        if (Utils.isY(facing))
        {
            boolean up = facing == class_2350.field_11036;
            if (!ySlope && quadDir.method_10166() != facing.method_10166())
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideUpDown(!up, .5F))
                        .apply(Modifiers.cutSideLeftRight(false, up ? 0 : 1, up ? 1 : 0))
                        .apply(Modifiers.cutSideLeftRight(true, up ? 0 : 1, up ? 1 : 0))
                        .apply(Modifiers.makeVerticalSlope(up, 45))
                        .export(quadMap.get(null));
            }
            else if (ySlope && quadDir == facing)
            {
                for (class_2350 dir : class_2350.class_2353.field_11062)
                {
                    boolean northeast = dir == class_2350.field_11043 || dir == class_2350.field_11034;
                    float angle = up ? -45 : 45;
                    if (northeast) { angle *= -1F; }
                    QuadModifier.geometry(quad)
                            .apply(Modifiers.cutTopBottom(dir, .5F))
                            .apply(Modifiers.cutTopBottom(dir.method_10160(), 0, 1))
                            .apply(Modifiers.cutTopBottom(dir.method_10170(), 1, 0))
                            .apply(Modifiers.setPosition(.5F))
                            .apply(Modifiers.rotateCentered(dir.method_10170().method_10166(), angle, true))
                            .export(quadMap.get(null));
                }
            }
        }
        else
        {
            if (!ySlope && quadDir.method_10166() == facing.method_10166())
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideUpDown(true, .5F))
                        .apply(Modifiers.cutSideLeftRight(facing.method_10170(), 1, 0))
                        .apply(Modifiers.cutSideLeftRight(facing.method_10160(), 1, 0))
                        .apply(Modifiers.makeVerticalSlope(true, 45))
                        .export(quadMap.get(null));

                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideUpDown(false, .5F))
                        .apply(Modifiers.cutSideLeftRight(facing.method_10170(), 0, 1))
                        .apply(Modifiers.cutSideLeftRight(facing.method_10160(), 0, 1))
                        .apply(Modifiers.makeVerticalSlope(false, 45))
                        .export(quadMap.get(null));
            }
            else if (ySlope && Utils.isY(quadDir))
            {
                boolean up = quadDir == class_2350.field_11036;

                float angle = up ? 45 : -45;
                if (facing == class_2350.field_11043 || facing == class_2350.field_11034)
                {
                    angle *= -1F;
                }

                Vector3f origin = facing.method_10153().method_23955().max(ZERO);
                if (up)
                {
                    origin.add(0, 1, 0);
                }

                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(facing, .5F))
                        .apply(Modifiers.cutTopBottom(facing.method_10160(), 0, 1))
                        .apply(Modifiers.cutTopBottom(facing.method_10170(), 1, 0))
                        .apply(Modifiers.rotate(facing.method_10170().method_10166(), origin, angle, true))
                        .export(quadMap.get(null));
            }
            else if (quadDir.method_10166() == facing.method_10170().method_10166())
            {
                boolean right = quadDir == facing.method_10170();
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(facing, .5F))
                        .apply(Modifiers.cutSideUpDown(true, right ? 1 : 0, right ? 0 : 1))
                        .apply(Modifiers.cutSideUpDown(false, right ? 1 : 0, right ? 0 : 1))
                        .apply(Modifiers.makeHorizontalSlope(!right, 45))
                        .export(quadMap.get(null));
            }
        }
    }

    @Override
    protected void applyInHandTransformation(class_4587 poseStack, class_811 ctx)
    {
        poseStack.method_22904(0, .5, 0);
    }



    public static class_2680 itemSource()
    {
        return FBContent.BLOCK_FRAMED_PYRAMID_SLAB.get().method_9564();
    }
}
