package xfacthd.framedblocks.client.model.slope;

import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.common.FBContent;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_777;

public class FramedInnerThreewayCornerModel extends FramedBlockModel
{
    private final class_2350 dir;
    private final boolean top;
    private final boolean ySlope;

    public FramedInnerThreewayCornerModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        this.dir = state.method_11654(FramedProperties.FACING_HOR);
        this.top = state.method_11654(FramedProperties.TOP);
        this.ySlope = state.method_11654(FramedProperties.Y_SLOPE);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();
        if ((quadDir == class_2350.field_11033 && top) || (quadDir == class_2350.field_11036 && !top))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir.method_10153(), 1, 0))
                    .export(quadMap.get(quadDir));
        }
        else if (quadDir == dir.method_10170() || quadDir == dir.method_10153())
        {
            class_2350 cutDir = quadDir == dir.method_10153() ? dir.method_10170() : dir.method_10153();
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(cutDir, top ? 1 : 0, top ? 0 : 1))
                    .export(quadMap.get(quadDir));
        }

        if (quadDir == dir.method_10170())
        {
            if (!ySlope)
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSmallTriangle(dir))
                        .apply(Modifiers.makeVerticalSlope(!top, 45))
                        .export(quadMap.get(null));
            }

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSmallTriangle(top ? class_2350.field_11036 : class_2350.field_11033))
                    .apply(Modifiers.makeHorizontalSlope(true, 45))
                    .export(quadMap.get(null));
        }
        else if (!ySlope && quadDir == dir.method_10153())
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSmallTriangle(dir.method_10160()))
                    .apply(Modifiers.makeVerticalSlope(!top, 45))
                    .export(quadMap.get(null));
        }
        else if (ySlope && ((!top && quadDir == class_2350.field_11036) || (top && quadDir == class_2350.field_11033)))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSmallTriangle(dir))
                    .apply(Modifiers.makeVerticalSlope(dir.method_10170(), 45))
                    .export(quadMap.get(null));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSmallTriangle(dir.method_10160()))
                    .apply(Modifiers.makeVerticalSlope(dir.method_10153(), 45))
                    .export(quadMap.get(null));
        }
    }



    public static class_2680 itemSource()
    {
        return FBContent.BLOCK_FRAMED_INNER_THREEWAY_CORNER.get()
                .method_9564()
                .method_11657(FramedProperties.FACING_HOR, class_2350.field_11035);
    }
}