package xfacthd.framedblocks.client.model.slope;

import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.common.FBContent;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_777;

public class FramedInnerPrismCornerModel extends FramedBlockModel
{
    private final class_2350 dir;
    private final boolean top;
    private final boolean offset;
    private final boolean ySlope;

    public FramedInnerPrismCornerModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        this.dir = state.method_11654(FramedProperties.FACING_HOR);
        this.top = state.method_11654(FramedProperties.TOP);
        this.offset = state.method_11654(FramedProperties.OFFSET);
        this.ySlope = state.method_11654(FramedProperties.Y_SLOPE);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();
        if ((quadDir == class_2350.field_11033 && top) || (quadDir == class_2350.field_11036 && !top))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir.method_10153(), 1, 0))
                    .export(quadMap.get(quadDir));
        }
        else if (quadDir == dir.method_10153() || quadDir == dir.method_10170())
        {
            class_2350 cutDir = quadDir == dir.method_10153() ? dir.method_10170() : dir.method_10153();
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(cutDir, top ? 1 : 0, top ? 0 : 1))
                    .export(quadMap.get(quadDir));
        }

        if (!ySlope && quadDir == dir.method_10153())
        {
            if (offset)
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(dir.method_10170(), .5F))
                        .apply(Modifiers.offset(dir.method_10170(), .5F))
                        .apply(Modifiers.cutPrismTriangle(top, false))
                        .export(quadMap.get(null));

                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(dir.method_10160(), .5F))
                        .apply(Modifiers.offset(dir.method_10160(), .5F))
                        .apply(Modifiers.cutPrismTriangle(top, false))
                        .export(quadMap.get(null));
            }
            else
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutPrismTriangle(top, false))
                        .export(quadMap.get(null));
            }
        }
        else if (ySlope && ((!top && quadDir == class_2350.field_11036) || (top && quadDir == class_2350.field_11033)))
        {
            if (offset)
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(dir.method_10170(), .5F))
                        .apply(Modifiers.offset(dir.method_10170(), .5F))
                        .apply(Modifiers.cutPrismTriangle(dir.method_10153(), false))
                        .export(quadMap.get(null));

                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(dir.method_10160(), .5F))
                        .apply(Modifiers.offset(dir.method_10160(), .5F))
                        .apply(Modifiers.cutPrismTriangle(dir.method_10153(), false))
                        .export(quadMap.get(null));
            }
            else
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutPrismTriangle(dir.method_10153(), false))
                        .export(quadMap.get(null));
            }
        }
    }



    public static class_2680 itemSource()
    {
        return FBContent.BLOCK_FRAMED_INNER_PRISM_CORNER.get()
                .method_9564()
                .method_11657(FramedProperties.FACING_HOR, class_2350.field_11035);
    }
}