package xfacthd.framedblocks.client.model.slopepanelcorner;

import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.client.model.slopepanel.FramedSlopePanelModel;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.HorizontalRotation;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_777;

public class FramedExtendedCornerSlopePanelWallModel extends FramedBlockModel
{
    private final class_2350 dir;
    private final class_2350 horRotDir;
    private final class_2350 vertRotDir;
    private final boolean ySlope;

    public FramedExtendedCornerSlopePanelWallModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        this.dir = state.method_11654(FramedProperties.FACING_HOR);
        HorizontalRotation rot = state.method_11654(PropertyHolder.ROTATION);
        class_2350 rotDir = rot.withFacing(dir);
        class_2350 perpRotDir = rot.rotate(class_2470.field_11465).withFacing(dir);
        this.horRotDir = Utils.isY(rotDir) ? perpRotDir : rotDir;
        this.vertRotDir = Utils.isY(rotDir) ? rotDir : perpRotDir;
        this.ySlope = state.method_11654(FramedProperties.Y_SLOPE);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();
        boolean cw = horRotDir == dir.method_10170();
        boolean up = vertRotDir == class_2350.field_11036;
        if (quadDir == horRotDir)
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideUpDown(up, cw ? .5F : 1F, cw ? 1F : .5F))
                    .export(quadMap.get(quadDir));
        }
        else if (quadDir == vertRotDir)
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(horRotDir.method_10153(), cw ? 1F : .5F, cw ? .5F : 1F))
                    .export(quadMap.get(quadDir));
        }
        else if (quadDir == horRotDir.method_10153())
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideUpDown(vertRotDir == class_2350.field_11036, cw ? 1F : .5F, cw ? .5F : 1F))
                    .apply(Modifiers.makeHorizontalSlope(!cw, FramedSlopePanelModel.SLOPE_ANGLE))
                    .export(quadMap.get(null));
        }
        else if (quadDir == dir.method_10153())
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(horRotDir.method_10153(), .5F))
                    .apply(Modifiers.cutSideUpDown(vertRotDir == class_2350.field_11036, .5F))
                    .export(quadMap.get(quadDir));

            if (!ySlope)
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(horRotDir.method_10153(), up ? .5F : 1F, up ? 1F : .5F))
                        .apply(Modifiers.makeVerticalSlope(!up, FramedSlopePanelModel.SLOPE_ANGLE_VERT))
                        .apply(Modifiers.offset(vertRotDir.method_10153(), .5F))
                        .export(quadMap.get(null));
            }
        }
        else if (ySlope && quadDir == vertRotDir.method_10153())
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(horRotDir.method_10153(), cw ? 1F : .5F, cw ? .5F : 1F))
                    .apply(Modifiers.makeVerticalSlope(dir.method_10153(), FramedSlopePanelModel.SLOPE_ANGLE))
                    .export(quadMap.get(null));
        }
    }
}
