package xfacthd.framedblocks.client.model.slopepanelcorner;

import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.client.model.slopepanel.FramedSlopePanelModel;
import xfacthd.framedblocks.common.FBContent;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_777;

public class FramedLargeInnerCornerSlopePanelModel extends FramedBlockModel
{
    private final class_2350 dir;
    private final boolean top;
    private final boolean ySlope;

    public FramedLargeInnerCornerSlopePanelModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        this.dir = state.method_11654(FramedProperties.FACING_HOR);
        this.top = state.method_11654(FramedProperties.TOP);
        this.ySlope = state.method_11654(FramedProperties.Y_SLOPE);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();
        if (quadDir == dir || quadDir == dir.method_10160())
        {
            class_2350 cutDir = quadDir == dir ? dir.method_10170() : dir.method_10153();

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(cutDir.method_10153(), top ? .5F : 0F, top ? 0F : .5F))
                    .export(quadMap.get(quadDir));

            if (!ySlope)
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(cutDir, top ? .5F : 1F, top ? 1F : .5F))
                        .apply(Modifiers.makeVerticalSlope(!top, FramedSlopePanelModel.SLOPE_ANGLE))
                        .apply(Modifiers.offset(quadDir.method_10153(), .5F))
                        .export(quadMap.get(null));
            }
        }
        else if (ySlope && ((!top && quadDir == class_2350.field_11036) || (top && quadDir == class_2350.field_11033)))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir.method_10153(), .5F, 1))
                    .apply(Modifiers.makeVerticalSlope(dir.method_10160(), FramedSlopePanelModel.SLOPE_ANGLE_VERT))
                    .export(quadMap.get(null));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir.method_10170(), 1, .5F))
                    .apply(Modifiers.makeVerticalSlope(dir, FramedSlopePanelModel.SLOPE_ANGLE_VERT))
                    .export(quadMap.get(null));
        }
        else if ((!top && quadDir == class_2350.field_11033) || (top && quadDir == class_2350.field_11036))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir, .5F))
                    .export(quadMap.get(quadDir));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir.method_10153(), .5F))
                    .apply(Modifiers.cutTopBottom(dir.method_10160(), .5F))
                    .export(quadMap.get(quadDir));
        }
    }



    public static class_2680 itemModelSource()
    {
        return FBContent.BLOCK_FRAMED_LARGE_INNER_CORNER_SLOPE_PANEL.get()
                .method_9564()
                .method_11657(FramedProperties.FACING_HOR, class_2350.field_11034);
    }
}
