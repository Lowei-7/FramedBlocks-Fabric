package xfacthd.framedblocks.client.model.slopeedge;

import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.SlopeType;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_777;

public class FramedElevatedSlopeEdgeModel extends FramedBlockModel
{
    private final class_2350 dir;
    private final SlopeType type;
    private final boolean ySlope;

    public FramedElevatedSlopeEdgeModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        this.dir = state.method_11654(FramedProperties.FACING_HOR);
        this.type = state.method_11654(PropertyHolder.SLOPE_TYPE);
        this.ySlope = state.method_11654(FramedProperties.Y_SLOPE);
    }

    @Override
    public void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();
        if (type == SlopeType.HORIZONTAL)
        {
            if (quadDir == dir.method_10153())
            {
                if (!ySlope)
                {
                    QuadModifier.geometry(quad)
                            .apply(Modifiers.cutSideLeftRight(dir.method_10160(), .5F))
                            .apply(Modifiers.makeHorizontalSlope(false, 45))
                            .apply(Modifiers.offset(dir.method_10153(), .5F))
                            .export(quadMap.get(null));
                }

                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(dir.method_10170(), .5F))
                        .export(quadMap.get(quadDir));
            }
            else if (quadDir == dir.method_10170())
            {
                if (ySlope)
                {
                    QuadModifier.geometry(quad)
                            .apply(Modifiers.cutSideLeftRight(dir, .5F))
                            .apply(Modifiers.makeHorizontalSlope(true, 45))
                            .apply(Modifiers.offset(dir.method_10170(), .5F))
                            .export(quadMap.get(null));
                }

                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(dir.method_10153(), .5F))
                        .export(quadMap.get(quadDir));
            }
            else if (Utils.isY(quadDir))
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(dir.method_10160(), .5F))
                        .apply(Modifiers.cutTopBottom(dir.method_10153(), 1.5F, .5F))
                        .export(quadMap.get(quadDir));

                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(dir.method_10170(), .5F))
                        .export(quadMap.get(quadDir));
            }
        }
        else
        {
            boolean top = type == SlopeType.TOP;
            if (quadDir == dir.method_10153())
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideUpDown(top, .5F))
                        .export(quadMap.get(quadDir));

                if (!ySlope)
                {
                    QuadModifier.geometry(quad)
                            .apply(Modifiers.cutSideUpDown(!top, .5F))
                            .apply(Modifiers.makeVerticalSlope(!top, 45))
                            .apply(Modifiers.offset(dir.method_10153(), .5F))
                            .export(quadMap.get(null));
                }
            }
            else if ((!top && quadDir == class_2350.field_11036) || (top && quadDir == class_2350.field_11033))
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(dir.method_10153(), .5F))
                        .export(quadMap.get(quadDir));

                if (ySlope)
                {
                    QuadModifier.geometry(quad)
                            .apply(Modifiers.cutTopBottom(dir, .5F))
                            .apply(Modifiers.makeVerticalSlope(dir.method_10153(), 45))
                            .apply(Modifiers.offset(top ? class_2350.field_11033 : class_2350.field_11036, .5F))
                            .export(quadMap.get(null));
                }
            }
            else if (quadDir == dir.method_10170() || quadDir == dir.method_10160())
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideUpDown(!top, .5F))
                        .apply(Modifiers.cutSideLeftRight(dir.method_10153(), top ? 1.5F : .5F, top ? .5F : 1.5F))
                        .export(quadMap.get(quadDir));

                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideUpDown(top, .5F))
                        .export(quadMap.get(quadDir));
            }
        }
    }
}
