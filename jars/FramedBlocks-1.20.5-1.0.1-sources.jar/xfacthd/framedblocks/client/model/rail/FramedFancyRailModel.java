package xfacthd.framedblocks.client.model.rail;

import com.mojang.datafixers.util.Pair;
import net.minecraft.class_1087;
import net.minecraft.class_156;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2768;
import net.minecraft.class_2769;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import net.minecraft.world.level.block.state.properties.*;
import org.joml.Vector3f;
import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.model.util.ModelCache;
import xfacthd.framedblocks.api.util.Utils;

import java.util.*;

public class FramedFancyRailModel extends FramedBlockModel
{
    private static final int SLEEPER_COUNT = 4;
    private static final int SLEEPER_COUNT_CURVE = 3;
    private static final float SLEEPER_BASE_OFFSET = 1F/16F;
    private static final float SLEEPER_DIST = 4F/16F;
    private static final float SLEEPER_DIST_CURVE = 6F/16F;
    private static final float SLEEPER_WIDTH = 2F/16F;
    private static final float SLEEPER_HEIGHT = 1F/16F;
    private static final float SLEEPER_DIAGONAL_OFFSET = 1.85F/16F;
    private static final Vector3f SCALE_X = new Vector3f(1, 0, 0);
    private static final Vector3f SCALE_Z = new Vector3f(0, 0, 1);
    private static final Vector3f[] SLOPE_ORIGINS = class_156.method_654(new Vector3f[4], arr ->
    {
        arr[class_2350.field_11043.method_10161()] = new Vector3f(0, 0, 1);
        arr[class_2350.field_11034.method_10161()] =  new Vector3f(0, 0, 0);
        arr[class_2350.field_11035.method_10161()] = new Vector3f(0, 0, 0);
        arr[class_2350.field_11039.method_10161()] =  new Vector3f(1, 0, 0);
    });

    private final class_2768 shape;
    private final class_2350 mainDir;
    private final class_2350 secDir;

    private FramedFancyRailModel(class_2680 state, class_1087 baseModel, class_2769<class_2768> shapeProperty)
    {
        super(state, baseModel);
        this.shape = state.method_11654(shapeProperty);
        this.mainDir = getDirectionFromRailShape(shape);
        this.secDir = getSecondaryDirectionFromRailShape(shape);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        Pair<List<class_777>, class_2350> result;
        if (shape.method_11897())
        {
            result = makeAscendingRailSleepers(quad, mainDir);
        }
        else if (shape == class_2768.field_12665 || shape == class_2768.field_12674)
        {
            result = makeStraightRailSleepers(quad, mainDir);
        }
        else
        {
            result = makeCurvedRailSleepers(quad, mainDir, secDir);
        }
        quadMap.get(result.getSecond()).addAll(result.getFirst());
    }

    private static Pair<List<class_777>, class_2350> makeStraightRailSleepers(class_777 quad, class_2350 dir)
    {
        List<class_777> result = new ArrayList<>(SLEEPER_COUNT);
        class_2350 targetDir;

        class_2350 quadDir = quad.method_3358();
        if (Utils.isY(quadDir))
        {
            targetDir = quadDir == class_2350.field_11036 ? null : quadDir;

            forAllSleepers((i, distDir, distOpp) ->
                    QuadModifier.geometry(quad)
                            .apply(Modifiers.cutTopBottom(dir, distDir))
                            .apply(Modifiers.cutTopBottom(dir.method_10153(), distOpp))
                            .applyIf(Modifiers.setPosition(SLEEPER_HEIGHT), quadDir == class_2350.field_11036)
                            .export(result::add)
            );
        }
        else if (quadDir.method_10166() == dir.method_10166())
        {
            targetDir = null;

            forAllSleepers((i, distDir, distOpp) ->
                    QuadModifier.geometry(quad)
                            .apply(Modifiers.cutSideUpDown(false, SLEEPER_HEIGHT))
                            .apply(Modifiers.setPosition(distDir))
                            .export(result::add)
            );
        }
        else
        {
            targetDir = quadDir;

            forAllSleepers((i, distDir, distOpp) ->
                    QuadModifier.geometry(quad)
                            .apply(Modifiers.cutSideUpDown(false, SLEEPER_HEIGHT))
                            .apply(Modifiers.cutSideLeftRight(dir, distDir))
                            .apply(Modifiers.cutSideLeftRight(dir.method_10153(), distOpp))
                            .export(result::add)
            );
        }

        return Pair.of(result, targetDir);
    }

    private static Pair<List<class_777>, class_2350> makeAscendingRailSleepers(class_777 quad, class_2350 dir)
    {
        Pair<List<class_777>, class_2350> result = makeStraightRailSleepers(quad, dir);

        class_2350.class_2351 axis = dir.method_10170().method_10166();
        Vector3f origin = SLOPE_ORIGINS[dir.method_10161()];
        float angle = Utils.isPositive(dir) == Utils.isX(dir) ? 45F : -45F;
        Vector3f scaleVec = Utils.isX(dir) ? SCALE_X : SCALE_Z;

        List<class_777> quads = result.getFirst();
        for (class_777 resultQuad : quads)
        {
            QuadModifier.geometry(resultQuad)
                    .apply(Modifiers.rotate(axis, origin, angle, true, scaleVec))
                    .modifyInPlace();
        }

        class_2350 targetDir = result.getSecond() == class_2350.field_11033 ? null : result.getSecond();
        return Pair.of(quads, targetDir);
    }

    private static Pair<List<class_777>, class_2350> makeCurvedRailSleepers(class_777 quad, class_2350 dir, class_2350 secDir)
    {
        List<class_777> result = new ArrayList<>(SLEEPER_COUNT_CURVE);
        class_2350 targetDir;

        class_2350 quadDir = quad.method_3358();
        if (Utils.isY(quadDir))
        {
            targetDir = quadDir == class_2350.field_11036 ? null : quadDir;

            forAllSleepersCurve((i, distDir, distOpp) ->
            {
                boolean nonDiagUp = quadDir == class_2350.field_11036 && i != 1;
                float height = nonDiagUp ? (SLEEPER_HEIGHT - .001F) : SLEEPER_HEIGHT;
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(dir, distDir))
                        .apply(Modifiers.cutTopBottom(dir.method_10153(), distOpp))
                        .applyIf(Modifiers.setPosition(height), quadDir == class_2350.field_11036)
                        .applyIf(rotateCurveSleeper(dir, secDir, i), i < 2)
                        .applyIf(Modifiers.offset(dir, SLEEPER_DIAGONAL_OFFSET), i == 1)
                        .applyIf(Modifiers.offset(secDir, SLEEPER_DIAGONAL_OFFSET), i == 1)
                        .export(result::add);
            });
        }
        else if (quadDir.method_10166() == dir.method_10166())
        {
            targetDir = null;

            boolean inDir = quadDir == dir;
            forAllSleepersCurve((i, distDir, distOpp) ->
                    QuadModifier.geometry(quad)
                            .apply(Modifiers.cutSideUpDown(false, SLEEPER_HEIGHT))
                            .apply(Modifiers.setPosition(inDir ? distDir : distOpp))
                            .applyIf(rotateCurveSleeper(dir, secDir, i), i < 2)
                            .applyIf(Modifiers.offset(dir, SLEEPER_DIAGONAL_OFFSET), i == 1)
                            .applyIf(Modifiers.offset(secDir, SLEEPER_DIAGONAL_OFFSET), i == 1)
                            .export(result::add)
            );
        }
        else
        {
            targetDir = quadDir;

            forAllSleepersCurve((i, distDir, distOpp) ->
                    QuadModifier.geometry(quad)
                            .apply(Modifiers.cutSideUpDown(false, SLEEPER_HEIGHT))
                            .apply(Modifiers.cutSideLeftRight(dir, distDir))
                            .apply(Modifiers.cutSideLeftRight(dir.method_10153(), distOpp))
                            .applyIf(rotateCurveSleeper(dir, secDir, i), i < 2)
                            .applyIf(Modifiers.offset(dir, SLEEPER_DIAGONAL_OFFSET), i == 1)
                            .applyIf(Modifiers.offset(secDir, SLEEPER_DIAGONAL_OFFSET), i == 1)
                            .export(result::add)
            );
        }

        return Pair.of(result, targetDir);
    }

    private static QuadModifier.Modifier rotateCurveSleeper(class_2350 dir, class_2350 secDir, int i)
    {
        float angle = 45F * (SLEEPER_COUNT_CURVE - 1 - i);
        if (secDir == dir.method_10160())
        {
            angle *= -1F;
        }
        return Modifiers.rotateCentered(class_2350.class_2351.field_11052, angle, false);
    }

    private static void forAllSleepers(SleeperConsumer consumer)
    {
        for (int i = 0; i < SLEEPER_COUNT; i++)
        {
            float distDir = SLEEPER_BASE_OFFSET + (i * SLEEPER_DIST) + SLEEPER_WIDTH;
            float distOpp = 1F - distDir + SLEEPER_WIDTH;
            consumer.accept(i, distDir, distOpp);
        }
    }

    private static void forAllSleepersCurve(SleeperConsumer consumer)
    {
        for (int i = 0; i < SLEEPER_COUNT_CURVE; i++)
        {
            float distDir = SLEEPER_BASE_OFFSET + (i * SLEEPER_DIST_CURVE) + SLEEPER_WIDTH;
            float distOpp = 1F - distDir + SLEEPER_WIDTH;
            consumer.accept(i, distDir, distOpp);
        }
    }

    @Override
    protected Set<class_1921> getAdditionalRenderTypes(class_5819 rand, Object extraData)
    {
        return ModelCache.getRenderTypes(state, rand, null);
    }

    @Override
    protected void getAdditionalQuads(
            Map<class_2350, List<class_777>> quadMap,
            class_2680 state,
            class_5819 rand,
            Object data,
            class_1921 renderType
    )
    {
        Utils.forAllDirections(dir -> quadMap.get(dir).addAll(baseModel.method_4707(state, dir, rand)));
    }

    @Override
    public boolean useSolidNoCamoModel()
    {
        return true;
    }

    @SuppressWarnings("DuplicateBranchesInSwitch")
    public static class_2350 getDirectionFromRailShape(class_2768 shape)
    {
        return switch (shape)
        {
            case field_12665 -> class_2350.field_11043;
            case field_12674 -> class_2350.field_11034;
            case field_12670 -> class_2350.field_11043;
            case field_12667 -> class_2350.field_11034;
            case field_12668 -> class_2350.field_11035;
            case field_12666 -> class_2350.field_11039;
            case field_12663, field_12672 -> class_2350.field_11043;
            case field_12664, field_12671 -> class_2350.field_11035;
        };
    }

    private static class_2350 getSecondaryDirectionFromRailShape(class_2768 shape)
    {
        return switch (shape)
        {
            case field_12663, field_12664 -> class_2350.field_11034;
            case field_12672, field_12671 -> class_2350.field_11039;
            default -> null;
        };
    }



    public static FramedFancyRailModel normal(class_2680 state, class_1087 baseModel)
    {
        return new FramedFancyRailModel(state, baseModel, class_2741.field_12507);
    }

    public static FramedFancyRailModel straight(class_2680 state, class_1087 baseModel)
    {
        return new FramedFancyRailModel(state, baseModel, class_2741.field_12542);
    }

    @FunctionalInterface
    public interface SleeperConsumer
    {
        void accept(int index, float distDir, float distOpp);
    }
}
