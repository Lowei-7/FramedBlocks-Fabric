package xfacthd.framedblocks.client.model.rail;

import net.minecraft.class_1087;
import net.minecraft.class_1921;
import net.minecraft.class_2246;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2754;
import net.minecraft.class_2768;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import net.minecraft.world.level.block.state.properties.*;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.model.util.ModelCache;
import xfacthd.framedblocks.client.model.slope.FramedSlopeModel;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.util.FramedUtils;

import org.jetbrains.annotations.Nullable;
import java.util.*;

public class FramedRailSlopeModel extends FramedSlopeModel
{
    private final class_2680 railState;

    private FramedRailSlopeModel(
            class_2680 state, class_1087 baseModel, class_2680 railBlock, class_2754<class_2768> shapeProperty
    )
    {
        super(getSlopeState(state), baseModel);

        class_2768 shape = state.method_11654(PropertyHolder.ASCENDING_RAIL_SHAPE);
        railState = railBlock.method_11657(shapeProperty, shape);
    }

    @Override
    protected void getAdditionalQuads(
            Map<class_2350, List<class_777>> quadMap,
            class_2680 state,
            class_5819 rand,
            Object data,
            class_1921 renderType
    )
    {
        quadMap.get(null).addAll(getRailQuads(null, rand, renderType));

        for (class_2350 side : class_2350.values())
        {
            quadMap.get(side).addAll(getRailQuads(side, rand, renderType));
        }
    }

    @Override
    protected Set<class_1921> getAdditionalRenderTypes(class_5819 rand, Object extraData)
    {
        return ModelCache.getRenderTypes(railState, rand, null);
    }

    private List<class_777> getRailQuads(@Nullable class_2350 side, class_5819 rand, class_1921 layer)
    {
        return ModelCache.getModel(railState).method_4707(railState, side, rand);
    }

    private static class_2680 getSlopeState(class_2680 state)
    {
        class_2768 shape = state.method_11654(PropertyHolder.ASCENDING_RAIL_SHAPE);
        class_2350 dir = FramedUtils.getDirectionFromAscendingRailShape(shape);
        boolean ySlope = state.method_11654(FramedProperties.Y_SLOPE);

        return FBContent.BLOCK_FRAMED_SLOPE.get()
                .method_9564()
                .method_11657(FramedProperties.FACING_HOR, dir)
                .method_11657(FramedProperties.Y_SLOPE, ySlope);
    }



    public static FramedRailSlopeModel normal(class_2680 state, class_1087 baseModel)
    {
        return new FramedRailSlopeModel(state, baseModel, class_2246.field_10167.method_9564(), class_2741.field_12507);
    }

    public static FramedRailSlopeModel powered(class_2680 state, class_1087 baseModel)
    {
        boolean powered = state.method_11654(class_2741.field_12484);
        return new FramedRailSlopeModel(
                state,
                baseModel,
                class_2246.field_10425.method_9564().method_11657(class_2741.field_12484, powered),
                class_2741.field_12542
        );
    }

    public static FramedRailSlopeModel detector(class_2680 state, class_1087 baseModel)
    {
        boolean powered = state.method_11654(class_2741.field_12484);
        return new FramedRailSlopeModel(
                state,
                baseModel,
                class_2246.field_10025.method_9564().method_11657(class_2741.field_12484, powered),
                class_2741.field_12542
        );
    }

    public static FramedRailSlopeModel activator(class_2680 state, class_1087 baseModel)
    {
        boolean powered = state.method_11654(class_2741.field_12484);
        return new FramedRailSlopeModel(
                state,
                baseModel,
                class_2246.field_10546.method_9564().method_11657(class_2741.field_12484, powered),
                class_2741.field_12542
        );
    }

    public static class_2680 itemSourceNormal()
    {
        return FBContent.BLOCK_FRAMED_RAIL_SLOPE.get()
                .method_9564()
                .method_11657(PropertyHolder.ASCENDING_RAIL_SHAPE, class_2768.field_12668);
    }

    public static class_2680 itemSourcePowered()
    {
        return FBContent.BLOCK_FRAMED_POWERED_RAIL_SLOPE.get()
                .method_9564()
                .method_11657(PropertyHolder.ASCENDING_RAIL_SHAPE, class_2768.field_12668);
    }

    public static class_2680 itemSourceDetector()
    {
        return FBContent.BLOCK_FRAMED_DETECTOR_RAIL_SLOPE.get()
                .method_9564()
                .method_11657(PropertyHolder.ASCENDING_RAIL_SHAPE, class_2768.field_12668);
    }

    public static class_2680 itemSourceActivator()
    {
        return FBContent.BLOCK_FRAMED_ACTIVATOR_RAIL_SLOPE.get()
                .method_9564()
                .method_11657(PropertyHolder.ASCENDING_RAIL_SHAPE, class_2768.field_12668);
    }
}