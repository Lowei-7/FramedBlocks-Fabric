package xfacthd.framedblocks.client.model.slab;

import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_777;

public class FramedSlabModel extends FramedBlockModel
{
    private final boolean top;

    public FramedSlabModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        top = state.method_11654(FramedProperties.TOP);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, final class_777 quad)
    {
        if ((top && quad.method_3358() == class_2350.field_11033) || (!top && quad.method_3358() == class_2350.field_11036))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.setPosition(.5F))
                    .export(quadMap.get(null));
        }
        else if (!Utils.isY(quad.method_3358()))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideUpDown(top, .5F))
                    .export(quadMap.get(quad.method_3358()));
        }
    }
}