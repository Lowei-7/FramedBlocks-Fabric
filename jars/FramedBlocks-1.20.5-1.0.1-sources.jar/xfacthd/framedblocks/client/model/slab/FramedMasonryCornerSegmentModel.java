package xfacthd.framedblocks.client.model.slab;

import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_777;

public class FramedMasonryCornerSegmentModel extends FramedBlockModel
{
    private final class_2350 dir;
    private final boolean top;

    public FramedMasonryCornerSegmentModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        this.dir = state.method_11654(FramedProperties.FACING_HOR);
        this.top = state.method_11654(FramedProperties.TOP);
    }

    @Override
    public void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();

        if ((!top && quadDir == class_2350.field_11036) || (top && quadDir == class_2350.field_11033))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir, .5F))
                    .apply(Modifiers.cutTopBottom(dir.method_10170(), .5F))
                    .apply(Modifiers.setPosition(.5F))
                    .export(quadMap.get(null));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir.method_10160(), .5F))
                    .export(quadMap.get(quadDir));
        }
        else if ((!top && quadDir == class_2350.field_11033) || (top && quadDir == class_2350.field_11036))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir.method_10153(), .5F))
                    .apply(Modifiers.cutTopBottom(dir.method_10160(), .5F))
                    .apply(Modifiers.setPosition(.5F))
                    .export(quadMap.get(null));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir, .5F))
                    .export(quadMap.get(quadDir));
        }
        else if (quadDir.method_10166() == dir.method_10166())
        {
            boolean inDir = quadDir == dir;
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideUpDown(top, .5F))
                    .applyIf(Modifiers.setPosition(.5F), inDir)
                    .export(quadMap.get(inDir ? null : quadDir));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideUpDown(!top, .5F))
                    .apply(Modifiers.cutSideLeftRight(dir.method_10160(), .5F))
                    .export(quadMap.get(quadDir));
        }
        else if (quadDir.method_10166() == dir.method_10170().method_10166())
        {
            boolean inDir = quadDir == dir.method_10160();
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideUpDown(!top, .5F))
                    .applyIf(Modifiers.setPosition(.5F), inDir)
                    .export(quadMap.get(inDir ? null : quadDir));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideUpDown(top, .5F))
                    .apply(Modifiers.cutSideLeftRight(dir, .5F))
                    .export(quadMap.get(quadDir));
        }
    }
}
