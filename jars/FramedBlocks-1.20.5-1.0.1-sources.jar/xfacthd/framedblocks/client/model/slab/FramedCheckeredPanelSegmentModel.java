package xfacthd.framedblocks.client.model.slab;

import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.data.PropertyHolder;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_777;

public class FramedCheckeredPanelSegmentModel extends FramedBlockModel
{
    private final class_2350 dir;
    private final boolean second;

    public FramedCheckeredPanelSegmentModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        this.dir = state.method_11654(FramedProperties.FACING_HOR);
        this.second = state.method_11654(PropertyHolder.SECOND);
    }

    @Override
    public void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();
        if (Utils.isY(quadDir))
        {
            boolean up = quadDir == class_2350.field_11036;
            class_2350 xDir = (second ^ up) ? class_2350.field_11039 : class_2350.field_11034;

            if (dir == class_2350.field_11043 || dir == xDir.method_10153())
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(class_2350.field_11035, .5F))
                        .apply(Modifiers.cutTopBottom(xDir, .5F))
                        .export(quadMap.get(quadDir));
            }

            if (dir == class_2350.field_11035 || dir == xDir)
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(class_2350.field_11043, .5F))
                        .apply(Modifiers.cutTopBottom(xDir.method_10153(), .5F))
                        .export(quadMap.get(quadDir));
            }

            if (dir == class_2350.field_11043 || dir == xDir)
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(class_2350.field_11035, .5F))
                        .apply(Modifiers.cutTopBottom(xDir.method_10153(), .5F))
                        .apply(Modifiers.setPosition(.5F))
                        .export(quadMap.get(null));
            }

            if (dir == class_2350.field_11035 || dir == xDir.method_10153())
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(class_2350.field_11043, .5F))
                        .apply(Modifiers.cutTopBottom(xDir, .5F))
                        .apply(Modifiers.setPosition(.5F))
                        .export(quadMap.get(null));
            }
        }
        else
        {
            class_2350 horDir = Utils.isX(quadDir) ^ second ? quadDir.method_10160() : quadDir.method_10170();

            if (quadDir != dir.method_10153())
            {
                if (quadDir == dir || horDir.method_10153() == dir)
                {
                    QuadModifier.geometry(quad)
                            .apply(Modifiers.cutSideUpDown(false, .5F))
                            .apply(Modifiers.cutSideLeftRight(horDir, .5F))
                            .export(quadMap.get(quadDir));
                }

                if (quadDir == dir || horDir == dir)
                {
                    QuadModifier.geometry(quad)
                            .apply(Modifiers.cutSideUpDown(true, .5F))
                            .apply(Modifiers.cutSideLeftRight(horDir.method_10153(), .5F))
                            .export(quadMap.get(quadDir));
                }
            }

            if (quadDir != dir)
            {
                if (quadDir == dir.method_10153() || horDir == dir)
                {
                    QuadModifier.geometry(quad)
                            .apply(Modifiers.cutSideUpDown(false, .5F))
                            .apply(Modifiers.cutSideLeftRight(horDir.method_10153(), .5F))
                            .apply(Modifiers.setPosition(.5F))
                            .export(quadMap.get(null));
                }

                if (quadDir == dir.method_10153() || horDir.method_10153() == dir)
                {
                    QuadModifier.geometry(quad)
                            .apply(Modifiers.cutSideUpDown(true, .5F))
                            .apply(Modifiers.cutSideLeftRight(horDir, .5F))
                            .apply(Modifiers.setPosition(.5F))
                            .export(quadMap.get(null));
                }
            }
        }
    }
}
