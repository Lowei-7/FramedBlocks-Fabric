package xfacthd.framedblocks.client.model.pane;

import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_777;

public class FramedFloorModel extends FramedBlockModel
{
    private final boolean top;

    public FramedFloorModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        this.top = state.method_11654(FramedProperties.TOP);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 face = quad.method_3358();
        if ((!top && face == class_2350.field_11036) || (top && face == class_2350.field_11033))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.setPosition(1F/16F))
                    .export(quadMap.get(null));
        }
        else if (!Utils.isY(quad.method_3358()))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideUpDown(top, 1F/16F))
                    .export(quadMap.get(quad.method_3358()));
        }
    }
}