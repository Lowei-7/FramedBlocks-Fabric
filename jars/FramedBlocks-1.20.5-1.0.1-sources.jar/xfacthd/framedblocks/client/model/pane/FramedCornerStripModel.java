package xfacthd.framedblocks.client.model.pane;

import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.render.Quaternions;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.SlopeType;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_777;
import net.minecraft.class_811;

public class FramedCornerStripModel extends FramedBlockModel
{
    private final class_2350 dir;
    private final SlopeType type;

    public FramedCornerStripModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        this.dir = state.method_11654(FramedProperties.FACING_HOR);
        this.type = state.method_11654(PropertyHolder.SLOPE_TYPE);
    }

    @Override
    public void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();
        if (type == SlopeType.HORIZONTAL)
        {
            if (Utils.isY(quadDir))
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(dir.method_10153(), 1F/16F))
                        .apply(Modifiers.cutTopBottom(dir.method_10170(), 1F/16F))
                        .export(quadMap.get(quadDir));
            }
            else if (quadDir.method_10166() == dir.method_10166())
            {
                boolean onFace = quadDir == dir;
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(dir.method_10170(), 1F/16F))
                        .applyIf(Modifiers.setPosition(1F/16F), !onFace)
                        .export(quadMap.get(onFace ? quadDir : null));
            }
            else if (quadDir.method_10166() == dir.method_10170().method_10166())
            {
                boolean onFace = quadDir == dir.method_10160();
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(dir.method_10153(), 1F/16F))
                        .applyIf(Modifiers.setPosition(1F/16F), !onFace)
                        .export(quadMap.get(onFace ? quadDir : null));
            }
        }
        else
        {
            boolean top = type == SlopeType.TOP;
            if (quadDir.method_10166() == dir.method_10170().method_10166())
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(dir.method_10153(), 1F/16F))
                        .apply(Modifiers.cutSideUpDown(top, 1F/16F))
                        .export(quadMap.get(quadDir));
            }
            else if (quadDir.method_10166() == dir.method_10166())
            {
                boolean onFace = quadDir == dir;
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideUpDown(top, 1F/16F))
                        .applyIf(Modifiers.setPosition(1F/16F), !onFace)
                        .export(quadMap.get(onFace ? quadDir : null));
            }
            else if (Utils.isY(quadDir))
            {
                boolean onFace = top ? quadDir == class_2350.field_11036 : quadDir == class_2350.field_11033;
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(dir.method_10153(), 1F/16F))
                        .applyIf(Modifiers.setPosition(1F/16F), !onFace)
                        .export(quadMap.get(onFace ? quadDir : null));
            }
        }
    }

    @Override
    public void applyInHandTransformation(class_4587 poseStack, class_811 ctx)
    {
        if (ctx.method_29998())
        {
            poseStack.method_22907(Quaternions.YP_90);
        }
        poseStack.method_22904(0, .5, 0);
    }
}
