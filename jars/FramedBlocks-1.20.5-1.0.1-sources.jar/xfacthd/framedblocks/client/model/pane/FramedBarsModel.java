package xfacthd.framedblocks.client.model.pane;

import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.util.Utils;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_777;

public class FramedBarsModel extends FramedPaneModel
{
    public FramedBarsModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 face = quad.method_3358();
        if (Utils.isY(face))
        {
            createTopBottomCenterQuad(quadMap, quad, false);
            createTopBottomCenterQuad(quadMap, quad, true);

            if (north)
            {
                createTopBottomEdgeQuad(quadMap, quad, class_2350.field_11043, false);
                createTopBottomEdgeQuad(quadMap, quad, class_2350.field_11043, true);
            }
            if (east)
            {
                createTopBottomEdgeQuad(quadMap, quad, class_2350.field_11034, false);
                createTopBottomEdgeQuad(quadMap, quad, class_2350.field_11034, true);
            }
            if (south)
            {
                createTopBottomEdgeQuad(quadMap, quad, class_2350.field_11035, false);
                createTopBottomEdgeQuad(quadMap, quad, class_2350.field_11035, true);
            }
            if (west)
            {
                createTopBottomEdgeQuad(quadMap, quad, class_2350.field_11039, false);
                createTopBottomEdgeQuad(quadMap, quad, class_2350.field_11039, true);
            }
        }
        else
        {
            if (!isSideInset(face))
            {
                createSideEdgeQuad(quadMap, quad, false, false);
            }
            if (!isSideInset(face.method_10153()))
            {
                createSideEdgeQuad(quadMap, quad, false, true);
            }

            if (Utils.isX(face))
            {
                createCenterPillarQuad(quadMap.get(null), quad, east, west, south, north);

                if (north)
                {
                    createPillarQuad(quadMap.get(null), quad, class_2350.field_11043);
                    createBarQuads(quadMap.get(null), quad, class_2350.field_11043);
                }
                if (south)
                {
                    createPillarQuad(quadMap.get(null), quad, class_2350.field_11035);
                    createBarQuads(quadMap.get(null), quad, class_2350.field_11035);
                }
            }

            if (Utils.isZ(face))
            {
                createCenterPillarQuad(quadMap.get(null), quad, south, north, east, west);

                if (east)
                {
                    createPillarQuad(quadMap.get(null), quad, class_2350.field_11034);
                    createBarQuads(quadMap.get(null), quad, class_2350.field_11034);
                }
                if (west)
                {
                    createPillarQuad(quadMap.get(null), quad, class_2350.field_11039);
                    createBarQuads(quadMap.get(null), quad, class_2350.field_11039);
                }
            }
        }
    }

    @Override
    public boolean useSolidNoCamoModel()
    {
        return true;
    }

    /**
     * @param perpNeg Connection state in the negative direction perpendicular to the quad
     * @param perpPos Connection state in the positive direction perpendicular to the quad
     * @param parNeg Connection state in the negative direction in the same plane as the quad
     * @param parPos Connection state in the positive direction in the same plane as the quad
     */
    private static void createCenterPillarQuad(List<class_777> quadList, class_777 quad, boolean perpNeg, boolean perpPos, boolean parNeg, boolean parPos)
    {
        if (perpNeg && perpPos && !parNeg && !parPos)
        {
            return;
        }

        boolean perpendicular = perpNeg || perpPos;
        boolean oneParallel = parNeg ^ parPos;

        float minXZ = perpendicular && oneParallel && !parPos ? 8F/16F : 7F/16F;
        float maxXZ = perpendicular && oneParallel && !parNeg ? 8F/16F : 9F/16F;

        float offset;
        if (parNeg || parPos)
        {
            offset = .5F;
        }
        else
        {
            offset = perpNeg ? 9F/16F : (perpPos ? 7F/16F : .5F);

            if (Utils.isPositive(quad.method_3358()))
            {
                offset = 1F - offset;
            }
        }

        QuadModifier.geometry(quad)
                .apply(Modifiers.cutSide(minXZ, 0, maxXZ, 1))
                .apply(Modifiers.setPosition(offset))
                .export(quadList);
    }

    private static void createPillarQuad(List<class_777> quadList, class_777 quad, class_2350 dir)
    {
        if (Utils.isY(dir))
        {
            throw new IllegalArgumentException(String.format("Invalid direction: %s!", dir));
        }

        boolean positive = Utils.isPositive(dir);
        float minXZ = positive ? 12F/16F : 2F/16F;
        float maxXZ = positive ? 14F/16F : 4F/16F;

        QuadModifier.geometry(quad)
                .apply(Modifiers.cutSide(minXZ, 0, maxXZ, 1))
                .apply(Modifiers.setPosition(.5F))
                .export(quadList);
    }

    private static void createBarQuads(List<class_777> quadList, class_777 quad, class_2350 dir)
    {
        if (Utils.isY(dir))
        {
            throw new IllegalArgumentException(String.format("Invalid direction: %s!", dir));
        }

        boolean positive = Utils.isPositive(dir);
        boolean northeast = dir == class_2350.field_11043 || dir == class_2350.field_11034;

        float minXZ = positive ?  9F/16F : 4F/16F;
        float maxXZ = positive ? 12F/16F : 7F/16F;
        float minY = northeast ? 2F/16F : 12F/16F;
        float maxY = northeast ? 4F/16F : 14F/16F;

        QuadModifier.geometry(quad)
                .apply(Modifiers.cutSide(minXZ, minY, maxXZ, maxY))
                .apply(Modifiers.setPosition(.5F))
                .export(quadList);

        minXZ = positive ? 14F/16F : 0;
        maxXZ = positive ? 1 :  2F/16F;

        QuadModifier.geometry(quad)
                .apply(Modifiers.cutSide(minXZ, 7F/16F, maxXZ, 9F/16F))
                .apply(Modifiers.setPosition(.5F))
                .export(quadList);
    }
}