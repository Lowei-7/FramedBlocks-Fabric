package xfacthd.framedblocks.client.model.pane;

import com.google.common.base.Preconditions;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_777;
import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.util.Utils;

import java.util.List;
import java.util.Map;

public class FramedPaneModel extends FramedBlockModel
{
    protected final boolean north;
    protected final boolean east;
    protected final boolean south;
    protected final boolean west;

    protected FramedPaneModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);

        north = state.method_11654(class_2741.field_12489);
        east = state.method_11654(class_2741.field_12487);
        south = state.method_11654(class_2741.field_12540);
        west = state.method_11654(class_2741.field_12527);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 face = quad.method_3358();
        if (Utils.isY(face))
        {
            if (isPillarVisible())
            {
                createTopBottomCenterQuad(quadMap, quad, false);
            }

            if (north) { createTopBottomEdgeQuad(quadMap, quad, class_2350.field_11043, false); }
            if (east) { createTopBottomEdgeQuad(quadMap, quad, class_2350.field_11034, false); }
            if (south) { createTopBottomEdgeQuad(quadMap, quad, class_2350.field_11035, false); }
            if (west) { createTopBottomEdgeQuad(quadMap, quad, class_2350.field_11039, false); }
        }
        else
        {
            boolean inset = isSideInset(face);
            if (!inset || isPillarVisible())
            {
                createSideEdgeQuad(quadMap, quad, inset, false);
            }

            if (Utils.isX(face))
            {
                if (north) { createSideQuad(quadMap.get(null), quad, class_2350.field_11043); }
                if (south) { createSideQuad(quadMap.get(null), quad, class_2350.field_11035); }
            }

            if (Utils.isZ(face))
            {
                if (east) { createSideQuad(quadMap.get(null), quad, class_2350.field_11034); }
                if (west) { createSideQuad(quadMap.get(null), quad, class_2350.field_11039); }
            }
        }
    }

    protected boolean isPillarVisible()
    {
        return true;
    }

    protected static void createTopBottomCenterQuad(
            Map<class_2350, List<class_777>> quadMap, class_777 quad, boolean mirrored
    )
    {
        QuadModifier.geometry(quad)
                .apply(Modifiers.cutTopBottom(7F/16F, 7F/16F, 9F/16F, 9F/16F))
                .applyIf(Modifiers.setPosition(.001F), mirrored)
                .export(quadMap.get(mirrored ? null : quad.method_3358()));
    }

    protected static void createTopBottomEdgeQuad(
            Map<class_2350, List<class_777>> quadMap, class_777 quad, class_2350 dir, boolean mirrored
    )
    {
        Preconditions.checkArgument(!Utils.isY(dir), String.format("Invalid direction: %s!", dir));

        QuadModifier.geometry(quad)
                .apply(Modifiers.cutTopBottom(dir.method_10153(), 7F/16F))
                .apply(Modifiers.cutTopBottom(dir.method_10170().method_10166(), 9F/16F))
                .applyIf(Modifiers.setPosition(.001F), mirrored)
                .export(quadMap.get(mirrored ? null : quad.method_3358()));
    }

    protected static void createSideEdgeQuad(
            Map<class_2350, List<class_777>> quadMap, class_777 quad, boolean inset, boolean mirrored
    )
    {
        Preconditions.checkArgument(!inset || !mirrored, "Quad can't be mirrored and inset!");

        class_2350 quadDir = quad.method_3358();
        class_2350 exportSide = inset ? null : (mirrored ? quadDir.method_10153() : quadDir);

        QuadModifier.geometry(quad)
                .apply(Modifiers.cutSideLeftRight(9F/16F))
                .applyIf(Modifiers.setPosition(9F/16F), inset)
                .applyIf(Modifiers.setPosition(.001F), !inset && mirrored)
                .export(quadMap.get(exportSide));
    }

    private static void createSideQuad(List<class_777> quadList, class_777 quad, class_2350 dir)
    {
        QuadModifier.geometry(quad)
                .apply(Modifiers.cutSideLeftRight(dir.method_10153(), 7F/16F))
                .apply(Modifiers.setPosition(9F/16F))
                .export(quadList);
    }

    protected boolean isSideInset(class_2350 face)
    {
        return switch (face)
        {
            case field_11043 -> !north;
            case field_11034 -> !east;
            case field_11035 -> !south;
            case field_11039 -> !west;
            default -> throw new IllegalArgumentException(String.format("Invalid face: %s!", face));
        };
    }



    public static class_1087 createPaneModel(class_2680 state, class_1087 baseModel)
    {
        // Diagonal pane support requires the optional "diagonalwindows" mod API
        return new FramedPaneModel(state, baseModel);
    }
}