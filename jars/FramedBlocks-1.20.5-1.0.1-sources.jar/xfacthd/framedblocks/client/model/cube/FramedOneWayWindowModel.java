package xfacthd.framedblocks.client.model.cube;

import java.util.Set;
import net.minecraft.class_1087;
import net.minecraft.class_1921;
import net.minecraft.class_2246;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_5819;
import net.minecraft.class_773;
import net.minecraft.class_777;
import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.util.ModelUtils;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.NullableDirection;

import java.util.List;
import java.util.Map;

public class FramedOneWayWindowModel extends FramedBlockModel
{
    private static class_1087 tintedGlassModel;

    private final NullableDirection face;

    public FramedOneWayWindowModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        this.face = state.method_11654(PropertyHolder.NULLABLE_FACE);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad) { }

    @Override
    protected Set<class_1921> getAdditionalRenderTypes(class_5819 rand, Object extraData)
    {
        if (face != NullableDirection.NONE)
        {
            return ModelUtils.TRANSLUCENT;
        }
        return Set.of();
    }

    @Override
    protected void getAdditionalQuads(
            Map<class_2350, List<class_777>> quadMap,
            class_2680 state,
            class_5819 rand,
            Object data,
            class_1921 renderType
    )
    {
        if (face != NullableDirection.NONE && renderType == class_1921.method_23583())
        {
            class_2350 side = face.toDirection();
            quadMap.get(side).addAll(tintedGlassModel.method_4707(
                    class_2246.field_27115.method_9564(),
                    side,
                    rand
            ));
        }
    }

    @Override
    protected boolean useBaseModel()
    {
        return true;
    }



    public static void captureTintedGlassModel(Map<class_2960, class_1087> models)
    {
        class_2960 loc = class_773.method_3340(class_2246.field_27115.method_9564());
        tintedGlassModel = models.get(loc);
    }
}
