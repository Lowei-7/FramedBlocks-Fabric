package xfacthd.framedblocks.client.model.cube;

import java.util.Set;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.model.util.ModelUtils;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;

import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import net.minecraft.class_1087;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import net.minecraft.class_777;

public class FramedBookshelfModel extends FramedBlockModel
{
    private final Predicate<class_2350> frontFacePred;

    private FramedBookshelfModel(class_2680 state, class_1087 baseModel, Predicate<class_2350> frontFacePred)
    {
        super(state, baseModel);
        this.frontFacePred = frontFacePred;
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();
        if (Utils.isY(quadDir) || !frontFacePred.test(quadDir))
        {
            return;
        }

        List<class_777> quads = quadMap.get(quadDir);

        QuadModifier.geometry(quad)
                .apply(Modifiers.cutSideUpDown(true, 1F/16F))
                .export(quads);

        QuadModifier.geometry(quad)
                .apply(Modifiers.cutSideUpDown(false, 1F/16F))
                .export(quads);

        QuadModifier.geometry(quad)
                .apply(Modifiers.cutSideLeftRight(true, 1F/16F))
                .apply(Modifiers.cutSideUpDown(15F/16F))
                .export(quads);

        QuadModifier.geometry(quad)
                .apply(Modifiers.cutSideLeftRight(false, 1F/16F))
                .apply(Modifiers.cutSideUpDown(15F/16F))
                .export(quads);

        QuadModifier.geometry(quad)
                .apply(Modifiers.cutSideUpDown(9F/16F))
                .apply(Modifiers.cutSideLeftRight(15F/16F))
                .export(quads);
    }

    @Override
    protected Set<class_1921> getAdditionalRenderTypes(class_5819 rand, Object extraData)
    {
        return ModelUtils.CUTOUT;
    }

    @Override
    protected void getAdditionalQuads(Map<class_2350, List<class_777>> quadMap, class_2680 state, class_5819 rand, Object data, class_1921 renderType)
    {
        if (renderType == class_1921.method_23581())
        {
            for (class_2350 dir : class_2350.class_2353.field_11062)
            {
                quadMap.get(dir).addAll(baseModel.method_4707(state, dir, rand));
            }
        }
    }



    public static FramedBookshelfModel normal(class_2680 state, class_1087 baseModel)
    {
        return new FramedBookshelfModel(state, baseModel, dir -> true);
    }

    public static FramedBookshelfModel chiseled(class_2680 state, class_1087 baseModel)
    {
        class_2350 facing = state.method_11654(FramedProperties.FACING_HOR);
        return new FramedBookshelfModel(state, baseModel, facing::equals);
    }

    public static class_2680 itemSourceNormal()
    {
        return FBContent.BLOCK_FRAMED_BOOKSHELF.get().method_9564();
    }

    public static class_2680 itemSourceChiseled()
    {
        return FBContent.BLOCK_FRAMED_CHISELED_BOOKSHELF.get().method_9564();
    }
}
