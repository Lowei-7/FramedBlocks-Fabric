package xfacthd.framedblocks.client.model.cube;

import xfacthd.framedblocks.api.model.util.ModelUtils;

import java.util.*;
import net.minecraft.class_1087;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import net.minecraft.class_765;
import net.minecraft.class_777;

public class FramedGlowingCubeModel extends FramedCubeBaseModel
{
    public FramedGlowingCubeModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
    }

    @Override
    public List<class_777> getQuads(
            class_2680 state, class_2350 side, class_5819 rand, Object extraData, class_1921 renderType
    )
    {
        List<class_777> quads = super.getQuads(state, side, rand, extraData, renderType);
        return applyFullbright(quads);
    }

    @Override
    public List<class_777> method_4707(class_2680 state, class_2350 side, class_5819 rand)
    {
        List<class_777> quads = super.method_4707(state, side, rand);
        return applyFullbright(quads);
    }

    @Override
    public boolean method_4708()
    {
        return false;
    }

    @Override
    public boolean useAmbientOcclusionWithLightEmission(class_2680 state, class_1921 layer)
    {
        // Return true despite explicitly not wanting AO on this, simply to avoid the light emission check
        return true;
    }



    private static List<class_777> applyFullbright(List<class_777> quads)
    {
        List<class_777> fullbrightQuads = new ArrayList<>(quads.size());
        quads.forEach(quad ->
        {
            int[] vertexData = quad.method_3357();
            class_777 newQuad = new class_777(
                    Arrays.copyOf(vertexData, vertexData.length),
                    quad.method_3359(),
                    quad.method_3358(),
                    quad.method_35788(),
                    false
            );
            setMaxEmissivity(newQuad);
            fullbrightQuads.add(newQuad);
        });
        return fullbrightQuads;
    }

    private static void setMaxEmissivity(class_777 quad)
    {
        int[] vertexData = quad.method_3357();
        for (int vert = 0; vert < 4; vert++)
        {
            int offset = vert * ModelUtils.QUADS_STRIDE + ModelUtils.STRIDE_UV2;
            vertexData[offset] = class_765.method_23687(15, 15);
        }
    }
}
