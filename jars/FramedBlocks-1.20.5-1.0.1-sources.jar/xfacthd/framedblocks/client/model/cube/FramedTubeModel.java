package xfacthd.framedblocks.client.model.cube;

import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.util.Utils;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_777;

public class FramedTubeModel extends FramedBlockModel
{
    private final class_2350.class_2351 axis;

    public FramedTubeModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        this.axis = state.method_11654(class_2741.field_12496);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();
        if (axis == class_2350.class_2351.field_11052)
        {
            if (quadDir.method_10166() == axis)
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(class_2350.field_11043, 2F / 16F))
                        .export(quadMap.get(quadDir));
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(class_2350.field_11035, 2F / 16F))
                        .export(quadMap.get(quadDir));
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(class_2350.field_11034, 2F / 16F))
                        .apply(Modifiers.cutTopBottom(class_2350.class_2351.field_11051, 14F / 16F))
                        .export(quadMap.get(quadDir));
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(class_2350.field_11039, 2F / 16))
                        .apply(Modifiers.cutTopBottom(class_2350.class_2351.field_11051, 14F / 16F))
                        .export(quadMap.get(quadDir));
            }
            else
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(14F/16F))
                        .apply(Modifiers.setPosition(2F/16F))
                        .export(quadMap.get(null));
            }
        }
        else
        {
            if (quadDir.method_10166() == axis)
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideUpDown(false, 2F / 16F))
                        .export(quadMap.get(quadDir));
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideUpDown(true, 2F / 16F))
                        .export(quadMap.get(quadDir));
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(quadDir.method_10170(), 2F / 16F))
                        .apply(Modifiers.cutSideUpDown(14F / 16F))
                        .export(quadMap.get(quadDir));
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(quadDir.method_10160(), 2F / 16F))
                        .apply(Modifiers.cutSideUpDown(14F / 16F))
                        .export(quadMap.get(quadDir));
            }
            else if (Utils.isY(quadDir))
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(Utils.nextAxisNotEqualTo(axis, class_2350.class_2351.field_11052), 14F/16F))
                        .apply(Modifiers.setPosition(2F/16F))
                        .export(quadMap.get(null));
            }
            else
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideUpDown(14F/16F))
                        .apply(Modifiers.setPosition(2F/16F))
                        .export(quadMap.get(null));
            }
        }
    }

    @Override
    protected boolean transformAllQuads(class_2680 state)
    {
        return true;
    }
}
