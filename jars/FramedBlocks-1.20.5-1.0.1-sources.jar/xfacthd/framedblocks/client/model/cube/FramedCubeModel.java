package xfacthd.framedblocks.client.model.cube;

import net.minecraft.class_1087;
import net.minecraft.class_2680;
import xfacthd.framedblocks.api.model.data.FramedBlockData;

public class FramedCubeModel extends FramedCubeBaseModel
{
    public FramedCubeModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
    }

    @Override
    protected class_2680 getNoCamoModelState(class_2680 camoState, FramedBlockData fbData)
    {
        return super.getNoCamoModelState(this.state, fbData);
    }
}