package xfacthd.framedblocks.client.model.cube;

import java.util.Set;
import net.minecraft.class_1087;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.util.*;
import xfacthd.framedblocks.api.model.util.ModelUtils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.ChestState;
import xfacthd.framedblocks.common.data.property.LatchType;

import java.util.List;
import java.util.Map;

public class FramedChestModel extends FramedBlockModel
{
    private final class_2350 facing;
    private final boolean closed;
    private final LatchType latch;
    private final Set<class_1921> addLayers;

    public FramedChestModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        this.facing = state.method_11654(FramedProperties.FACING_HOR);
        this.closed = state.method_11654(PropertyHolder.CHEST_STATE) == ChestState.CLOSED || ClientUtils.OPTIFINE_LOADED.get();
        this.latch = state.method_11654(PropertyHolder.LATCH_TYPE);
        this.addLayers = latch == LatchType.DEFAULT ? ModelUtils.CUTOUT : Set.of();
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();
        if (Utils.isY(quad.method_3358()))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(1F/16F, 1F/16F, 15F/16F, 15F/16F))
                    .applyIf(Modifiers.setPosition(closed ? 14F/16F : 10F/16F), quadDir == class_2350.field_11036)
                    .export(quadMap.get(quadDir == class_2350.field_11036 ? null : quadDir));
        }
        else
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSide(1F/16F, 0, 15F/16F, closed ? 14F/16F : 10F/16F))
                    .apply(Modifiers.setPosition(15F/16F))
                    .export(quadMap.get(null));
        }

        if (latch == LatchType.CAMO && closed)
        {
            makeChestLatch(quadMap, quad, facing);
        }
    }

    public static void makeChestLatch(Map<class_2350, List<class_777>> quadMap, class_777 quad, class_2350 facing)
    {
        class_2350 face = quad.method_3358();

        if (face == facing || face == facing.method_10153())
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSide(7F/16F, 7F/16F, 9F/16F, 11F/16F))
                    .applyIf(Modifiers.setPosition(1F/16F), face != facing)
                    .export(quadMap.get(face == facing ? facing : null));
        }
        else if (Utils.isY(face))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(facing.method_10153(), 1F/16F))
                    .apply(Modifiers.cutTopBottom(facing.method_10170(), 9F/16F))
                    .apply(Modifiers.cutTopBottom(facing.method_10160(), 9F/16F))
                    .apply(Modifiers.setPosition(face == class_2350.field_11036 ? 11F/16F : 9F/16F))
                    .export(quadMap.get(null));
        }
        else
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSide(0, 7F/16F, 1, 11F/16F))
                    .apply(Modifiers.cutSideLeftRight(facing.method_10153(), 1F/16F))
                    .apply(Modifiers.setPosition(9F/16F))
                    .export(quadMap.get(null));
        }
    }

    @Override
    protected Set<class_1921> getAdditionalRenderTypes(class_5819 rand, Object extraData)
    {
        return addLayers;
    }

    @Override
    protected void getAdditionalQuads(
            Map<class_2350, List<class_777>> quadMap,
            class_2680 state,
            class_5819 rand,
            Object data,
            class_1921 renderType
    )
    {
        if (!closed || latch != LatchType.DEFAULT)
        {
            return;
        }

        List<class_777> quads = baseModel.method_4707(state, null, rand);
        for (class_777 quad : quads)
        {
            quadMap.get(null).add(quad);
        }
    }



    public static class_2680 itemSource()
    {
        return FBContent.BLOCK_FRAMED_CHEST.get().method_9564();
    }
}