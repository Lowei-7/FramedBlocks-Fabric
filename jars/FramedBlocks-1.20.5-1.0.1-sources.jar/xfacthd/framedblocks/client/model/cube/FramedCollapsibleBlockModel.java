package xfacthd.framedblocks.client.model.cube;

import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.data.FramedBlockData;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.blockentity.special.FramedCollapsibleBlockEntity;
import xfacthd.framedblocks.common.data.PropertyHolder;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_777;

public class FramedCollapsibleBlockModel extends FramedBlockModel
{
    public static final class_2960 ALT_BASE_MODEL_LOC = Utils.rl("block/framed_collapsible_block_alt");
    private static final float MIN_DEPTH = .001F;
    private static class_1087 altBaseModel = null;

    private final class_2350 collapsedFace;
    private final boolean rotSplitLine;

    public FramedCollapsibleBlockModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        this.collapsedFace = state.method_11654(PropertyHolder.NULLABLE_FACE).toDirection();
        this.rotSplitLine = state.method_11654(PropertyHolder.ROTATE_SPLIT_LINE);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad, Object data)
    {
        class_2350 quadDir = quad.method_3358();
        if (collapsedFace == null || quadDir == collapsedFace.method_10153())
        {
            quadMap.get(quadDir).add(quad);
            return;
        }

        Integer offsets = data instanceof FramedBlockData fbData ? fbData.getPackedOffsets() : null;
        float[] vertexPos = new float[] { 1F, 1F, 1F, 1F };
        if (offsets != null && offsets != 0)
        {
            byte[] relOff = FramedCollapsibleBlockEntity.unpackOffsets(offsets);
            boolean allSame = relOff[0] == relOff[1] && relOff[0] == relOff[2] && relOff[0] == relOff[3];
            for (int i = 0; i < 4; i++)
            {
                vertexPos[i] = Math.max(1F - ((float) relOff[i] / 16F), allSame ? MIN_DEPTH : 0F);
            }
        }

        if (quadDir == collapsedFace)
        {
            float diff02 = Math.abs(vertexPos[0] - vertexPos[2]);
            float diff13 = Math.abs(vertexPos[1] - vertexPos[3]);
            boolean rotate = (diff13 > diff02) != rotSplitLine;

            float[] vertexPosTwo = new float[] { 1F, 1F, 1F, 1F };
            System.arraycopy(vertexPos, 0, vertexPosTwo, 0, vertexPos.length);
            if (rotate)
            {
                vertexPos[2] = vertexPos[1] + vertexPos[3] - vertexPos[0];
                vertexPosTwo[0] = vertexPosTwo[1] + vertexPosTwo[3] - vertexPosTwo[2];
            }
            else
            {
                vertexPos[3] = vertexPos[0] + vertexPos[2] - vertexPos[1];
                vertexPosTwo[1] = vertexPosTwo[0] + vertexPosTwo[2] - vertexPosTwo[3];
            }

            if (Utils.isY(collapsedFace))
            {
                rotate ^= collapsedFace == class_2350.field_11033;
                float left = rotate ? 0F : 1F;
                float right = rotate ? 1F : 0F;

                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(class_2350.field_11034, left, right))
                        .apply(Modifiers.setPosition(vertexPos))
                        .export(quadMap.get(null));

                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(class_2350.field_11039, left, right))
                        .apply(Modifiers.setPosition(vertexPosTwo))
                        .export(quadMap.get(null));
            }
            else
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(quadDir.method_10160(), rotate ? 1F : 0F, rotate ? 0F : 1F))
                        .apply(Modifiers.setPosition(vertexPos))
                        .export(quadMap.get(null));

                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(quadDir.method_10170(), rotate ? 0F : 1F, rotate ? 1F : 0F))
                        .apply(Modifiers.setPosition(vertexPosTwo))
                        .export(quadMap.get(null));
            }
        }
        else
        {
            if (Utils.isY(collapsedFace))
            {
                boolean top = collapsedFace == class_2350.field_11036;
                int idxOne = getYCollapsedIndexOffset(quadDir);
                int idxTwo = Math.floorMod(idxOne + (top ? 1 : -1), 4);
                float posOne = vertexPos[idxOne];
                float posTwo = vertexPos[idxTwo];

                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideUpDown(!top, posOne, posTwo))
                        .export(quadMap.get(quadDir));
            }
            else if (Utils.isY(quadDir))
            {
                boolean top = quad.method_3358() == class_2350.field_11036;
                float posOne = vertexPos[top ? 0 : 1];
                float posTwo = vertexPos[top ? 3 : 2];

                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(collapsedFace, posOne, posTwo))
                        .export(quadMap.get(quadDir));
            }
            else
            {
                boolean right = collapsedFace == quadDir.method_10170();
                float posTop = vertexPos[right ? 3 : 0];
                float posBot = vertexPos[right ? 2 : 1];

                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(collapsedFace, posTop, posBot))
                        .export(quadMap.get(quadDir));
            }
        }
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad) { }

    @Override
    protected boolean useBaseModel()
    {
        return true;
    }

    @Override
    protected class_1087 getCamoModel(class_2680 camoState, boolean useBaseModel, boolean useAltModel)
    {
        if (useBaseModel && useAltModel)
        {
            return altBaseModel;
        }
        return super.getCamoModel(camoState, useBaseModel, useAltModel);
    }

    @Override
    protected QuadCacheKey makeCacheKey(class_2680 state, Object ctCtx, Object data)
    {
        Integer packedOffsets = data instanceof FramedBlockData fbData ? fbData.getPackedOffsets() : null;
        return new CollapsibleBlockQuadCacheKey(state, ctCtx, packedOffsets);
    }

    private int getYCollapsedIndexOffset(class_2350 quadFace)
    {
        boolean top = collapsedFace == class_2350.field_11036;
        return switch (quadFace)
        {
            case field_11043 -> top ? 3 : 2;
            case field_11034 -> top ? 2 : 3;
            case field_11035 -> top ? 1 : 0;
            case field_11039 -> top ? 0 : 1;
            case field_11033, field_11036 -> throw new IllegalArgumentException("Invalid facing for y face collapse!");
        };
    }

    private record CollapsibleBlockQuadCacheKey(class_2680 state, Object ctCtx, Integer packedOffsets) implements QuadCacheKey { }



    public static void captureAltBaseModel(Map<class_2960, class_1087> models)
    {
        altBaseModel = models.get(ALT_BASE_MODEL_LOC);
    }
}
