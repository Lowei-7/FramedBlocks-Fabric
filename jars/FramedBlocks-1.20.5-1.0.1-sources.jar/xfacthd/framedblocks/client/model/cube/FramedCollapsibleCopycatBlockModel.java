package xfacthd.framedblocks.client.model.cube;

import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.data.FramedBlockData;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.blockentity.special.FramedCollapsibleCopycatBlockEntity;
import xfacthd.framedblocks.common.data.PropertyHolder;

import java.util.*;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_777;

public class FramedCollapsibleCopycatBlockModel extends FramedBlockModel
{
    public static final class_2960 ALT_BASE_MODEL_LOC = Utils.rl("block/framed_collapsible_copycat_block_alt");
    private static final int UP = class_2350.field_11036.ordinal();
    private static final int DOWN = class_2350.field_11033.ordinal();
    private static final int NORTH = class_2350.field_11043.ordinal();
    private static final int EAST = class_2350.field_11034.ordinal();
    private static final int SOUTH = class_2350.field_11035.ordinal();
    private static final int WEST = class_2350.field_11039.ordinal();
    private static class_1087 altBaseModel = null;

    private final int solidFaces;

    public FramedCollapsibleCopycatBlockModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        this.solidFaces = state.method_11654(PropertyHolder.SOLID_FACES);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad, Object data)
    {
        class_2350 quadDir = quad.method_3358();
        Integer packedOffsets = data instanceof FramedBlockData fbData ? fbData.getPackedOffsets() : null;
        if (packedOffsets == null)
        {
            quadMap.get(quadDir).add(quad);
            return;
        }

        byte[] offsets = FramedCollapsibleCopycatBlockEntity.unpackOffsets(packedOffsets);
        boolean solid = (solidFaces & (1 << quadDir.ordinal())) != 0;
        List<QuadModifier> mods = new ArrayList<>(2);
        QuadModifier initialModifier = QuadModifier.geometry(quad).apply(Modifiers.setPosition((16F - offsets[quadDir.ordinal()]) / 16F));
        if (Utils.isY(quadDir))
        {
            if (offsets[NORTH] > 0 || offsets[SOUTH] > 0)
            {
                FloatPair length = getLenghts(offsets[NORTH], offsets[SOUTH]);
                if (length.valOne > 0F)
                {
                    mods.add(initialModifier
                            .derive()
                            .apply(Modifiers.cutTopBottom(class_2350.field_11035, length.valOne))
                            .apply(Modifiers.offset(class_2350.field_11035, offsets[NORTH] / 16F))
                    );
                }
                if (length.valTwo > 0F)
                {
                    mods.add(initialModifier
                            .apply(Modifiers.cutTopBottom(class_2350.field_11043, length.valTwo))
                            .apply(Modifiers.offset(class_2350.field_11043, offsets[SOUTH] / 16F))
                    );
                }
            }
            else
            {
                mods.add(initialModifier);
            }

            if (offsets[EAST] > 0 || offsets[WEST] > 0)
            {
                FloatPair length = getLenghts(offsets[WEST], offsets[EAST]);
                for (QuadModifier modifier : mods)
                {
                    if (length.valOne > 0F)
                    {
                        modifier.derive()
                                .apply(Modifiers.cutTopBottom(class_2350.field_11034, length.valOne))
                                .apply(Modifiers.offset(class_2350.field_11034, offsets[WEST] / 16F))
                                .export(quadMap.get(solid ? quadDir : null));
                    }
                    if (length.valTwo > 0F)
                    {
                        modifier.apply(Modifiers.cutTopBottom(class_2350.field_11039, length.valTwo))
                                .apply(Modifiers.offset(class_2350.field_11039, offsets[EAST] / 16F))
                                .export(quadMap.get(solid ? quadDir : null));
                    }
                }
            }
            else
            {
                for (QuadModifier modifier : mods)
                {
                    modifier.export(quadMap.get(solid ? quadDir : null));
                }
            }
        }
        else
        {
            boolean xAxis = Utils.isX(quadDir);
            class_2350 axisNeg = xAxis ? class_2350.field_11043 : class_2350.field_11039;
            int axisMin = xAxis ? NORTH : WEST;
            int axisMax = xAxis ? SOUTH : EAST;
            if (offsets[axisMin] > 0 || offsets[axisMax] > 0)
            {
                FloatPair length = getLenghts(offsets[axisMin], offsets[axisMax]);
                if (length.valOne > 0F)
                {
                    mods.add(initialModifier
                            .derive()
                            .apply(Modifiers.cutSideLeftRight(axisNeg.method_10153(), length.valOne))
                            .apply(Modifiers.offset(axisNeg.method_10153(), offsets[axisMin] / 16F))
                    );
                }
                if (length.valTwo > 0F)
                {
                    mods.add(initialModifier
                            .apply(Modifiers.cutSideLeftRight(axisNeg, length.valTwo))
                            .apply(Modifiers.offset(axisNeg, offsets[axisMax] / 16F))
                    );
                }
            }
            else
            {
                mods.add(initialModifier);
            }

            if (offsets[DOWN] > 0 || offsets[UP] > 0)
            {
                FloatPair length = getLenghts(offsets[DOWN], offsets[UP]);
                for (QuadModifier modifier : mods)
                {
                    if (length.valOne > 0F)
                    {
                        modifier.derive()
                                .apply(Modifiers.cutSideUpDown(false, length.valOne))
                                .apply(Modifiers.offset(class_2350.field_11036, offsets[DOWN] / 16F))
                                .export(quadMap.get(solid ? quadDir : null));
                    }
                    if (length.valTwo > 0F)
                    {
                        modifier.apply(Modifiers.cutSideUpDown(true, length.valTwo))
                                .apply(Modifiers.offset(class_2350.field_11033, offsets[UP] / 16F))
                                .export(quadMap.get(solid ? quadDir : null));
                    }
                }
            }
            else
            {
                for (QuadModifier modifier : mods)
                {
                    modifier.export(quadMap.get(solid ? quadDir : null));
                }
            }
        }
    }

    private static FloatPair getLenghts(int offsetMin, int offsetMax)
    {
        float length = (16 - offsetMin - offsetMax) / 2F;
        boolean ceilFirst = offsetMin > offsetMax;
        return new FloatPair(
                (float)(ceilFirst ? Math.ceil(length) : Math.floor(length)) / 16F,
                (float)(ceilFirst ? Math.floor(length) : Math.ceil(length)) / 16F
        );
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad) { }

    @Override
    protected boolean useBaseModel()
    {
        return true;
    }

    @Override
    protected class_1087 getCamoModel(class_2680 camoState, boolean useBaseModel, boolean useAltModel)
    {
        if (useBaseModel && useAltModel)
        {
            return altBaseModel;
        }
        return super.getCamoModel(camoState, useBaseModel, useAltModel);
    }

    @Override
    protected QuadCacheKey makeCacheKey(class_2680 state, Object ctCtx, Object data)
    {
        Integer packedOffsets = data instanceof FramedBlockData fbData ? fbData.getPackedOffsets() : null;
        return new CollapsibleCopycatBlockQuadCacheKey(state, ctCtx, packedOffsets);
    }

    private record FloatPair(float valOne, float valTwo) { }

    private record CollapsibleCopycatBlockQuadCacheKey(class_2680 state, Object ctCtx, Integer packedOffsets) implements QuadCacheKey { }



    public static void captureAltBaseModel(Map<class_2960, class_1087> models)
    {
        altBaseModel = models.get(ALT_BASE_MODEL_LOC);
    }
}
