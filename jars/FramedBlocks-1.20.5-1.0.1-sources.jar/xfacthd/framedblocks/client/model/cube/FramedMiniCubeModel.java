package xfacthd.framedblocks.client.model.cube;

import org.joml.Vector3f;
import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.util.Utils;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_777;

public class FramedMiniCubeModel extends FramedBlockModel
{
    private static final Vector3f ORIGIN = new Vector3f(.5F, 0, .5F);

    private final float rotAngle;

    public FramedMiniCubeModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        int rot = state.method_11654(class_2741.field_12532);
        this.rotAngle = (4 - (rot % 4)) * 22.5F;
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();


        QuadModifier.geometry(quad)
                .apply(Modifiers.scaleFace(.5F, ORIGIN))
                .applyIf(Modifiers.setPosition(.5F), quadDir == class_2350.field_11036)
                .applyIf(Modifiers.setPosition(.75F), !Utils.isY(quadDir))
                .apply(Modifiers.rotate(class_2350.class_2351.field_11052, ORIGIN, rotAngle, false))
                .export(quadMap.get(quadDir == class_2350.field_11033 ? quadDir : null));
    }
}
