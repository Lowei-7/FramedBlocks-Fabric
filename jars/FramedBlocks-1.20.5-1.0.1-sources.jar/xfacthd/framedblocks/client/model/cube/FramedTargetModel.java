package xfacthd.framedblocks.client.model.cube;

import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.api.model.util.ModelUtils;
import xfacthd.framedblocks.common.FBContent;

import java.util.*;
import net.minecraft.class_1087;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_5819;
import net.minecraft.class_777;

public class FramedTargetModel extends FramedBlockModel
{
    public static final class_2960 OVERLAY_LOCATION = Utils.rl("block/target_overlay");
    public static final int OVERLAY_TINT_IDX = 1024;

    private final class_1087 overlayModel;

    public FramedTargetModel(class_2680 state, class_1087 baseModel, Map<class_2960, class_1087> registry)
    {
        super(state, baseModel);
        this.overlayModel = registry.get(OVERLAY_LOCATION);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad) { }

    @Override
    protected Set<class_1921> getAdditionalRenderTypes(class_5819 rand, Object extraData)
    {
        return ModelUtils.CUTOUT;
    }

    @Override
    protected void getAdditionalQuads(
            ArrayList<class_777> quads,
            class_2350 side,
            class_2680 state,
            class_5819 rand,
            Object data,
            class_1921 renderType
    )
    {
        Utils.copyAll(overlayModel.method_4707(state, side, rand), quads);
    }



    public static class_2680 itemSource()
    {
        return FBContent.BLOCK_FRAMED_TARGET.get().method_9564();
    }
}
