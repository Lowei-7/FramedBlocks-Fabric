package xfacthd.framedblocks.client.model.cube;

import xfacthd.framedblocks.api.model.data.FramedBlockData;
import xfacthd.framedblocks.api.model.util.ModelUtils;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.client.util.ClientConfig;

import java.util.*;
import net.minecraft.class_1087;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_5819;
import net.minecraft.class_777;

public class FramedMarkedCubeModel extends FramedCubeBaseModel
{
    public static final class_2960 SLIME_FRAME_LOCATION = Utils.rl("block/slime_frame");
    public static final class_2960 REDSTONE_FRAME_LOCATION = Utils.rl("block/redstone_frame");
    private final class_1087 frameModel;

    public FramedMarkedCubeModel(
            class_2680 state,
            class_1087 baseModel,
            Map<class_2960, class_1087> registry,
            class_2960 frameLocation
    )
    {
        super(state, baseModel);
        frameModel = registry.get(frameLocation);
    }

    @Override
    protected Set<class_1921> getAdditionalRenderTypes(class_5819 rand, Object extraData)
    {
        FramedBlockData fbData = (extraData instanceof FramedBlockData fbd) ? fbd : null;
        if (fbData != null && !fbData.getCamoState().method_26215())
        {
            return ModelUtils.CUTOUT;
        }
        return Set.of();
    }

    @Override
    protected void getAdditionalQuads(
            ArrayList<class_777> quads,
            class_2350 side,
            class_2680 state,
            class_5819 rand,
            Object data,
            class_1921 renderType
    )
    {
        FramedBlockData fbData = (data instanceof FramedBlockData fbd) ? fbd : null;
        if (fbData != null && !fbData.getCamoState().method_26215())
        {
            Utils.copyAll(frameModel.method_4707(state, side, rand), quads);
        }
    }



    public static FramedCubeBaseModel slime(
            class_2680 state, class_1087 baseModel, Map<class_2960, class_1087> registry
    )
    {
        if (ClientConfig.INSTANCE.showSpecialCubeOverlay())
        {
            return new FramedMarkedCubeModel(state, baseModel, registry, SLIME_FRAME_LOCATION);
        }
        return new FramedCubeBaseModel(state, baseModel);
    }

    public static FramedCubeBaseModel redstone(
            class_2680 state, class_1087 baseModel, Map<class_2960, class_1087> registry
    )
    {
        if (ClientConfig.INSTANCE.showSpecialCubeOverlay())
        {
            return new FramedMarkedCubeModel(state, baseModel, registry, REDSTONE_FRAME_LOCATION);
        }
        return new FramedCubeBaseModel(state, baseModel);
    }
}
