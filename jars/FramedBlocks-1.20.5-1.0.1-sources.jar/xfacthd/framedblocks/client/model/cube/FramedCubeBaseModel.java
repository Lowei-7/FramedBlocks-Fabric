package xfacthd.framedblocks.client.model.cube;

import xfacthd.framedblocks.api.model.FramedBlockModel;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_777;

public class FramedCubeBaseModel extends FramedBlockModel
{
    public FramedCubeBaseModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad) { }

    @Override
    protected boolean forceUngeneratedBaseModel()
    {
        return true;
    }
}
