package xfacthd.framedblocks.client.model.pillar;

import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.block.FramedProperties;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_777;

public class FramedCornerPillarModel extends FramedBlockModel
{
    private final class_2350 dir;

    public FramedCornerPillarModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        dir = state.method_11654(FramedProperties.FACING_HOR);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();
        if (quadDir == dir || quadDir == dir.method_10153())
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(dir.method_10170(), .5F))
                    .applyIf(Modifiers.setPosition(.5F), quadDir != dir)
                    .export(quadMap.get(quadDir == dir ? quadDir : null));
        }
        else if (quadDir == dir.method_10170() || quadDir == dir.method_10160())
        {
            boolean isCCW = quadDir == dir.method_10160();
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(dir.method_10153(), .5F))
                    .applyIf(Modifiers.setPosition(.5F), !isCCW)
                    .export(quadMap.get(isCCW ? quadDir : null));
        }
        else
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir.method_10153(), .5F))
                    .apply(Modifiers.cutTopBottom(dir.method_10170(), .5F))
                    .export(quadMap.get(quadDir));
        }
    }
}