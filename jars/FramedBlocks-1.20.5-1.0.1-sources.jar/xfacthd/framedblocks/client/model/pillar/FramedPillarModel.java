package xfacthd.framedblocks.client.model.pillar;

import xfacthd.framedblocks.api.block.IFramedBlock;
import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.type.IBlockType;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.data.BlockType;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_777;

public class FramedPillarModel extends FramedBlockModel
{
    private final class_2350.class_2351 axis;
    private final float capStart;
    private final float capEnd;
    private final float sideCut;

    public FramedPillarModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        axis = state.method_11654(class_2741.field_12496);

        IBlockType type = ((IFramedBlock)state.method_26204()).getBlockType();
        capStart = type == BlockType.FRAMED_POST ? (6F / 16F) : (4F / 16F);
        capEnd = type == BlockType.FRAMED_POST ? (10F / 16F) : (12F / 16F);
        sideCut = type == BlockType.FRAMED_POST ? (10F / 16F) : (12F / 16F);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();
        createPillarQuad(quad, axis, capStart, capEnd, sideCut)
                .export(quadMap.get(quadDir.method_10166() == axis ? quadDir : null));
    }

    public static QuadModifier createPillarQuad(
            class_777 quad, class_2350.class_2351 axis, float capStart, float capEnd, float sideCut
    )
    {
        class_2350 quadDir = quad.method_3358();
        if (quadDir.method_10166() == axis)
        {
            if (axis == class_2350.class_2351.field_11052)
            {
                return QuadModifier.geometry(quad).apply(Modifiers.cutTopBottom(capStart, capStart, capEnd, capEnd));
            }
            else
            {
                return QuadModifier.geometry(quad).apply(Modifiers.cutSide(capStart, capStart, capEnd, capEnd));
            }
        }
        else
        {
            if (axis == class_2350.class_2351.field_11052)
            {
                return QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(quadDir.method_10170(), sideCut))
                        .apply(Modifiers.cutSideLeftRight(quadDir.method_10160(), sideCut))
                        .apply(Modifiers.setPosition(sideCut));
            }
            else if (Utils.isY(quadDir))
            {
                return QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(axisToDir(axis, true).method_10170(), sideCut))
                        .apply(Modifiers.cutTopBottom(axisToDir(axis, false).method_10170(), sideCut))
                        .apply(Modifiers.setPosition(sideCut));
            }
            else
            {
                return QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideUpDown(true, sideCut))
                        .apply(Modifiers.cutSideUpDown(false, sideCut))
                        .apply(Modifiers.setPosition(sideCut));
            }
        }
    }

    @Override
    public boolean useSolidNoCamoModel()
    {
        return true;
    }

    private static class_2350 axisToDir(class_2350.class_2351 axis, boolean positive)
    {
        return switch (axis)
        {
            case field_11048 -> positive ? class_2350.field_11034 : class_2350.field_11039;
            case field_11052 -> positive ? class_2350.field_11036 : class_2350.field_11033;
            case field_11051 -> positive ? class_2350.field_11035 : class_2350.field_11043;
        };
    }
}