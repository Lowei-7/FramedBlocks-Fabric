package xfacthd.framedblocks.client.model.pillar;

import org.joml.Vector4f;
import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.util.Utils;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_4778;
import net.minecraft.class_777;

public class FramedWallModel extends FramedBlockModel
{
    private static final Vector4f[] rects = new Vector4f[] { //Wall half segment top/bottom rects
            new Vector4f( 5F/16F,      0F, 11F/16F,  5F/16F), //North
            new Vector4f( 5F/16F, 11F/16F, 11F/16F,      1F), //South
            new Vector4f(     0F,  5F/16F,  5F/16F, 11F/16F), //West
            new Vector4f(11F/16F,  5F/16F,      1F, 11F/16F), //East
            new Vector4f( 5F/16F,      0F, 11F/16F,  4F/16F), //North, with center pillar
            new Vector4f( 5F/16F, 12F/16F, 11F/16F,      1F), //South, with center pillar
            new Vector4f(     0F,  5F/16F,  4F/16F, 11F/16F), //West, with center pillar
            new Vector4f(12F/16F,  5F/16F,      1F, 11F/16F)  //East, with center pillar
    };
    private static final float LOW_HEIGHT = 14F/16F;
    private static final float SMALL_MIN = 5F/16F;
    private static final float SMALL_MAX = 11F/16F;
    private static final float LARGE_MIN = 4F/16F;
    private static final float LARGE_MAX = 12F/16F;

    private final boolean center;
    private final class_4778 north;
    private final class_4778 east;
    private final class_4778 south;
    private final class_4778 west;

    public FramedWallModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        center = state.method_11654(class_2741.field_12519);
        north = state.method_11654(class_2741.field_22175);
        east =  state.method_11654(class_2741.field_22174);
        south = state.method_11654(class_2741.field_22176);
        west =  state.method_11654(class_2741.field_22177);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        if (north != class_4778.field_22178)
        {
            buildWallHalfSegment(quadMap, quad, class_2350.field_11043, north);
        }
        if (south != class_4778.field_22178)
        {
            buildWallHalfSegment(quadMap, quad, class_2350.field_11035, south);
        }

        if (east != class_4778.field_22178)
        {
            buildWallHalfSegment(quadMap, quad, class_2350.field_11034, east);
        }
        if (west != class_4778.field_22178)
        {
            buildWallHalfSegment(quadMap, quad, class_2350.field_11039, west);
        }

        buildWallEndCap(quadMap, quad, class_2350.field_11043, north);
        buildWallEndCap(quadMap, quad, class_2350.field_11034, east);
        buildWallEndCap(quadMap, quad, class_2350.field_11035, south);
        buildWallEndCap(quadMap, quad, class_2350.field_11039, west);

        buildCenterPillar(quadMap, quad);
    }

    private void buildWallHalfSegment(
            Map<class_2350, List<class_777>> quadMap, class_777 quad, class_2350 dir, class_4778 height
    )
    {
        if (height != class_4778.field_22178)
        {
            class_2350 quadDir = quad.method_3358();
            if (Utils.isY(quadDir))
            {
                Vector4f rect = rects[dir.ordinal() - 2 + (center ? 4 : 0)];
                boolean inset = height != class_4778.field_22180 && quadDir != class_2350.field_11033;
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(rect.x(), rect.y(), rect.z(), rect.w()))
                        .applyIf(Modifiers.setPosition(LOW_HEIGHT), inset)
                        .export(quadMap.get(inset ? null : quadDir));
            }
            else if (quadDir.method_10166() != dir.method_10166())
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(dir.method_10153(), center ? LARGE_MIN : SMALL_MIN))
                        .applyIf(Modifiers.cutSideUpDown(false, LOW_HEIGHT), height != class_4778.field_22180)
                        .apply(Modifiers.setPosition(SMALL_MAX))
                        .export(quadMap.get(null));
            }
        }
    }

    private static void buildWallEndCap(
            Map<class_2350, List<class_777>> quadMap, class_777 quad, class_2350 dir, class_4778 height
    )
    {
        if (quad.method_3358() == dir && height != class_4778.field_22178)
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSide(SMALL_MIN, 0, SMALL_MAX, height == class_4778.field_22180 ? 1F : LOW_HEIGHT))
                    .export(quadMap.get(dir));
        }
    }

    private void buildCenterPillar(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();
        if (center)
        {
            if (Utils.isY(quadDir))
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(LARGE_MIN, LARGE_MIN, LARGE_MAX, LARGE_MAX))
                        .export(quadMap.get(quadDir));
            }
            else
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSide(LARGE_MIN, 0, LARGE_MAX, 1))
                        .apply(Modifiers.setPosition(LARGE_MAX))
                        .export(quadMap.get(null));
            }
        }
        else
        {
            boolean tall = north == class_4778.field_22180 || east == class_4778.field_22180 || south == class_4778.field_22180 || west == class_4778.field_22180;

            switch (quadDir)
            {
                case field_11036, field_11033 ->
                {
                    boolean inset = !tall && quadDir == class_2350.field_11036;
                    QuadModifier.geometry(quad)
                            .apply(Modifiers.cutTopBottom(SMALL_MIN, SMALL_MIN, SMALL_MAX, SMALL_MAX))
                            .applyIf(Modifiers.setPosition(LOW_HEIGHT), inset)
                            .export(quadMap.get(inset ? null : quadDir));
                }
                case field_11043 -> buildSmallCenterSide(quadMap.get(null), quad, north, tall);
                case field_11034 -> buildSmallCenterSide(quadMap.get(null), quad, east , tall);
                case field_11035 -> buildSmallCenterSide(quadMap.get(null), quad, south, tall);
                case field_11039 -> buildSmallCenterSide(quadMap.get(null), quad, west , tall);
            }
        }
    }

    private static void buildSmallCenterSide(List<class_777> quadList, class_777 quad, class_4778 height, boolean tall)
    {
        if (height == class_4778.field_22178)
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSide(SMALL_MIN, 0, SMALL_MAX, tall ? 1 : LOW_HEIGHT))
                    .apply(Modifiers.setPosition(SMALL_MAX))
                    .export(quadList);
        }
        else if (tall && height == class_4778.field_22179)
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSide(SMALL_MIN, LOW_HEIGHT, SMALL_MAX, 1))
                    .apply(Modifiers.setPosition(SMALL_MAX))
                    .export(quadList);
        }
    }
}