package xfacthd.framedblocks.client.model.pillar;

import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.util.Utils;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_777;

public class FramedHalfPillarModel extends FramedBlockModel
{
    private final class_2350 face;

    public FramedHalfPillarModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        face = state.method_11654(class_2741.field_12525);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        QuadModifier mod = FramedPillarModel.createPillarQuad(quad, face.method_10166(), 4F / 16F, 12F / 16F, 12F / 16F);
        if (mod.hasFailed())
        {
            return;
        }

        class_2350 quadDir = quad.method_3358();
        if (quadDir == face)
        {
            mod.export(quadMap.get(face));
        }
        else if (quadDir == face.method_10153())
        {
            mod.apply(Modifiers.setPosition(.5F))
                    .export(quadMap.get(null));
        }
        else if (Utils.isY(face))
        {
            mod.apply(Modifiers.cutSideUpDown(face == class_2350.field_11036, .5F))
                    .export(quadMap.get(null));
        }
        else if (Utils.isY(quadDir))
        {
            mod.apply(Modifiers.cutTopBottom(face.method_10153(), .5F))
                    .export(quadMap.get(null));
        }
        else
        {
            mod.apply(Modifiers.cutSideLeftRight(face.method_10153(), .5F))
                    .export(quadMap.get(null));
        }
    }
}