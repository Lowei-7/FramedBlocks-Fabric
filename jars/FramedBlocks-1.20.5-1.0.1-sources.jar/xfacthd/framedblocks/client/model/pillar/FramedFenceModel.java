package xfacthd.framedblocks.client.model.pillar;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_777;
import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.util.Utils;

import java.util.List;
import java.util.Map;

public class FramedFenceModel extends FramedBlockModel
{
    private final boolean north;
    private final boolean east;
    private final boolean south;
    private final boolean west;

    protected FramedFenceModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        north = state.method_11654(class_2741.field_12489);
        east = state.method_11654(class_2741.field_12487);
        south = state.method_11654(class_2741.field_12540);
        west = state.method_11654(class_2741.field_12527);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();
        if (Utils.isY(quadDir))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(6F/16F, 6F/16F, 10F/16F, 10F/16F))
                    .export(quadMap.get(quadDir));
        }
        else
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(quadDir.method_10170(), 10F/16F))
                    .apply(Modifiers.cutSideLeftRight(quadDir.method_10160(), 10F/16F))
                    .apply(Modifiers.setPosition(10F/16F))
                    .export(quadMap.get(null));
        }

        createFenceBars(quadMap, quad, class_2350.field_11043, north);
        createFenceBars(quadMap, quad, class_2350.field_11034, east);
        createFenceBars(quadMap, quad, class_2350.field_11035, south);
        createFenceBars(quadMap, quad, class_2350.field_11039, west);
    }

    private static void createFenceBars(
            Map<class_2350, List<class_777>> quadMap, class_777 quad, class_2350 dir, boolean active
    )
    {
        if (!active)
        {
            return;
        }

        class_2350 quadDir = quad.method_3358();
        if (Utils.isY(quadDir))
        {
            QuadModifier mod = QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir.method_10153(), 6F/16F))
                    .apply(Modifiers.cutTopBottom(dir.method_10170(), 9F/16F))
                    .apply(Modifiers.cutTopBottom(dir.method_10160(), 9F/16F));

            mod.apply(Modifiers.setPosition(quadDir == class_2350.field_11036 ? 15F/16F : 4F/16F))
                    .export(quadMap.get(null));

            mod.apply(Modifiers.setPosition(quadDir == class_2350.field_11036 ? 9F/16F : 10F/16F))
                    .export(quadMap.get(null));
        }
        else if (quadDir == dir.method_10170() || quadDir == dir.method_10160())
        {
            boolean neg = !Utils.isPositive(dir);

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSide(neg ? 0F : 10F/16F, 6F/16F, neg ? 6F/16F : 1F, 9F/16F))
                    .apply(Modifiers.setPosition(9F/16F))
                    .export(quadMap.get(null));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSide(neg ? 0F : 10F/16F, 12F/16F, neg ? 6F/16F : 1F, 15F/16F))
                    .apply(Modifiers.setPosition(9F/16F))
                    .export(quadMap.get(null));
        }
        else if (quadDir == dir)
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSide(7F/16F, 6F/16F, 9F/16F, 9F/16F))
                    .export(quadMap.get(quadDir));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSide(7F/16F, 12F/16F, 9F/16F, 15F/16F))
                    .export(quadMap.get(quadDir));
        }
    }

    @Override
    public boolean useSolidNoCamoModel()
    {
        return true;
    }



    public static class_1087 createFenceModel(class_2680 state, class_1087 baseModel)
    {
        // Diagonal fence support requires the optional "diagonalfences" mod API
        return new FramedFenceModel(state, baseModel);
    }
}