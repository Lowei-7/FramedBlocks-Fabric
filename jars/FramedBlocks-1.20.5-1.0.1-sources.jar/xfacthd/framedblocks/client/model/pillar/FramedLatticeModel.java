package xfacthd.framedblocks.client.model.pillar;

import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_777;

public class FramedLatticeModel extends FramedBlockModel
{
    private static final float MIN_COORD = 6F/16F;
    private static final float MAX_COORD = 10F/16F;
    private static final float MIN_COORD_THICK = 4F/16F;
    private static final float MAX_COORD_THICK = 12F/16F;

    private final boolean xAxis;
    private final boolean yAxis;
    private final boolean zAxis;
    private final float minCoord;
    private final float maxCoord;

    public FramedLatticeModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        this.xAxis = state.method_11654(FramedProperties.X_AXIS);
        this.yAxis = state.method_11654(FramedProperties.Y_AXIS);
        this.zAxis = state.method_11654(FramedProperties.Z_AXIS);
        boolean thick = state.method_26204() == FBContent.BLOCK_FRAMED_THICK_LATTICE.get();
        this.minCoord = thick ? MIN_COORD_THICK : MIN_COORD;
        this.maxCoord = thick ? MAX_COORD_THICK : MAX_COORD;
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();
        if (Utils.isY(quadDir))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(minCoord, minCoord, maxCoord, maxCoord))
                    .applyIf(Modifiers.setPosition(maxCoord), !yAxis)
                    .export(quadMap.get(yAxis ? quadDir : null));

            if (xAxis)
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(0F, minCoord, minCoord, maxCoord))
                        .apply(Modifiers.setPosition(maxCoord))
                        .export(quadMap.get(null));

                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(maxCoord, minCoord, 1F, maxCoord))
                        .apply(Modifiers.setPosition(maxCoord))
                        .export(quadMap.get(null));
            }

            if (zAxis)
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(minCoord, 0F, maxCoord, minCoord))
                        .apply(Modifiers.setPosition(maxCoord))
                        .export(quadMap.get(null));

                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(minCoord, maxCoord, maxCoord, 1F))
                        .apply(Modifiers.setPosition(maxCoord))
                        .export(quadMap.get(null));
            }
        }
        else if (Utils.isX(quadDir))
        {
            createHorizontalStrutSideQuads(quadMap, quad, xAxis, zAxis);
        }
        else if (Utils.isZ(quadDir))
        {
            createHorizontalStrutSideQuads(quadMap, quad, zAxis, xAxis);
        }

        if (!Utils.isY(quadDir) && yAxis)
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSide(minCoord, 0F, maxCoord, minCoord))
                    .apply(Modifiers.setPosition(maxCoord))
                    .export(quadMap.get(null));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSide(minCoord, maxCoord, maxCoord, 1F))
                    .apply(Modifiers.setPosition(maxCoord))
                    .export(quadMap.get(null));
        }
    }

    private void createHorizontalStrutSideQuads(
            Map<class_2350, List<class_777>> quadMap, class_777 quad, boolean frontAxis, boolean sideAxis
    )
    {
        QuadModifier.geometry(quad)
                .apply(Modifiers.cutSide(minCoord, minCoord, maxCoord, maxCoord))
                .applyIf(Modifiers.setPosition(maxCoord), !frontAxis)
                .export(quadMap.get(frontAxis ? quad.method_3358() : null));

        if (sideAxis)
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSide(0F, minCoord, minCoord, maxCoord))
                    .apply(Modifiers.setPosition(maxCoord))
                    .export(quadMap.get(null));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSide(maxCoord, minCoord, 1F, maxCoord))
                    .apply(Modifiers.setPosition(maxCoord))
                    .export(quadMap.get(null));
        }
    }

    @Override
    public boolean useSolidNoCamoModel()
    {
        return true;
    }
}