package xfacthd.framedblocks.client.model.interactive;

import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.util.Utils;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_777;

public class FramedWallSignModel extends FramedBlockModel
{
    private static final float DEPTH = 2F/16F;
    private final class_2350 dir;

    public FramedWallSignModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        dir = state.method_11654(class_2741.field_12481);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();
        if (quadDir.method_10166() == dir.method_10166())
        {
            boolean inset = quadDir == dir;
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSide(0F, 4.5F/16F, 1F, 12.5F/16F))
                    .applyIf(Modifiers.setPosition(DEPTH), inset)
                    .export(quadMap.get(inset ? null : quadDir));
        }
        else if (Utils.isY(quadDir))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir, DEPTH))
                    .apply(Modifiers.setPosition(quadDir == class_2350.field_11036 ? 12.5F/16F : 11.5F/16F))
                    .export(quadMap.get(null));
        }
        else
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(dir, DEPTH))
                    .apply(Modifiers.cutSideUpDown(false, 12.5F/16F))
                    .apply(Modifiers.cutSideUpDown(true, 11.5F/16F))
                    .export(quadMap.get(quadDir));
        }
    }
}