package xfacthd.framedblocks.client.model.interactive;

import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.interactive.FramedLargeButtonBlock;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2738;
import net.minecraft.class_2741;
import net.minecraft.class_777;

public class FramedLargeButtonModel extends FramedBlockModel
{
    protected final class_2350 dir;
    protected final class_2738 face;
    protected final class_2350 facing;
    protected final boolean pressed;

    public FramedLargeButtonModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        dir = state.method_11654(class_2741.field_12481);
        face = state.method_11654(class_2741.field_12555);
        facing = getFacing(dir, face);
        pressed = state.method_11654(class_2741.field_12484);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();
        if (Utils.isY(facing))
        {
            generateVerticalButton(quadMap, quad, quadDir);
        }
        else
        {
            generateHorizontalButton(quadMap, quad, quadDir);
        }
    }

    private void generateVerticalButton(Map<class_2350, List<class_777>> quadMap, class_777 quad, class_2350 quadDir)
    {
        if (quadDir.method_10166() == facing.method_10166())
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(1F/16F, 1F/16F, 15F/16F, 15F/16F))
                    .applyIf(Modifiers.setPosition(pressed ? 1F/16F : 2F/16F), quadDir == facing)
                    .export(quadMap.get(quadDir == facing ? null : quadDir));
        }
        else
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideUpDown(facing == class_2350.field_11033, pressed ? 1F/16F : 2F/16F))
                    .apply(Modifiers.cutSideLeftRight(15F/16F))
                    .apply(Modifiers.setPosition(15F/16F))
                    .export(quadMap.get(null));
        }
    }

    private void generateHorizontalButton(Map<class_2350, List<class_777>> quadMap, class_777 quad, class_2350 quadDir)
    {
        float height = pressed ? 1F/16F : 2F/16F;
        if (quadDir.method_10166() == facing.method_10166())
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSide(1F/16F, 1F/16F, 15F/16F, 15F/16F))
                    .applyIf(Modifiers.setPosition(height), quadDir == facing)
                    .export(quadMap.get(quadDir == facing ? null : quadDir));
        }
        else if (Utils.isY(quadDir))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir, height))
                    .apply(Modifiers.cutTopBottom(dir.method_10170().method_10166(), 15F/16F))
                    .apply(Modifiers.setPosition(15F/16F))
                    .export(quadMap.get(null));
        }
        else
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(dir, height))
                    .apply(Modifiers.cutSideUpDown(15F/16F))
                    .apply(Modifiers.setPosition(15F/16F))
                    .export(quadMap.get(null));
        }
    }

    @Override
    protected boolean useBaseModel()
    {
        return !state.method_27852(FBContent.BLOCK_FRAMED_LARGE_BUTTON.get());
    }



    private static class_2350 getFacing(class_2350 dir, class_2738 face)
    {
        return switch (face)
        {
            case field_12475 -> class_2350.field_11036;
            case field_12473 -> class_2350.field_11033;
            case field_12471 -> dir;
        };
    }

    public static class_2680 mergeStates(class_2680 state)
    {
        class_2738 face = state.method_11654(FramedLargeButtonBlock.field_11007);
        if (face == class_2738.field_12471)
        {
            return state;
        }

        return state.method_11657(FramedLargeButtonBlock.field_11177, class_2350.field_11043)
                .method_11657(FramedProperties.GLOWING, false);
    }
}