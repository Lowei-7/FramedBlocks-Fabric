package xfacthd.framedblocks.client.model.interactive;

import xfacthd.framedblocks.api.model.data.FramedBlockData;
import xfacthd.framedblocks.api.model.util.ModelUtils;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.client.util.ClientConfig;

import java.util.*;
import net.minecraft.class_1087;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_2440;
import net.minecraft.class_2557;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_5819;
import net.minecraft.class_777;

public class FramedMarkedPressurePlateModel extends FramedPressurePlateModel
{
    public static final class_2960 STONE_FRAME_LOCATION = Utils.rl("block/stone_plate_frame");
    public static final class_2960 STONE_FRAME_DOWN_LOCATION = Utils.rl("block/stone_plate_down_frame");
    public static final class_2960 OBSIDIAN_FRAME_LOCATION = Utils.rl("block/obsidian_plate_frame");
    public static final class_2960 OBSIDIAN_FRAME_DOWN_LOCATION = Utils.rl("block/obsidian_plate_down_frame");
    public static final class_2960 GOLD_FRAME_LOCATION = Utils.rl("block/gold_plate_frame");
    public static final class_2960 GOLD_FRAME_DOWN_LOCATION = Utils.rl("block/gold_plate_down_frame");
    public static final class_2960 IRON_FRAME_LOCATION = Utils.rl("block/iron_plate_frame");
    public static final class_2960 IRON_FRAME_DOWN_LOCATION = Utils.rl("block/iron_plate_down_frame");
    private static final Map<class_2960, class_1087> FRAME_MODELS = new HashMap<>();

    private final class_1087 frameModel;

    private FramedMarkedPressurePlateModel(
            class_2680 state, class_1087 baseModel, class_2960 frameLocation, boolean powered
    )
    {
        super(state, baseModel, powered);
        frameModel = FRAME_MODELS.get(frameLocation);
    }

    @Override
    protected Set<class_1921> getAdditionalRenderTypes(class_5819 rand, Object extraData)
    {
        FramedBlockData fbData = (extraData instanceof FramedBlockData fbd) ? fbd : null;
        if (fbData != null && !fbData.getCamoState().method_26215())
        {
            return ModelUtils.CUTOUT;
        }
        return Set.of();
    }

    @Override
    protected void getAdditionalQuads(
            Map<class_2350, List<class_777>> quadMap,
            class_2680 state,
            class_5819 rand,
            Object data,
            class_1921 layer
    )
    {
        FramedBlockData fbData = (data instanceof FramedBlockData fbd) ? fbd : null;
        if (fbData == null || fbData.getCamoState().method_26215())
        {
            return;
        }

        quadMap.get(null).addAll(frameModel.method_4707(state, null, rand));
        for (class_2350 side : class_2350.values())
        {
            quadMap.get(side).addAll(frameModel.method_4707(state, side, rand));
        }
    }



    public static FramedPressurePlateModel stone(class_2680 state, class_1087 baseModel)
    {
        boolean powered = state.method_11654(class_2440.field_11358);
        if (!ClientConfig.INSTANCE.showButtonPlateOverlay())
        {
            return new FramedPressurePlateModel(state, baseModel, powered);
        }

        class_2960 frame = powered ? STONE_FRAME_DOWN_LOCATION : STONE_FRAME_LOCATION;
        return new FramedMarkedPressurePlateModel(state, baseModel, frame, powered);
    }

    public static FramedPressurePlateModel obsidian(class_2680 state, class_1087 baseModel)
    {
        boolean powered = state.method_11654(class_2440.field_11358);
        if (!ClientConfig.INSTANCE.showButtonPlateOverlay())
        {
            return new FramedPressurePlateModel(state, baseModel, powered);
        }

        class_2960 frame = powered ? OBSIDIAN_FRAME_DOWN_LOCATION : OBSIDIAN_FRAME_LOCATION;
        return new FramedMarkedPressurePlateModel(state, baseModel, frame, powered);
    }

    public static FramedPressurePlateModel gold(class_2680 state, class_1087 baseModel)
    {
        boolean powered = state.method_11654(class_2557.field_11739) > 0;
        if (!ClientConfig.INSTANCE.showButtonPlateOverlay())
        {
            return new FramedPressurePlateModel(state, baseModel, powered);
        }

        class_2960 frame = powered ? GOLD_FRAME_DOWN_LOCATION : GOLD_FRAME_LOCATION;
        return new FramedMarkedPressurePlateModel(state, baseModel, frame, powered);
    }

    public static FramedPressurePlateModel iron(class_2680 state, class_1087 baseModel)
    {
        boolean powered = state.method_11654(class_2557.field_11739) > 0;
        if (!ClientConfig.INSTANCE.showButtonPlateOverlay())
        {
            return new FramedPressurePlateModel(state, baseModel, powered);
        }

        class_2960 frame = powered ? IRON_FRAME_DOWN_LOCATION : IRON_FRAME_LOCATION;
        return new FramedMarkedPressurePlateModel(state, baseModel, frame, powered);
    }

    public static void registerFrameModels(java.util.Collection<class_2960> locations)
    {
        locations.add(FramedMarkedPressurePlateModel.STONE_FRAME_LOCATION);
        locations.add(FramedMarkedPressurePlateModel.STONE_FRAME_DOWN_LOCATION);
        locations.add(FramedMarkedPressurePlateModel.OBSIDIAN_FRAME_LOCATION);
        locations.add(FramedMarkedPressurePlateModel.OBSIDIAN_FRAME_DOWN_LOCATION);
        locations.add(FramedMarkedPressurePlateModel.GOLD_FRAME_LOCATION);
        locations.add(FramedMarkedPressurePlateModel.GOLD_FRAME_DOWN_LOCATION);
        locations.add(FramedMarkedPressurePlateModel.IRON_FRAME_LOCATION);
        locations.add(FramedMarkedPressurePlateModel.IRON_FRAME_DOWN_LOCATION);
    }

    public static void cacheFrameModels(Map<class_2960, class_1087> registry)
    {
        FRAME_MODELS.clear();

        FRAME_MODELS.put(STONE_FRAME_LOCATION, registry.get(STONE_FRAME_LOCATION));
        FRAME_MODELS.put(STONE_FRAME_DOWN_LOCATION, registry.get(STONE_FRAME_DOWN_LOCATION));
        FRAME_MODELS.put(OBSIDIAN_FRAME_LOCATION, registry.get(OBSIDIAN_FRAME_LOCATION));
        FRAME_MODELS.put(OBSIDIAN_FRAME_DOWN_LOCATION, registry.get(OBSIDIAN_FRAME_DOWN_LOCATION));
        FRAME_MODELS.put(GOLD_FRAME_LOCATION, registry.get(GOLD_FRAME_LOCATION));
        FRAME_MODELS.put(GOLD_FRAME_DOWN_LOCATION, registry.get(GOLD_FRAME_DOWN_LOCATION));
        FRAME_MODELS.put(IRON_FRAME_LOCATION, registry.get(IRON_FRAME_LOCATION));
        FRAME_MODELS.put(IRON_FRAME_DOWN_LOCATION, registry.get(IRON_FRAME_DOWN_LOCATION));
    }
}
