package xfacthd.framedblocks.client.model.interactive;

import java.util.Set;
import net.minecraft.class_1087;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.model.util.ModelUtils;
import xfacthd.framedblocks.api.util.Utils;

import java.util.List;
import java.util.Map;

public class FramedCeilingHangingSignModel extends FramedBlockModel
{
    private final class_2350 dir;
    private final float rotDegrees;
    private final boolean attached;

    public FramedCeilingHangingSignModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        int rotation = state.method_11654(class_2741.field_12532);
        this.dir = class_2350.method_10139(rotation / 4);
        this.rotDegrees = (float) (rotation % 4) * -22.5F;
        this.attached = state.method_11654(class_2741.field_12493);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();
        if (quadDir.method_10166() == dir.method_10166())
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideUpDown(false, 10F/16F))
                    .apply(Modifiers.cutSideLeftRight(15F/16F))
                    .apply(Modifiers.setPosition(9F/16F))
                    .applyIf(Modifiers.rotateCentered(class_2350.class_2351.field_11052, rotDegrees, false), attached)
                    .export(quadMap.get(null));
        }
        else if (quadDir.method_10166() == dir.method_10170().method_10166())
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideUpDown(false, 10F/16F))
                    .apply(Modifiers.cutSideLeftRight(9F/16F))
                    .apply(Modifiers.setPosition(15F/16F))
                    .applyIf(Modifiers.rotateCentered(class_2350.class_2351.field_11052, rotDegrees, false), attached)
                    .export(quadMap.get(null));
        }
        else
        {
            boolean up = quadDir == class_2350.field_11036;
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir.method_10166(), 9F/16F))
                    .apply(Modifiers.cutTopBottom(dir.method_10170().method_10166(), 15F/16F))
                    .applyIf(Modifiers.setPosition(10F/16F), up)
                    .applyIf(Modifiers.rotateCentered(class_2350.class_2351.field_11052, rotDegrees, false), attached)
                    .export(quadMap.get(up ? null : quadDir));
        }
    }

    @Override
    protected Set<class_1921> getAdditionalRenderTypes(class_5819 rand, Object extraData)
    {
        return ModelUtils.CUTOUT;
    }

    @Override
    protected void getAdditionalQuads(
            Map<class_2350, List<class_777>> quadMap, class_2680 state, class_5819 rand, Object data, class_1921 renderType
    )
    {
        if (renderType == class_1921.method_23581())
        {
            Utils.forAllDirections(dir ->
            {
                List<class_777> quads = quadMap.get(dir);
                for (class_777 quad : baseModel.method_4707(state, dir, rand))
                {
                    QuadModifier.geometry(quad)
                            .applyIf(Modifiers.rotateCentered(class_2350.class_2351.field_11052, rotDegrees, false), attached)
                            .export(quads);
                }
            });
        }
    }
}
