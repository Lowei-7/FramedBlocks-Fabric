package xfacthd.framedblocks.client.model.interactive;

import java.util.Set;
import net.minecraft.class_1087;
import net.minecraft.class_1921;
import net.minecraft.class_2246;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2738;
import net.minecraft.class_2741;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.api.util.ClientUtils;
import xfacthd.framedblocks.api.model.util.ModelCache;

import java.util.List;
import java.util.Map;

public class FramedLeverModel extends FramedBlockModel
{
    private static final float MIN_SMALL = 5F/16F;
    private static final float MAX_SMALL = 11F/16F;
    private static final float MIN_LARGE = 4F/16F;
    private static final float MAX_LARGE = 12F/16F;
    private static final float HEIGHT = 3F/16F;

    private final class_2350 dir;
    private final class_2738 face;

    public FramedLeverModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        dir = state.method_11654(class_2741.field_12481);
        face = state.method_11654(class_2741.field_12555);
    }

    @Override
    protected Set<class_1921> getAdditionalRenderTypes(class_5819 rand, Object extraData)
    {
        return ModelCache.getRenderTypes(class_2246.field_10363.method_9564(), rand, extraData);
    }

    @Override
    protected void getAdditionalQuads(
            Map<class_2350, List<class_777>> quadMap,
            class_2680 state,
            class_5819 rand,
            Object data,
            class_1921 renderType
    )
    {
        List<class_777> quads = baseModel.method_4707(state, null, rand);
        for (class_777 quad : quads)
        {
            if (!ClientUtils.isDummyTexture(quad))
            {
                quadMap.get(null).add(quad);
            }
        }
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();
        class_2350 facing = getFacing();
        boolean quadInDir = quadDir == facing;

        if (Utils.isY(facing))
        {
            if (quadDir.method_10166() == facing.method_10166())
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(dir.method_10166(), MAX_LARGE))
                        .apply(Modifiers.cutTopBottom(dir.method_10170().method_10166(), MAX_SMALL))
                        .applyIf(Modifiers.setPosition(HEIGHT), quadInDir)
                        .export(quadMap.get(quadInDir ? null : quadDir));
            }
            else
            {
                boolean smallSide = dir.method_10166() == quadDir.method_10166();

                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideUpDown(facing == class_2350.field_11033, HEIGHT))
                        .apply(Modifiers.cutSideLeftRight(smallSide ? MAX_SMALL : MAX_LARGE))
                        .apply(Modifiers.setPosition(smallSide ? MAX_LARGE : MAX_SMALL))
                        .export(quadMap.get(null));
            }
        }
        else
        {
            if (quadDir.method_10166() == facing.method_10166())
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSide(MIN_SMALL, MIN_LARGE, MAX_SMALL, MAX_LARGE))
                        .applyIf(Modifiers.setPosition(HEIGHT), quadInDir)
                        .export(quadMap.get(quadInDir ? null : quadDir));
            }
            else if (Utils.isY(quadDir))
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(dir, HEIGHT))
                        .apply(Modifiers.cutTopBottom(dir.method_10170().method_10166(), MAX_SMALL))
                        .apply(Modifiers.setPosition(MAX_LARGE))
                        .export(quadMap.get(null));
            }
            else
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(dir, HEIGHT))
                        .apply(Modifiers.cutSideUpDown(MAX_LARGE))
                        .apply(Modifiers.setPosition(MAX_SMALL))
                        .export(quadMap.get(null));
            }
        }
    }

    private class_2350 getFacing()
    {
        return switch (face)
        {
            case field_12475 -> class_2350.field_11036;
            case field_12471 -> dir;
            case field_12473 -> class_2350.field_11033;
        };
    }

    @Override
    public boolean useSolidNoCamoModel()
    {
        return true;
    }
}