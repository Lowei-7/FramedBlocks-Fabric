package xfacthd.framedblocks.client.model.interactive;

import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.util.Utils;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_777;

public class FramedSignModel extends FramedBlockModel
{
    private static final float Y_OFF = 1.75F/16F;
    private static final float POS = 9F/16F;
    private final class_2350 dir;
    private final float rotDegrees;

    public FramedSignModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        int rotation = state.method_11654(class_2741.field_12532);
        dir = class_2350.method_10139(rotation / 4);
        rotDegrees = (float)(rotation % 4) * -22.5F;
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();
        if (quadDir.method_10166() == dir.method_10166())
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideUpDown(true, .5F))
                    .apply(Modifiers.setPosition(POS))
                    .apply(Modifiers.offset(class_2350.field_11036, Y_OFF))
                    .apply(Modifiers.rotateCentered(class_2350.class_2351.field_11052, rotDegrees, false))
                    .export(quadMap.get(null));
        }
        else if (Utils.isY(quadDir))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir.method_10166(), 9F/16F))
                    .applyIf(Modifiers.setPosition(.5F), quadDir == class_2350.field_11033)
                    .apply(Modifiers.offset(class_2350.field_11036, Y_OFF))
                    .apply(Modifiers.rotateCentered(class_2350.class_2351.field_11052, rotDegrees, false))
                    .export(quadMap.get(null));
        }
        else
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSide(7F/16F, .5F, 9F/16F, 1F))
                    .apply(Modifiers.offset(class_2350.field_11036, Y_OFF))
                    .apply(Modifiers.rotateCentered(class_2350.class_2351.field_11052, rotDegrees, false))
                    .export(quadMap.get(null));
        }

        if (!Utils.isY(quadDir))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSide(7F/16F, 0F, 9F/16F, 9.75F/16F))
                    .apply(Modifiers.setPosition(POS))
                    .apply(Modifiers.rotateCentered(class_2350.class_2351.field_11052, rotDegrees, false))
                    .export(quadMap.get(null));
        }
        else if (quadDir == class_2350.field_11033)
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(7F/16F, 7F/16F, 9F/16F, 9F/16F))
                    .apply(Modifiers.rotateCentered(class_2350.class_2351.field_11052, rotDegrees, false))
                    .export(quadMap.get(class_2350.field_11033));
        }
    }

    @Override
    public boolean useSolidNoCamoModel()
    {
        return true;
    }
}