package xfacthd.framedblocks.client.model.interactive;

import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_777;

public class FramedPressurePlateModel extends FramedBlockModel
{
    private final boolean pressed;

    public FramedPressurePlateModel(class_2680 state, class_1087 baseModel)
    {
        this(state, baseModel, state.method_11654(class_2741.field_12484));
    }

    protected FramedPressurePlateModel(class_2680 state, class_1087 baseModel, boolean powered)
    {
        super(state, baseModel);
        this.pressed = powered;
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();
        float height = pressed ? .5F / 16F : 1F / 16F;

        if (Utils.isY(quadDir))
        {
            boolean up = quadDir == class_2350.field_11036;
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(1F/16F, 1F/16F, 15F/16F, 15F/16F))
                    .applyIf(Modifiers.setPosition(height), up)
                    .export(quadMap.get(up ? null : class_2350.field_11033));
        }
        else
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSide(1F/16F, 0F, 15F/16F, height))
                    .apply(Modifiers.setPosition(15F/16F))
                    .export(quadMap.get(null));
        }
    }

    @Override
    protected boolean useBaseModel()
    {
        return !state.method_27852(FBContent.BLOCK_FRAMED_PRESSURE_PLATE.get()) && !state.method_27852(FBContent.BLOCK_FRAMED_WATERLOGGABLE_PRESSURE_PLATE.get());
    }
}