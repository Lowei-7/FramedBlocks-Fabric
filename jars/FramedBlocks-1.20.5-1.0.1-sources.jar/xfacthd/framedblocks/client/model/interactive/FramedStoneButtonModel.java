package xfacthd.framedblocks.client.model.interactive;

import java.util.Set;
import net.minecraft.class_1087;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2738;
import net.minecraft.class_2960;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import xfacthd.framedblocks.api.model.data.FramedBlockData;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.api.model.util.ModelUtils;
import xfacthd.framedblocks.client.util.ClientConfig;

import java.util.List;
import java.util.Map;

public class FramedStoneButtonModel extends FramedButtonModel
{
    private static final class_2960 FRAME_LOCATION = Utils.rl("block/framed_stone_button_frame");
    private static final class_2960 FRAME_PRESSED_LOCATION = Utils.rl("block/framed_stone_button_pressed_frame");

    private static class_1087 frameNormalModel;
    private static class_1087 framePressedModel;

    private final class_1087 frameModel;
    private final int rotX;
    private final int rotY;

    private FramedStoneButtonModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        this.frameModel = pressed ? framePressedModel : frameNormalModel;

        this.rotX = switch (face)
        {
            case field_12475 -> 0;
            case field_12471 -> 90;
            case field_12473 -> 180;
        };
        this.rotY = (int)-dir.method_10144();
    }

    @Override
    protected Set<class_1921> getAdditionalRenderTypes(class_5819 rand, Object extraData)
    {
        FramedBlockData fbData = (extraData instanceof FramedBlockData fbd) ? fbd : null;
        if (fbData != null && !fbData.getCamoState().method_26215())
        {
            return ModelUtils.CUTOUT;
        }
        return Set.of();
    }

    @Override
    protected void getAdditionalQuads(
            Map<class_2350, List<class_777>> quadMap,
            class_2680 state,
            class_5819 rand,
            Object data,
            class_1921 layer
    )
    {
        FramedBlockData fbData = (data instanceof FramedBlockData fbd) ? fbd : null;
        if (fbData == null || fbData.getCamoState().method_26215())
        {
            return;
        }

        List<class_777> quads = frameModel.method_4707(state, null, rand);
        addRotatedQuads(quads, quadMap.get(null));

        for (class_2350 side : class_2350.values())
        {
            quads = frameModel.method_4707(state, side, rand);
            addRotatedQuads(quads, quadMap.get(side));
        }
    }

    private void addRotatedQuads(List<class_777> source, List<class_777> dest)
    {
        if (face == class_2738.field_12475 && Utils.isZ(dir))
        {
            dest.addAll(source);
            return;
        }

        for (class_777 quad : source)
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.rotateCentered(class_2350.class_2351.field_11048, rotX, false))
                    .apply(Modifiers.rotateCentered(class_2350.class_2351.field_11052, rotY, false))
                    .export(dest);
        }
    }



    public static FramedButtonModel create(class_2680 state, class_1087 baseModel)
    {
        if (ClientConfig.INSTANCE.showButtonPlateOverlay())
        {
            return new FramedStoneButtonModel(state, baseModel);
        }
        return new FramedButtonModel(state, baseModel);
    }

    public static void registerFrameModels(java.util.Collection<class_2960> locations)
    {
        locations.add(FRAME_LOCATION);
        locations.add(FRAME_PRESSED_LOCATION);
    }

    public static void cacheFrameModels(Map<class_2960, class_1087> registry)
    {
        frameNormalModel = registry.get(FRAME_LOCATION);
        framePressedModel = registry.get(FRAME_PRESSED_LOCATION);
    }
}
