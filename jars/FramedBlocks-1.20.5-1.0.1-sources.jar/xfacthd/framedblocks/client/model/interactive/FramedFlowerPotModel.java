package xfacthd.framedblocks.client.model.interactive;

import com.mojang.datafixers.util.Pair;
import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.model.data.FramedBlockData;
import xfacthd.framedblocks.api.util.ClientUtils;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.api.model.util.ModelCache;
import xfacthd.framedblocks.api.model.util.ModelUtils;
import xfacthd.framedblocks.common.block.interactive.FramedFlowerPotBlock;
import xfacthd.framedblocks.common.blockentity.special.FramedFlowerPotBlockEntity;
import xfacthd.framedblocks.common.util.compat.SupplementariesCompat;
import xfacthd.framedblocks.common.data.PropertyHolder;

import java.util.*;
import java.util.stream.Collectors;
import net.minecraft.class_1087;
import net.minecraft.class_1921;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_5819;
import net.minecraft.class_777;

public class FramedFlowerPotModel extends FramedBlockModel
{
    private static final class_2960 POT_TEXTURE = new class_2960("minecraft:block/flower_pot");
    private static final class_2960 DIRT_TEXTURE = new class_2960("minecraft:block/dirt");

    private final boolean hanging;
    private final class_1087 hangingPotModel;

    public FramedFlowerPotModel(class_2680 state, class_1087 baseModel, Map<class_2960, class_1087> registry)
    {
        super(state, baseModel);
        this.hanging = SupplementariesCompat.isLoaded() && state.method_11654(PropertyHolder.HANGING);
        this.hangingPotModel = hanging ? registry.get(SupplementariesCompat.HANGING_MODEL_LOCATION) : null;
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        if (quad.method_3358() == class_2350.field_11033)
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(5F/16F, 5F/16F, 11F/16F, 11F/16F))
                    .export(quadMap.get(class_2350.field_11033));
        }
        else if (quad.method_3358() == class_2350.field_11036)
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(5F/16F, 5F/16F, 11F/16F, 6F/16F))
                    .apply(Modifiers.setPosition(6F/16F))
                    .export(quadMap.get(null));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(5F/16F, 10F/16F, 11F/16F, 11F/16F))
                    .apply(Modifiers.setPosition(6F/16F))
                    .export(quadMap.get(null));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(5F/16F, 6F/16F, 6F/16F, 10F/16F))
                    .apply(Modifiers.setPosition(6F/16F))
                    .export(quadMap.get(null));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(10F/16F, 6F/16F, 11F/16F, 10F/16F))
                    .apply(Modifiers.setPosition(6F/16F))
                    .export(quadMap.get(null));
        }
        else if (!Utils.isY(quad.method_3358()))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSide(5F/16F, 0, 11F/16F, 6F/16F))
                    .apply(Modifiers.setPosition(11F/16F))
                    .export(quadMap.get(null));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSide(6F/16F, 1F/16F, 10F/16F, 6F/16F))
                    .apply(Modifiers.setPosition(6F/16F))
                    .export(quadMap.get(null));
        }
    }

    @Override
    protected Set<class_1921> getAdditionalRenderTypes(class_5819 rand, Object data)
    {
        class_2248 flower = getFlowerBlock(data);
        return ModelUtils.union(
                ModelCache.getRenderTypes(class_2246.field_10566.method_9564(), rand, null),
                ModelCache.getRenderTypes(flower.method_9564(), rand, null),
                hanging ? ModelUtils.CUTOUT : Set.of()
        );
    }

    @Override
    protected void getAdditionalQuads(
            Map<class_2350, List<class_777>> quadMap,
            class_2680 state,
            class_5819 rand,
            Object data,
            class_1921 layer
    )
    {
        class_2680 potState = FramedFlowerPotBlock.getFlowerPotState(getFlowerBlock(data));
        if (!potState.method_26215())
        {
            addPlantQuads(quadMap, potState, rand, layer);
        }
        addDirtQuads(quadMap, rand, data, layer);

        if (hanging && layer == class_1921.method_23581())
        {
            quadMap.get(null).addAll(hangingPotModel.method_4707(
                    null, null, rand
            ));

            for (class_2350 side : class_2350.values())
            {
                quadMap.get(side).addAll(hangingPotModel.method_4707(
                        null, side, rand
                ));
            }
        }
    }

    @Override
    protected QuadCacheKey makeCacheKey(class_2680 state, Object ctCtx, Object data)
    {
        return new FlowerPotQuadCacheKey(state, ctCtx, getFlowerBlock(data));
    }

    @Override
    public boolean useSolidNoCamoModel()
    {
        return true;
    }

    private static void addPlantQuads(
            Map<class_2350, List<class_777>> quadMap, class_2680 potState, class_5819 rand, class_1921 layer
    )
    {
        class_1087 potModel = ModelCache.getModel(potState);

        if (ModelCache.getRenderTypes(potState, rand, null).contains(layer))
        {
            Arrays.stream(class_2350.values())
                    .map(dir -> Pair.of(dir, getFilteredPlantQuads(potState, potModel, dir, rand, layer)))
                    .forEach(pair -> quadMap.get(pair.getFirst()).addAll(pair.getSecond()));

            quadMap.get(null).addAll(getFilteredPlantQuads(potState, potModel, null, rand, layer));
        }
    }

    private static List<class_777> getFilteredPlantQuads(
            class_2680 potState, class_1087 potModel, class_2350 face, class_5819 rand, class_1921 layer
    )
    {
        return potModel.method_4707(potState, face, rand)
                .stream()
                .filter(q -> !ClientUtils.isTexture(q, POT_TEXTURE))
                .filter(q -> !ClientUtils.isTexture(q, DIRT_TEXTURE))
                .map(ModelUtils::invertTintIndex)
                .collect(Collectors.toList());
    }

    private static void addDirtQuads(
            Map<class_2350, List<class_777>> quadMap, class_5819 rand, Object data, class_1921 layer
    )
    {
        class_1087 dirtModel = ModelCache.getModel(class_2246.field_10566.method_9564());
        if (ModelCache.getRenderTypes(class_2246.field_10566.method_9564(), rand, null).contains(layer))
        {
            dirtModel.method_4707(class_2246.field_10566.method_9564(), class_2350.field_11036, rand).forEach(q ->
                    QuadModifier.geometry(q)
                            .apply(Modifiers.cutTopBottom(6F/16F, 6F/16F, 10F/16F, 10F/16F))
                            .apply(Modifiers.setPosition(4F/16F))
                            .export(quadMap.get(null))
            );

            FramedBlockData fbData = (data instanceof FramedBlockData fbd) ? fbd : null;
            if (fbData != null && !fbData.getCamoState().method_26225())
            {
                dirtModel.method_4707(class_2246.field_10566.method_9564(), class_2350.field_11033, rand).forEach(q ->
                        QuadModifier.geometry(q)
                                .apply(Modifiers.cutTopBottom(6F/16F, 6F/16F, 10F/16F, 10F/16F))
                                .apply(Modifiers.setPosition(15F/16F))
                                .export(quadMap.get(null))
                );

                class_2350.class_2353.field_11062.method_29716()
                        .flatMap(face -> dirtModel.method_4707(class_2246.field_10124.method_9564(), face, rand).stream())
                        .forEach(q -> QuadModifier.geometry(q)
                                .apply(Modifiers.cutSide(6F/16F, 1F/16F, 10F/16F, 4F/16F))
                                .apply(Modifiers.setPosition(10F/16F))
                                .export(quadMap.get(null))
                        );
            }
        }
    }

    private static class_2248 getFlowerBlock(Object data)
    {
        if (data instanceof FramedBlockData fbData)
        {
            // This is a placeholder as flowerBlock is not in FramedBlockData
            return class_2246.field_10124;
        }
        return class_2246.field_10124;
    }

    private record FlowerPotQuadCacheKey(class_2680 state, Object ctCtx, class_2248 flower) implements QuadCacheKey { }
}
