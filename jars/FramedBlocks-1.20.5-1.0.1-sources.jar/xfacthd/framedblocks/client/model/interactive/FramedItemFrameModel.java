package xfacthd.framedblocks.client.model.interactive;

import java.util.Set;
import net.minecraft.class_1087;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.api.util.ClientUtils;
import xfacthd.framedblocks.api.model.util.ModelUtils;
import xfacthd.framedblocks.common.data.PropertyHolder;

import java.util.List;
import java.util.Map;

public class FramedItemFrameModel extends FramedBlockModel
{
    private static final int GLOWING_BRIGHTNESS = 5;

    private final class_2350 facing;
    private final boolean leather;
    private final boolean mapFrame;
    private final boolean glowing;
    private final float innerLength;
    private final float innerPos;
    private final float innerMin;
    private final float innerMax;
    private final float outerMin;
    private final float outerMax;

    private FramedItemFrameModel(class_2680 state, class_1087 baseModel, boolean glowing)
    {
        super(state, baseModel);
        this.facing = state.method_11654(class_2741.field_12525);
        this.leather = state.method_11654(PropertyHolder.LEATHER);
        this.mapFrame = state.method_11654(PropertyHolder.MAP_FRAME);
        this.glowing = glowing;

        this.innerLength = mapFrame ? 15F/16F : 13F/16F;
        this.innerPos = mapFrame ? 1F/16F : 3F/16F;
        this.innerMin = mapFrame ? 1F/16F : 3F/16F;
        this.innerMax = mapFrame ? 15F/16F : 13F/16F;
        this.outerMin = mapFrame ? 0F : 2F/16F;
        this.outerMax = mapFrame ? 1F : 14F/16F;
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadFace = quad.method_3358();
        if (Utils.isY(facing))
        {
            makeVerticalFrame(quadMap, quad, quadFace);
        }
        else
        {
            makeHorizontalFrame(quadMap, quad, quadFace);
        }
    }

    private void makeVerticalFrame(Map<class_2350, List<class_777>> quadMap, class_777 quad, class_2350 quadFace)
    {
        if (quadFace == facing)
        {
            QuadModifier.full(quad)
                    .applyIf(Modifiers.cutTopBottom(outerMin, outerMin, outerMax, outerMax), !mapFrame)
                    .applyIf(Modifiers.applyLightmap(GLOWING_BRIGHTNESS, 0), glowing)
                    .export(quadMap.get(quadFace));
        }
        else if (quadFace == facing.method_10153())
        {
            if (!leather && !mapFrame)
            {
                QuadModifier.full(quad)
                        .apply(Modifiers.cutTopBottom(innerMin, innerMin, innerMax, innerMax))
                        .applyIf(Modifiers.applyLightmap(GLOWING_BRIGHTNESS, 0), glowing)
                        .apply(Modifiers.setPosition(.5F/16F))
                        .export(quadMap.get(null));
            }

            if (!mapFrame || leather)
            {
                QuadModifier.full(quad)
                        .apply(Modifiers.cutTopBottom(outerMin, outerMin, innerMin, outerMax))
                        .applyIf(Modifiers.applyLightmap(GLOWING_BRIGHTNESS, 0), glowing)
                        .apply(Modifiers.setPosition(1F / 16F))
                        .export(quadMap.get(null));

                QuadModifier.full(quad)
                        .apply(Modifiers.cutTopBottom(innerMax, outerMin, outerMax, outerMax))
                        .applyIf(Modifiers.applyLightmap(GLOWING_BRIGHTNESS, 0), glowing)
                        .apply(Modifiers.setPosition(1F / 16F))
                        .export(quadMap.get(null));

                QuadModifier.full(quad)
                        .apply(Modifiers.cutTopBottom(innerMin, outerMin, innerMax, innerMin))
                        .applyIf(Modifiers.applyLightmap(GLOWING_BRIGHTNESS, 0), glowing)
                        .apply(Modifiers.setPosition(1F / 16F))
                        .export(quadMap.get(null));

                QuadModifier.full(quad)
                        .apply(Modifiers.cutTopBottom(innerMin, innerMax, innerMax, outerMax))
                        .applyIf(Modifiers.applyLightmap(GLOWING_BRIGHTNESS, 0), glowing)
                        .apply(Modifiers.setPosition(1F / 16F))
                        .export(quadMap.get(null));
            }

            if (mapFrame && !leather)
            {
                QuadModifier.full(quad)
                        .applyIf(Modifiers.applyLightmap(GLOWING_BRIGHTNESS, 0), glowing)
                        .apply(Modifiers.setPosition(1F/16F))
                        .export(quadMap.get(quadFace));
            }
        }
        else
        {
            boolean down = facing == class_2350.field_11036;

            QuadModifier.full(quad)
                    .apply(Modifiers.cutSideUpDown(down, 1F/16F))
                    .applyIf(Modifiers.cutSideLeftRight(outerMax), !mapFrame)
                    .applyIf(Modifiers.applyLightmap(GLOWING_BRIGHTNESS, 0), glowing)
                    .applyIf(Modifiers.setPosition(outerMax), !mapFrame)
                    .export(quadMap.get(null));

            if (!mapFrame)
            {
                QuadModifier.full(quad)
                        .apply(Modifiers.cutSideUpDown(!down, 15.5F / 16F))
                        .apply(Modifiers.cutSideUpDown(down, 1F / 16F))
                        .apply(Modifiers.cutSideLeftRight(innerLength))
                        .applyIf(Modifiers.applyLightmap(GLOWING_BRIGHTNESS, 0), glowing)
                        .apply(Modifiers.setPosition(innerPos))
                        .export(quadMap.get(null));
            }
        }
    }

    private void makeHorizontalFrame(Map<class_2350, List<class_777>> quadMap, class_777 quad, class_2350 quadFace)
    {
        if (quadFace == facing)
        {
            QuadModifier.full(quad)
                    .applyIf(Modifiers.cutSide(outerMin, outerMin, outerMax, outerMax), !mapFrame)
                    .applyIf(Modifiers.applyLightmap(GLOWING_BRIGHTNESS, 0), glowing)
                    .export(quadMap.get(quadFace));
        }
        else if (quadFace == facing.method_10153())
        {
            if (!leather && !mapFrame)
            {
                QuadModifier.full(quad)
                        .apply(Modifiers.cutSide(innerMin, innerMin, innerMax, innerMax))
                        .applyIf(Modifiers.applyLightmap(GLOWING_BRIGHTNESS, 0), glowing)
                        .apply(Modifiers.setPosition(.5F/16F))
                        .export(quadMap.get(null));
            }

            if (!mapFrame || leather)
            {
                QuadModifier.full(quad)
                        .apply(Modifiers.cutSide(outerMin, outerMin, innerMin, outerMax))
                        .applyIf(Modifiers.applyLightmap(GLOWING_BRIGHTNESS, 0), glowing)
                        .apply(Modifiers.setPosition(1F/16F))
                        .export(quadMap.get(null));

                QuadModifier.full(quad)
                        .apply(Modifiers.cutSide(innerMax, outerMin, outerMax, outerMax))
                        .applyIf(Modifiers.applyLightmap(GLOWING_BRIGHTNESS, 0), glowing)
                        .apply(Modifiers.setPosition(1F/16F))
                        .export(quadMap.get(null));

                QuadModifier.full(quad)
                        .apply(Modifiers.cutSide(innerMin, outerMin, innerMax, innerMin))
                        .applyIf(Modifiers.applyLightmap(GLOWING_BRIGHTNESS, 0), glowing)
                        .apply(Modifiers.setPosition(1F/16F))
                        .export(quadMap.get(null));

                QuadModifier.full(quad)
                        .apply(Modifiers.cutSide(innerMin, innerMax, innerMax, outerMax))
                        .applyIf(Modifiers.applyLightmap(GLOWING_BRIGHTNESS, 0), glowing)
                        .apply(Modifiers.setPosition(1F/16F))
                        .export(quadMap.get(null));
            }

            if (mapFrame && !leather)
            {
                QuadModifier.full(quad)
                        .applyIf(Modifiers.applyLightmap(GLOWING_BRIGHTNESS, 0), glowing)
                        .apply(Modifiers.setPosition(1F/16F))
                        .export(quadMap.get(quadFace));
            }
        }
        else if (Utils.isY(quadFace))
        {
            QuadModifier.full(quad)
                    .apply(Modifiers.cutTopBottom(facing.method_10153(), 1F/16F))
                    .applyIf(Modifiers.cutTopBottom(facing.method_10170().method_10166(), outerMax), !mapFrame)
                    .applyIf(Modifiers.applyLightmap(GLOWING_BRIGHTNESS, 0), glowing)
                    .applyIf(Modifiers.setPosition(outerMax), !mapFrame)
                    .export(quadMap.get(null));

            if (!mapFrame)
            {
                QuadModifier.full(quad)
                        .apply(Modifiers.cutTopBottom(facing, 15.5F/16F))
                        .apply(Modifiers.cutTopBottom(facing.method_10153(), 1F/16F))
                        .apply(Modifiers.cutTopBottom(facing.method_10170().method_10166(), innerLength))
                        .applyIf(Modifiers.applyLightmap(GLOWING_BRIGHTNESS, 0), glowing)
                        .apply(Modifiers.setPosition(innerPos))
                        .export(quadMap.get(null));
            }
        }
        else
        {
            QuadModifier.full(quad)
                    .apply(Modifiers.cutSideLeftRight(facing.method_10153(), 1F/16F))
                    .applyIf(Modifiers.cutSideUpDown(outerMax), !mapFrame)
                    .applyIf(Modifiers.applyLightmap(GLOWING_BRIGHTNESS, 0), glowing)
                    .applyIf(Modifiers.setPosition(outerMax), !mapFrame)
                    .export(quadMap.get(null));

            if (!mapFrame)
            {
                QuadModifier.full(quad)
                        .apply(Modifiers.cutSideLeftRight(facing, 15.5F/16F))
                        .apply(Modifiers.cutSideLeftRight(facing.method_10153(), 1F/16F))
                        .apply(Modifiers.cutSideUpDown(innerLength))
                        .applyIf(Modifiers.applyLightmap(GLOWING_BRIGHTNESS, 0), glowing)
                        .apply(Modifiers.setPosition(innerPos))
                        .export(quadMap.get(null));
            }
        }
    }

    @Override
    protected Set<class_1921> getAdditionalRenderTypes(class_5819 rand, Object extraData)
    {
        if (leather)
        {
            return ModelUtils.SOLID;
        }
        return super.getAdditionalRenderTypes(rand, extraData);
    }

    @Override
    protected void getAdditionalQuads(
            Map<class_2350, List<class_777>> quadMap,
            class_2680 state,
            class_5819 rand,
            Object data,
            class_1921 renderType
    )
    {
        if (leather)
        {
            List<class_777> quads = baseModel.method_4707(state, null, rand);
            for (class_777 quad : quads)
            {
                if (!ClientUtils.isDummyTexture(quad))
                {
                    if (glowing)
                    {
                        QuadModifier.full(quad)
                                .apply(Modifiers.applyLightmap(GLOWING_BRIGHTNESS, 0))
                                .modifyInPlace();
                    }
                    quadMap.get(null).add(quad);
                }
            }
        }
    }

    @Override
    public boolean method_4708()
    {
        return false;
    }

    

    public static FramedItemFrameModel normal(class_2680 state, class_1087 baseModel)
    {
        return new FramedItemFrameModel(state, baseModel, false);
    }

    public static FramedItemFrameModel glowing(class_2680 state, class_1087 baseModel)
    {
        return new FramedItemFrameModel(state, baseModel, true);
    }
}
