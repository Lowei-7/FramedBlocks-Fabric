package xfacthd.framedblocks.client.model.prism;

import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.DirectionAxis;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_777;

public class FramedInnerPrismModel extends FramedBlockModel
{
    private final class_2350 facing;
    private final class_2350.class_2351 axis;
    private final boolean ySlope;

    public FramedInnerPrismModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        DirectionAxis dirAxis = state.method_11654(PropertyHolder.FACING_AXIS);
        this.facing = dirAxis.direction();
        this.axis = dirAxis.axis();
        this.ySlope = state.method_11654(FramedProperties.Y_SLOPE);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        boolean yFacing = Utils.isY(facing);
        boolean yAxis = axis == class_2350.class_2351.field_11052;
        class_2350 quadFace = quad.method_3358();
        boolean quadOnFacingAxis = quadFace.method_10166() == facing.method_10166();
        boolean quadOnAxis = quadFace.method_10166() == axis;

        if (!ySlope && yFacing && !quadOnAxis && !quadOnFacingAxis) // Slopes for Y facing without Y_SLOPE
        {
            boolean up = facing == class_2350.field_11036;
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideUpDown(up, .5F))
                    .apply(Modifiers.makeVerticalSlope(up, 45))
                    .export(quadMap.get(null));
        }
        else if (ySlope && yFacing && quadFace == facing) // Slopes for Y facing with Y_SLOPE
        {
            class_2350 onAxis = class_2350.method_10169(axis, class_2350.class_2352.field_11056);

            class_2350 offAxisCW = onAxis.method_10170();
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(offAxisCW, .5F))
                    .apply(Modifiers.makeVerticalSlope(offAxisCW, 45))
                    .export(quadMap.get(null));

            class_2350 offAxisCCW = onAxis.method_10160();
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(offAxisCCW, .5F))
                    .apply(Modifiers.makeVerticalSlope(offAxisCCW, 45))
                    .export(quadMap.get(null));
        }
        else if (!yFacing && yAxis && !quadOnAxis && quadOnFacingAxis) // Slopes for horizontal facing and Y axis without Y_SLOPE
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(facing.method_10170(), .5F))
                    .apply(Modifiers.makeHorizontalSlope(true, 45))
                    .export(quadMap.get(null));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(facing.method_10160(), .5F))
                    .apply(Modifiers.makeHorizontalSlope(false, 45))
                    .export(quadMap.get(null));
        }
        else if (!ySlope && !yFacing && !yAxis && quadFace == facing)
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideUpDown(false, .5F))
                    .apply(Modifiers.makeVerticalSlope(true, 45))
                    .export(quadMap.get(null));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideUpDown(true, .5F))
                    .apply(Modifiers.makeVerticalSlope(false, 45))
                    .export(quadMap.get(null));
        }
        else if (ySlope && !yFacing && !yAxis && Utils.isY(quadFace)) // Slopes for horizontal facing and Y axis with Y_SLOPE
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(facing.method_10153(), .5F))
                    .apply(Modifiers.makeVerticalSlope(facing, 45))
                    .export(quadMap.get(null));
        }
        else if (quadOnAxis)
        {
            if (yAxis)
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(facing.method_10170(), .5F))
                        .apply(Modifiers.cutTopBottom(facing, 0F, 1F))
                        .export(quadMap.get(quadFace));

                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(facing.method_10160(), .5F))
                        .apply(Modifiers.cutTopBottom(facing, 1F, 0F))
                        .export(quadMap.get(quadFace));
            }
            else if (yFacing)
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(quadFace.method_10170(), .5F))
                        .apply(Modifiers.cutSideUpDown(facing == class_2350.field_11033, 0F, 1F))
                        .export(quadMap.get(quadFace));

                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(quadFace.method_10160(), .5F))
                        .apply(Modifiers.cutSideUpDown(facing == class_2350.field_11033, 1F, 0F))
                        .export(quadMap.get(quadFace));
            }
            else //!yAxis && !yFacing
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideUpDown(true, .5F))
                        .apply(Modifiers.cutSideLeftRight(facing, 1F, 0F))
                        .export(quadMap.get(quadFace));

                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideUpDown(false, .5F))
                        .apply(Modifiers.cutSideLeftRight(facing, 0F, 1F))
                        .export(quadMap.get(quadFace));
            }
        }
    }

    @Override
    protected boolean transformAllQuads(class_2680 state)
    {
        if (state.method_11654(FramedProperties.Y_SLOPE))
        {
            return true;
        }
        DirectionAxis dirAxis = state.method_11654(PropertyHolder.FACING_AXIS);
        return Utils.isY(dirAxis.direction()) || dirAxis.axis() == class_2350.class_2351.field_11052;
    }



    public static class_2680 itemSource()
    {
        return FBContent.BLOCK_FRAMED_INNER_PRISM.get()
                .method_9564()
                .method_11657(PropertyHolder.FACING_AXIS, DirectionAxis.UP_X);
    }
}
