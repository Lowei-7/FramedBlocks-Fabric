package xfacthd.framedblocks.client.model.prism;

import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.CompoundDirection;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_777;

public class FramedInnerSlopedPrismModel extends FramedBlockModel
{
    private final class_2350 facing;
    private final class_2350 orientation;
    private final boolean ySlope;

    public FramedInnerSlopedPrismModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        CompoundDirection cmpDir = state.method_11654(PropertyHolder.FACING_DIR);
        this.facing = cmpDir.direction();
        this.orientation = cmpDir.orientation();
        this.ySlope = state.method_11654(FramedProperties.Y_SLOPE);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        boolean yFacing = Utils.isY(facing);
        boolean yOrient = Utils.isY(orientation);
        class_2350 quadFace = quad.method_3358();

        if (quadFace == facing)
        {
            if (ySlope && yFacing)
            {
                boolean up = orientation == class_2350.field_11036;

                // Tilted triangle for vertical facing with Y_SLOPE
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSmallTriangle(orientation))
                        .apply(Modifiers.makeVerticalSlope(orientation, up ? -45 : 45))
                        .export(quadMap.get(null));

                // Side slope for vertical facing with Y_SLOPE
                class_2350 oriCW = orientation.method_10170();
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(oriCW, .5F))
                        .apply(Modifiers.cutTopBottom(orientation.method_10153(), 1, 0))
                        .apply(Modifiers.makeVerticalSlope(oriCW, up ? -45 : 45))
                        .export(quadMap.get(null));

                // Side slope for vertical facing with Y_SLOPE
                class_2350 oriCCW = orientation.method_10160();
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(oriCCW, .5F))
                        .apply(Modifiers.cutTopBottom(orientation.method_10153(), 0, 1))
                        .apply(Modifiers.makeVerticalSlope(oriCCW, up ? -45 : 45))
                        .export(quadMap.get(null));
            }
            else if (!ySlope && !yFacing && yOrient)
            {
                // Tilted triangle for horizontal facing and vertical orientation without Y_SLOPE
                boolean up = orientation == class_2350.field_11036;
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSmallTriangle(orientation))
                        .apply(Modifiers.makeVerticalSlope(up, 45))
                        .export(quadMap.get(null));
            }

            if (!yFacing && !yOrient)
            {
                // Tilted triangle for horizontal facing and horizontal orientation
                boolean right = orientation == facing.method_10170();
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(orientation, .5F))
                        .apply(Modifiers.cutSmallTriangle(orientation))
                        .apply(Modifiers.makeHorizontalSlope(right, 45))
                        .export(quadMap.get(null));

                if (!ySlope)
                {
                    // Side slope for horizontal facing and horizontal orientation without Y_SLOPE
                    QuadModifier.geometry(quad)
                            .apply(Modifiers.cutSideUpDown(true, .5F))
                            .apply(Modifiers.cutSideLeftRight(orientation.method_10153(), 1, 0))
                            .apply(Modifiers.makeVerticalSlope(false, 45))
                            .export(quadMap.get(null));

                    // Side slope for horizontal facing and horizontal orientation without Y_SLOPE
                    QuadModifier.geometry(quad)
                            .apply(Modifiers.cutSideUpDown(false, .5F))
                            .apply(Modifiers.cutSideLeftRight(orientation.method_10153(), 0, 1))
                            .apply(Modifiers.makeVerticalSlope(true, 45))
                            .export(quadMap.get(null));
                }
            }
            else if (!yFacing/* && yOrient*/)
            {
                boolean up = orientation == class_2350.field_11036;

                // Side slope for horizontal facing and vertical orientation
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(true, .5F))
                        .apply(Modifiers.cutSideUpDown(up, 0, 1))
                        .apply(Modifiers.makeHorizontalSlope(true, 45))
                        .export(quadMap.get(null));

                // Side slope for horizontal facing and vertical orientation
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(false, .5F))
                        .apply(Modifiers.cutSideUpDown(up, 1, 0))
                        .apply(Modifiers.makeHorizontalSlope(false, 45))
                        .export(quadMap.get(null));
            }
        }
        else if (quadFace == orientation)
        {
            if (yOrient)
            {
                // Front face for horizontal facing and vertical orientation
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(facing.method_10170(), .5F))
                        .apply(Modifiers.cutTopBottom(facing, 0F, 1F))
                        .export(quadMap.get(quadFace));

                // Front face for horizontal facing and vertical orientation
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(facing.method_10160(), .5F))
                        .apply(Modifiers.cutTopBottom(facing, 1F, 0F))
                        .export(quadMap.get(quadFace));

                if (ySlope)
                {
                    // Tilted triangle for horizontal facing and vertical orientation with Y_SLOPE
                    QuadModifier.geometry(quad)
                            .apply(Modifiers.cutSmallTriangle(facing.method_10153()))
                            .apply(Modifiers.makeVerticalSlope(facing, 45))
                            .export(quadMap.get(null));
                }
            }
            else if (yFacing)
            {
                // Front face for vertical facing
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(quadFace.method_10170(), .5F))
                        .apply(Modifiers.cutSideUpDown(facing == class_2350.field_11033, 0F, 1F))
                        .export(quadMap.get(quadFace));

                // Front face for vertical facing
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(quadFace.method_10160(), .5F))
                        .apply(Modifiers.cutSideUpDown(facing == class_2350.field_11033, 1F, 0F))
                        .export(quadMap.get(quadFace));

                if (!ySlope)
                {
                    // Tilted triangle for vertical facing without Y_SLOPE
                    boolean up = facing == class_2350.field_11036;
                    QuadModifier.geometry(quad)
                            .apply(Modifiers.cutSmallTriangle(facing.method_10153()))
                            .apply(Modifiers.makeVerticalSlope(up, 45))
                            .export(quadMap.get(null));
                }
            }
            else //!yOrient && !yFacing
            {
                // Front face for horizontal facing and horizontal orientation
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideUpDown(true, .5F))
                        .apply(Modifiers.cutSideLeftRight(facing, 1F, 0F))
                        .export(quadMap.get(quadFace));

                // Front face for horizontal facing and horizontal orientation
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideUpDown(false, .5F))
                        .apply(Modifiers.cutSideLeftRight(facing, 0F, 1F))
                        .export(quadMap.get(quadFace));
            }
        }
        else if (quadFace.method_10166() != orientation.method_10166() && quadFace.method_10166() != facing.method_10166())
        {
            if (ySlope && !yFacing && !yOrient)
            {
                // Side slope for horizontal facing and horizontal orientation with Y_SLOPE
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(facing.method_10153(), .5F))
                        .apply(Modifiers.cutTopBottom(orientation.method_10153(), 1, 0))
                        .apply(Modifiers.makeVerticalSlope(facing, 45))
                        .export(quadMap.get(null));

                // Side slope for horizontal facing and horizontal orientation with Y_SLOPE
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(facing.method_10153(), .5F))
                        .apply(Modifiers.cutTopBottom(orientation.method_10153(), 0, 1))
                        .apply(Modifiers.makeVerticalSlope(facing, 45))
                        .export(quadMap.get(null));
            }
            else if (!ySlope && yFacing)
            {
                // Side slope for vertical facing without Y_SLOPE
                boolean up = facing == class_2350.field_11036;
                float top = up ? 1 : 0;
                float bottom = up ? 0 : 1;
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideUpDown(up, .5F))
                        .apply(Modifiers.cutSideLeftRight(orientation.method_10153(), top, bottom))
                        .apply(Modifiers.makeVerticalSlope(up, 45))
                        .export(quadMap.get(null));
            }
        }
    }

    @Override
    protected boolean transformAllQuads(class_2680 state)
    {
        if (state.method_11654(FramedProperties.Y_SLOPE))
        {
            return true;
        }
        CompoundDirection cmpDir = state.method_11654(PropertyHolder.FACING_DIR);
        return Utils.isY(cmpDir.direction()) || Utils.isY(cmpDir.orientation());
    }



    public static class_2680 itemSource()
    {
        return FBContent.BLOCK_FRAMED_INNER_SLOPED_PRISM.get()
                .method_9564()
                .method_11657(PropertyHolder.FACING_DIR, CompoundDirection.UP_EAST);
    }
}
