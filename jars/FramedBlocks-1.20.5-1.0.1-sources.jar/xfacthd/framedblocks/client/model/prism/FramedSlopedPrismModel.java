package xfacthd.framedblocks.client.model.prism;

import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.CompoundDirection;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_777;
import net.minecraft.class_811;

public class FramedSlopedPrismModel extends FramedBlockModel
{
    private final class_2350 facing;
    private final class_2350 orientation;
    private final boolean ySlope;

    public FramedSlopedPrismModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        CompoundDirection cmpDir = state.method_11654(PropertyHolder.FACING_DIR);
        this.facing = cmpDir.direction();
        this.orientation = cmpDir.orientation();
        this.ySlope = state.method_11654(FramedProperties.Y_SLOPE);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        boolean yFacing = Utils.isY(facing);
        boolean yOrient = Utils.isY(orientation);
        class_2350 orientOpp = orientation.method_10153();
        class_2350 quadFace = quad.method_3358();

        if (quadFace == orientOpp && !yOrient)
        {
            if (!yFacing) // Triangle for horizontal facing and horizontal orientation
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSmallTriangle(facing))
                        .apply(Modifiers.makeHorizontalSlope(orientation == facing.method_10170(), 45))
                        .export(quadMap.get(null));
            }
            else if (!ySlope)  // Triangle for horizontal facing and vertical orientation without Y_SLOPE
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSmallTriangle(facing))
                        .apply(Modifiers.makeVerticalSlope(facing == class_2350.field_11036, 45))
                        .export(quadMap.get(null));
            }
        }
        else if (ySlope && yFacing && Utils.isY(quadFace)) // Triangle and slopes for vertical facing with Y_SLOPE
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSmallTriangle(orientation))
                    .apply(Modifiers.makeVerticalSlope(orientOpp, 45))
                    .export(quadMap.get(null));

            class_2350 offAxisCW = orientation.method_10170();
            class_2350 offAxisCCW = orientation.method_10160();

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(offAxisCW, .5F))
                    .apply(Modifiers.cutTopBottom(orientOpp, 1, 0))
                    .apply(Modifiers.makeVerticalSlope(offAxisCCW, 45))
                    .export(quadMap.get(null));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(offAxisCCW, .5F))
                    .apply(Modifiers.cutTopBottom(orientOpp, 0, 1))
                    .apply(Modifiers.makeVerticalSlope(offAxisCW, 45))
                    .export(quadMap.get(null));
        }
        else if (!ySlope && yOrient && quadFace == facing) // Tilted triangle for horizontal facing and vertical orientation without Y_SLOPE
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSmallTriangle(orientation))
                    .apply(Modifiers.makeVerticalSlope(orientation == class_2350.field_11033, 45))
                    .export(quadMap.get(null));
        }
        else if (ySlope && yOrient && quadFace == orientOpp) // Tilted triangle for horizontal facing and vertical orientation with Y_SLOPE
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSmallTriangle(facing))
                    .apply(Modifiers.makeVerticalSlope(facing, 45))
                    .export(quadMap.get(null));
        }
        else if (quadFace == orientation) // Triangle
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSmallTriangle(facing))
                    .export(quadMap.get(quadFace));
        }
        else if (!ySlope && yFacing && quadFace.method_10166() == orientation.method_10170().method_10166()) // Slopes for Y facing without Y_SLOPE
        {
            boolean up = facing == class_2350.field_11036;
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideUpDown(facing == class_2350.field_11033, .5F))
                    .apply(Modifiers.cutSideLeftRight(orientation.method_10153(), up ? 0 : 1, up ? 1 : 0))
                    .apply(Modifiers.makeVerticalSlope(up, 45))
                    .export(quadMap.get(null));
        }
        else if (yOrient && quadFace.method_10166() == facing.method_10170().method_10166()) // Slopes for horizontal facing and vertical orientation
        {
            boolean right = quadFace == facing.method_10170();
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(facing, .5F))
                    .apply(Modifiers.cutSideUpDown(orientation == class_2350.field_11036, right ? 1 : 0, right ? 0 : 1))
                    .apply(Modifiers.makeHorizontalSlope(quadFace == facing.method_10160(), 45))
                    .export(quadMap.get(null));
        }
        else if (!ySlope && !yOrient && !yFacing && quadFace == facing) // Slopes for horizontal facing and horizontal orientation without Y_SLOPE
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideUpDown(false, .5F))
                    .apply(Modifiers.cutSideLeftRight(orientation.method_10153(), 0, 1))
                    .apply(Modifiers.makeVerticalSlope(false, 45))
                    .export(quadMap.get(null));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideUpDown(true, .5F))
                    .apply(Modifiers.cutSideLeftRight(orientation.method_10153(), 1, 0))
                    .apply(Modifiers.makeVerticalSlope(true, 45))
                    .export(quadMap.get(null));
        }
        else if (ySlope && !yOrient && !yFacing && Utils.isY(quadFace)) // Slopes for horizontal facing and horizontal orientation with Y_SLOPE
        {
            boolean right = orientation == facing.method_10170();
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(facing, .5F))
                    .apply(Modifiers.cutTopBottom(orientOpp, right ? 0 : 1, right ? 1 : 0))
                    .apply(Modifiers.makeVerticalSlope(facing, 45))
                    .export(quadMap.get(null));
        }
    }

    @Override
    protected void applyInHandTransformation(class_4587 poseStack, class_811 ctx)
    {
        poseStack.method_22904(0, .5, 0);
    }



    public static class_2680 itemSource()
    {
        return FBContent.BLOCK_FRAMED_SLOPED_PRISM.get()
                .method_9564()
                .method_11657(PropertyHolder.FACING_DIR, CompoundDirection.UP_WEST);
    }
}
