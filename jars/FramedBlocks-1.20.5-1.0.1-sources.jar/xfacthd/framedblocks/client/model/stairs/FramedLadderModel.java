package xfacthd.framedblocks.client.model.stairs;

import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_777;

public class FramedLadderModel extends FramedBlockModel
{
    private static final float RUNG_DEPTH = 1F/16F;
    private static final float LEG_DEPTH = RUNG_DEPTH * 2F;
    private static final float RUNG_OFFSET = .5F/16F;
    private static final float[] RUNGS = new float[] {
            1.5F/16F,
            5.5F/16F,
            9.5F/16F,
            13.5F/16F
    };

    private final class_2350 dir;

    public FramedLadderModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        dir = state.method_11654(FramedProperties.FACING_HOR);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();
        if (Utils.isY(quadDir))
        {
            QuadModifier capMod = QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir.method_10153(), LEG_DEPTH));

            capMod.derive().apply(Modifiers.cutTopBottom(dir.method_10170(), LEG_DEPTH))
                    .export(quadMap.get(quadDir));

            capMod.apply(Modifiers.cutTopBottom(dir.method_10160(), LEG_DEPTH))
                    .export(quadMap.get(quadDir));

            QuadModifier rungMod = QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir, 1F - RUNG_OFFSET))
                    .apply(Modifiers.cutTopBottom(dir.method_10153(), RUNG_DEPTH + RUNG_OFFSET))
                    .apply(Modifiers.cutTopBottom(dir.method_10170(), 1F - LEG_DEPTH))
                    .apply(Modifiers.cutTopBottom(dir.method_10160(), 1F - LEG_DEPTH));

            for (int i = 0; i < 4; i++)
            {
                // Don't need to derive since the quad is only moved
                float height = quad.method_3358() == class_2350.field_11033 ? 1F - RUNGS[i] : RUNGS[i] + RUNG_DEPTH;
                rungMod.apply(Modifiers.setPosition(height))
                        .export(quadMap.get(null));
            }
        }
        else if (quadDir.method_10166() == dir.method_10166())
        {
            boolean opposite = quadDir == dir.method_10153();

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(dir.method_10170(), LEG_DEPTH))
                    .applyIf(Modifiers.setPosition(LEG_DEPTH), opposite)
                    .export(quadMap.get(opposite ? null : quadDir));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(dir.method_10160(), LEG_DEPTH))
                    .applyIf(Modifiers.setPosition(LEG_DEPTH), opposite)
                    .export(quadMap.get(opposite ? null : quadDir));

            float pos = quad.method_3358() == dir ? (1F - RUNG_OFFSET) : (RUNG_DEPTH + RUNG_OFFSET);

            for (int i = 0; i < 4; i++)
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSide(LEG_DEPTH, RUNGS[i], 1F - LEG_DEPTH, RUNGS[i] + RUNG_DEPTH))
                        .apply(Modifiers.setPosition(pos))
                        .export(quadMap.get(null));
            }
        }
        else
        {
            QuadModifier mod = QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(dir.method_10153(), RUNG_DEPTH * 2F));

            mod.export(quadMap.get(quadDir));

            mod.apply(Modifiers.setPosition(RUNG_DEPTH * 2F))
                    .export(quadMap.get(null));
        }
    }

    @Override
    public boolean useSolidNoCamoModel()
    {
        return true;
    }



    public static class_2680 itemSource()
    {
        return FBContent.BLOCK_FRAMED_LADDER.get()
                .method_9564()
                .method_11657(FramedProperties.FACING_HOR, class_2350.field_11035);
    }
}