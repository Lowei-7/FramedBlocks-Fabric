package xfacthd.framedblocks.client.model.stairs;

import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.StairsType;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_777;

public class FramedVerticalStairsModel extends FramedBlockModel
{
    private final StairsType type;
    private final class_2350 dir;

    public FramedVerticalStairsModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        type = state.method_11654(PropertyHolder.STAIRS_TYPE);
        dir = state.method_11654(FramedProperties.FACING_HOR);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();
        if (type == StairsType.VERTICAL && (quadDir == dir.method_10153() || quadDir == dir.method_10170()))
        {
            class_2350 cutDir = quadDir == dir.method_10153() ? dir.method_10170() : dir.method_10153();

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(cutDir, .5F))
                    .export(quadMap.get(quadDir));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(cutDir.method_10153(), .5F))
                    .apply(Modifiers.setPosition(.5F))
                    .export(quadMap.get(null));
        }

        if ((quadDir == class_2350.field_11036 && !type.isTop()) || (quadDir == class_2350.field_11033 && !type.isBottom()))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir.method_10153(), .5F))
                    .export(quadMap.get(quadDir));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir, .5F))
                    .apply(Modifiers.cutTopBottom(dir.method_10170(), .5F))
                    .export(quadMap.get(quadDir));
        }

        if ((quadDir == dir.method_10153() || quadDir == dir.method_10170()) && type != StairsType.VERTICAL)
        {
            boolean opposite = quadDir == dir.method_10153();
            class_2350 cutDir = opposite ? dir.method_10170() : dir.method_10153();

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(cutDir, .5F))
                    .apply(Modifiers.cutSideUpDown(!type.isTop(), .5F))
                    .export(quadMap.get(quadDir));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(cutDir, .5F))
                    .apply(Modifiers.cutSideUpDown(type.isTop(), .5F))
                    .apply(Modifiers.setPosition(.5F))
                    .export(quadMap.get(null));

            cutDir = opposite ? dir.method_10160() : dir;
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(cutDir, .5F))
                    .apply(Modifiers.cutSideUpDown(!type.isTop(), .5F))
                    .apply(Modifiers.setPosition(.5F))
                    .export(quadMap.get(null));
        }

        if ((quadDir == class_2350.field_11036 && type.isTop()) || (quadDir == class_2350.field_11033 && type.isBottom()))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir.method_10153(), .5F))
                    .apply(Modifiers.cutTopBottom(dir.method_10170(), .5F))
                    .export(quadMap.get(quadDir));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir.method_10153(), .5F))
                    .apply(Modifiers.cutTopBottom(dir.method_10160(), .5F))
                    .apply(Modifiers.setPosition(.5F))
                    .export(quadMap.get(null));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir, .5F))
                    .apply(Modifiers.cutTopBottom(dir.method_10170(), .5F))
                    .apply(Modifiers.setPosition(.5F))
                    .export(quadMap.get(null));
        }

        if ((quadDir == dir || quadDir == dir.method_10160()) && type != StairsType.VERTICAL)
        {
            boolean ccw = quadDir == dir.method_10160();

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideUpDown(!type.isTop(), .5F))
                    .export(quadMap.get(quadDir));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideUpDown(type.isTop(), .5F))
                    .apply(Modifiers.cutSideLeftRight(ccw ? dir.method_10153() : dir.method_10170(), .5F))
                    .export(quadMap.get(quadDir));
        }
    }
}