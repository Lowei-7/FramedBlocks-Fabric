package xfacthd.framedblocks.client.model.stairs;

import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2760;
import net.minecraft.class_2778;
import net.minecraft.class_777;
import net.minecraft.world.level.block.state.properties.*;
import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.util.Utils;

import java.util.List;
import java.util.Map;

public class FramedStairsModel extends FramedBlockModel
{
    private final class_2350 dir;
    private final boolean top;
    private final class_2778 shape;

    public FramedStairsModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        dir = state.method_11654(class_2741.field_12481);
        top = state.method_11654(class_2741.field_12518) == class_2760.field_12619;
        shape = state.method_11654(class_2741.field_12503);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();
        if ((top && quadDir == class_2350.field_11033) || (!top && quadDir == class_2350.field_11036))
        {
            createCenterQuads(quadMap.get(null), quad);
            createTopBottomQuads(quadMap.get(quadDir), quad);
        }
        else if (!Utils.isY(quad.method_3358()))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideUpDown(top, .5F))
                    .export(quadMap.get(quadDir));

            createSideQuads(quadMap, quad, quadDir);
        }
    }

    private void createCenterQuads(List<class_777> quadList, class_777 quad)
    {
        if (shape == class_2778.field_12710 || shape == class_2778.field_12708 || shape == class_2778.field_12709)
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir, .5F))
                    .apply(Modifiers.setPosition(.5F))
                    .export(quadList);
        }

        if (shape != class_2778.field_12710)
        {
            boolean opposite = shape == class_2778.field_12708 || shape == class_2778.field_12709;
            boolean left = shape == class_2778.field_12708 || shape == class_2778.field_12712;

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(opposite ? dir.method_10153() : dir, .5F))
                    .apply(Modifiers.cutTopBottom(left ? dir.method_10160() : dir.method_10170(), .5F))
                    .apply(Modifiers.setPosition(.5F))
                    .export(quadList);
        }
    }

    private void createTopBottomQuads(List<class_777> quadList, class_777 quad)
    {
        if (shape == class_2778.field_12710 || shape == class_2778.field_12712 || shape == class_2778.field_12713)
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir.method_10153(), .5F))
                    .export(quadList);
        }

        if (shape != class_2778.field_12710)
        {
            boolean outer = shape == class_2778.field_12708 || shape == class_2778.field_12709;
            boolean left = shape == class_2778.field_12708 || shape == class_2778.field_12712;

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(outer ? dir.method_10153() : dir, .5F))
                    .apply(Modifiers.cutTopBottom(left ? dir.method_10170() : dir.method_10160(), .5F))
                    .export(quadList);
        }
    }

    private void createSideQuads(Map<class_2350, List<class_777>> quadMap, class_777 quad, class_2350 quadDir)
    {
        boolean inner = shape == class_2778.field_12712 || shape == class_2778.field_12713;
        boolean left = shape == class_2778.field_12708 || shape == class_2778.field_12712;

        if (quadDir == dir.method_10153())
        {
            class_2350 cutDir = left != inner ? dir.method_10170() : dir.method_10160();
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideUpDown(!top, .5F))
                    .applyIf(Modifiers.cutSideLeftRight(cutDir, .5F), shape != class_2778.field_12710)
                    .apply(Modifiers.setPosition(.5F))
                    .export(quadMap.get(null));

            if (inner)
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideUpDown(!top, .5F))
                        .apply(Modifiers.cutSideLeftRight(left ? dir.method_10170() : dir.method_10160(), .5F))
                        .export(quadMap.get(quadDir));
            }
        }
        else if (quadDir == dir && !inner)
        {
            class_2350 cutDir = left ? dir.method_10170() : dir.method_10160();
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideUpDown(!top, .5F))
                    .apply(Modifiers.cutSideLeftRight(cutDir, .5F))
                    .export(quadMap.get(quadDir));
        }
        else if (quadDir.method_10166() != dir.method_10166())
        {
            boolean outerLeft = shape == class_2778.field_12708 && quadDir == dir.method_10170();
            boolean outerRight = shape == class_2778.field_12709 && quadDir == dir.method_10160();
            boolean innerLeft = shape == class_2778.field_12712 && quadDir == dir.method_10170();
            boolean innerRight = shape == class_2778.field_12713 && quadDir == dir.method_10160();

            if (shape == class_2778.field_12710 || !inner || innerLeft || innerRight)
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideUpDown(!top, .5F))
                        .apply(Modifiers.cutSideLeftRight(dir.method_10153(), .5F))
                        .applyIf(Modifiers.setPosition(.5F), outerLeft || outerRight)
                        .export(quadMap.get(outerLeft || outerRight ? null : quadDir));
            }

            if (innerLeft || innerRight)
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideUpDown(!top, .5F))
                        .apply(Modifiers.cutSideLeftRight(dir, .5F))
                        .apply(Modifiers.setPosition(.5F))
                        .export(quadMap.get(null));
            }
        }
    }
}