package xfacthd.framedblocks.client.model.stairs;

import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_777;

public class FramedVerticalHalfStairsModel extends FramedBlockModel
{
    private final class_2350 dir;
    private final boolean top;

    public FramedVerticalHalfStairsModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        this.dir = state.method_11654(FramedProperties.FACING_HOR);
        this.top = state.method_11654(FramedProperties.TOP);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();
        if (quadDir == dir.method_10153() || quadDir == dir.method_10170())
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(quadDir == dir.method_10153() ? dir.method_10170() : dir.method_10153(), .5F))
                    .apply(Modifiers.cutSideUpDown(top, .5F))
                    .export(quadMap.get(quadDir));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(quadDir == dir.method_10153() ? dir.method_10160() : dir, .5F))
                    .apply(Modifiers.cutSideUpDown(top, .5F))
                    .apply(Modifiers.setPosition(.5F))
                    .export(quadMap.get(null));
        }
        else if (quadDir == dir || quadDir == dir.method_10160())
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideUpDown(top, .5F))
                    .export(quadMap.get(quadDir));
        }
        else if (Utils.isY(quadDir))
        {
            boolean inset = (quadDir == class_2350.field_11036) != top;

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir.method_10153(), .5F))
                    .applyIf(Modifiers.setPosition(.5F), inset)
                    .export(quadMap.get(inset ? null : quadDir));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(dir, .5F))
                    .apply(Modifiers.cutTopBottom(dir.method_10170(), .5F))
                    .applyIf(Modifiers.setPosition(.5F), inset)
                    .export(quadMap.get(inset ? null : quadDir));
        }
    }
}
