package xfacthd.framedblocks.client.model.stairs;

import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.data.PropertyHolder;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_777;

public class FramedHalfStairsModel extends FramedBlockModel
{
    private final class_2350 dir;
    private final boolean top;
    private final boolean right;

    public FramedHalfStairsModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        dir = state.method_11654(FramedProperties.FACING_HOR);
        top = state.method_11654(FramedProperties.TOP);
        right = state.method_11654(PropertyHolder.RIGHT);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 face = quad.method_3358();
        class_2350 vertCut = right ? dir.method_10160() : dir.method_10170();

        if (face == dir)
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(vertCut, .5F))
                    .export(quadMap.get(face));
        }
        else if (face == dir.method_10153())
        {
            QuadModifier mod = QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(vertCut, .5F));

            mod.derive().apply(Modifiers.cutSideUpDown(!top, .5F))
                    .apply(Modifiers.setPosition(.5F))
                    .export(quadMap.get(null));

            mod.apply(Modifiers.cutSideUpDown(top, .5F))
                    .export(quadMap.get(face));
        }
        else if (!Utils.isY(face) && face.method_10166() != dir.method_10166())
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(dir.method_10153(), .5F))
                    .applyIf(Modifiers.setPosition(.5F), face == vertCut)
                    .export(quadMap.get(face == vertCut ? null : face));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideLeftRight(dir, .5F))
                    .apply(Modifiers.cutSideUpDown(top, .5F))
                    .applyIf(Modifiers.setPosition(.5F), face == vertCut)
                    .export(quadMap.get(face == vertCut ? null : face));
        }
        else if (Utils.isY(face))
        {
            boolean base = (face == class_2350.field_11036 && top) || (face == class_2350.field_11033 && !top);

            QuadModifier mod = QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(vertCut, .5F));

            if (!base)
            {
                mod.derive().apply(Modifiers.cutTopBottom(dir, .5F))
                        .apply(Modifiers.setPosition(.5F))
                        .export(quadMap.get(null));
            }

            mod.applyIf(Modifiers.cutTopBottom(dir.method_10153(), .5F), !base)
                    .export(quadMap.get(face));
        }
    }
}
