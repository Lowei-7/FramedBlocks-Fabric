package xfacthd.framedblocks.client.model.stairs;

import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.HorizontalRotation;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_777;

public class FramedVerticalSlopedStairsModel extends FramedBlockModel
{
    private final class_2350 facing;
    private final class_2350 rotDir;
    private final class_2350 rotDirTwo;
    private final boolean ySlope;

    public FramedVerticalSlopedStairsModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        this.facing = state.method_11654(FramedProperties.FACING_HOR);
        HorizontalRotation rot = state.method_11654(PropertyHolder.ROTATION);
        this.rotDir = rot.withFacing(facing);
        this.rotDirTwo = rot.rotate(class_2470.field_11465).withFacing(facing);
        this.ySlope = state.method_11654(FramedProperties.Y_SLOPE);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();
        if (quadDir == rotDir || quadDir == rotDirTwo)
        {
            if (Utils.isY(quadDir))
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(facing.method_10153(), .5F))
                        .export(quadMap.get(quadDir));
            }
            else
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(facing.method_10153(), .5F))
                        .export(quadMap.get(quadDir));
            }
        }
        else if (quadDir == facing.method_10153())
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSide(rotDir, 1F, 0F))
                    .export(quadMap.get(quadDir));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSide(rotDir.method_10153(), 1F, 0F))
                    .apply(Modifiers.setPosition(.5F))
                    .export(quadMap.get(null));
        }

        boolean useRotDirQuad = Utils.isY(rotDir) == ySlope;
        class_2350 slopeQuadDir = useRotDirQuad ? rotDir : rotDirTwo;
        class_2350 slopeRotDir = useRotDirQuad ? rotDirTwo : rotDir;

        if (quadDir == slopeQuadDir)
        {
            if (Utils.isY(slopeQuadDir))
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutTopBottom(facing, .5F))
                        .apply(Modifiers.makeVerticalSlope(slopeRotDir, 45F))
                        .export(quadMap.get(null));
            }
            else
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(facing, .5F))
                        .apply(Modifiers.makeVerticalSlope(slopeRotDir == class_2350.field_11036, 45F))
                        .export(quadMap.get(null));
            }
        }
    }



    public static class_2680 itemSource()
    {
        return FBContent.BLOCK_FRAMED_VERTICAL_SLOPED_STAIRS.get()
                .method_9564()
                .method_11657(FramedProperties.FACING_HOR, class_2350.field_11035);
    }
}
