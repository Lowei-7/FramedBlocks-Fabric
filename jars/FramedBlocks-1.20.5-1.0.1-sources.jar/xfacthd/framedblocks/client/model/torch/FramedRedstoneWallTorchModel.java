package xfacthd.framedblocks.client.model.torch;

import java.util.Set;
import net.minecraft.class_1087;
import net.minecraft.class_1921;
import net.minecraft.class_2246;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import org.joml.Vector3f;
import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.api.util.ClientUtils;
import xfacthd.framedblocks.api.model.util.ModelCache;

import java.util.List;
import java.util.Map;

public class FramedRedstoneWallTorchModel extends FramedBlockModel
{
    private static final Vector3f ROTATION_ORIGIN = new Vector3f(0, 3.5F/16F, 8F/16F);
    private static final float MIN = 7F/16F;
    private static final float MAX = 9F/16F;
    private static final float TOP = 11.5F/16F;
    private static final float BOTTOM = 12.5F/16F;

    private final class_2350 dir;
    private final boolean lit;

    public FramedRedstoneWallTorchModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        this.dir = state.method_11654(class_2741.field_12481);
        this.lit = state.method_11654(class_2741.field_12548);
    }

    @Override
    protected Set<class_1921> getAdditionalRenderTypes(class_5819 rand, Object extraData)
    {
        return ModelCache.getRenderTypes(class_2246.field_10301.method_9564(), rand, extraData);
    }

    @Override
    protected void getAdditionalQuads(
            Map<class_2350, List<class_777>> quadMap,
            class_2680 state,
            class_5819 rand,
            Object extraData,
            class_1921 renderType
    )
    {
        List<class_777> quads = baseModel.method_4707(state, null, rand);
        for (class_777 quad : quads)
        {
            if (!ClientUtils.isDummyTexture(quad))
            {
                quadMap.get(null).add(quad);
            }
        }
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        /*
        "from": [-1, 3.5, 7],
		"to": [1, 11.5, 9],
        "rotation": {"angle": -22.5, "axis": "z", "origin": [0, 3.5, 8]},
        */

        class_2350 quadDir = quad.method_3358();
        if (Utils.isY(quadDir))
        {
            float top = lit ? (TOP - (1F/16F)) : TOP;
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(MIN, MIN, MAX, MAX))
                    .apply(Modifiers.setPosition(quadDir == class_2350.field_11036 ? top : BOTTOM))
                    .apply(Modifiers.offset(class_2350.field_11039, .5F))
                    .export(quadMap.get(null));
        }
        else
        {
            boolean xAxis = Utils.isX(quadDir);
            boolean east = quadDir == class_2350.field_11034;
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSide(MIN, 0, MAX, lit ? (7F/16F) : .5F))
                    .applyIf(Modifiers.setPosition(east ? 1F/16F : 17F/16F), xAxis)
                    .applyIf(Modifiers.setPosition(MAX), !xAxis)
                    .applyIf(Modifiers.offset(class_2350.field_11039, .5F), !xAxis)
                    .apply(Modifiers.offset(class_2350.field_11036, 3.5F/16F))
                    .export(quadMap.get(null));
        }
    }

    @Override
    protected void postProcessQuads(Map<class_2350, List<class_777>> quadMap)
    {
        float yAngle = 270F - dir.method_10144();
        quadMap.get(null).forEach(q ->
                QuadModifier.geometry(q)
                        .apply(Modifiers.rotate(class_2350.class_2351.field_11051, ROTATION_ORIGIN, -22.5F, false))
                        .apply(Modifiers.rotateCentered(class_2350.class_2351.field_11052, yAngle, false))
                        .modifyInPlace()
        );
    }

    @Override
    public boolean method_4708()
    {
        return false;
    }

    @Override
    public boolean useSolidNoCamoModel()
    {
        return true;
    }
}