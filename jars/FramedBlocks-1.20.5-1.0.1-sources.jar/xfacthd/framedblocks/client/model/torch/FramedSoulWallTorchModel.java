package xfacthd.framedblocks.client.model.torch;

import java.util.Set;
import net.minecraft.class_1087;
import net.minecraft.class_1921;
import net.minecraft.class_2246;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import xfacthd.framedblocks.api.model.util.ModelCache;

public class FramedSoulWallTorchModel extends FramedWallTorchModel
{
    public FramedSoulWallTorchModel(class_2680 state, class_1087 baseModel) { super(state, baseModel); }

    @Override
    protected Set<class_1921> getAdditionalRenderTypes(class_5819 rand, Object extraData)
    {
        return ModelCache.getRenderTypes(class_2246.field_22092.method_9564(), rand, null);
    }
}