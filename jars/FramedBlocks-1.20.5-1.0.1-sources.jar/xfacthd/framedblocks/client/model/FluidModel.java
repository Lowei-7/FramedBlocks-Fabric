package xfacthd.framedblocks.client.model;

import com.google.common.base.Preconditions;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandler;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandlerRegistry;
import net.minecraft.class_1058;
import net.minecraft.class_1059;
import net.minecraft.class_1087;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3611;
import net.minecraft.class_4696;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import net.minecraft.class_806;
import net.minecraft.class_809;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.util.Utils;

import java.util.*;
import java.util.function.Function;

@SuppressWarnings("deprecation")
public final class FluidModel implements class_1087
{
    public static final class_2960 BARE_MODEL = Utils.rl("fluid/bare");
    public static final class_2960 BARE_MODEL_SINGLE = Utils.rl("fluid/bare_single");
    private static class_1087 bareModel;
    private static class_1087 bareModelSingle;
    private static final Function<class_2960, class_1058> SPRITE_GETTER = (loc ->
            class_310.method_1551().method_1549(class_1059.field_5275).apply(loc)
    );
    private final class_1921 fluidLayer;
    private final Set<class_1921> fluidLayerSet;
    private final Map<class_2350, List<class_777>> quads;
    private final class_1058 particles;

    private FluidModel(class_1921 fluidLayer, Map<class_2350, List<class_777>> quads, class_1058 particles)
    {
        this.fluidLayer = fluidLayer;
        this.fluidLayerSet = Set.of(fluidLayer);
        this.quads = quads;
        this.particles = particles;
    }

    @Override
    public List<class_777> method_4707(@Nullable class_2680 state, @Nullable class_2350 side, class_5819 random)
    {
        return getQuads(state, side, random, null, class_1921.method_23583());
    }

    public List<class_777> getQuads(
            @Nullable class_2680 state,
            @Nullable class_2350 side,
            class_5819 rand,
            Object extraData,
            class_1921 layer
    )
    {
        if (side == null || layer != fluidLayer)
        {
            return Collections.emptyList();
        }
        return quads.get(side);
    }

    public Set<class_1921> getRenderTypes(class_2680 state, class_5819 rand, Object data)
    {
        return fluidLayerSet;
    }

    @Override
    public boolean method_4708()
    {
        return false;
    }

    @Override
    public boolean method_4712()
    {
        return false;
    }

    @Override
    public boolean method_24304()
    {
        return false;
    }

    @Override
    public boolean method_4713()
    {
        return false;
    }

    @Override
    public class_1058 method_4711()
    {
        return particles;
    }

    @Override
    public class_809 method_4709()
    {
        return class_809.field_4301;
    }

    @Override
    public class_806 method_4710()
    {
        return class_806.field_4292;
    }



    public static FluidModel create(class_3611 fluid)
    {
        class_2960 stillTexture = getFluidTexture(fluid, 0);
        class_2960 flowingTexture = getFluidTexture(fluid, 1);
        Preconditions.checkNotNull(
                stillTexture,
                "Fluid %s returned null from FluidRenderHandler#getFluidSprites()",
                fluid
        );
        Preconditions.checkNotNull(
                flowingTexture,
                "Fluid %s returned null from FluidRenderHandler#getFluidSprites()",
                fluid
        );

        boolean singleTexture = flowingTexture.equals(stillTexture);
        class_1087 bakedModel = singleTexture ? bareModelSingle : bareModel;
        Preconditions.checkNotNull(bakedModel, "Bare fluid model not loaded!");

        Map<class_2350, List<class_777>> quads = new EnumMap<>(class_2350.class);
        class_2680 defState = fluid.method_15785().method_15759();
        class_5819 random = class_5819.method_43047();
        class_1921 layer = class_4696.method_23680(fluid.method_15785());

        for (class_2350 side : class_2350.values())
        {
            quads.put(side, bakedModel.method_4707(defState, side, random));
        }

        return new FluidModel(layer, quads, SPRITE_GETTER.apply(stillTexture));
    }

    public static void cacheBareModels(Map<class_2960, class_1087> registry)
    {
        bareModel = registry.get(BARE_MODEL);
        bareModelSingle = registry.get(BARE_MODEL_SINGLE);
    }

    private static class_2960 getFluidTexture(class_3611 fluid, int idx)
    {
        class_1058 sprite = getFluidSprite(fluid, idx);
        return sprite != null ? sprite.method_45851().method_45816() : null;
    }

    private static class_1058 getFluidSprite(class_3611 fluid, int idx)
    {
        FluidRenderHandler handler = FluidRenderHandlerRegistry.INSTANCE.get(fluid);
        class_1058[] sprites = handler.getFluidSprites(
                class_310.method_1551().field_1687,
                null,
                fluid.method_15785()
        );
        if (sprites == null || sprites.length <= idx)
        {
            return null;
        }
        return sprites[idx];
    }
}
