package xfacthd.framedblocks.client.model.slopeslab;

import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.util.Utils;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_777;

public class FramedCompoundSlopeSlabModel extends FramedBlockModel
{
    private final class_2350 dir;
    private final boolean ySlope;

    public FramedCompoundSlopeSlabModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        this.dir = state.method_11654(FramedProperties.FACING_HOR);
        this.ySlope = state.method_11654(FramedProperties.Y_SLOPE);
    }

    @Override
    public void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 quadDir = quad.method_3358();
        if (quadDir == dir)
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideUpDown(true, .5F))
                    .export(quadMap.get(quadDir));

            if (!ySlope)
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.makeVerticalSlope(false, FramedSlopeSlabModel.SLOPE_ANGLE))
                        .apply(Modifiers.offset(class_2350.field_11033, .5F))
                        .export(quadMap.get(null));
            }
        }
        else if (quadDir == dir.method_10153())
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideUpDown(false, .5F))
                    .export(quadMap.get(quadDir));

            if (!ySlope)
            {
                QuadModifier.geometry(quad)
                        .apply(Modifiers.makeVerticalSlope(true, FramedSlopeSlabModel.SLOPE_ANGLE))
                        .apply(Modifiers.offset(class_2350.field_11036, .5F))
                        .export(quadMap.get(null));
            }
        }
        else if (ySlope && Utils.isY(quadDir))
        {
            class_2350 edge = quadDir == class_2350.field_11036 ? dir.method_10153() : dir;
            QuadModifier.geometry(quad)
                    .apply(Modifiers.makeVerticalSlope(edge, FramedSlopeSlabModel.SLOPE_ANGLE_VERT))
                    .export(quadMap.get(null));
        }
        else if (quadDir.method_10166() == dir.method_10170().method_10166())
        {
            boolean cw = quadDir == dir.method_10170();
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideUpDown(false, cw ? .5F : 1F, cw ? 1F : .5F))
                    .apply(Modifiers.cutSideUpDown(true, cw ? 1F : .5F, cw ? .5F : 1F))
                    .export(quadMap.get(quadDir));
        }
    }
}
