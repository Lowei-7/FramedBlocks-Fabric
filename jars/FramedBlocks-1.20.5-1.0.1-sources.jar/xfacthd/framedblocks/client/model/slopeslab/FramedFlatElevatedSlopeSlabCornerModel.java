package xfacthd.framedblocks.client.model.slopeslab;

import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.common.FBContent;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_777;

public class FramedFlatElevatedSlopeSlabCornerModel extends FramedBlockModel
{
    private final class_2350 facing;
    private final boolean top;
    private final boolean ySlope;

    public FramedFlatElevatedSlopeSlabCornerModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        this.facing = state.method_11654(FramedProperties.FACING_HOR);
        this.top = state.method_11654(FramedProperties.TOP);
        this.ySlope = state.method_11654(FramedProperties.Y_SLOPE);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 face = quad.method_3358();

        if (face == facing.method_10153() || face == facing.method_10170())
        {
            if (!ySlope)
            {
                boolean right = face == facing.method_10170();
                float lenTop = top ? 1F : 0F;
                float lenBot = top ? 0F : 1F;

                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(right, lenTop, lenBot))
                        .apply(Modifiers.makeVerticalSlope(!top, FramedSlopeSlabModel.SLOPE_ANGLE))
                        .apply(Modifiers.offset(top ? class_2350.field_11033 : class_2350.field_11036, .5F))
                        .export(quadMap.get(null));
            }

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideUpDown(top, .5F))
                    .export(quadMap.get(face));
        }
        else if (ySlope && ((!top && face == class_2350.field_11036) || (top && face == class_2350.field_11033)))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(facing.method_10170(), 1, 0))
                    .apply(Modifiers.makeVerticalSlope(facing.method_10153(), FramedSlopeSlabModel.SLOPE_ANGLE_VERT))
                    .export(quadMap.get(null));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(facing.method_10153(), 0, 1))
                    .apply(Modifiers.makeVerticalSlope(facing.method_10170(), FramedSlopeSlabModel.SLOPE_ANGLE_VERT))
                    .export(quadMap.get(null));
        }
        else if (face == facing || face == facing.method_10160())
        {
            boolean rightFace = face == facing;
            float right = rightFace ? .5F : 1;
            float left =  rightFace ? 1 : .5F;

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideUpDown(top, right, left))
                    .export(quadMap.get(face));
        }
    }



    public static class_2680 itemSource()
    {
        return FBContent.BLOCK_FRAMED_FLAT_ELEVATED_SLOPE_SLAB_CORNER.get()
                .method_9564()
                .method_11657(FramedProperties.FACING_HOR, class_2350.field_11035);
    }
}
