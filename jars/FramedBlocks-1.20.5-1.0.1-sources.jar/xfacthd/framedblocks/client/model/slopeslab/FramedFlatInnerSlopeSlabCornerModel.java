package xfacthd.framedblocks.client.model.slopeslab;

import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.data.PropertyHolder;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_777;
import net.minecraft.class_811;

public class FramedFlatInnerSlopeSlabCornerModel extends FramedBlockModel
{
    private final class_2350 facing;
    private final boolean top;
    private final boolean topHalf;
    private final boolean ySlope;

    public FramedFlatInnerSlopeSlabCornerModel(class_2680 state, class_1087 baseModel)
    {
        super(state, baseModel);
        this.facing = state.method_11654(FramedProperties.FACING_HOR);
        this.top = state.method_11654(FramedProperties.TOP);
        this.topHalf = state.method_11654(PropertyHolder.TOP_HALF);
        this.ySlope = state.method_11654(FramedProperties.Y_SLOPE);
    }

    @Override
    protected void transformQuad(Map<class_2350, List<class_777>> quadMap, class_777 quad)
    {
        class_2350 face = quad.method_3358();
        boolean offset = top != topHalf;

        if (face == facing.method_10153() || face == facing.method_10170())
        {
            if (!ySlope)
            {
                boolean right = face != facing.method_10170();
                float lenTop = top ? 0F : 1F;
                float lenBot = top ? 1F : 0F;

                QuadModifier.geometry(quad)
                        .apply(Modifiers.cutSideLeftRight(right, lenTop, lenBot))
                        .apply(Modifiers.makeVerticalSlope(!top, FramedSlopeSlabModel.SLOPE_ANGLE))
                        .applyIf(Modifiers.offset(top ? class_2350.field_11033 : class_2350.field_11036, .5F), offset)
                        .export(quadMap.get(null));
            }

            boolean rightFace = face == facing.method_10170();
            float lenRight = rightFace ? (offset ? .5F : 0) : (offset ? 1 : .5F);
            float lenLeft =  rightFace ? (offset ? 1 : .5F) : (offset ? .5F : 0);

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideUpDown(top, lenRight, lenLeft))
                    .applyIf(Modifiers.cutSideUpDown(!top, .5F), offset)
                    .export(quadMap.get(face));
        }
        else if (ySlope && ((!top && face == class_2350.field_11036) || (top && face == class_2350.field_11033)))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(facing.method_10160(), 1, 0))
                    .apply(Modifiers.makeVerticalSlope(facing.method_10153(), FramedSlopeSlabModel.SLOPE_ANGLE_VERT))
                    .applyIf(Modifiers.offset(top ? class_2350.field_11036 : class_2350.field_11033, .5F), !offset)
                    .export(quadMap.get(null));

            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutTopBottom(facing, 0, 1))
                    .apply(Modifiers.makeVerticalSlope(facing.method_10170(), FramedSlopeSlabModel.SLOPE_ANGLE_VERT))
                    .applyIf(Modifiers.offset(top ? class_2350.field_11036 : class_2350.field_11033, .5F), !offset)
                    .export(quadMap.get(null));
        }
        else if (face == facing || face == facing.method_10160())
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.cutSideUpDown(topHalf, .5F))
                    .export(quadMap.get(face));
        }
        else if ((top && !topHalf && face == class_2350.field_11036) || (!top && topHalf && face == class_2350.field_11033))
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.setPosition(.5F))
                    .export(quadMap.get(null));
        }
    }

    @Override
    protected void applyInHandTransformation(class_4587 poseStack, class_811 ctx)
    {
        poseStack.method_22904(0, .5, 0);
    }



    public static class_2680 itemSource()
    {
        return FBContent.BLOCK_FRAMED_FLAT_INNER_SLOPE_SLAB_CORNER.get()
                .method_9564()
                .method_11657(FramedProperties.FACING_HOR, class_2350.field_11035);
    }
}
