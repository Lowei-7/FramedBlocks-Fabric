package xfacthd.framedblocks.client.data.outline;

import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_7833;
import org.joml.Quaternionf;
import xfacthd.framedblocks.api.render.Quaternions;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.api.render.OutlineRenderer;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.CompoundDirection;

public class SlopedPrismOutlineRenderer extends PrismOutlineRenderer
{
    private static final Quaternionf[][] ZP_DIR = makeQuaternionArray();

    @Override
    public void drawCenterAndTriangle(class_4587 pstack, class_4588 builder)
    {
        // Center line
        OutlineRenderer.drawLine(builder, pstack, .5F, .5F, .5F, .5F, .5F, 1);

        // Front sloped triangle
        OutlineRenderer.drawLine(builder, pstack, 0, 0, 0, .5F, .5F, .5F);
        OutlineRenderer.drawLine(builder, pstack, .5F, .5F, .5F, 1, 0, 0);
    }

    @Override
    public void rotateMatrix(class_4587 pstack, class_2680 state)
    {
        CompoundDirection cmpDir = state.method_11654(PropertyHolder.FACING_DIR);
        class_2350 facing = cmpDir.direction();
        class_2350 orientation = cmpDir.orientation();

        if (Utils.isY(facing))
        {
            if (orientation != class_2350.field_11035)
            {
                pstack.method_22907(YN_DIR[orientation.method_10161()]);
            }
            if (facing == class_2350.field_11033)
            {
                pstack.method_22907(Quaternions.ZP_180);
            }
        }
        else
        {
            if (facing != class_2350.field_11035)
            {
                pstack.method_22907(YN_DIR[facing.method_10161()]);
            }
            if (orientation != class_2350.field_11033)
            {
                pstack.method_22907(ZP_DIR[facing.method_10161()][orientation.ordinal()]);
            }
            pstack.method_22907(Quaternions.XP_90);
        }
    }



    private static Quaternionf[][] makeQuaternionArray()
    {
        Quaternionf[][] array = new Quaternionf[4][6];
        for (class_2350 dir : class_2350.class_2353.field_11062)
        {
            array[dir.method_10161()] = new Quaternionf[6];
            for (class_2350 orientation : class_2350.values())
            {
                int mult = 2;
                if (orientation == dir.method_10160())
                {
                    mult = 1;
                }
                else if (orientation == dir.method_10170())
                {
                    mult = 3;
                }
                array[dir.method_10161()][orientation.ordinal()] = class_7833.field_40718.rotation(class_3532.field_29844 / 2F * mult);
            }
        }
        return array;
    }
}
