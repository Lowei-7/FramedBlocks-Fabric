package xfacthd.framedblocks.client.data.outline;

import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_7833;
import org.joml.Quaternionf;
import xfacthd.framedblocks.api.render.Quaternions;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.api.render.OutlineRenderer;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.DirectionAxis;

public class PrismOutlineRenderer implements OutlineRenderer
{
    protected static final Quaternionf[] YN_DIR = makeQuaternionArray();

    @Override
    public void draw(class_2680 state, class_4587 pstack, class_4588 builder)
    {
        // Base edges
        OutlineRenderer.drawLine(builder, pstack, 0, 0, 0, 0, 0, 1);
        OutlineRenderer.drawLine(builder, pstack, 1, 0, 0, 1, 0, 1);
        OutlineRenderer.drawLine(builder, pstack, 0, 0, 0, 1, 0, 0);
        OutlineRenderer.drawLine(builder, pstack, 0, 0, 1, 1, 0, 1);

        // Back triangle
        OutlineRenderer.drawLine(builder, pstack, 0, 0, 1, .5F, .5F, 1);
        OutlineRenderer.drawLine(builder, pstack, .5F, .5F, 1, 1, 0, 1);

        drawCenterAndTriangle(pstack, builder);
    }

    protected void drawCenterAndTriangle(class_4587 pstack, class_4588 builder)
    {
        // Center line
        OutlineRenderer.drawLine(builder, pstack, .5F, .5F, 0, .5F, .5F, 1);

        // Front triangle
        OutlineRenderer.drawLine(builder, pstack, 0, 0, 0, .5F, .5F, 0);
        OutlineRenderer.drawLine(builder, pstack, .5F, .5F, 0, 1, 0, 0);
    }

    @Override
    public void rotateMatrix(class_4587 pstack, class_2680 state)
    {
        DirectionAxis dirAxis = state.method_11654(PropertyHolder.FACING_AXIS);
        class_2350 facing = dirAxis.direction();
        class_2350.class_2351 axis = dirAxis.axis();

        if (Utils.isY(facing))
        {
            if (facing == class_2350.field_11033)
            {
                pstack.method_22907(Quaternions.ZP_180);
            }
            if (axis == class_2350.class_2351.field_11048)
            {
                pstack.method_22907(Quaternions.YP_90);
            }
        }
        else
        {
            if (facing != class_2350.field_11035)
            {
                pstack.method_22907(YN_DIR[facing.method_10161()]);
            }
            if (axis != class_2350.class_2351.field_11052)
            {
                pstack.method_22907(Quaternions.ZP_90);
            }
            pstack.method_22907(Quaternions.XP_90);
        }
    }



    private static Quaternionf[] makeQuaternionArray()
    {
        Quaternionf[] array = new Quaternionf[4];
        for (class_2350 dir : class_2350.class_2353.field_11062)
        {
            array[dir.method_10161()] = class_7833.field_40715.rotation(class_3532.field_29844 / 2F * dir.method_10161());
        }
        return array;
    }
}
