package xfacthd.framedblocks.client.data.outline;

import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.render.OutlineRenderer;

public final class VerticalHalfSlopeOutlineRenderer implements OutlineRenderer
{
    @Override
    public void draw(class_2680 state, class_4587 poseStack, class_4588 builder)
    {
        //Back
        OutlineRenderer.drawLine(builder, poseStack, 0,  0, 1, 1,  0, 1);
        OutlineRenderer.drawLine(builder, poseStack, 0, .5, 1, 1, .5, 1);
        OutlineRenderer.drawLine(builder, poseStack, 0,  0, 1, 0, .5, 1);
        OutlineRenderer.drawLine(builder, poseStack, 1,  0, 1, 1, .5, 1);

        //Left side
        OutlineRenderer.drawLine(builder, poseStack, 1,  0, 0, 1,  0, 1);
        OutlineRenderer.drawLine(builder, poseStack, 1, .5, 0, 1, .5, 1);
        OutlineRenderer.drawLine(builder, poseStack, 1,  0, 0, 1, .5, 0);

        //Slope
        OutlineRenderer.drawLine(builder, poseStack, 1,  0, 0, 0,  0, 1);
        OutlineRenderer.drawLine(builder, poseStack, 1, .5, 0, 0, .5, 1);
    }

    @Override
    public void rotateMatrix(class_4587 poseStack, class_2680 state)
    {
        OutlineRenderer.super.rotateMatrix(poseStack, state);

        if (state.method_11654(FramedProperties.TOP))
        {
            poseStack.method_22904(0, .5, 0);
        }
    }
}
