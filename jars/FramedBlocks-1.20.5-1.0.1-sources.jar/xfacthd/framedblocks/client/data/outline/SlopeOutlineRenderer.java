package xfacthd.framedblocks.client.data.outline;

import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import xfacthd.framedblocks.api.render.OutlineRenderer;
import xfacthd.framedblocks.common.block.ISlopeBlock;
import xfacthd.framedblocks.common.data.property.SlopeType;

public final class SlopeOutlineRenderer implements OutlineRenderer
{
    public static final SlopeOutlineRenderer INSTANCE = new SlopeOutlineRenderer();

    private SlopeOutlineRenderer() { }

    @Override
    public void draw(class_2680 state, class_4587 poseStack, class_4588 builder)
    {
        SlopeType type = ((ISlopeBlock) state.method_26204()).getSlopeType(state);

        if (type != SlopeType.HORIZONTAL)
        {
            //Back edges
            OutlineRenderer.drawLine(builder, poseStack, 0, 0, 1, 0, 1, 1);
            OutlineRenderer.drawLine(builder, poseStack, 1, 0, 1, 1, 1, 1);

            //Bottom face
            OutlineRenderer.drawLine(builder, poseStack, 0, 0, 0, 0, 0, 1);
            OutlineRenderer.drawLine(builder, poseStack, 0, 0, 0, 1, 0, 0);
            OutlineRenderer.drawLine(builder, poseStack, 1, 0, 0, 1, 0, 1);
            OutlineRenderer.drawLine(builder, poseStack, 0, 0, 1, 1, 0, 1);

            //Top edge
            OutlineRenderer.drawLine(builder, poseStack, 0, 1, 1, 1, 1, 1);

            //Slope
            OutlineRenderer.drawLine(builder, poseStack, 0, 0, 0, 0, 1, 1);
            OutlineRenderer.drawLine(builder, poseStack, 1, 0, 0, 1, 1, 1);
        }
        else
        {
            //Back
            OutlineRenderer.drawLine(builder, poseStack, 0, 0, 1, 1, 0, 1);
            OutlineRenderer.drawLine(builder, poseStack, 0, 1, 1, 1, 1, 1);
            OutlineRenderer.drawLine(builder, poseStack, 0, 0, 1, 0, 1, 1);
            OutlineRenderer.drawLine(builder, poseStack, 1, 0, 1, 1, 1, 1);

            //Left side
            OutlineRenderer.drawLine(builder, poseStack, 1, 0, 0, 1, 0, 1);
            OutlineRenderer.drawLine(builder, poseStack, 1, 1, 0, 1, 1, 1);
            OutlineRenderer.drawLine(builder, poseStack, 1, 0, 0, 1, 1, 0);

            //Slope
            OutlineRenderer.drawLine(builder, poseStack, 1, 0, 0, 0, 0, 1);
            OutlineRenderer.drawLine(builder, poseStack, 1, 1, 0, 0, 1, 1);
        }
    }

    @Override
    public class_2350 getRotationDir(class_2680 state)
    {
        return ((ISlopeBlock) state.method_26204()).getFacing(state);
    }

    @Override
    public void rotateMatrix(class_4587 poseStack, class_2680 state)
    {
        OutlineRenderer.super.rotateMatrix(poseStack, state);

        if (((ISlopeBlock) state.method_26204()).getSlopeType(state) == SlopeType.TOP)
        {
            OutlineRenderer.mirrorHorizontally(poseStack, false);
        }
    }
}
