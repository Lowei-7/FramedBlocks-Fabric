package xfacthd.framedblocks.client.data.outline;

import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import xfacthd.framedblocks.api.render.OutlineRenderer;
import xfacthd.framedblocks.api.render.Quaternions;
import xfacthd.framedblocks.common.data.PropertyHolder;

public class SlopeEdgeOutlineRenderer implements OutlineRenderer
{
    @Override
    public void draw(class_2680 state, class_4587 poseStack, class_4588 builder)
    {
        // Horizontal perpendicular edges
        OutlineRenderer.drawLine(builder, poseStack, 0D,  0D,  1D, 1D,  0D,  1D);
        OutlineRenderer.drawLine(builder, poseStack, 0D,  0D, .5D, 1D,  0D, .5D);
        OutlineRenderer.drawLine(builder, poseStack, 0D, .5D,  1D, 1D, .5D,  1D);

        // Vertical edges
        OutlineRenderer.drawLine(builder, poseStack, 0D, 0D, 1D, 0D, .5D, 1D);
        OutlineRenderer.drawLine(builder, poseStack, 1D, 0D, 1D, 1D, .5D, 1D);

        // Horizontal parallel edges
        OutlineRenderer.drawLine(builder, poseStack, 0D, 0D, .5D, 0D, 0D, 1D);
        OutlineRenderer.drawLine(builder, poseStack, 1D, 0D, .5D, 1D, 0D, 1D);

        // Sloped edges
        OutlineRenderer.drawLine(builder, poseStack, 0D, 0D, .5D, 0D, .5D, 1D);
        OutlineRenderer.drawLine(builder, poseStack, 1D, 0D, .5D, 1D, .5D, 1D);
    }

    @Override
    public void rotateMatrix(class_4587 poseStack, class_2680 state)
    {
        OutlineRenderer.super.rotateMatrix(poseStack, state);
        switch (state.method_11654(PropertyHolder.SLOPE_TYPE))
        {
            case TOP -> poseStack.method_22907(Quaternions.ZP_180);
            case HORIZONTAL -> poseStack.method_22907(Quaternions.ZP_90);
        }
        if (state.method_11654(PropertyHolder.ALT_TYPE))
        {
            poseStack.method_46416(0F, .5F, -.5F);
        }
    }
}
