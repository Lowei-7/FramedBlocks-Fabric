package xfacthd.framedblocks.client.data.outline;

import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import xfacthd.framedblocks.api.render.OutlineRenderer;

public final class InnerPrismOutlineRenderer extends PrismOutlineRenderer
{
    @Override
    public void draw(class_2680 state, class_4587 pstack, class_4588 builder)
    {
        // Base edges
        OutlineRenderer.drawLine(builder, pstack, 0, 0, 0, 0, 0, 1);
        OutlineRenderer.drawLine(builder, pstack, 1, 0, 0, 1, 0, 1);
        OutlineRenderer.drawLine(builder, pstack, 0, 0, 0, 1, 0, 0);
        OutlineRenderer.drawLine(builder, pstack, 0, 0, 1, 1, 0, 1);

        // Top edges
        OutlineRenderer.drawLine(builder, pstack, 0, 1, 0, 0, 1, 1);
        OutlineRenderer.drawLine(builder, pstack, 1, 1, 0, 1, 1, 1);

        // Vertical edges
        OutlineRenderer.drawLine(builder, pstack, 0, 0, 0, 0, 1, 0);
        OutlineRenderer.drawLine(builder, pstack, 1, 0, 0, 1, 1, 0);
        OutlineRenderer.drawLine(builder, pstack, 0, 0, 1, 0, 1, 1);
        OutlineRenderer.drawLine(builder, pstack, 1, 0, 1, 1, 1, 1);

        // Back triangle
        OutlineRenderer.drawLine(builder, pstack, 0, 1, 1, .5F, .5F, 1);
        OutlineRenderer.drawLine(builder, pstack, .5F, .5F, 1, 1, 1, 1);

        // Center line
        OutlineRenderer.drawLine(builder, pstack, .5F, .5F, 0, .5F, .5F, 1);

        // Front triangle
        OutlineRenderer.drawLine(builder, pstack, 0, 1, 0, .5F, .5F, 0);
        OutlineRenderer.drawLine(builder, pstack, .5F, .5F, 0, 1, 1, 0);
    }
}
