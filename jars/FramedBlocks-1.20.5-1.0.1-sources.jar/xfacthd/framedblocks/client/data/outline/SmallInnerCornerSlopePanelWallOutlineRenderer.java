package xfacthd.framedblocks.client.data.outline;

import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import xfacthd.framedblocks.api.render.OutlineRenderer;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.HorizontalRotation;

public final class SmallInnerCornerSlopePanelWallOutlineRenderer implements OutlineRenderer
{
    @Override
    public void draw(class_2680 state, class_4587 poseStack, class_4588 builder)
    {
        // Back face
        OutlineRenderer.drawLine(builder, poseStack, .5, .5, 1,  1, .5, 1);
        OutlineRenderer.drawLine(builder, poseStack, .5,  1, 1,  1,  1, 1);
        OutlineRenderer.drawLine(builder, poseStack, .5, .5, 1, .5,  1, 1);
        OutlineRenderer.drawLine(builder, poseStack,  1, .5, 1,  1,  1, 1);

        // Horizontal edge
        OutlineRenderer.drawLine(builder, poseStack,  1, .5, 0,  1, .5, 1);
        OutlineRenderer.drawLine(builder, poseStack, .5,  1, 0, .5,  1, 1);
        OutlineRenderer.drawLine(builder, poseStack, .5, .5, 0, .5, .5, 1);

        // Front edges
        OutlineRenderer.drawLine(builder, poseStack, .5, .5, 0,  1, .5, 0);
        OutlineRenderer.drawLine(builder, poseStack, .5, .5, 0, .5,  1, 0);

        // Slopes
        OutlineRenderer.drawLine(builder, poseStack, .5,  1, 0, 1, 1, 1);
        OutlineRenderer.drawLine(builder, poseStack,  1, .5, 0, 1, 1, 1);
        OutlineRenderer.drawLine(builder, poseStack, .5, .5, 0, 1, 1, 1);
    }

    @Override
    public void rotateMatrix(class_4587 poseStack, class_2680 state)
    {
        OutlineRenderer.super.rotateMatrix(poseStack, state);

        HorizontalRotation rotation = state.method_11654(PropertyHolder.ROTATION);
        poseStack.method_22907(SlopePanelOutlineRenderer.ROTATIONS[rotation.ordinal()]);
    }
}
