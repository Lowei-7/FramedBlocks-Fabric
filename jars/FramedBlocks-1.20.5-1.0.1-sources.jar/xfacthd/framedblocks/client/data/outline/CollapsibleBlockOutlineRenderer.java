package xfacthd.framedblocks.client.data.outline;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_259;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_7833;
import net.minecraft.world.phys.shapes.*;
import org.joml.Quaternionf;
import xfacthd.framedblocks.api.render.Quaternions;
import xfacthd.framedblocks.api.render.OutlineRenderer;
import xfacthd.framedblocks.common.blockentity.special.FramedCollapsibleBlockEntity;
import xfacthd.framedblocks.common.data.property.NullableDirection;
import xfacthd.framedblocks.common.data.PropertyHolder;

public final class CollapsibleBlockOutlineRenderer implements OutlineRenderer
{
    private static final Quaternionf ROTATION = class_7833.field_40715.rotationDegrees(180);

    @Override
    public void rotateMatrix(class_4587 poseStack, class_2680 state)
    {
        poseStack.method_22907(ROTATION);
    }

    @Override
    public void draw(class_2680 state, class_1937 level, class_2338 pos, class_4587 poseStack, class_4588 builder)
    {
        NullableDirection face = state.method_11654(PropertyHolder.NULLABLE_FACE);
        if (face == NullableDirection.NONE)
        {
            class_259.method_1077().method_1104((pMinX, pMinY, pMinZ, pMaxX, pMaxY, pMaxZ) ->
                    OutlineRenderer.drawLine(builder, poseStack, pMinX, pMinY, pMinZ, pMaxX, pMaxY, pMaxZ)
            );
        }
        else
        {
            if (!(level.method_8321(pos) instanceof FramedCollapsibleBlockEntity be))
            {
                return;
            }

            byte[] offsets = be.getVertexOffsets();
            class_2350 faceDir = face.toDirection().method_10153();

            poseStack.method_22903();
            poseStack.method_22904(.5, .5, .5);
            if (faceDir == class_2350.field_11036)
            {
                poseStack.method_22907(Quaternions.XP_180);
            }
            else if (faceDir != class_2350.field_11033)
            {
                poseStack.method_22907(OutlineRenderer.YN_DIR[faceDir.method_10153().method_10161()]);
                poseStack.method_22907(Quaternions.XN_90);
            }
            poseStack.method_22904(-.5, -.5, -.5);

            //Top
            OutlineRenderer.drawLine(builder, poseStack, 0, 1D - (offsets[2] / 16D), 0, 0, 1D - (offsets[3] / 16D), 1);
            OutlineRenderer.drawLine(builder, poseStack, 0, 1D - (offsets[2] / 16D), 0, 1, 1D - (offsets[1] / 16D), 0);
            OutlineRenderer.drawLine(builder, poseStack, 1, 1D - (offsets[1] / 16D), 0, 1, 1D - (offsets[0] / 16D), 1);
            OutlineRenderer.drawLine(builder, poseStack, 0, 1D - (offsets[3] / 16D), 1, 1, 1D - (offsets[0] / 16D), 1);

            //Bottom
            OutlineRenderer.drawLine(builder, poseStack, 0, 0, 0, 0, 0, 1);
            OutlineRenderer.drawLine(builder, poseStack, 0, 0, 0, 1, 0, 0);
            OutlineRenderer.drawLine(builder, poseStack, 1, 0, 0, 1, 0, 1);
            OutlineRenderer.drawLine(builder, poseStack, 0, 0, 1, 1, 0, 1);

            //Vertical
            OutlineRenderer.drawLine(builder, poseStack, 1, 0, 1, 1, 1D - (offsets[0] / 16D), 1);
            OutlineRenderer.drawLine(builder, poseStack, 1, 0, 0, 1, 1D - (offsets[1] / 16D), 0);
            OutlineRenderer.drawLine(builder, poseStack, 0, 0, 0, 0, 1D - (offsets[2] / 16D), 0);
            OutlineRenderer.drawLine(builder, poseStack, 0, 0, 1, 0, 1D - (offsets[3] / 16D), 1);

            poseStack.method_22909();
        }
    }

    @Override
    public void draw(class_2680 state, class_4587 poseStack, class_4588 builder)
    {
        throw new UnsupportedOperationException();
    }
}