package xfacthd.framedblocks.client.data.outline;

import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.render.OutlineRenderer;

public final class SlopedStairsOutlineRenderer implements OutlineRenderer
{
    @Override
    public void draw(class_2680 state, class_4587 poseStack, class_4588 builder)
    {
        // Bottom face
        OutlineRenderer.drawLine(builder, poseStack, 0, 0, 0, 0, 0, 1);
        OutlineRenderer.drawLine(builder, poseStack, 0, 0, 0, 1, 0, 0);
        OutlineRenderer.drawLine(builder, poseStack, 1, 0, 0, 1, 0, 1);
        OutlineRenderer.drawLine(builder, poseStack, 0, 0, 1, 1, 0, 1);

        // Center face
        OutlineRenderer.drawLine(builder, poseStack, 0, .5, 0, 0, .5, 1);
        OutlineRenderer.drawLine(builder, poseStack, 0, .5, 0, 1, .5, 0);

        // Top face
        OutlineRenderer.drawLine(builder, poseStack, 1, 1, 0, 1, 1, 1);
        OutlineRenderer.drawLine(builder, poseStack, 0, 1, 1, 1, 1, 1);

        // Vertical edges
        OutlineRenderer.drawLine(builder, poseStack, 0, 0, 1, 0, 1, 1);
        OutlineRenderer.drawLine(builder, poseStack, 1, 0, 0, 1, 1, 0);
        OutlineRenderer.drawLine(builder, poseStack, 1, 0, 1, 1, 1, 1);

        // Front vertical edge
        OutlineRenderer.drawLine(builder, poseStack, 0, 0, 0, 0, .5, 0);

        // Top diagonal edge
        OutlineRenderer.drawLine(builder, poseStack, 0, 1, 1, 1, 1, 0);

        // Center diagonal edge
        OutlineRenderer.drawLine(builder, poseStack, 0, .5, 1, 1, .5, 0);
    }

    @Override
    public void rotateMatrix(class_4587 poseStack, class_2680 state)
    {
        OutlineRenderer.super.rotateMatrix(poseStack, state);

        if (state.method_11654(FramedProperties.TOP))
        {
            OutlineRenderer.mirrorHorizontally(poseStack, true);
        }
    }
}
