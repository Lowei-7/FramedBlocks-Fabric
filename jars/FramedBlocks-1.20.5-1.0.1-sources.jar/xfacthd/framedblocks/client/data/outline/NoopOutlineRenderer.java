package xfacthd.framedblocks.client.data.outline;

import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import xfacthd.framedblocks.api.render.OutlineRenderer;

public final class NoopOutlineRenderer implements OutlineRenderer
{
    public static final NoopOutlineRenderer INSTANCE = new NoopOutlineRenderer();

    private NoopOutlineRenderer() { }

    @Override
    public void draw(class_2680 state, class_4587 poseStack, class_4588 builder)
    {
        //NO-OP
    }

    @Override
    public void rotateMatrix(class_4587 poseStack, class_2680 state)
    {
        // NO-OP
    }
}
