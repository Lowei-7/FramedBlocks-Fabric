package xfacthd.framedblocks.client.data.outline;

import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_7833;
import org.joml.Quaternionf;
import xfacthd.framedblocks.api.render.Quaternions;
import xfacthd.framedblocks.api.render.OutlineRenderer;

public final class PyramidOutlineRenderer implements OutlineRenderer
{
    private static final Quaternionf[] XN_DIR = makeQuaternionArray();

    private final float height;

    public PyramidOutlineRenderer(boolean slab)
    {
        this.height = slab ? .5F : 1;
    }

    @Override
    public void draw(class_2680 state, class_4587 pstack, class_4588 builder)
    {
        // Base edges
        OutlineRenderer.drawLine(builder, pstack, 0, 0, 0, 1, 0, 0);
        OutlineRenderer.drawLine(builder, pstack, 0, 0, 1, 1, 0, 1);
        OutlineRenderer.drawLine(builder, pstack, 0, 0, 0, 0, 0, 1);
        OutlineRenderer.drawLine(builder, pstack, 1, 0, 0, 1, 0, 1);

        // Slopes
        OutlineRenderer.drawLine(builder, pstack, 0, 0, 0, .5F, height, .5F);
        OutlineRenderer.drawLine(builder, pstack, 1, 0, 0, .5F, height, .5F);
        OutlineRenderer.drawLine(builder, pstack, 0, 0, 1, .5F, height, .5F);
        OutlineRenderer.drawLine(builder, pstack, 1, 0, 1, .5F, height, .5F);
    }

    @Override
    public void rotateMatrix(class_4587 poseStack, class_2680 state)
    {
        class_2350 dir = state.method_11654(class_2741.field_12525);
        if (dir == class_2350.field_11033)
        {
            poseStack.method_22907(Quaternions.ZP_180);
        }
        else if (dir != class_2350.field_11036)
        {
            poseStack.method_22907(Quaternions.ZP_90);
            poseStack.method_22907(XN_DIR[dir.method_10161()]);
        }
    }



    private static Quaternionf[] makeQuaternionArray()
    {
        Quaternionf[] array = new Quaternionf[4];
        for (class_2350 dir : class_2350.class_2353.field_11062)
        {
            array[dir.method_10161()] = class_7833.field_40713.rotationDegrees(dir.method_10144() - 90F);
        }
        return array;
    }
}
