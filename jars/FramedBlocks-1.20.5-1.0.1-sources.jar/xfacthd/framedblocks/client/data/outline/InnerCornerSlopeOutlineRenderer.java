package xfacthd.framedblocks.client.data.outline;

import xfacthd.framedblocks.api.render.Quaternions;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import xfacthd.framedblocks.api.render.OutlineRenderer;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.CornerType;

public final class InnerCornerSlopeOutlineRenderer implements OutlineRenderer
{
    @Override
    public void draw(class_2680 state, class_4587 poseStack, class_4588 builder)
    {
        CornerType type = state.method_11654(PropertyHolder.CORNER_TYPE);
        if (!type.isHorizontal())
        {
            //Back face
            OutlineRenderer.drawLine(builder, poseStack, 0, 0, 1, 1, 0, 1);
            OutlineRenderer.drawLine(builder, poseStack, 0, 1, 1, 1, 1, 1);
            OutlineRenderer.drawLine(builder, poseStack, 0, 0, 1, 0, 1, 1);
            OutlineRenderer.drawLine(builder, poseStack, 1, 0, 1, 1, 1, 1);

            //Left face
            OutlineRenderer.drawLine(builder, poseStack, 1, 0, 0, 1, 0, 1);
            OutlineRenderer.drawLine(builder, poseStack, 1, 1, 0, 1, 1, 1);
            OutlineRenderer.drawLine(builder, poseStack, 1, 0, 0, 1, 1, 0);

            //Bottom face
            OutlineRenderer.drawLine(builder, poseStack, 0, 0, 0, 0, 0, 1);
            OutlineRenderer.drawLine(builder, poseStack, 0, 0, 0, 1, 0, 0);

            //Slope edges
            OutlineRenderer.drawLine(builder, poseStack, 0, 0, 0, 0, 1, 1);
            OutlineRenderer.drawLine(builder, poseStack, 0, 0, 0, 1, 1, 0);
            OutlineRenderer.drawLine(builder, poseStack, 0, 0, 0, 1, 1, 1);
        }
        else
        {
            //Top face
            OutlineRenderer.drawLine(builder, poseStack, 0, 1, 1, 1, 1, 1);
            OutlineRenderer.drawLine(builder, poseStack, 0, 1, 0, 0, 1, 1);
            OutlineRenderer.drawLine(builder, poseStack, 0, 1, 0, 1, 1, 1);

            //Bottom face
            OutlineRenderer.drawLine(builder, poseStack, 0, 0, 0, 1, 0, 0);
            OutlineRenderer.drawLine(builder, poseStack, 0, 0, 1, 1, 0, 1);
            OutlineRenderer.drawLine(builder, poseStack, 0, 0, 0, 0, 0, 1);
            OutlineRenderer.drawLine(builder, poseStack, 1, 0, 0, 1, 0, 1);

            //Right face
            OutlineRenderer.drawLine(builder, poseStack, 0, 0, 0, 0, 1, 0);
            OutlineRenderer.drawLine(builder, poseStack, 0, 0, 1, 0, 1, 1);

            //Left face
            OutlineRenderer.drawLine(builder, poseStack, 1, 0, 1, 1, 1, 1);
            OutlineRenderer.drawLine(builder, poseStack, 1, 0, 0, 1, 1, 1);

            //Slope edge
            OutlineRenderer.drawLine(builder, poseStack, 0, 0, 0, 1, 1, 1);
        }
    }

    @Override
    public void rotateMatrix(class_4587 poseStack, class_2680 state)
    {
        OutlineRenderer.super.rotateMatrix(poseStack, state);

        CornerType type = state.method_11654(PropertyHolder.CORNER_TYPE);
        if (!type.isHorizontal())
        {
            if (type.isTop())
            {
                OutlineRenderer.mirrorHorizontally(poseStack, true);
            }
        }
        else
        {
            if (!type.isRight())
            {
                poseStack.method_22907(Quaternions.ZP_90);
            }
            if (type.isTop())
            {
                poseStack.method_22907(type.isRight() ? Quaternions.ZN_90 : Quaternions.ZP_90);
            }
        }
    }
}
