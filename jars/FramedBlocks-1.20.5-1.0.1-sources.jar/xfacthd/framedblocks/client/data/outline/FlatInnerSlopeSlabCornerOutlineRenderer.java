package xfacthd.framedblocks.client.data.outline;

import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.render.OutlineRenderer;
import xfacthd.framedblocks.common.data.PropertyHolder;

public final class FlatInnerSlopeSlabCornerOutlineRenderer implements OutlineRenderer
{
    @Override
    public void draw(class_2680 state, class_4587 poseStack, class_4588 builder)
    {
        //Bottom face
        OutlineRenderer.drawLine(builder, poseStack, 0, 0, 0, 0, 0, 1);
        OutlineRenderer.drawLine(builder, poseStack, 0, 0, 0, 1, 0, 0);
        OutlineRenderer.drawLine(builder, poseStack, 1, 0, 0, 1, 0, 1);
        OutlineRenderer.drawLine(builder, poseStack, 0, 0, 1, 1, 0, 1);

        //Back edges
        OutlineRenderer.drawLine(builder, poseStack, 1, 0, 1, 1, .5, 1);
        OutlineRenderer.drawLine(builder, poseStack, 0, 0, 1, 0, .5, 1);
        OutlineRenderer.drawLine(builder, poseStack, 1, 0, 0, 1, .5, 0);

        //Top edges
        OutlineRenderer.drawLine(builder, poseStack, 0, .5, 1, 1, .5, 1);
        OutlineRenderer.drawLine(builder, poseStack, 1, .5, 0, 1, .5, 1);

        //Slope
        OutlineRenderer.drawLine(builder, poseStack, 0, 0, 0, 1, .5, 0);
        OutlineRenderer.drawLine(builder, poseStack, 0, 0, 0, 1, .5, 1);
        OutlineRenderer.drawLine(builder, poseStack, 0, 0, 0, 0, .5, 1);
    }

    @Override
    public void rotateMatrix(class_4587 poseStack, class_2680 state)
    {
        OutlineRenderer.super.rotateMatrix(poseStack, state);

        boolean top = state.method_11654(FramedProperties.TOP);
        boolean topHalf = state.method_11654(PropertyHolder.TOP_HALF);
        if (top)
        {
            OutlineRenderer.mirrorHorizontally(poseStack, true);
        }
        if (topHalf != top)
        {
            poseStack.method_22904(0, .5, 0);
        }
    }
}
