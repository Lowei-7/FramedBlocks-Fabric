package xfacthd.framedblocks.client.data.outline;

import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import org.joml.Quaternionf;
import xfacthd.framedblocks.api.render.Quaternions;
import xfacthd.framedblocks.api.render.OutlineRenderer;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.HorizontalRotation;

public final class SlopePanelOutlineRenderer implements OutlineRenderer
{
    public static final Quaternionf[] ROTATIONS = new Quaternionf[] {
            Quaternions.ONE,
            Quaternions.ZP_180,
            Quaternions.ZP_90,
            Quaternions.ZN_90
    };

    @Override
    public void draw(class_2680 state, class_4587 poseStack, class_4588 builder)
    {
        // Bottom edges
        OutlineRenderer.drawLine(builder, poseStack, 0, 0,  0, 1, 0,  0);
        OutlineRenderer.drawLine(builder, poseStack, 0, 0, .5, 1, 0, .5);
        OutlineRenderer.drawLine(builder, poseStack, 0, 0,  0, 0, 0, .5);
        OutlineRenderer.drawLine(builder, poseStack, 1, 0,  0, 1, 0, .5);

        // Back edges
        OutlineRenderer.drawLine(builder, poseStack, 0, 0, .5, 0, 1, .5);
        OutlineRenderer.drawLine(builder, poseStack, 1, 0, .5, 1, 1, .5);

        // Top edge
        OutlineRenderer.drawLine(builder, poseStack, 0, 1, .5, 1, 1, .5);

        // Slopes
        OutlineRenderer.drawLine(builder, poseStack, 0, 0,  0, 0, 1, .5);
        OutlineRenderer.drawLine(builder, poseStack, 1, 0,  0, 1, 1, .5);
    }

    @Override
    public void rotateMatrix(class_4587 poseStack, class_2680 state)
    {
        OutlineRenderer.super.rotateMatrix(poseStack, state);

        HorizontalRotation rotation = state.method_11654(PropertyHolder.ROTATION);
        poseStack.method_22907(ROTATIONS[rotation.ordinal()]);

        if (!state.method_11654(PropertyHolder.FRONT))
        {
            poseStack.method_22904(0, 0, .5);
        }
    }
}
