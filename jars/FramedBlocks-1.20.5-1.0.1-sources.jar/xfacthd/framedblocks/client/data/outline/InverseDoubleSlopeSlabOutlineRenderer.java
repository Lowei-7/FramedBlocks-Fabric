package xfacthd.framedblocks.client.data.outline;

import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import xfacthd.framedblocks.api.render.OutlineRenderer;

public final class InverseDoubleSlopeSlabOutlineRenderer implements OutlineRenderer
{
    public static final InverseDoubleSlopeSlabOutlineRenderer INSTANCE = new InverseDoubleSlopeSlabOutlineRenderer();

    private InverseDoubleSlopeSlabOutlineRenderer() { }

    @Override
    public void draw(class_2680 state, class_4587 poseStack, class_4588 builder)
    {
        //Back vertical edges
        OutlineRenderer.drawLine(builder, poseStack, 0, .5, 1, 0, 1, 1);
        OutlineRenderer.drawLine(builder, poseStack, 1, .5, 1, 1, 1, 1);

        //Center horizontal edges
        OutlineRenderer.drawLine(builder, poseStack, 0, .5, 0, 1, .5, 0);
        OutlineRenderer.drawLine(builder, poseStack, 0, .5, 1, 1, .5, 1);

        //Top edge
        OutlineRenderer.drawLine(builder, poseStack, 0, 1, 1, 1, 1, 1);

        //Top slope
        OutlineRenderer.drawLine(builder, poseStack, 0, .5, 0, 0, 1, 1);
        OutlineRenderer.drawLine(builder, poseStack, 1, .5, 0, 1, 1, 1);

        //Bottom edge
        OutlineRenderer.drawLine(builder, poseStack, 0, 0, 0, 1, 0, 0);

        //Bottom slope
        OutlineRenderer.drawLine(builder, poseStack, 0, 0, 0, 0, .5, 1);
        OutlineRenderer.drawLine(builder, poseStack, 1, 0, 0, 1, .5, 1);

        //Front vertical edges
        OutlineRenderer.drawLine(builder, poseStack, 0, 0, 0, 0, .5, 0);
        OutlineRenderer.drawLine(builder, poseStack, 1, 0, 0, 1, .5, 0);
    }
}
