package xfacthd.framedblocks.client.data.ghost;

import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_2323;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2756;
import net.minecraft.class_3965;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.ghost.CamoPair;
import xfacthd.framedblocks.api.ghost.GhostRenderBehaviour;

public final class DoorGhostRenderBehaviour implements GhostRenderBehaviour
{
    @Override
    public boolean hasSecondBlock(class_1799 stack, class_1799 proxiedStack) { return true; }

    @Override
    @Nullable
    public class_2680 getRenderState(
            class_1799 stack,
            @Nullable class_1799 proxiedStack,
            class_3965 hit,
            class_1750 ctx,
            class_2680 hitState,
            boolean secondPass
    )
    {
        class_2680 state = GhostRenderBehaviour.super.getRenderState(stack, proxiedStack, hit, ctx, hitState, secondPass);
        if (state != null && secondPass)
        {
            state = state.method_11657(class_2323.field_10946, class_2756.field_12609);
        }
        return state;
    }

    @Override
    public class_2338 getRenderPos(
            class_1799 stack,
            @Nullable class_1799 proxiedStack,
            class_3965 hit,
            class_1750 ctx,
            class_2680 hitState,
            class_2338 defaultPos,
            boolean secondPass
    )
    {
        return secondPass ? defaultPos.method_10084() : defaultPos;
    }

    @Override
    public boolean canRenderAt(
            class_1799 stack,
            @Nullable class_1799 proxiedStack,
            class_3965 hit,
            class_1750 ctx,
            class_2680 hitState,
            class_2680 renderState,
            class_2338 renderPos
    )
    {
        return GhostRenderBehaviour.super.canRenderAt(stack, proxiedStack, hit, ctx, hitState, renderState, renderPos) &&
               GhostRenderBehaviour.super.canRenderAt(stack, proxiedStack, hit, ctx, hitState, renderState, renderPos.method_10084());
    }

    @Override
    public CamoPair readCamo(class_1799 stack, @Nullable class_1799 proxiedStack, boolean secondPass)
    {
        CamoPair pair = GhostRenderBehaviour.super.readCamo(stack, proxiedStack, false);
        // Properly render a camo on both halves without breaking blueprint support
        return secondPass ? pair.swap() : pair;
    }

    @Override
    public CamoPair postProcessCamo(
            class_1799 stack,
            @Nullable class_1799 proxiedStack,
            class_1750 ctx,
            class_2680 renderState,
            boolean secondPass,
            CamoPair camo
    )
    {
        return secondPass ? camo.swap() : camo;
    }
}
