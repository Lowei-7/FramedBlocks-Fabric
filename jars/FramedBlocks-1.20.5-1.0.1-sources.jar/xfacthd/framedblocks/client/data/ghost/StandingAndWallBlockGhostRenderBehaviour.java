package xfacthd.framedblocks.client.data.ghost;

import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.ghost.GhostRenderBehaviour;
import xfacthd.framedblocks.api.util.Utils;

import java.lang.invoke.MethodHandle;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_2680;
import net.minecraft.class_3965;

public sealed class StandingAndWallBlockGhostRenderBehaviour implements GhostRenderBehaviour
        permits StandingAndWallDoubleBlockGhostRenderBehaviour
{
    private static final MethodHandle BLOCKITEM_GETPLACESTATE = Utils.unreflectMethod(class_1747.class, "method_7707", new String[]{"getPlacementState"}, class_1750.class);

    @Override
    @Nullable
    public class_2680 getRenderState(
            class_1799 stack,
            @Nullable class_1799 proxiedStack,
            class_3965 hit,
            class_1750 ctx,
            class_2680 hitState,
            boolean secondPass
    )
    {
        try
        {
            return (class_2680) BLOCKITEM_GETPLACESTATE.invokeExact((class_1747) stack.method_7909(), ctx);
        }
        catch (Throwable e)
        {
            throw new RuntimeException("Failed to invoke BlockItem#getPlacementState on '%s'".formatted(stack.method_7909()), e);
        }
    }
}
