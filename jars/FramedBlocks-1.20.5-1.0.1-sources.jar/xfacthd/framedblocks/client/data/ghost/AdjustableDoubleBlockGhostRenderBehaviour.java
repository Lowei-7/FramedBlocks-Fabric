package xfacthd.framedblocks.client.data.ghost;

import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_2680;
import net.minecraftforge.client.model.data.ModelData;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.model.data.FramedBlockData;
import xfacthd.framedblocks.common.blockentity.FramedDoubleBlockEntity;
import xfacthd.framedblocks.common.blockentity.doubled.FramedAdjustableDoubleBlockEntity;

public final class AdjustableDoubleBlockGhostRenderBehaviour extends DoubleBlockGhostRenderBehaviour
{
    private final FramedAdjustableDoubleBlockEntity.OffsetPacker offsetPacker;

    private AdjustableDoubleBlockGhostRenderBehaviour(FramedAdjustableDoubleBlockEntity.OffsetPacker offsetPacker)
    {
        this.offsetPacker = offsetPacker;
    }

    @Override
    public ModelData appendModelData(class_1799 stack, @Nullable class_1799 proxiedStack, class_1750 ctx, class_2680 renderState, boolean secondPass, ModelData data)
    {
        int offsetsLeft = offsetPacker.pack(renderState, FramedAdjustableDoubleBlockEntity.CENTER_PART_HEIGHT, false);
        int offsetsRight = offsetPacker.pack(renderState, FramedAdjustableDoubleBlockEntity.CENTER_PART_HEIGHT, true);

        ModelData dataLeft = (ModelData) data.get(FramedDoubleBlockEntity.DATA_LEFT);
        if (dataLeft != null)
        {
            FramedBlockData frame = dataLeft.get(FramedBlockData.PROPERTY);
            if (frame != null)
            {
                frame.setPackedOffsets(offsetsLeft);
            }
        }
        ModelData dataRight = (ModelData) data.get(FramedDoubleBlockEntity.DATA_RIGHT);
        if (dataRight != null)
        {
            FramedBlockData frame = dataRight.get(FramedBlockData.PROPERTY);
            if (frame != null)
            {
                frame.setPackedOffsets(offsetsRight);
            }
        }
        return data;
    }



    public static AdjustableDoubleBlockGhostRenderBehaviour standard()
    {
        return new AdjustableDoubleBlockGhostRenderBehaviour(FramedAdjustableDoubleBlockEntity::getPackedOffsetsStandard);
    }

    public static AdjustableDoubleBlockGhostRenderBehaviour copycat()
    {
        return new AdjustableDoubleBlockGhostRenderBehaviour(FramedAdjustableDoubleBlockEntity::getPackedOffsetsCopycat);
    }
}
