package xfacthd.framedblocks.client.data.ghost;

import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.ghost.GhostRenderBehaviour;
import xfacthd.framedblocks.common.FBContent;

public final class FancyRailGhostRenderBehaviour implements GhostRenderBehaviour
{
    private final RailSlopeGhostRenderBehaviour railSlopeBehaviour = new RailSlopeGhostRenderBehaviour();

    @Override
    public boolean mayRender(class_1799 stack, @Nullable class_1799 proxiedStack)
    {
        return railSlopeBehaviour.mayRender(stack, proxiedStack) || GhostRenderBehaviour.super.mayRender(stack, proxiedStack);
    }

    @Override
    public @Nullable class_2680 getRenderState(
            class_1799 stack,
            @Nullable class_1799 proxiedStack,
            class_3965 hit,
            class_1750 ctx,
            class_2680 hitState,
            boolean secondPass
    )
    {
        class_2680 state = railSlopeBehaviour.getRenderState(stack, proxiedStack, hit, ctx, hitState, secondPass);
        if (state != null)
        {
            return state;
        }
        return GhostRenderBehaviour.super.getRenderState(stack, proxiedStack, hit, ctx, hitState, secondPass);
    }

    @Override
    public class_2338 getRenderPos(
            class_1799 stack,
            @Nullable class_1799 proxiedStack,
            class_3965 hit,
            class_1750 ctx,
            class_2680 hitState,
            class_2338 defaultPos,
            boolean secondPass
    )
    {
        if (hitState.method_26204() == FBContent.BLOCK_FRAMED_SLOPE.get())
        {
            return railSlopeBehaviour.getRenderPos(stack, proxiedStack, hit, ctx, hitState, defaultPos, secondPass);
        }
        return GhostRenderBehaviour.super.getRenderPos(stack, proxiedStack, hit, ctx, hitState, defaultPos, secondPass);
    }

    @Override
    public boolean canRenderAt(
            class_1799 stack,
            @Nullable class_1799 proxiedStack,
            class_3965 hit,
            class_1750 ctx,
            class_2680 hitState,
            class_2680 renderState,
            class_2338 renderPos
    )
    {
        if (renderPos.equals(hit.method_17777()))
        {
            return railSlopeBehaviour.canRenderAt(stack, proxiedStack, hit, ctx, hitState, renderState, renderPos);
        }
        return GhostRenderBehaviour.super.canRenderAt(stack, proxiedStack, hit, ctx, hitState, renderState, renderPos);
    }
}
