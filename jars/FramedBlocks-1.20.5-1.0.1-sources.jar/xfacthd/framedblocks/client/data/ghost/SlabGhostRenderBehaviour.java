package xfacthd.framedblocks.client.data.ghost;

import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.ghost.GhostRenderBehaviour;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.common.FBContent;

public final class SlabGhostRenderBehaviour implements GhostRenderBehaviour
{
    @Override
    @Nullable
    public class_2680 getRenderState(
            class_1799 stack,
            @Nullable class_1799 proxiedStack,
            class_3965 hit,
            class_1750 ctx,
            class_2680 hitState,
            boolean secondPass
    )
    {
        if (hitState.method_26204() == FBContent.BLOCK_FRAMED_SLAB.get())
        {
            boolean top = hitState.method_11654(FramedProperties.TOP);
            if ((top && hit.method_17780() == class_2350.field_11033) || (!top && hit.method_17780() == class_2350.field_11036))
            {
                return hitState.method_11657(FramedProperties.TOP, !top);
            }
        }
        return GhostRenderBehaviour.super.getRenderState(stack, proxiedStack, hit, ctx, hitState, secondPass);
    }

    @Override
    public class_2338 getRenderPos(
            class_1799 stack,
            @Nullable class_1799 proxiedStack,
            class_3965 hit,
            class_1750 ctx,
            class_2680 hitState,
            class_2338 defaultPos,
            boolean secondPass
    )
    {
        if (hitState.method_26204() == FBContent.BLOCK_FRAMED_SLAB.get())
        {
            boolean top = hitState.method_11654(FramedProperties.TOP);
            if ((top && hit.method_17780() == class_2350.field_11033) || (!top && hit.method_17780() == class_2350.field_11036))
            {
                return hit.method_17777();
            }
        }
        return defaultPos;
    }

    @Override
    public boolean canRenderAt(
            class_1799 stack,
            @Nullable class_1799 proxiedStack,
            class_3965 hit,
            class_1750 ctx,
            class_2680 hitState,
            class_2680 renderState,
            class_2338 renderPos
    )
    {
        if (renderPos.equals(hit.method_17777()))
        {
            return true;
        }
        return GhostRenderBehaviour.super.canRenderAt(stack, proxiedStack, hit, ctx, hitState, renderState, renderPos);
    }
}
