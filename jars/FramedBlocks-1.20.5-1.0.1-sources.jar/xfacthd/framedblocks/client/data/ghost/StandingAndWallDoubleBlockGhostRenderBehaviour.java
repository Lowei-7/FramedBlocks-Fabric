package xfacthd.framedblocks.client.data.ghost;

import net.minecraft.class_1799;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.ghost.CamoPair;

public final class StandingAndWallDoubleBlockGhostRenderBehaviour extends StandingAndWallBlockGhostRenderBehaviour
{
    @Override
    public CamoPair readCamo(class_1799 stack, @Nullable class_1799 proxiedStack, boolean secondPass)
    {
        return DoubleBlockGhostRenderBehaviour.readDoubleCamo(stack);
    }
}
