package xfacthd.framedblocks.client.data.ghost;

import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import net.minecraftforge.client.model.data.ModelData;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.ghost.GhostRenderBehaviour;
import xfacthd.framedblocks.api.model.data.FramedBlockData;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.NullableDirection;

public final class CollapsibleBlockGhostRenderBehaviour implements GhostRenderBehaviour
{
    @Override
    @Nullable
    public class_2680 getRenderState(
            class_1799 stack,
            @Nullable class_1799 proxiedStack,
            class_3965 hit,
            class_1750 ctx,
            class_2680 hitState,
            boolean secondPass
    )
    {
        class_2680 state = GhostRenderBehaviour.super.getRenderState(stack, proxiedStack, hit, ctx, hitState, secondPass);
        //noinspection ConstantConditions
        class_9279 blockEntityData = stack.method_57824(class_9334.field_49611);
        if (state != null && blockEntityData != null)
        {
            int faceIdx = blockEntityData.method_57463().method_10550("face");
            class_2350 face = faceIdx == -1 ? null : class_2350.method_10143(faceIdx);
            state = state.method_11657(PropertyHolder.NULLABLE_FACE, NullableDirection.fromDirection(face));
        }
        return state;
    }

    @Override
    public ModelData appendModelData(
            class_1799 stack,
            @Nullable class_1799 proxiedStack,
            class_1750 ctx,
            class_2680 renderState,
            boolean secondPass,
            ModelData data
    )
    {
        //noinspection ConstantConditions
        class_9279 blockEntityData = stack.method_57824(class_9334.field_49611);
        if (blockEntityData != null)
        {
            int offsets = blockEntityData.method_57463().method_10550("offsets");
            FramedBlockData frame = data.get(FramedBlockData.PROPERTY);
            if (frame != null)
            {
                frame.setPackedOffsets(offsets);
            }
        }
        return data;
    }
}
