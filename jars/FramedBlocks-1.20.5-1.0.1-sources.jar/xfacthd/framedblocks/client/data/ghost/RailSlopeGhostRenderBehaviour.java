package xfacthd.framedblocks.client.data.ghost;

import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_2241;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2768;
import net.minecraft.class_3965;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.ghost.GhostRenderBehaviour;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.util.FramedUtils;

public final class RailSlopeGhostRenderBehaviour implements GhostRenderBehaviour
{
    @Override
    public boolean mayRender(class_1799 stack, @Nullable class_1799 proxiedStack)
    {
        return FramedUtils.isRailItem(stack.method_7909());
    }

    @Override
    @Nullable
    public class_2680 getRenderState(
            class_1799 stack,
            @Nullable class_1799 proxiedStack,
            class_3965 hit,
            class_1750 ctx,
            class_2680 hitState,
            boolean secondPass
    )
    {
        if (hitState.method_26204() == FBContent.BLOCK_FRAMED_SLOPE.get())
        {
            class_2768 shape = FramedUtils.getAscendingRailShapeFromDirection(hitState.method_11654(FramedProperties.FACING_HOR));
            if (!(stack.method_7909() instanceof class_1747 item) || !(item.method_7711() instanceof class_2241 block))
            {
                return null;
            }
            //noinspection deprecation
            return block.method_9564().method_11657(block.method_9474(), shape);
        }
        return null;
    }

    @Override
    public class_2338 getRenderPos(
            class_1799 stack,
            @Nullable class_1799 proxiedStack,
            class_3965 hit,
            class_1750 ctx,
            class_2680 hitState,
            class_2338 defaultPos,
            boolean secondPass
    )
    {
        return hit.method_17777();
    }

    @Override
    public boolean canRenderAt(
            class_1799 stack,
            @Nullable class_1799 proxiedStack,
            class_3965 hit,
            class_1750 ctx,
            class_2680 hitState,
            class_2680 renderState,
            class_2338 renderPos
    )
    {
        return true;
    }
}
