package xfacthd.framedblocks.client.data.ghost;

import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.ghost.CamoPair;
import xfacthd.framedblocks.api.block.FramedProperties;

public final class DoublePanelGhostRenderBehaviour extends DoubleBlockGhostRenderBehaviour
{
    @Override
    public CamoPair postProcessCamo(
            class_1799 stack,
            @Nullable class_1799 proxiedStack,
            class_1750 ctx,
            class_2680 renderState,
            boolean secondPass,
            CamoPair camo
    )
    {
        //noinspection ConstantConditions
        if (renderState.method_11654(FramedProperties.FACING_NE) != ctx.method_8036().method_5735())
        {
            return camo.swap();
        }
        return camo;
    }
}
