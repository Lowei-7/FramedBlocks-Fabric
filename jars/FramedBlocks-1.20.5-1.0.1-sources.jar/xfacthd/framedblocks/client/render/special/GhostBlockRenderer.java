package xfacthd.framedblocks.client.render.special;

import net.minecraftforge.client.model.data.ModelData;

import com.google.common.base.Preconditions;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.*;
import net.minecraft.client.renderer.*;
import net.minecraft.world.item.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.phys.*;
import net.minecraftforge.client.ForgeRenderTypes;
import xfacthd.framedblocks.api.ghost.CamoPair;
import xfacthd.framedblocks.api.ghost.GhostRenderBehaviour;
import xfacthd.framedblocks.api.model.data.FramedBlockData;
import xfacthd.framedblocks.api.model.data.FramedDoubleBlockData;
import xfacthd.framedblocks.api.util.*;
import xfacthd.framedblocks.api.model.util.ModelCache;
import xfacthd.framedblocks.client.model.FramedDoubleBlockModel;
import xfacthd.framedblocks.client.render.util.GhostVertexConsumer;
import xfacthd.framedblocks.client.render.util.ModelRenderUtils;
import xfacthd.framedblocks.client.util.*;
import xfacthd.framedblocks.common.blockentity.FramedDoubleBlockEntity;

import java.util.IdentityHashMap;
import java.util.Map;

@SuppressWarnings("ConstantConditions")
public final class GhostBlockRenderer
{
    private static final class_5819 RANDOM = class_5819.method_43047();
    private static ModelData MODEL_DATA;
    private static final FramedBlockData GHOST_MODEL_DATA = new FramedBlockData();
    private static final FramedBlockData GHOST_MODEL_DATA_TWO = new FramedBlockData();
    private static final Map<class_1792, GhostRenderBehaviour> RENDER_BEHAVIOURS = new IdentityHashMap<>();
    private static boolean locked = false;
    private static final GhostRenderBehaviour DEFAULT_BEHAVIOUR = new GhostRenderBehaviour() {};
    private static final String PROFILER_KEY = FramedConstants.MOD_ID + "_ghost_block";
    private static final float SCALE = 1.0001F;

    public static void init()
    {
        MODEL_DATA = ModelData.builder()
                .with(FramedBlockData.PROPERTY, GHOST_MODEL_DATA)
                .with(FramedDoubleBlockEntity.DATA_LEFT, ModelData.builder()
                        .with(FramedBlockData.PROPERTY, GHOST_MODEL_DATA)
                        .build()
                )
                .with(FramedDoubleBlockEntity.DATA_RIGHT, ModelData.builder()
                        .with(FramedBlockData.PROPERTY, GHOST_MODEL_DATA_TWO)
                        .build()
                )
                .build();

        GHOST_MODEL_DATA.setCamoState(class_2246.field_10124.method_9564());
        GHOST_MODEL_DATA_TWO.setCamoState(class_2246.field_10124.method_9564());
        GHOST_MODEL_DATA_TWO.setUseAltModel(true);

        WorldRenderEvents.LAST.register(GhostBlockRenderer::onWorldRender);
    }

    public static void onWorldRender(final WorldRenderContext context)
    {
        if (!ClientConfig.showGhostBlocks())
        {
            return;
        }

        class_3695 profiler = context.profiler();
        profiler.method_15396(PROFILER_KEY);
        try
        {
            tryDrawGhostBlock(context.matrixStack(), profiler);
        }
        catch (Throwable t)
        {
            class_128 report = class_128.method_560(t, "FramedBlocks: Rendering placement preview");

            class_129 category = report.method_562("Placement preview context");
            mc().field_1724.method_5819(category);
            category.method_578("Rotation", mc().field_1724.method_36454());
            category.method_578("Direction", mc().field_1724.method_5735());
            category.method_578("Held item", Utils.formatItemStack(mc().field_1724.method_6047()));
            category.method_578("Level", mc().field_1687);
            category.method_578("Hit result", Utils.formatHitResult(mc().field_1765));
            // Nuke pointless stacktrace spam
            category.method_580(category.method_575().length);

            throw new class_148(report);
        }
        profiler.method_15407();
    }

    private static void tryDrawGhostBlock(class_4587 poseStack, class_3695 profiler)
    {
        if (mc().field_1724.method_7325())
        {
            return;
        }
        if (!(mc().field_1765 instanceof class_3965 hit) || hit.method_17783() != class_239.class_240.field_1332)
        {
            return;
        }

        class_1799 stack = mc().field_1724.method_6047();
        if (stack.method_7960())
        {
            return;
        }

        GhostRenderBehaviour behaviour = RENDER_BEHAVIOURS.getOrDefault(stack.method_7909(), DEFAULT_BEHAVIOUR);

        profiler.method_15396("get_stack");
        class_1799 proxiedStack = behaviour.getProxiedStack(stack);
        profiler.method_15407(); //get_stack

        profiler.method_15396("may_render");
        if (!behaviour.mayRender(stack, proxiedStack))
        {
            profiler.method_15407(); //may_render
            return;
        }
        profiler.method_15407(); //may_render

        profiler.method_15396("make_context");
        class_1750 context = new class_1750(mc().field_1724, class_1268.field_5808, stack, hit);
        class_2680 hitState = mc().field_1687.method_8320(hit.method_17777());
        profiler.method_15407(); //make_context

        drawGhostBlock(poseStack, profiler, behaviour, stack, proxiedStack, hit, context, hitState, false);
    }

    private static void drawGhostBlock(
            class_4587 poseStack,
            class_3695 profiler,
            GhostRenderBehaviour behaviour,
            class_1799 stack,
            class_1799 proxiedStack,
            class_3965 hit,
            class_1750 context,
            class_2680 hitState,
            boolean secondPass
    )
    {
        profiler.method_15396("get_state");
        class_2680 renderState = behaviour.getRenderState(stack, proxiedStack, hit, context, hitState, secondPass);
        profiler.method_15407(); //get_state
        if (renderState == null)
        {
            return;
        }

        profiler.method_15396("get_pos");
        class_2338 renderPos = behaviour.getRenderPos(stack, proxiedStack, hit, context, hitState, context.method_8037(), secondPass);
        profiler.method_15405("can_render"); //get_pos
        if (!secondPass && !behaviour.canRenderAt(stack, proxiedStack, hit, context, hitState, renderState, renderPos))
        {
            profiler.method_15407(); //can_render
            return;
        }
        profiler.method_15407(); //can_render

        profiler.method_15396("get_camo");
        CamoPair camo = behaviour.readCamo(stack, proxiedStack, secondPass);
        camo = behaviour.postProcessCamo(stack, proxiedStack, context, renderState, secondPass, camo);
        GHOST_MODEL_DATA.setCamoState(camo.getCamoOne());
        GHOST_MODEL_DATA_TWO.setCamoState(camo.getCamoTwo());
        profiler.method_15407(); //get_camo

        profiler.method_15396("append_modeldata");
        ModelData modelData = behaviour.appendModelData(stack, proxiedStack, context, renderState, secondPass, MODEL_DATA);
        profiler.method_15407(); //append_modeldata

        class_4597.class_4598 buffers = mc().method_22940().method_23000();

        doRenderGhostBlock(poseStack, buffers, profiler, renderPos, renderState, modelData);

        GHOST_MODEL_DATA.setCamoState(class_2246.field_10124.method_9564());
        GHOST_MODEL_DATA_TWO.setCamoState(class_2246.field_10124.method_9564());

        if (!secondPass && behaviour.hasSecondBlock(stack, proxiedStack))
        {
            drawGhostBlock(poseStack, profiler, behaviour, stack, proxiedStack, hit, context, hitState, true);
        }
    }

    private static void doRenderGhostBlock(
            class_4587 poseStack,
            class_4597.class_4598 buffers,
            class_3695 profiler,
            class_2338 renderPos,
            class_2680 renderState,
            ModelData modelData
    )
    {
        class_1921 bufferType = ClientConfig.altGhostRenderer() ?
                class_4722.method_24076() :
                ForgeRenderTypes.TRANSLUCENT_ON_PARTICLES_TARGET.get();

        profiler.method_15396("buffer");
        class_243 offset = class_243.method_24954(renderPos).method_1020(mc().field_1773.method_19418().method_19326());
        class_4588 builder = new GhostVertexConsumer(buffers.getBuffer(bufferType), 0xAA);
        profiler.method_15407(); //buffer

        profiler.method_15396("draw");
        class_1087 model = ModelCache.getModel(renderState);
        Object data = resolveRenderData(model, modelData);
        poseStack.method_22903();
        poseStack.method_22904(offset.field_1352 + .5, offset.field_1351 + .5, offset.field_1350 + .5);
        poseStack.method_22905(SCALE, SCALE, SCALE); // Scale up very slightly to avoid z-fighting with replaceable blocks like snow layers
        poseStack.method_46416(-.5F, -.5F, -.5F);
        for (class_1921 type : ModelRenderUtils.getRenderTypes(model, renderState, RANDOM, data))
        {
            ModelRenderUtils.emitModelQuads(
                    poseStack,
                    builder,
                    renderState,
                    renderPos,
                    mc().field_1687,
                    RANDOM,
                    model,
                    data,
                    class_761.method_23794(mc().field_1687, renderPos),
                    class_4608.field_21444,
                    type
            );
        }
        poseStack.method_22909();
        profiler.method_15407(); //draw

        profiler.method_15396("upload");
        RenderSystem.enableCull();
        buffers.method_22994(bufferType);
        profiler.method_15407(); //upload
    }

    private static Object resolveRenderData(class_1087 model, ModelData modelData)
    {
        FramedBlockData frame = modelData.get(FramedBlockData.PROPERTY);
        if (model instanceof FramedDoubleBlockModel)
        {
            ModelData dataLeft = (ModelData) modelData.get(FramedDoubleBlockEntity.DATA_LEFT);
            ModelData dataRight = (ModelData) modelData.get(FramedDoubleBlockEntity.DATA_RIGHT);
            FramedBlockData left = dataLeft != null ? dataLeft.get(FramedBlockData.PROPERTY) : frame;
            FramedBlockData right = dataRight != null ? dataRight.get(FramedBlockData.PROPERTY) : frame;
            return new FramedDoubleBlockData(left, right);
        }
        return frame;
    }



    public static synchronized void registerBehaviour(GhostRenderBehaviour behaviour, class_2248... blocks)
    {
        Preconditions.checkState(!locked, "GhostRenderBehaviour registry is locked!");

        Preconditions.checkNotNull(behaviour, "GhostRenderBehaviour must be non-null");
        Preconditions.checkNotNull(blocks, "Blocks array must be non-null to register a GhostRenderBehaviour");
        Preconditions.checkArgument(blocks.length > 0, "At least one block must be provided to register a GhostRenderBehaviour");

        for (class_2248 block : blocks)
        {
            class_1792 item = block.method_8389();
            Preconditions.checkState(item instanceof class_1747, "Block must have an associated BlockItem");
            registerBehaviour(behaviour, item);
        }
    }

    public static synchronized void registerBehaviour(GhostRenderBehaviour behaviour, class_1792... items)
    {
        Preconditions.checkState(!locked, "GhostRenderBehaviour registry is locked!");

        Preconditions.checkNotNull(behaviour, "GhostRenderBehaviour must be non-null");
        Preconditions.checkNotNull(items, "Items array must be non-null to register a GhostRenderBehaviour");
        Preconditions.checkArgument(items.length > 0, "At least one item must be provided to register a GhostRenderBehaviour");

        for (class_1792 item : items)
        {
            RENDER_BEHAVIOURS.put(item, behaviour);
        }
    }

    public static GhostRenderBehaviour getBehaviour(class_1792 item)
    {
        return RENDER_BEHAVIOURS.getOrDefault(item, DEFAULT_BEHAVIOUR);
    }

    public static void lockRegistration()
    {
        locked = true;
    }

    private static class_310 mc()
    {
        return class_310.method_1551();
    }



    private GhostBlockRenderer() { }
}
