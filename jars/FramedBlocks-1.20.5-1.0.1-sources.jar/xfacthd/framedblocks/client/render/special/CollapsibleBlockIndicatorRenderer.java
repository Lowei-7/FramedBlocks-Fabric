package xfacthd.framedblocks.client.render.special;

import com.mojang.blaze3d.vertex.*;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import org.joml.Matrix4f;
import xfacthd.framedblocks.api.render.OutlineRenderer;
import xfacthd.framedblocks.api.render.Quaternions;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.client.render.util.FramedRenderTypes;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.blockentity.special.FramedCollapsibleBlockEntity;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.NullableDirection;

public final class CollapsibleBlockIndicatorRenderer
{
    private static final double[] VERTEX_NO_OFFSET = new double[] { 1D, 1D, 1D, 1D };

    public static void register()
    {
        WorldRenderEvents.BLOCK_OUTLINE.register(CollapsibleBlockIndicatorRenderer::onBlockOutline);
    }

    public static boolean onBlockOutline(WorldRenderContext world, WorldRenderContext.BlockOutlineContext event)
    {
        //noinspection ConstantConditions
        class_1799 heldItem = class_310.method_1551().field_1724.method_6047();
        if (heldItem.method_7909() != FBContent.ITEM_FRAMED_HAMMER.get())
        {
            return true;
        }

        class_1937 level = class_310.method_1551().field_1687;
        //noinspection ConstantConditions
        class_2680 state = level.method_8320(event.blockPos());
        if (state.method_26204() != FBContent.BLOCK_FRAMED_COLLAPSIBLE_BLOCK.get())
        {
            return true;
        }

        class_239 hit = class_310.method_1551().field_1765;
        if (!(hit instanceof class_3965 blockHit))
        {
            return true;
        }

        NullableDirection face = state.method_11654(PropertyHolder.NULLABLE_FACE);
        class_2350 faceDir = blockHit.method_17780();
        if (face != NullableDirection.NONE && face.toDirection() != faceDir)
        {
            return true;
        }

        class_2338 pos = event.blockPos();
        class_4587 poseStack = world.matrixStack();
        class_243 offset = class_243.method_24954(pos).method_1020(world.camera().method_19326());
        class_4588 builder = world.consumers().getBuffer(FramedRenderTypes.LINES_NO_DEPTH);

        poseStack.method_22903();
        poseStack.method_22904(offset.field_1352 + .5, offset.field_1351 + .5, offset.field_1350 + .5);
        if (faceDir == class_2350.field_11033)
        {
            poseStack.method_22907(Quaternions.XP_180);
        }
        else if (faceDir != class_2350.field_11036)
        {
            poseStack.method_22907(OutlineRenderer.YN_DIR[faceDir.method_10161()]);
            poseStack.method_22907(Quaternions.XP_90);
        }
        poseStack.method_22904(-.5, -.5, -.5);

        double[] vY = getVertexHeights(level, pos, face);
        drawSectionOverlay(builder, poseStack, vY);
        drawCornerMarkers(builder, poseStack, faceDir, blockHit, vY);

        poseStack.method_22909();
        return true;
    }

    private static double[] getVertexHeights(class_1937 level, class_2338 pos, NullableDirection face)
    {
        if (face == NullableDirection.NONE || !(level.method_8321(pos) instanceof FramedCollapsibleBlockEntity be))
        {
            return VERTEX_NO_OFFSET;
        }
        byte[] offsets = be.getVertexOffsets();
        return new double[] {
                1D - (offsets[0] / 16D),
                1D - (offsets[1] / 16D),
                1D - (offsets[2] / 16D),
                1D - (offsets[3] / 16D)
        };
    }

    private static void drawSectionOverlay(class_4588 builder, class_4587 poseStack, double[] vY)
    {
        double cenx = class_3532.method_16436(.5, vY[0], vY[1]); // center edge negative X
        double cepx = class_3532.method_16436(.5, vY[3], vY[2]); // center edge positive X
        double cenz = class_3532.method_16436(.5, vY[0], vY[3]); // center edge negative Z
        double cepz = class_3532.method_16436(.5, vY[1], vY[2]); // center edge positive Z

        double cinx = class_3532.method_16436(.25, cenx, cepx); // center inset negative X
        double cipx = class_3532.method_16436(.75, cenx, cepx); // center inset positive X
        double cinz = class_3532.method_16436(.25, cenz, cepz); // center inset negative Z
        double cipz = class_3532.method_16436(.75, cenz, cepz); // center inset positive Z

        drawLine(builder, poseStack,  .5, cenz,   0,  .5, cinz, .25);
        drawLine(builder, poseStack,  .5, cipz, .75,  .5, cepz,   1);
        drawLine(builder, poseStack,   0, cenx,  .5, .25, cinx,  .5);
        drawLine(builder, poseStack, .75, cipx,  .5,   1, cepx,  .5);

        drawLine(builder, poseStack, .5, cinz, .25, .25, cinx, .5);
        drawLine(builder, poseStack, .5, cinz, .25, .75, cipx, .5);
        drawLine(builder, poseStack, .5, cipz, .75, .25, cinx, .5);
        drawLine(builder, poseStack, .5, cipz, .75, .75, cipx, .5);
    }

    private static void drawCornerMarkers(
            class_4588 builder, class_4587 poseStack, class_2350 faceDir, class_3965 hit, double[] vY
    )
    {
        int vert = FramedCollapsibleBlockEntity.vertexFromHit(faceDir, Utils.fraction(hit.method_17784()));
        if (vert == 0 || vert == 4)
        {
            drawCubeFrame(builder, poseStack,  0.25/16D,  0.25/16D, vY[0]);
        }
        if (vert == 1 || vert == 4)
        {
            drawCubeFrame(builder, poseStack,  0.25/16D, 15.75/16D, vY[1]);
        }
        if (vert == 2 || vert == 4)
        {
            drawCubeFrame(builder, poseStack, 15.75/16D, 15.75/16D, vY[2]);
        }
        if (vert == 3 || vert == 4)
        {
            drawCubeFrame(builder, poseStack, 15.75/16D,  0.25/16D, vY[3]);
        }
    }

    private static void drawCubeFrame(
            class_4588 builder, class_4587 poseStack, double x, double z, double vY
    )
    {
        double minX = x - .5D/16D;
        double maxX = x + .5D/16D;
        double minZ = z - .5D/16D;
        double maxZ = z + .5D/16D;

        double minY = vY - .75/16D;
        double maxY = vY + .25/16D;

        // Bottom
        drawLine(builder, poseStack, minX, minY, minZ, minX, minY, maxZ);
        drawLine(builder, poseStack, minX, minY, minZ, maxX, minY, minZ);
        drawLine(builder, poseStack, maxX, minY, minZ, maxX, minY, maxZ);
        drawLine(builder, poseStack, minX, minY, maxZ, maxX, minY, maxZ);

        // Top
        drawLine(builder, poseStack, minX, maxY, minZ, minX, maxY, maxZ);
        drawLine(builder, poseStack, minX, maxY, minZ, maxX, maxY, minZ);
        drawLine(builder, poseStack, maxX, maxY, minZ, maxX, maxY, maxZ);
        drawLine(builder, poseStack, minX, maxY, maxZ, maxX, maxY, maxZ);

        // Vertical
        drawLine(builder, poseStack, minX, minY, minZ, minX, maxY, minZ);
        drawLine(builder, poseStack, minX, minY, maxZ, minX, maxY, maxZ);
        drawLine(builder, poseStack, maxX, minY, minZ, maxX, maxY, minZ);
        drawLine(builder, poseStack, maxX, minY, maxZ, maxX, maxY, maxZ);
    }

    private static void drawLine(
            class_4588 builder, class_4587 poseStack, double x1, double y1, double z1, double x2, double y2, double z2
    )
    {
        float nX = (float)(x2 - x1);
        float nY = (float)(y2 - y1);
        float nZ = (float)(z2 - z1);
        float nLen = class_3532.method_15355(nX * nX + nY * nY + nZ * nZ);

        nX = nX / nLen;
        nY = nY / nLen;
        nZ = nZ / nLen;

        Matrix4f pose = poseStack.method_23760().method_23761();
        builder.method_22918(pose, (float)x1, (float)y1, (float)z1).method_22915(1f, 0F, 0F, .6F).method_23763(poseStack.method_23760(), nX, nY, nZ).method_1344();
        builder.method_22918(pose, (float)x2, (float)y2, (float)z2).method_22915(1f, 0F, 0F, .6F).method_23763(poseStack.method_23760(), nX, nY, nZ).method_1344();
    }



    private CollapsibleBlockIndicatorRenderer() { }
}
