package xfacthd.framedblocks.client.render.special;

import com.google.common.base.Preconditions;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_761;
import xfacthd.framedblocks.FramedBlocks;
import xfacthd.framedblocks.api.block.IFramedBlock;
import xfacthd.framedblocks.api.type.IBlockType;
import xfacthd.framedblocks.api.render.OutlineRenderer;
import xfacthd.framedblocks.api.util.TestProperties;
import xfacthd.framedblocks.client.util.ClientConfig;

import java.util.*;

public final class BlockOutlineRenderer
{
    private static final Map<IBlockType, OutlineRenderer> OUTLINE_RENDERERS = new HashMap<>();
    private static final Set<IBlockType> ERRORED_TYPES = new HashSet<>();
    private static boolean locked = false;

    public static void register()
    {
        WorldRenderEvents.BLOCK_OUTLINE.register(BlockOutlineRenderer::onBlockOutline);
    }

    public static boolean onBlockOutline(WorldRenderContext world, WorldRenderContext.BlockOutlineContext event)
    {
        if (!ClientConfig.fancyHitboxes() && !TestProperties.ENABLE_OCCLUSION_SHAPE_DEBUG_RENDERER)
        {
            return true;
        }

        //noinspection ConstantConditions
        class_2680 state = class_310.method_1551().field_1687.method_8320(event.blockPos());
        if (!(state.method_26204() instanceof IFramedBlock block))
        {
            return true;
        }

        class_2338 pos = event.blockPos();
        class_4587 mstack = world.matrixStack();
        class_243 offset = class_243.method_24954(pos).method_1020(world.camera().method_19326());

        if (TestProperties.ENABLE_OCCLUSION_SHAPE_DEBUG_RENDERER)
        {
            class_4588 builder = world.consumers().getBuffer(net.minecraft.class_1921.method_23594());
            class_265 shape = state.method_26201(class_310.method_1551().field_1687, pos);
            mstack.method_22903();
            mstack.method_22904(offset.field_1352, offset.field_1351, offset.field_1350);
            class_761.method_22982(mstack, builder, shape.method_1107(), 0F, 0F, 0F, .4F);
            mstack.method_22909();
            return false;
        }

        IBlockType type = block.getBlockType();
        if (!type.hasSpecialHitbox())
        {
            return true;
        }

        OutlineRenderer renderer = OUTLINE_RENDERERS.get(type);
        if (renderer == null)
        {
            if (ERRORED_TYPES.add(type))
            {
                FramedBlocks.LOGGER.error("IBlockType '{}' requests custom outline rendering but no OutlineRender was registered!", type.getName());
            }
            return true;
        }

        class_4588 builder = world.consumers().getBuffer(net.minecraft.class_1921.method_23594());

        mstack.method_22903();
        mstack.method_22904(offset.field_1352, offset.field_1351, offset.field_1350);
        mstack.method_22904(.5, .5, .5);
        renderer.rotateMatrix(mstack, state);
        mstack.method_22904(-.5, -.5, -.5);

        renderer.draw(state, class_310.method_1551().field_1687, pos, mstack, builder);

        mstack.method_22909();
        return false;
    }

    public static synchronized void registerOutlineRender(IBlockType type, OutlineRenderer render)
    {
        Preconditions.checkState(!locked, "OutlineRenderer registry is locked!");

        if (!type.hasSpecialHitbox())
        {
            throw new IllegalArgumentException(String.format(
                    "Type %s doesn't return true from IBlockType#hasSpecialHitbox()", type
            ));
        }

        OUTLINE_RENDERERS.put(type, render);
    }

    public static void lockRegistration()
    {
        locked = true;
    }

    public static boolean hasOutlineRenderer(IBlockType type)
    {
        return OUTLINE_RENDERERS.containsKey(type);
    }



    private BlockOutlineRenderer() { }
}
