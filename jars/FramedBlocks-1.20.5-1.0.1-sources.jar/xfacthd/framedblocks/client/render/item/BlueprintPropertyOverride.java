package xfacthd.framedblocks.client.render.item;

import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.mixin.ItemPropertiesInvoker;

public final class BlueprintPropertyOverride
{
    public static final class_2960 HAS_DATA = Utils.rl("blueprint_override");

    private BlueprintPropertyOverride() { }

    public static void register()
    {
        ItemPropertiesInvoker.framedblocks$register(
                FBContent.ITEM_FRAMED_BLUEPRINT.get(),
                HAS_DATA,
                (stack, level, entity, seed) ->
                {
                    class_2487 tag = null;
                    class_9279 customData = stack.method_57824(class_9334.field_49628);
                    if (customData != null && customData.method_57450("blueprint_data"))
                    {
                        tag = customData.method_57463().method_10562("blueprint_data");
                    }
                    return tag != null && !tag.method_33133() ? 1 : 0;
                }
        );
    }
}