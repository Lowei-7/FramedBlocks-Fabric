package xfacthd.framedblocks.client.render.block;

import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Table;
import net.minecraft.client.renderer.blockentity.*;
import net.minecraft.class_1087;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_4722;
import net.minecraft.class_5614;
import net.minecraft.class_5819;
import net.minecraft.class_761;
import net.minecraft.class_773;
import net.minecraft.class_7833;
import net.minecraft.class_827;
import net.minecraft.client.renderer.*;
import net.minecraftforge.client.RenderTypeHelper;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.model.FramedBlockModel;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.api.util.ClientUtils;
import xfacthd.framedblocks.client.model.cube.FramedChestLidModel;
import xfacthd.framedblocks.client.render.util.ModelRenderUtils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.data.*;
import xfacthd.framedblocks.common.blockentity.special.FramedChestBlockEntity;
import xfacthd.framedblocks.common.data.property.ChestState;
import xfacthd.framedblocks.common.data.property.LatchType;

import java.util.*;

public class FramedChestRenderer implements class_827<FramedChestBlockEntity>
{
    private static final Table<class_2350, LatchType, FramedBlockModel> LID_MODELS = HashBasedTable.create(4, 3);
    private static final class_5819 RANDOM = class_5819.method_43047();

    @SuppressWarnings("unused")
    public FramedChestRenderer(class_5614.class_5615 ctx) { }

    @Override
    public void render(
            FramedChestBlockEntity be,
            float partialTicks,
            class_4587 poseStack,
            class_4597 buffer,
            int light,
            int overlay
    )
    {
        class_2680 state = be.method_11010();

        ChestState chestState = state.method_11654(PropertyHolder.CHEST_STATE);
        if (chestState == ChestState.CLOSED)
        {
            return;
        }

        class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
        long lastChange = be.getLastChangeTime(chestState);

        class_1087 model = LID_MODELS.get(dir, state.method_11654(PropertyHolder.LATCH_TYPE));
        Object data = be.getRenderAttachmentData();

        float angle = calculateAngle(be, chestState, dir, lastChange, partialTicks);

        float xOff = Utils.isX(dir) ? (Utils.isPositive(dir) ? 1F/16F : 15F/16F) : 0;
        float zOff = Utils.isZ(dir) ? (Utils.isPositive(dir) ? 1F/16F : 15F/16F) : 0;

        poseStack.method_22903();

        poseStack.method_46416(xOff, 9F/16F, zOff);
        poseStack.method_22907(Utils.isX(dir) ? class_7833.field_40718.rotationDegrees(angle) : class_7833.field_40713.rotationDegrees(angle));
        poseStack.method_46416(-xOff, -9F/16F, -zOff);

        renderLidModel(be, state, poseStack, buffer, model, data);

        poseStack.method_22909();
    }

    private static void renderLidModel(
            FramedChestBlockEntity be,
            class_2680 state,
            class_4587 matrix,
            class_4597 buffer,
            class_1087 model,
            Object data
    )
    {
        //noinspection ConstantConditions
        int light = class_761.method_23794(be.method_10997(), be.method_11016());

        RANDOM.method_43052(42);
        for (class_1921 type : ModelRenderUtils.getRenderTypes(model, state, RANDOM, data))
        {
            class_1921 bufferType = type == class_1921.method_23577() ? class_4722.method_24073() : RenderTypeHelper.getEntityRenderType(type, false);

            ModelRenderUtils.emitModelQuads(
                    matrix,
                    buffer.getBuffer(bufferType),
                    state,
                    be.method_11016(),
                    be.method_10997(),
                    RANDOM,
                    model,
                    data,
                    light,
                    class_4608.field_21444,
                    type
            );
        }
    }

    private static float calculateAngle(
            FramedChestBlockEntity be, ChestState chestState, class_2350 dir, long lastChange, float partialTicks
    )
    {
        //noinspection ConstantConditions
        float diff = (float) (be.method_10997().method_8510() - lastChange) + partialTicks;

        float factor = class_3532.method_16439(diff / 10F, 0, 1);
        if (chestState == ChestState.CLOSING) { factor = 1F - factor; }

        factor = 1.0F - factor;
        factor = 1.0F - factor * factor * factor;

        float angle = class_3532.method_15363(factor * 90F, 0F, 90F);
        if (!Utils.isPositive(dir)) { angle *= -1F; }

        return angle;
    }

    @Override
    public boolean shouldRender(FramedChestBlockEntity be, class_243 camera)
    {
        return !ClientUtils.OPTIFINE_LOADED.get() && class_827.super.method_33892(be, camera);
    }



    public static void onModelsLoaded(Map<class_2960, class_1087> registry)
    {
        for (class_2350 dir : class_2350.class_2353.field_11062)
        {
            for (LatchType latch : LatchType.values())
            {
                class_2680 state = FBContent.BLOCK_FRAMED_CHEST.get().method_9564()
                        .method_11657(FramedProperties.FACING_HOR, dir)
                        .method_11657(PropertyHolder.LATCH_TYPE, latch);

                class_2960 location = class_773.method_3340(state);

                class_1087 model = registry.get(location);
                if (model instanceof FramedBlockModel fbModel)
                {
                    model = fbModel.getBaseModel();
                }
                LID_MODELS.put(dir, latch, new FramedChestLidModel(state, model));
            }
        }
    }

    public static void clearModelCaches()
    {
        for (FramedBlockModel model : LID_MODELS.values())
        {
            if (model != null)
            {
                model.clearCache();
            }
        }
    }
}