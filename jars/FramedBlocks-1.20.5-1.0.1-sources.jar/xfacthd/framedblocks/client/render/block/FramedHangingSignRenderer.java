package xfacthd.framedblocks.client.render.block;

import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_5614;
import net.minecraft.class_7833;
import org.joml.Vector3f;
import xfacthd.framedblocks.common.block.sign.AbstractFramedSignBlock;

public class FramedHangingSignRenderer extends FramedSignRenderer
{
    private static final float TEXT_RENDER_SCALE = 0.9F;
    private static final Vector3f TEXT_OFFSET = new Vector3f(0.1F/16F, -5.12F/16F, 1.024F/16F);

    public FramedHangingSignRenderer(class_5614.class_5615 ctx)
    {
        super(ctx);
    }

    @Override
    protected void applyTransforms(class_4587 poseStack, float yRot, class_2680 state)
    {
        poseStack.method_22904(0.5D, 0.9375D, 0.5D);
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(yRot));
        poseStack.method_46416(0.0F, -0.3125F, 0.0F);
    }

    @Override
    protected float getSignTextRenderScale()
    {
        return TEXT_RENDER_SCALE;
    }

    @Override
    protected Vector3f getTextOffset(AbstractFramedSignBlock signBlock)
    {
        return TEXT_OFFSET;
    }
}
