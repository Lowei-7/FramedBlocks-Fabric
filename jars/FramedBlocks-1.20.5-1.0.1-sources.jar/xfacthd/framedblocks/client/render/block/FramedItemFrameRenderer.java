package xfacthd.framedblocks.client.render.block;

import net.minecraft.class_1799;
import net.minecraft.class_1806;
import net.minecraft.class_22;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2741;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_3965;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5614;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_827;
import net.minecraft.class_918;
import net.minecraft.class_9209;
import net.minecraft.class_9334;
import net.minecraft.world.item.*;
import org.joml.Matrix4f;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.blockentity.special.FramedItemFrameBlockEntity;

public class FramedItemFrameRenderer implements class_827<FramedItemFrameBlockEntity>
{
    private static final double ITEM_Z_OFF = 0.4375D;
    private static final float DIR_OFF_MULT = 0.49875F;
    private static final float MAP_SCALE = 0.0078125F;
    private static final double MAX_NAMETAG_DIST_SQR = 64D * 64D;

    private final class_918 itemRenderer;

    public FramedItemFrameRenderer(class_5614.class_5615 ctx)
    {
        itemRenderer = ctx.method_43335();
    }

    @Override
    public void render(
            FramedItemFrameBlockEntity be,
            float partialTick,
            class_4587 poseStack,
            class_4597 buffer,
            int packedLight,
            int packedOverlay
    )
    {
        poseStack.method_22903();

        class_2350 dir = be.method_11010().method_11654(class_2741.field_12525).method_10153();
        float dirOff = Utils.isPositive(dir) ? 0 : 1;
        poseStack.method_46416(
                dir.method_10148() * DIR_OFF_MULT + (Utils.isX(dir) ? dirOff : .5F),
                dir.method_10164() * DIR_OFF_MULT + (Utils.isY(dir) ? dirOff : .5F),
                dir.method_10165() * DIR_OFF_MULT + (Utils.isZ(dir) ? dirOff : .5F)
        );

        boolean vert = Utils.isY(dir);
        float yRot = vert ? 0 : dir.method_10144();
        if (vert)
        {
            poseStack.method_22907(class_7833.field_40714.rotationDegrees(-90F * dir.method_10171().method_10181()));
        }
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(180.0F - yRot));

        class_1799 item = be.getItem();
        //noinspection ConstantConditions
        class_22 mapData = class_1806.method_8001(item, be.method_10997());

        poseStack.method_22904(0.0D, 0.0D, ITEM_Z_OFF);
        float itemRotation = mapData != null ? (be.getRotation() % 4 * 2) : be.getRotation();
        poseStack.method_22907(class_7833.field_40718.rotationDegrees(itemRotation * 360.0F / 8.0F));

        if (mapData != null)
        {
            poseStack.method_22907(class_7833.field_40718.rotationDegrees(180.0F));

            poseStack.method_22905(MAP_SCALE, MAP_SCALE, MAP_SCALE);
            poseStack.method_22904(-64.0D, -64.0D, -1.0D);

            int mapLight = be.isGlowingFrame() ? 0x00F000D2 : packedLight;
            class_9209 mapId = item.method_57824(class_9334.field_49646);
            class_310.method_1551().field_1773.method_3194().method_1773(poseStack, buffer, mapId, mapData, true, mapLight);
        }
        else
        {
            poseStack.method_22905(0.5F, 0.5F, 0.5F);

            int itemLight = be.isGlowingFrame() ? 0x00F000F0 : packedLight;
            itemRenderer.method_23178(item, class_811.field_4319, itemLight, class_4608.field_21444, poseStack, buffer, be.method_10997(), 0);
        }

        poseStack.method_22909();

        renderCustomItemName(be, poseStack, buffer, packedLight);
    }

    private static void renderCustomItemName(FramedItemFrameBlockEntity be, class_4587 poseStack, class_4597 buffer, int packedLight)
    {
        class_1799 stack = be.getItem();

        if (!class_310.method_1498() || stack.method_7960() || !stack.method_57826(class_9334.field_49631)) return;
        if (!(class_310.method_1551().field_1765 instanceof class_3965 hitResult)) return;
        if (!be.method_11016().equals(hitResult.method_17777())) return;

        class_4184 camera = class_310.method_1551().field_1773.method_19418();
        double dist = camera.method_19326().method_1025(hitResult.method_17784());
        if (dist > MAX_NAMETAG_DIST_SQR) return;

        class_2350 dir = be.method_11010().method_11654(class_2741.field_12525);
        float dx = .5F + (dir.method_10148() * .46875F) - (dir.method_10148() * .3F);
        float dz = .5F + (dir.method_10165() * .46875F) - (dir.method_10165() * .3F);

        poseStack.method_22903();
        poseStack.method_46416(dx, 1.25F, dz);
        poseStack.method_22907(camera.method_23767());
        poseStack.method_22905(-0.025F, -0.025F, 0.025F);

        class_327 font = class_310.method_1551().field_1772;
        class_2561 name = stack.method_7964();

        Matrix4f pose = poseStack.method_23760().method_23761();
        int alpha = (int)(class_310.method_1551().field_1690.method_19343(0.25F) * 255.0F) << 24;
        float x = -font.method_27525(name) / 2F;

        font.method_30882(name, x, 0F, 553648127, false, pose, buffer, class_327.class_6415.field_33994, alpha, packedLight);
        font.method_30882(name, x, 0F, -1, false, pose, buffer, class_327.class_6415.field_33993, 0, packedLight);

        poseStack.method_22909();
    }

    @Override
    public boolean shouldRender(FramedItemFrameBlockEntity be, class_243 cameraPos)
    {
        return be.hasItem() && class_827.super.method_33892(be, cameraPos);
    }
}
