package xfacthd.framedblocks.client.render.block;

import net.minecraft.class_1297;
import net.minecraft.class_1767;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5253;
import net.minecraft.class_5481;
import net.minecraft.class_5614;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_8242;
import net.minecraft.class_827;
import net.minecraft.client.renderer.blockentity.*;
import net.minecraft.util.*;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import xfacthd.framedblocks.api.render.Quaternions;
import xfacthd.framedblocks.common.block.sign.AbstractFramedSignBlock;
import xfacthd.framedblocks.common.block.sign.FramedStandingSignBlock;
import xfacthd.framedblocks.common.blockentity.special.FramedSignBlockEntity;

import java.util.List;

public class FramedSignRenderer implements class_827<FramedSignBlockEntity>
{
    private static final int OUTLINE_RENDER_DISTANCE = class_3532.method_34954(16);
    private static final float RENDER_SCALE = 0.6666667F;
    private static final Vector3f TEXT_OFFSET = new Vector3f(0F, 5.6F/16F, 1.024F/16F);
    private static final Vector3f WALL_TEXT_OFFSET = new Vector3f(0F, 5.35F/16F, 1.024F/16F);

    private final class_327 font;

    public FramedSignRenderer(class_5614.class_5615 ctx)
    {
        font = ctx.method_32143();
    }

    @Override
    public void render(
            FramedSignBlockEntity sign,
            float partialTicks,
            class_4587 poseStack,
            class_4597 buffer,
            int light,
            int overlay
    )
    {
        class_2680 state = sign.method_11010();
        if (!(state.method_26204() instanceof AbstractFramedSignBlock signBlock))
        {
            return;
        }

        class_2338 pos = sign.method_11016();
        int lineHeight = signBlock.getTextLineHeight();
        int lineWidth = signBlock.getMaxTextLineWidth();

        poseStack.method_22903();
        applyTransforms(poseStack, -signBlock.getYRotationDegrees(state), state);
        renderText(pos, signBlock, sign.getFrontText(), poseStack, buffer, light, lineHeight, lineWidth, true);
        renderText(pos, signBlock, sign.getBackText(), poseStack, buffer, light, lineHeight, lineWidth, false);
        poseStack.method_22909();
    }

    protected void applyTransforms(class_4587 poseStack, float yRot, class_2680 state)
    {
        poseStack.method_46416(.5F, .75F * RENDER_SCALE, .5F);
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(yRot));
        if (!(state.method_26204() instanceof FramedStandingSignBlock))
        {
            poseStack.method_46416(0F, -5F/16F, -7F/16F);
        }
    }

    private void applyTextTransforms(class_4587 poseStack, AbstractFramedSignBlock signBlock, boolean front)
    {
        if (!front)
        {
            poseStack.method_22907(Quaternions.YP_180);
        }

        Vector3f offset = getTextOffset(signBlock);
        poseStack.method_46416(offset.x, offset.y, offset.z);
        float scale = 0.015625F * getSignTextRenderScale();
        poseStack.method_22905(scale, -scale, scale);
    }

    protected float getSignTextRenderScale()
    {
        return RENDER_SCALE;
    }

    protected Vector3f getTextOffset(AbstractFramedSignBlock signBlock)
    {
        boolean standing = signBlock instanceof FramedStandingSignBlock;
        return standing ? TEXT_OFFSET : WALL_TEXT_OFFSET;
    }

    private void renderText(
            class_2338 pos,
            AbstractFramedSignBlock signBlock,
            class_8242 text,
            class_4587 poseStack,
            class_4597 buffer,
            int light,
            int lineHeight,
            int lineWidth,
            boolean front
    )
    {
        poseStack.method_22903();
        applyTextTransforms(poseStack, signBlock, front);

        int darkColor = getDarkTextColor(text);
        int textColor;
        boolean outline;
        int textLight;
        if (text.method_49856())
        {
            textColor = text.method_49872().method_16357();
            outline = showOutline(pos, textColor);
            textLight = class_765.field_32767;
        }
        else
        {
            textColor = darkColor;
            outline = false;
            textLight = light;
        }

        boolean filter = class_310.method_1551().method_33883();
        class_5481[] lines = text.method_49868(filter, line ->
        {
            List<class_5481> parts = font.method_1728(line, lineWidth);
            return parts.isEmpty() ? class_5481.field_26385 : parts.get(0);
        });

        int centerY = 4 * lineHeight / 2;
        Matrix4f pose = poseStack.method_23760().method_23761();
        for (int idx = 0; idx < 4; ++idx)
        {
            class_5481 line = lines[idx];
            float textX = (float) -font.method_30880(line) / 2;
            float textY = idx * lineHeight - centerY;
            if (outline)
            {
                font.method_37296(line, textX, textY, textColor, darkColor, pose, buffer, textLight);
            }
            else
            {
                font.method_22942(line, textX, textY, textColor, false, pose, buffer, class_327.class_6415.field_33995, 0, textLight);
            }
        }

        poseStack.method_22909();
    }

    private static int getDarkTextColor(class_8242 text)
    {
        int color = text.method_49872().method_16357();
        if (color == class_1767.field_7963.method_16357() && text.method_49856())
        {
            return 0xFFF0EBCC;
        }

        int r = (int) ((double) class_5253.class_5254.method_27765(color) * 0.4D);
        int g = (int) ((double) class_5253.class_5254.method_27766(color) * 0.4D);
        int b = (int) ((double) class_5253.class_5254.method_27767(color) * 0.4D);
        return class_5253.class_5254.method_27764(0, r, g, b);
    }

    private static boolean showOutline(class_2338 pos, int textColor)
    {
        if (textColor == class_1767.field_7963.method_16357())
        {
            return true;
        }

        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null && mc.field_1690.method_31044().method_31034() && mc.field_1724.method_31550())
        {
            return true;
        }
        else
        {
            class_1297 camera = mc.method_1560();
            return camera != null && camera.method_5707(class_243.method_24953(pos)) < (double) OUTLINE_RENDER_DISTANCE;
        }
    }
}
