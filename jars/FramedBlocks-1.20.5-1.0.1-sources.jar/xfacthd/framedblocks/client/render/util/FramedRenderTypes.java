package xfacthd.framedblocks.client.render.util;

import java.util.OptionalDouble;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_4668;

public final class FramedRenderTypes extends class_1921
{
    public static final class_1921 LINES_NO_DEPTH = method_24049(
            "lines",
            class_290.field_29337,
            class_293.class_5596.field_27377,
            256,
            false,
            false,
            class_1921.class_4688.method_23598()
                    .method_34578(field_29433)
                    .method_23609(new class_4668.class_4677(OptionalDouble.empty()))
                    .method_23607(field_22241)
                    .method_23615(field_21370)
                    .method_23610(field_25643)
                    .method_23616(field_21349)
                    .method_23603(field_21345)
                    .method_23604(field_21346)
                    .method_23617(false)
    );



    private FramedRenderTypes()
    {
        //noinspection ConstantConditions
        super("", null, null, 0, false, false, null, null);
        throw new UnsupportedOperationException();
    }
}
