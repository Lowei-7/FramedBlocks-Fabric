package xfacthd.framedblocks.client.render.util;

import net.minecraft.class_4588;
import net.minecraftforge.client.model.pipeline.VertexConsumerWrapper;

public final class GhostVertexConsumer extends VertexConsumerWrapper
{
    private final int alpha;

    public GhostVertexConsumer(class_4588 wrapped, int alpha)
    {
        super(wrapped);
        this.alpha = alpha;
    }

    @Override
    public class_4588 method_1336(int red, int green, int blue, int alpha)
    {
        return parent.method_1336(red, green, blue, (alpha * this.alpha) / 0xFF);
    }
}