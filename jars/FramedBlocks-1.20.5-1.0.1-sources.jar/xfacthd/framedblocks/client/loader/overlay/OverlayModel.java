package xfacthd.framedblocks.client.loader.overlay;

import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import net.minecraftforge.client.model.BakedModelWrapper;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;
import xfacthd.framedblocks.api.model.quad.Modifiers;
import xfacthd.framedblocks.api.model.quad.QuadModifier;

import java.util.*;

final class OverlayModel extends BakedModelWrapper<class_1087>
{
    private final List<class_777> unculledQuads;
    private final Map<class_2350, List<class_777>> culledQuads;

    public OverlayModel(class_1087 model, Vector3f offset, Vector3f scale)
    {
        super(model);

        class_5819 random = class_5819.method_43047();
        unculledQuads = makeUnculledQuads(model, offset, scale, random);
        culledQuads = makeCulledQuads(model, offset, scale, random);
    }

    @Override
    public List<class_777> method_4707(@Nullable class_2680 state, @Nullable class_2350 side, class_5819 rand)
    {
        return side == null ? unculledQuads : culledQuads.get(side);
    }



    private static List<class_777> makeUnculledQuads(
            class_1087 model, Vector3f offset, Vector3f scale, class_5819 random
    )
    {
        return untranslateQuads(model.method_4707(null, null, random), offset, scale);
    }

    private static Map<class_2350, List<class_777>> makeCulledQuads(
            class_1087 model, Vector3f offset, Vector3f scale, class_5819 random
    )
    {
        Map<class_2350, List<class_777>> quadMap = new EnumMap<>(class_2350.class);
        for (class_2350 side : class_2350.values())
        {
            List<class_777> quads = model.method_4707(null, side, random);
            quadMap.put(side, untranslateQuads(quads, offset, scale));
        }
        return quadMap;
    }

    private static List<class_777> untranslateQuads(List<class_777> quads, Vector3f offset, Vector3f scale)
    {
        List<class_777> newQuads = new ArrayList<>(quads.size());

        for (class_777 quad : quads)
        {
            QuadModifier.geometry(quad)
                    .apply(Modifiers.offset(class_2350.field_11039, offset.x() * (1F / scale.x())))
                    .apply(Modifiers.offset(class_2350.field_11033, offset.y() * (1F / scale.y())))
                    .apply(Modifiers.offset(class_2350.field_11043, offset.z() * (1F / scale.z())))
                    .export(newQuads);
        }

        return newQuads;
    }
}
