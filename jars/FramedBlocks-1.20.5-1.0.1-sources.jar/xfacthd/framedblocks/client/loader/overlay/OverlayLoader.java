package xfacthd.framedblocks.client.loader.overlay;

import com.google.gson.*;
import net.minecraft.class_2960;
import net.minecraft.class_3518;
import net.minecraft.class_3532;
import net.minecraft.class_793;
import net.minecraftforge.client.model.geometry.IGeometryLoader;
import org.joml.Vector3f;
import xfacthd.framedblocks.api.util.Utils;

public final class OverlayLoader implements IGeometryLoader<OverlayGeometry>
{
    public static final class_2960 ID = Utils.rl("overlay");
    private static final Vector3f CENTER = new Vector3f(.5F, .5F, .5F);
    private static final Vector3f DEFAULT_SCALE = new Vector3f(1.001F, 1.001F, 1.001F);

    @Override
    public OverlayGeometry read(JsonObject obj, JsonDeserializationContext ctx) throws JsonParseException
    {
        class_793 model = ctx.deserialize(class_3518.method_15296(obj, "model"), class_793.class);

        Vector3f offset = OverlayGeometry.VEC_ZERO;
        Vector3f scale = new Vector3f(DEFAULT_SCALE);

        if (obj.has("center"))
        {
            JsonArray arr = class_3518.method_15261(obj, "center");
            if (arr.size() != 3)
            {
                throw new JsonSyntaxException("Invalid center array, expected exactly three elements");
            }

            Vector3f center = new Vector3f(
                    class_3518.method_15269(arr.get(0), "center[0]") / 16F,
                    class_3518.method_15269(arr.get(1), "center[1]") / 16F,
                    class_3518.method_15269(arr.get(2), "center[2]") / 16F
            );

            offset = new Vector3f(CENTER);
            offset.sub(center);

            // Slightly skew the scale to avoid z-fighting on off-center models
            Vector3f scaleAdd = new Vector3f(.01F, .01F, .01F);
            scaleAdd.mul(class_3532.method_15379(offset.x()), class_3532.method_15379(offset.y()), class_3532.method_15379(offset.z()));
            scale.add(scaleAdd);
        }

        return new OverlayGeometry(model, offset, scale);
    }
}
