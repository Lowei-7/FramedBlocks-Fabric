package xfacthd.framedblocks.client.loader.overlay;

import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1100;
import net.minecraft.class_2960;
import net.minecraft.class_3665;
import net.minecraft.class_4590;
import net.minecraft.class_4730;
import net.minecraft.class_7775;
import net.minecraft.class_793;
import net.minecraft.class_806;
import net.minecraft.client.renderer.block.model.*;
import net.minecraft.client.resources.model.*;
import net.minecraftforge.client.model.SimpleModelState;
import net.minecraftforge.client.model.geometry.IGeometryBakingContext;
import net.minecraftforge.client.model.geometry.IUnbakedGeometry;
import org.joml.Vector3f;

import java.util.function.Function;

record OverlayGeometry(class_793 wrapped, Vector3f offset, Vector3f scale) implements IUnbakedGeometry<OverlayGeometry>
{
    public static final Vector3f VEC_ZERO = new Vector3f();

    @Override
    public class_1087 bake(
            IGeometryBakingContext context,
            class_7775 bakery,
            Function<class_4730, class_1058> spriteGetter,
            class_3665 transform,
            class_806 overrides,
            class_2960 modelLocation
    )
    {
        class_4590 transformation = transform.method_3509().method_22933(new class_4590(offset, null, scale, null));
        transform = new SimpleModelState(transformation, transform.method_3512());

        class_1087 model = wrapped.method_3446(bakery, wrapped, spriteGetter, transform, modelLocation, true);
        return offset.equals(VEC_ZERO) ? model : new OverlayModel(model, offset, scale);
    }

    @Override
    public void resolveParents(Function<class_2960, class_1100> modelGetter, IGeometryBakingContext context)
    {
        wrapped.method_45785(modelGetter);
    }
}
