package xfacthd.framedblocks.client.util;

import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.client.screen.FramedSignScreen;
import xfacthd.framedblocks.common.blockentity.special.FramedSignBlockEntity;

import java.lang.invoke.MethodHandle;
import java.util.Objects;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_636;

public final class ClientAccess
{
    private static final MethodHandle MPGM_DESTROY_DELAY = Utils.unreflectFieldSetter(class_636.class, "field_3716", "destroyDelay");

    public static void openSignScreen(class_2338 pos, boolean front)
    {
        //noinspection ConstantConditions
        if (class_310.method_1551().field_1687.method_8321(pos) instanceof FramedSignBlockEntity be)
        {
            class_310.method_1551().method_1507(new FramedSignScreen(be, front));
        }
    }

    public static void resetDestroyDelay()
    {
        if (Objects.requireNonNull(class_310.method_1551().field_1724).method_7337())
        {
            return;
        }

        class_636 gameMode = Objects.requireNonNull(class_310.method_1551().field_1761);
        try
        {
            // 5 ticks is the delay used for continuous block breaking in creative
            MPGM_DESTROY_DELAY.invokeExact(gameMode, 5);
        }
        catch (Throwable e)
        {
            throw new RuntimeException("An error occured while resetting destroy delay", e);
        }
    }



    private ClientAccess() { }
}
