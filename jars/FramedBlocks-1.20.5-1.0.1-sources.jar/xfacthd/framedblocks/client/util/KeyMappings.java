package xfacthd.framedblocks.client.util;

import org.lwjgl.glfw.GLFW;
import xfacthd.framedblocks.FramedBlocks;
import xfacthd.framedblocks.api.block.FramedBlockEntity;
import xfacthd.framedblocks.api.util.FramedConstants;

import java.util.function.Supplier;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3965;

public final class KeyMappings
{
    public static final String KEY_CATEGORY = FramedConstants.MOD_ID + ".key.categories.framedblocks";
    public static final Supplier<class_304> KEYMAPPING_UPDATE_CULLING = () -> new class_304(FramedConstants.MOD_ID + ".key.update_cull", GLFW.GLFW_KEY_F9, KEY_CATEGORY);
    public static final Supplier<class_304> KEYMAPPING_WIPE_CACHE = () -> new class_304(FramedConstants.MOD_ID + ".key.wipe_cache", -1, KEY_CATEGORY);

    public static void onClientTick(class_310 client)
    {
        class_1937 level = client.field_1687;
        if (level == null || client.field_1755 != null)
        {
            return;
        }

        if (KEYMAPPING_UPDATE_CULLING.get().method_1436())
        {
            class_239 hit = client.field_1765;
            if (hit instanceof class_3965 blockHit && level.method_8321(blockHit.method_17777()) instanceof FramedBlockEntity be)
            {
                try
                {
                    be.updateCulling(true, true);
                }
                catch (Throwable throwable)
                {
                    FramedBlocks.LOGGER.error(
                            "Encountered unexpected exception while updating culling of " + be.method_11010().method_26204(),
                            throwable
                    );
                }

                class_2338 pos = blockHit.method_17777();
                class_2561 blockName = be.method_11010().method_26204().method_9518();

                class_2561 msg = class_2561.method_43470("Culling updated for '")
                        .method_10852(blockName)
                        .method_27693("' at ")
                        .method_10852(class_2561.method_43470(
                                String.format("{x=%d, y=%d, z=%d}", pos.method_10263(), pos.method_10264(), pos.method_10260())
                        ));

                //noinspection ConstantConditions
                client.field_1724.method_7353(msg, true);
            }
        }

        if (KEYMAPPING_WIPE_CACHE.get().method_1436())
        {
            FramedClientUtils.clearModelCaches();

            //noinspection ConstantConditions
            client.field_1724.method_7353(class_2561.method_43470("Model cache cleared"), true);
        }
    }

    private KeyMappings() { }
}
