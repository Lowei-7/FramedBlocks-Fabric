package xfacthd.framedblocks.client.util;

import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_326;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.client.model.cube.FramedTargetModel;
import xfacthd.framedblocks.common.blockentity.special.FramedTargetBlockEntity;

public final class FramedTargetBlockColor extends FramedBlockColor implements class_326
{
    public static final FramedTargetBlockColor INSTANCE = new FramedTargetBlockColor();

    private FramedTargetBlockColor() { }

    @Override
    public int getColor(class_2680 state, @Nullable class_1920 level, @Nullable class_2338 pos, int tintIndex)
    {
        if (tintIndex == FramedTargetModel.OVERLAY_TINT_IDX && level != null && pos != null)
        {
            if (level.method_8321(pos) instanceof FramedTargetBlockEntity be)
            {
                return be.getOverlayColor();
            }
        }
        return super.getColor(state, level, pos, tintIndex);
    }

    @Override
    public int getColor(class_1799 stack, int tintIndex)
    {
        if (tintIndex == FramedTargetModel.OVERLAY_TINT_IDX)
        {
            return class_1767.field_7964.method_16357();
        }
        return -1;
    }
}
