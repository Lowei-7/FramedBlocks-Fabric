package xfacthd.framedblocks.client.util;

import xfacthd.framedblocks.api.block.FramedBlockEntity;
import xfacthd.framedblocks.api.model.util.ModelUtils;
import xfacthd.framedblocks.common.blockentity.FramedDoubleBlockEntity;
import xfacthd.framedblocks.common.blockentity.special.FramedFlowerPotBlockEntity;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_322;
import org.jetbrains.annotations.Nullable;

public class FramedBlockColor implements class_322
{
    public static final FramedBlockColor INSTANCE = new FramedBlockColor();

    @Override
    public int getColor(class_2680 state, @Nullable class_1920 level, @Nullable class_2338 pos, int tintIndex)
    {
        int result = -1;
        if (level != null && pos != null)
        {
            class_2586 be = level.method_8321(pos);
            if (tintIndex < -1)
            {
                tintIndex = ModelUtils.decodeSecondaryTintIndex(tintIndex);

                if (be instanceof FramedDoubleBlockEntity dbe)
                {
                    result = dbe.getCamoTwo().getColor(level, pos, tintIndex);
                }
                else if (be instanceof FramedFlowerPotBlockEntity pbe)
                {
                    class_2680 plantState = pbe.getFlowerBlock().method_9564();
                    if (!plantState.method_26215())
                    {
                        result = class_310.method_1551().method_1505().method_1697(plantState, level, pos, tintIndex);
                    }
                }
            }
            else if (tintIndex >= 0 && be instanceof FramedBlockEntity fbe)
            {
                result = fbe.getCamo().getColor(level, pos, tintIndex);
            }
        }
        return result;
    }
}