package xfacthd.framedblocks.common.blockentity.doubled;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.blockentity.FramedDoubleBlockEntity;
import xfacthd.framedblocks.common.data.PropertyHolder;

public class FramedDoublePrismBlockEntity extends FramedDoubleBlockEntity
{
    public FramedDoublePrismBlockEntity(class_2338 pos, class_2680 state)
    {
        this(FBContent.BE_TYPE_FRAMED_DOUBLE_PRISM.get(), pos, state);
    }

    protected FramedDoublePrismBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state)
    {
        super(type, pos, state);
    }

    @Override
    protected boolean hitSecondary(class_3965 hit)
    {
        class_2350 side = hit.method_17780();

        class_2350 facing = getFacing(method_11010());
        if (side == facing)
        {
            return true;
        }
        if (side == facing.method_10153())
        {
            return false;
        }
        if (!isDoubleSide(side) && side.method_10166() != facing.method_10166())
        {
            return false;
        }

        if (isDoubleSide(side))
        {
            class_2350 horDir = side.method_35833(facing.method_10166());
            double hor = Utils.fractionInDir(hit.method_17784(), horDir);
            hor = Math.abs(hor - .5);

            double vert = Utils.fractionInDir(hit.method_17784(), facing) - .5;

            return vert > hor;
        }

        return false;
    }

    protected boolean isDoubleSide(class_2350 side)
    {
        return side.method_10166() == method_11010().method_11654(PropertyHolder.FACING_AXIS).axis();
    }

    protected class_2350 getFacing(class_2680 state)
    {
        return state.method_11654(PropertyHolder.FACING_AXIS).direction();
    }
}
