package xfacthd.framedblocks.common.blockentity.doubled;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.blockentity.FramedDoubleBlockEntity;
import xfacthd.framedblocks.common.data.PropertyHolder;

public class FramedExtendedDoubleSlopePanelBlockEntity extends FramedDoubleBlockEntity
{
    public FramedExtendedDoubleSlopePanelBlockEntity(class_2338 pos, class_2680 state)
    {
        super(FBContent.BE_TYPE_FRAMED_EXTENDED_DOUBLE_SLOPE_PANEL.get(), pos, state);
    }

    @Override
    protected boolean hitSecondary(class_3965 hit)
    {
        class_2350 face = hit.method_17780();
        class_2350 facing = method_11010().method_11654(FramedProperties.FACING_HOR);

        if (face == facing)
        {
            return false;
        }
        if (face == facing.method_10153())
        {
            return true;
        }

        class_2350 orientation = method_11010().method_11654(PropertyHolder.ROTATION).withFacing(facing);
        if (face == orientation.method_10153())
        {
            return false;
        }

        class_243 vec = Utils.fraction(hit.method_17784());

        double hor = Utils.isX(facing) ? vec.method_10216() : vec.method_10215();
        if (Utils.isPositive(facing))
        {
            hor = 1D - hor;
        }
        if (face == orientation)
        {
            return hor > .5D;
        }
        hor -= .5D;

        double vert = Utils.isY(orientation) ? vec.method_10214() : (Utils.isX(facing) ? vec.method_10215() : vec.method_10216());
        if (orientation == class_2350.field_11036 || (!Utils.isY(orientation) && Utils.isPositive(orientation)))
        {
            vert = 1F - vert;
        }
        return (hor * 2D) >= vert;
    }
}
