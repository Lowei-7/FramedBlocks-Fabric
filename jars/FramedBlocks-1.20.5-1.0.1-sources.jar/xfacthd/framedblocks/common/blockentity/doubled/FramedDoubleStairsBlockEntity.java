package xfacthd.framedblocks.common.blockentity.doubled;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.blockentity.FramedDoubleBlockEntity;

public class FramedDoubleStairsBlockEntity extends FramedDoubleBlockEntity
{
    public FramedDoubleStairsBlockEntity(class_2338 worldPosition, class_2680 blockState)
    {
        super(FBContent.BE_TYPE_FRAMED_DOUBLE_STAIRS.get(), worldPosition, blockState);
    }

    @Override
    protected boolean hitSecondary(class_3965 hit)
    {
        class_2350 facing = method_11010().method_11654(FramedProperties.FACING_HOR);
        boolean top = method_11010().method_11654(FramedProperties.TOP);
        class_2350 side = hit.method_17780();

        if (side == facing || (top && side == class_2350.field_11036) || (!top && side == class_2350.field_11033))
        {
            return false;
        }

        class_243 vec = Utils.fraction(hit.method_17784());

        if (side == facing.method_10153())
        {
            return (vec.field_1351 > .5) ^ top;
        }
        else if ((!top && side == class_2350.field_11036) || (top && side == class_2350.field_11033))
        {
            double xz = Utils.isX(facing) ? vec.field_1352 : vec.field_1350;
            boolean positive = Utils.isPositive(facing);
            return xz > .5 != positive;
        }
        else
        {
            if (vec.field_1351 > .5 == top)
            {
                return false;
            }
            double xz = Utils.isX(facing) ? vec.field_1352 : vec.field_1350;
            boolean positive = Utils.isPositive(facing);
            return xz > .5 != positive;
        }
    }
}
