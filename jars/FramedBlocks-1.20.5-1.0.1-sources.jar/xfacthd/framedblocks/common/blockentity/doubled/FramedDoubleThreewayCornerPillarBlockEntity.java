package xfacthd.framedblocks.common.blockentity.doubled;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.blockentity.FramedDoubleBlockEntity;

public class FramedDoubleThreewayCornerPillarBlockEntity extends FramedDoubleBlockEntity
{
    public FramedDoubleThreewayCornerPillarBlockEntity(class_2338 pos, class_2680 state)
    {
        super(FBContent.BE_TYPE_FRAMED_DOUBLE_THREEWAY_CORNER_PILLAR.get(), pos, state);
    }

    @Override
    protected boolean hitSecondary(class_3965 hit)
    {
        class_2350 dir = method_11010().method_11654(FramedProperties.FACING_HOR);
        boolean top = method_11010().method_11654(FramedProperties.TOP);
        class_2350 dirTwo = top ? class_2350.field_11036 : class_2350.field_11033;

        class_2350 face = hit.method_17780();
        class_243 hitVec = hit.method_17784();
        if (Utils.isY(face))
        {
            boolean overHalfPar = Utils.fractionInDir(hitVec, dir.method_10153()) > .5;
            boolean overHalfPerp = Utils.fractionInDir(hitVec, dir.method_10170()) > .5;
            return face == dirTwo ? (overHalfPar && overHalfPerp) : (overHalfPar || overHalfPerp);
        }
        else if (face.method_10166() == dir.method_10166())
        {
            boolean overHalfHor = Utils.fractionInDir(hitVec, dir.method_10170()) > .5;
            boolean overHalfVert = Utils.fractionInDir(hitVec, dirTwo.method_10153()) > .5;
            return face == dir ? (overHalfHor && overHalfVert) : (overHalfHor || overHalfVert);
        }
        else
        {
            boolean overHalfHor = Utils.fractionInDir(hitVec, dir.method_10153()) > .5;
            boolean overHalfVert = Utils.fractionInDir(hitVec, dirTwo.method_10153()) > .5;
            return face == dir.method_10160() ? (overHalfHor && overHalfVert) : (overHalfHor || overHalfVert);
        }
    }
}
