package xfacthd.framedblocks.common.blockentity.doubled;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.blockentity.FramedDoubleBlockEntity;

public class FramedStackedSlopeSlabBlockEntity extends FramedDoubleBlockEntity
{
    public FramedStackedSlopeSlabBlockEntity(class_2338 pos, class_2680 state)
    {
        super(FBContent.BE_TYPE_FRAMED_STACKED_SLOPE_SLAB.get(), pos, state);
    }

    @Override
    protected boolean hitSecondary(class_3965 hit)
    {
        boolean top = method_11010().method_11654(FramedProperties.TOP);
        if (hit.method_17780() == class_2350.field_11033)
        {
            return top;
        }

        boolean upper = hit.method_17780() == class_2350.field_11036 || class_3532.method_15385(hit.method_17784().method_10214()) >= .5F;
        return upper != top;
    }
}
