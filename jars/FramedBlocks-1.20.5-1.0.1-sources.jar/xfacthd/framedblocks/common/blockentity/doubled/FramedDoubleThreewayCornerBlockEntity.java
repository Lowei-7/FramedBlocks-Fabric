package xfacthd.framedblocks.common.blockentity.doubled;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.blockentity.FramedDoubleBlockEntity;

public class FramedDoubleThreewayCornerBlockEntity extends FramedDoubleBlockEntity
{
    public FramedDoubleThreewayCornerBlockEntity(class_2338 pos, class_2680 state)
    {
        super(FBContent.BE_TYPE_DOUBLE_FRAMED_THREEWAY_CORNER.get(), pos, state);
    }

    @Override
    protected boolean hitSecondary(class_3965 hit)
    {
        class_2350 facing = method_11010().method_11654(FramedProperties.FACING_HOR);
        boolean top = method_11010().method_11654(FramedProperties.TOP);
        class_2350 side = hit.method_17780();

        class_243 vec = Utils.fraction(hit.method_17784());

        if (top)
        {
            if (side == facing || side == class_2350.field_11036 || side == facing.method_10160())
            {
                return false;
            }

            if (side == facing.method_10170())
            {
                double hor = Utils.isX(facing) ? vec.method_10216() : vec.method_10215();
                if (!Utils.isPositive(facing))
                {
                    hor = 1D - hor;
                }
                return vec.method_10214() <= (1D - hor);
            }
            else if (side == facing.method_10153())
            {
                class_2350 dir = facing.method_10160();
                double hor = Utils.isX(dir) ? vec.method_10216() : vec.method_10215();
                if (!Utils.isPositive(dir))
                {
                    hor = 1D - hor;
                }
                return vec.method_10214() <= (1D - hor);
            }
            else if (side == class_2350.field_11033)
            {
                boolean secondary = Utils.isX(facing) ? vec.method_10216() >= vec.method_10215() : vec.method_10215() >= (1D - vec.method_10216());
                if (Utils.isPositive(facing))
                {
                    secondary = !secondary;
                }
                return secondary;
            }
        }
        else
        {
            if (side == facing || side == class_2350.field_11033 || side == facing.method_10160())
            {
                return false;
            }

            if (side == facing.method_10170())
            {
                double hor = Utils.isX(facing) ? vec.method_10216() : vec.method_10215();
                if (!Utils.isPositive(facing))
                {
                    hor = 1D - hor;
                }
                return vec.method_10214() >= hor;
            }
            else if (side == facing.method_10153())
            {
                class_2350 dir = facing.method_10160();
                double hor = Utils.isX(dir) ? vec.method_10216() : vec.method_10215();
                if (!Utils.isPositive(dir))
                {
                    hor = 1D - hor;
                }
                return vec.method_10214() >= hor;
            }
            else if (side == class_2350.field_11036)
            {
                boolean secondary = Utils.isX(facing) ? vec.method_10216() >= vec.method_10215() : vec.method_10215() >= (1D - vec.method_10216());
                if (Utils.isPositive(facing))
                {
                    secondary = !secondary;
                }
                return secondary;
            }
        }
        return false;
    }
}