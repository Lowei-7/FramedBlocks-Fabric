package xfacthd.framedblocks.common.blockentity.doubled;

import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.slab.FramedAdjustableDoubleBlock;
import xfacthd.framedblocks.common.blockentity.FramedDoubleBlockEntity;
import xfacthd.framedblocks.common.blockentity.special.*;

import java.util.Objects;
import net.minecraft.class_1657;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2487;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3545;
import net.minecraft.class_3965;
import net.minecraft.class_7225;

public class FramedAdjustableDoubleBlockEntity extends FramedDoubleBlockEntity implements ICollapsibleCopycatBlockEntity
{
    private static final int MIN_PART_HEIGHT = 1;
    private static final int MAX_PART_HEIGHT = 15;
    public static final int CENTER_PART_HEIGHT = 8;

    private final OffsetPacker offsetPacker;
    private int firstHeight = CENTER_PART_HEIGHT;

    private FramedAdjustableDoubleBlockEntity(
            class_2591<?> type,
            class_2338 pos,
            class_2680 state,
            OffsetPacker offsetPacker
    )
    {
        super(type, pos, state);
        this.offsetPacker = offsetPacker;
    }

    @Override
    protected boolean hitSecondary(class_3965 hit)
    {
        class_2350 facing = getFacing(method_11010());
        class_2350 face = hit.method_17780();
        if (face == facing.method_10153()) return false;
        if (face == facing) return true;

        int y = (int)(Utils.fractionInDir(hit.method_17784(), facing) * 16F);
        return y > firstHeight;
    }

    public boolean handleDeform(class_1657 player)
    {
        class_239 hit = player.method_5745(10D, 1F, false);
        if (!(hit instanceof class_3965 blockHit))
        {
            return false;
        }

        class_2350 facing = getFacing(method_11010());
        class_2350 faceHit = blockHit.method_17780();
        if (faceHit.method_10166() != facing.method_10166())
        {
            return false;
        }

        //noinspection ConstantConditions
        if (!field_11863.method_8608())
        {
            boolean upwards = faceHit == facing.method_10153() ^ player.method_5715();
            boolean changed = false;
            if (!upwards && firstHeight > MIN_PART_HEIGHT)
            {
                firstHeight--;
                changed = true;
            }
            else if (upwards && firstHeight < MAX_PART_HEIGHT)
            {
                firstHeight++;
                changed = true;
            }
            if (changed)
            {
                field_11863.method_8413(field_11867, method_11010(), method_11010(), class_2248.field_31036);
                method_5431();
            }
        }
        return true;
    }

    @Override
    public int getFaceOffset(class_2680 state, class_2350 side)
    {
        class_2350 facing = getFacing(method_11010());
        class_3545<class_2680, class_2680> blockPair = getBlockPair();
        if (state == blockPair.method_15442() && side == facing)
        {
            return 16 - firstHeight;
        }
        if (state == blockPair.method_15441() && side == facing.method_10153())
        {
            return firstHeight;
        }
        return 0;
    }

    @Override
    public int getPackedOffsets(class_2680 state)
    {
        class_3545<class_2680, class_2680> blockPair = getBlockPair();
        if (state == blockPair.method_15442())
        {
            return offsetPacker.pack(method_11010(), firstHeight, false);
        }
        if (state == blockPair.method_15441())
        {
            return offsetPacker.pack(method_11010(), firstHeight, true);
        }
        return 0;
    }


    private static class_2350 getFacing(class_2680 state)
    {
        return ((FramedAdjustableDoubleBlock) state.method_26204()).getFacing(state);
    }

    @Override
    protected void writeToDataPacket(class_2487 nbt)
    {
        super.writeToDataPacket(nbt);
        nbt.method_10569("first_height", firstHeight);
    }

    @Override
    protected boolean readFromDataPacket(class_2487 nbt)
    {
        boolean needUpdate = super.readFromDataPacket(nbt);

        int height = nbt.method_10550("first_height");
        if (height != firstHeight)
        {
            firstHeight = height;

            needUpdate = true;
            updateCulling(true, false);
        }

        return needUpdate;
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registries)
    {
        class_2487 nbt = super.method_16887(registries);
        nbt.method_10569("first_height", firstHeight);
        return nbt;
    }

    @Override
    public void handleUpdateTag(class_2487 nbt)
    {
        super.handleUpdateTag(nbt);
        firstHeight = nbt.method_10550("first_height");
    }

    @Override
    public void method_11007(class_2487 nbt, class_7225.class_7874 registries)
    {
        super.method_11007(nbt, registries);
        nbt.method_10569("first_height", firstHeight);
    }

    @Override
    public void method_11014(class_2487 nbt, class_7225.class_7874 registries)
    {
        super.method_11014(nbt, registries);
        firstHeight = nbt.method_10550("first_height");
    }



    public static FramedAdjustableDoubleBlockEntity standard(class_2338 pos, class_2680 state)
    {
        return new FramedAdjustableDoubleBlockEntity(
                FBContent.BE_TYPE_FRAMED_ADJ_DOUBLE_BLOCK.get(),
                pos,
                state,
                FramedAdjustableDoubleBlockEntity::getPackedOffsetsStandard
        );
    }

    public static FramedAdjustableDoubleBlockEntity copycat(class_2338 pos, class_2680 state)
    {
        return new FramedAdjustableDoubleBlockEntity(
                FBContent.BE_TYPE_FRAMED_ADJ_DOUBLE_COPYCAT_BLOCK.get(),
                pos,
                state,
                FramedAdjustableDoubleBlockEntity::getPackedOffsetsCopycat
        );
    }

    public static int getPackedOffsetsStandard(class_2680 state, int firstHeight, boolean right)
    {
        if (!right)
        {
            firstHeight = 16 - firstHeight;
        }

        int result = 0;
        for (int i = 0; i < 4; i++)
        {
            result |= (firstHeight << (i * 5));
        }
        return result;
    }

    public static int getPackedOffsetsCopycat(class_2680 state, int firstHeight, boolean right)
    {
        class_2350 facing = getFacing(state);
        if (right)
        {
            facing = facing.method_10153();
        }
        else
        {
            firstHeight = 16 - firstHeight;
        }
        return firstHeight << (facing.ordinal() * 4);
    }

    public interface OffsetPacker
    {
        int pack(class_2680 state, int firstHeight, boolean right);
    }
}