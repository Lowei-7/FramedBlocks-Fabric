package xfacthd.framedblocks.common.blockentity.doubled;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.data.PropertyHolder;

public class FramedDoubleSlopedPrismBlockEntity extends FramedDoublePrismBlockEntity
{
    public FramedDoubleSlopedPrismBlockEntity(class_2338 pos, class_2680 state)
    {
        super(FBContent.BE_TYPE_FRAMED_DOUBLE_SLOPED_PRISM.get(), pos, state);
    }

    @Override
    protected boolean isDoubleSide(class_2350 side)
    {
        return side == method_11010().method_11654(PropertyHolder.FACING_DIR).orientation();
    }

    @Override
    protected class_2350 getFacing(class_2680 state)
    {
        return state.method_11654(PropertyHolder.FACING_DIR).direction();
    }
}
