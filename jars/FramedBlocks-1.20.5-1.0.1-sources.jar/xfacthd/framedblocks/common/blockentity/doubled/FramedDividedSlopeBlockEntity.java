package xfacthd.framedblocks.common.blockentity.doubled;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.blockentity.FramedDoubleBlockEntity;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.SlopeType;

public class FramedDividedSlopeBlockEntity extends FramedDoubleBlockEntity
{
    public FramedDividedSlopeBlockEntity(class_2338 pos, class_2680 state)
    {
        super(FBContent.BE_TYPE_FRAMED_DIVIDED_SLOPE.get(), pos, state);
    }

    @Override
    protected boolean hitSecondary(class_3965 hit)
    {
        class_2350 dir;
        if (method_11010().method_11654(PropertyHolder.SLOPE_TYPE) == SlopeType.HORIZONTAL)
        {
            dir = class_2350.field_11036;
        }
        else
        {
            class_2350 facing = method_11010().method_11654(FramedProperties.FACING_HOR);
            dir = facing.method_10170();
        }

        class_2350 side = hit.method_17780();
        if (side == dir)
        {
            return true;
        }
        if (side == dir.method_10153())
        {
            return false;
        }

        return Utils.fractionInDir(hit.method_17784(), dir) > .5;
    }
}
