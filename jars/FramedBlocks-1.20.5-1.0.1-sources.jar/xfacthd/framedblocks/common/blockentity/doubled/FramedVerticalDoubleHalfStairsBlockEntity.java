package xfacthd.framedblocks.common.blockentity.doubled;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.blockentity.FramedDoubleBlockEntity;

public class FramedVerticalDoubleHalfStairsBlockEntity extends FramedDoubleBlockEntity
{
    public FramedVerticalDoubleHalfStairsBlockEntity(class_2338 pos, class_2680 state)
    {
        super(FBContent.BE_TYPE_FRAMED_VERTICAL_DOUBLE_HALF_STAIRS.get(), pos, state);
    }

    @Override
    protected boolean hitSecondary(class_3965 hit)
    {
        class_2350 dir = method_11010().method_11654(FramedProperties.FACING_HOR);
        class_2350 face = hit.method_17780();
        class_243 hitVec = hit.method_17784();
        if (face == dir || face == dir.method_10160())
        {
            return false;
        }
        else if (face == dir.method_10153())
        {
            return Utils.fractionInDir(hitVec, dir.method_10170()) > .5;
        }
        else if (face == dir.method_10170())
        {
            return Utils.fractionInDir(hitVec, dir.method_10153()) > .5;
        }
        else
        {
            boolean overHalfPar = Utils.fractionInDir(hitVec, dir.method_10153()) > .5;
            boolean overHalfPerp = Utils.fractionInDir(hitVec, dir.method_10170()) > .5;
            return overHalfPar && overHalfPerp;
        }
    }
}
