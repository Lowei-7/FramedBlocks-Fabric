package xfacthd.framedblocks.common.blockentity.doubled;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.blockentity.FramedDoubleBlockEntity;

public class FramedElevatedDoubleSlopeSlabBlockEntity extends FramedDoubleBlockEntity
{
    public FramedElevatedDoubleSlopeSlabBlockEntity(class_2338 pos, class_2680 state)
    {
        super(FBContent.BE_TYPE_FRAMED_ELEVATED_DOUBLE_SLOPE_SLAB.get(), pos, state);
    }

    @Override
    protected boolean hitSecondary(class_3965 hit)
    {
        class_2350 facing = method_11010().method_11654(FramedProperties.FACING_HOR);
        boolean top = method_11010().method_11654(FramedProperties.TOP);
        class_2350 side = hit.method_17780();

        if (side == class_2350.field_11036)
        {
            return !top;
        }
        if (side == class_2350.field_11033 || side == facing)
        {
            return top;
        }

        class_243 vec = Utils.fraction(hit.method_17784());
        if (side == facing.method_10153())
        {
            return (vec.method_10214() >= .5D) != top;
        }

        double hor = Utils.isX(facing) ? vec.method_10216() : vec.method_10215();
        if (!Utils.isPositive(facing))
        {
            hor = 1D - hor;
        }

        double y = vec.method_10214();
        if (top)
        {
            y = 1D - y;
        }
        y -= .5D;
        return (y * 2D) >= hor;
    }
}
