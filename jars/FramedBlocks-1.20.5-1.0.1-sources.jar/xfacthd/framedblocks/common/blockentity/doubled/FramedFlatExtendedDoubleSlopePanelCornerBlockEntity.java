package xfacthd.framedblocks.common.blockentity.doubled;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.blockentity.FramedDoubleBlockEntity;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.HorizontalRotation;

public class FramedFlatExtendedDoubleSlopePanelCornerBlockEntity extends FramedDoubleBlockEntity
{
    private final boolean isInner;

    public FramedFlatExtendedDoubleSlopePanelCornerBlockEntity(class_2338 pos, class_2680 state)
    {
        super(FBContent.BE_TYPE_FRAMED_FLAT_EXTENDED_DOUBLE_SLOPE_PANEL_CORNER.get(), pos, state);
        this.isInner = getBlockType() == BlockType.FRAMED_FLAT_EXT_INNER_DOUBLE_SLOPE_PANEL_CORNER;
    }

    @Override
    protected boolean hitSecondary(class_3965 hit)
    {
        class_2350 side = hit.method_17780();

        class_2350 facing = method_11010().method_11654(FramedProperties.FACING_HOR);
        if (side == facing)
        {
            return false;
        }
        if (side == facing.method_10153())
        {
            return true;
        }

        HorizontalRotation rotation = method_11010().method_11654(PropertyHolder.ROTATION);
        class_2350 rotDir = rotation.withFacing(facing);
        class_2350 perpRotDir = rotation.rotate(class_2470.field_11465).withFacing(facing);

        if (isInner && (side == rotDir.method_10153() || side == perpRotDir.method_10153()))
        {
            return false;
        }

        class_243 hitVec = hit.method_17784();
        double hor = Utils.fractionInDir(hitVec, facing.method_10153());
        if (!isInner && (side == rotDir || side == perpRotDir))
        {
            return hor > .5;
        }

        class_2350 perpDir;
        if (isInner)
        {
            perpDir = side == rotDir ? perpRotDir.method_10153() : rotDir.method_10153();
        }
        else
        {
            perpDir = side == rotDir.method_10153() ? perpRotDir.method_10153() : rotDir.method_10153();
        }

        double perpHor = Utils.fractionInDir(hitVec, perpDir);
        return ((hor - .5) * 2D) > perpHor;
    }
}
