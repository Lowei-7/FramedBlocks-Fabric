package xfacthd.framedblocks.common.blockentity.doubled;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.blockentity.FramedDoubleBlockEntity;
import xfacthd.framedblocks.common.data.PropertyHolder;

public class FramedFlatDoubleSlopeSlabCornerBlockEntity extends FramedDoubleBlockEntity
{
    public FramedFlatDoubleSlopeSlabCornerBlockEntity(class_2338 pos, class_2680 state)
    {
        super(FBContent.BE_TYPE_FRAMED_FLAT_DOUBLE_SLOPE_SLAB_CORNER.get(), pos, state);
    }

    @Override
    protected boolean hitSecondary(class_3965 hit)
    {
        class_2350 facing = method_11010().method_11654(FramedProperties.FACING_HOR);
        boolean top = method_11010().method_11654(FramedProperties.TOP);
        class_2350 side = hit.method_17780();

        if (side == class_2350.field_11036)
        {
            return !top;
        }
        if (side == class_2350.field_11033)
        {
            return top;
        }
        if (side == facing || side == facing.method_10160())
        {
            return false;
        }

        class_243 vec = Utils.fraction(hit.method_17784());

        class_2350 perpDir = side == facing.method_10170() ? facing : facing.method_10160();
        double hor = Utils.isX(perpDir) ? vec.method_10216() : vec.method_10215();
        if (!Utils.isPositive(perpDir))
        {
            hor = 1D - hor;
        }

        double y = vec.method_10214();
        if (method_11010().method_11654(PropertyHolder.TOP_HALF))
        {
            y -= .5;
        }
        if (top)
        {
            y = .5 - y;
        }
        return (y * 2D) >= hor;
    }
}
