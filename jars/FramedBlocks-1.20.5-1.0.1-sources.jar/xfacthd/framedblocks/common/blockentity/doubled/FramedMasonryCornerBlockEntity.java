package xfacthd.framedblocks.common.blockentity.doubled;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.blockentity.FramedDoubleBlockEntity;

public class FramedMasonryCornerBlockEntity extends FramedDoubleBlockEntity
{
    public FramedMasonryCornerBlockEntity(class_2338 pos, class_2680 state)
    {
        super(FBContent.BE_TYPE_FRAMED_MASONRY_CORNER.get(), pos, state);
    }

    @Override
    protected boolean hitSecondary(class_3965 hit)
    {
        class_2350 dir = method_11010().method_11654(FramedProperties.FACING_HOR);
        class_2350 side = hit.method_17780();
        class_243 hitVec = hit.method_17784();

        return switch (side)
        {
            case field_11033 -> Utils.fractionInDir(hitVec, dir) > .5;
            case field_11036 -> Utils.fractionInDir(hitVec, dir.method_10160()) > .5;
            default ->
            {
                boolean topHalf = Utils.fractionInDir(hitVec, class_2350.field_11036) > .5;
                class_2350 frontFace = topHalf ? dir.method_10160() : dir;
                if (side == frontFace) yield true;
                if (side == frontFace.method_10153()) yield false;
                yield Utils.fractionInDir(hitVec, frontFace) > .5;
            }
        };
    }
}
