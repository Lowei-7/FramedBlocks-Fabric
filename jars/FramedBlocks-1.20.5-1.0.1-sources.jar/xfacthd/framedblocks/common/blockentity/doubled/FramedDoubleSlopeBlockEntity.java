package xfacthd.framedblocks.common.blockentity.doubled;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.blockentity.FramedDoubleBlockEntity;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.SlopeType;
import xfacthd.framedblocks.api.util.Utils;

public class FramedDoubleSlopeBlockEntity extends FramedDoubleBlockEntity
{
    public FramedDoubleSlopeBlockEntity(class_2338 pos, class_2680 state)
    {
        super(FBContent.BE_TYPE_DOUBLE_FRAMED_SLOPE.get(), pos, state);
    }

    @Override
    protected boolean hitSecondary(class_3965 hit)
    {
        SlopeType type = method_11010().method_11654(PropertyHolder.SLOPE_TYPE);
        class_2350 facing = method_11010().method_11654(FramedProperties.FACING_HOR);
        class_2350 side = hit.method_17780();

        class_243 vec = Utils.fraction(hit.method_17784());

        if (type == SlopeType.HORIZONTAL)
        {
            if (side == facing || side == facing.method_10160())
            {
                return false;
            }
            if (side == facing.method_10153() || side == facing.method_10170())
            {
                return true;
            }

            boolean secondary = Utils.isX(facing) ? vec.method_10216() >= vec.method_10215() : vec.method_10215() >= (1D - vec.method_10216());

            if (Utils.isPositive(facing)) { secondary = !secondary; }
            return secondary;
        }
        else
        {
            double hor = Utils.isX(facing) ? vec.method_10216() : vec.method_10215();
            if (!Utils.isPositive(facing))
            {
                hor = 1D - hor;
            }

            if (type == SlopeType.TOP)
            {
                if (side == facing || side == class_2350.field_11036)
                {
                    return false;
                }
                if (side == facing.method_10153() || side == class_2350.field_11033)
                {
                    return true;
                }
                return vec.method_10214() <= (1D - hor);
            }
            else if (type == SlopeType.BOTTOM)
            {
                if (side == facing || side == class_2350.field_11033)
                {
                    return false;
                }
                if (side == facing.method_10153() || side == class_2350.field_11036)
                {
                    return true;
                }
                return vec.method_10214() >= hor;
            }
        }

        return false;
    }
}