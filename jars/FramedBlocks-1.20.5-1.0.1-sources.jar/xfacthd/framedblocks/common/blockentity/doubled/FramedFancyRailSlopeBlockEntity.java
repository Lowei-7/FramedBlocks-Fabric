package xfacthd.framedblocks.common.blockentity.doubled;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import xfacthd.framedblocks.api.camo.CamoContainer;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.ISlopeBlock;
import xfacthd.framedblocks.common.blockentity.FramedDoubleBlockEntity;

public class FramedFancyRailSlopeBlockEntity extends FramedDoubleBlockEntity
{
    public FramedFancyRailSlopeBlockEntity(class_2338 pos, class_2680 state)
    {
        super(FBContent.BE_TYPE_FRAMED_FANCY_RAIL_SLOPE.get(), pos, state);
    }

    @Override
    protected boolean hitSecondary(class_3965 hit)
    {
        class_2350 side = hit.method_17780();
        class_2680 state = method_11010();
        return side == class_2350.field_11036 || side == ((ISlopeBlock) state.method_26204()).getFacing(state).method_10153();
    }

    @Override
    public CamoContainer getCamo(class_2680 state)
    {
        //The primary camo is the only camo needed in skip predicates
        return getCamo();
    }

    @Override
    protected boolean isCamoSolid()
    {
        CamoContainer camo = getCamo();
        return !camo.isEmpty() && camo.isSolid(field_11863, field_11867);
    }
}
