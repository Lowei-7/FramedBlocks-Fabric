package xfacthd.framedblocks.common.blockentity.doubled;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.blockentity.FramedDoubleBlockEntity;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.HorizontalRotation;

public class FramedSmallDoubleCornerSlopePanelWallBlockEntity extends FramedDoubleBlockEntity
{
    public FramedSmallDoubleCornerSlopePanelWallBlockEntity(class_2338 pos, class_2680 state)
    {
        super(FBContent.BE_TYPE_FRAMED_SMALL_DOUBLE_CORNER_SLOPE_PANEL_WALL.get(), pos, state);
    }

    @Override
    protected boolean hitSecondary(class_3965 hit)
    {
        class_2350 side = hit.method_17780();
        class_2350 dir = method_11010().method_11654(FramedProperties.FACING_HOR);
        if (side == dir)
        {
            return false;
        }
        if (side == dir.method_10153())
        {
            return true;
        }

        HorizontalRotation rot = method_11010().method_11654(PropertyHolder.ROTATION);
        class_2350 rotDir = rot.withFacing(dir);
        class_2350 perpRotDir = rot.rotate(class_2470.field_11465).withFacing(dir);

        if (side == rotDir.method_10153() || side == perpRotDir.method_10153())
        {
            return false;
        }

        class_243 hitVec = hit.method_17784();
        double xzDir = Utils.fractionInDir(hitVec, dir);
        double xzPerp;
        if (Utils.isY(side))
        {
            xzPerp = Utils.fractionInDir(hitVec, Utils.isY(rotDir) ? perpRotDir : rotDir);
        }
        else
        {
            xzPerp = Utils.fractionInDir(hitVec, Utils.isY(rotDir) ? rotDir : perpRotDir);
        }

        return ((xzPerp - .5) * 2D) > xzDir;
    }
}
