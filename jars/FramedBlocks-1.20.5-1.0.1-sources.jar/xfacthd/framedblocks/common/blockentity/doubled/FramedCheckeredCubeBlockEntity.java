package xfacthd.framedblocks.common.blockentity.doubled;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.blockentity.FramedDoubleBlockEntity;

public class FramedCheckeredCubeBlockEntity extends FramedDoubleBlockEntity
{
    public FramedCheckeredCubeBlockEntity(class_2338 pos, class_2680 state)
    {
        super(FBContent.BE_TYPE_FRAMED_CHECKERED_CUBE.get(), pos, state);
    }

    @Override
    protected boolean hitSecondary(class_3965 hit)
    {
        class_2350 face = hit.method_17780();
        class_243 hitVec = Utils.fraction(hit.method_17784());
        if (Utils.isY(face))
        {
            boolean down = face == class_2350.field_11033;
            return ((hitVec.field_1352 > .5) == (hitVec.field_1350 > .5)) ^ down;
        }
        else
        {
            boolean neg = !Utils.isPositive(face);
            double xz = Utils.isX(face) ? hitVec.field_1350 : hitVec.field_1352;
            return ((xz > .5) == (hitVec.field_1351 > .5)) ^ neg;
        }
    }
}
