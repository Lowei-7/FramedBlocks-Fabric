package xfacthd.framedblocks.common.blockentity.doubled;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.blockentity.FramedDoubleBlockEntity;

public class FramedSlicedStairsBlockEntity extends FramedDoubleBlockEntity
{
    private final boolean panel;

    public FramedSlicedStairsBlockEntity(class_2338 pos, class_2680 state)
    {
        super(FBContent.BE_TYPE_FRAMED_SLICED_STAIRS.get(), pos, state);
        this.panel = state.method_27852(FBContent.BLOCK_FRAMED_SLICED_STAIRS_PANEL.get());
    }

    @Override
    protected boolean hitSecondary(class_3965 hit)
    {
        class_2350 dir = method_11010().method_11654(FramedProperties.FACING_HOR);
        boolean top = method_11010().method_11654(FramedProperties.TOP);
        class_2350 dirTwo = top ? class_2350.field_11036 : class_2350.field_11033;

        class_2350 face = hit.method_17780();
        class_243 hitVec = hit.method_17784();
        if (panel)
        {
            if (face == dir)
            {
                return false;
            }
            else if (face == dir.method_10153())
            {
                return Utils.fractionInDir(hitVec, dirTwo) > .5;
            }
            return Utils.fractionInDir(hitVec, dir.method_10153()) > .5;
        }
        else
        {
            if (face == dirTwo)
            {
                return false;
            }
            else if (face == dirTwo.method_10153())
            {
                return Utils.fractionInDir(hitVec, dir) > .5;
            }
            return Utils.fractionInDir(hitVec, dirTwo.method_10153()) > .5;
        }
    }
}
