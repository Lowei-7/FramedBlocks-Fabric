package xfacthd.framedblocks.common.blockentity.doubled;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.blockentity.FramedDoubleBlockEntity;

public class FramedInverseDoubleCornerSlopePanelBlockEntity extends FramedDoubleBlockEntity
{
    public FramedInverseDoubleCornerSlopePanelBlockEntity(class_2338 pos, class_2680 state)
    {
        super(FBContent.BE_TYPE_FRAMED_INVERSE_DOUBLE_CORNER_SLOPE_PANEL.get(), pos, state);
    }

    @Override
    protected boolean hitSecondary(class_3965 hit)
    {
        class_2350 side = hit.method_17780();
        class_2350 facing = method_11010().method_11654(FramedProperties.FACING_HOR);
        if (side == facing.method_10153() || side == facing.method_10170())
        {
            return false;
        }

        class_243 hitVec = hit.method_17784();
        if (side == facing)
        {
            return Utils.fractionInDir(hitVec, facing.method_10160()) > .5;
        }
        if (side == facing.method_10160())
        {
            return Utils.fractionInDir(hitVec, facing) > .5;
        }

        double xz1 = Utils.fractionInDir(hitVec, facing);
        double xz2 = Utils.fractionInDir(hitVec, facing.method_10160());
        return xz1 > .5 && xz2 > .5;
    }
}
