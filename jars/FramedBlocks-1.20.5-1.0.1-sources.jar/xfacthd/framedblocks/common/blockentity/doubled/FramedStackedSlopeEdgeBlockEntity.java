package xfacthd.framedblocks.common.blockentity.doubled;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.blockentity.FramedDoubleBlockEntity;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.SlopeType;

public class FramedStackedSlopeEdgeBlockEntity extends FramedDoubleBlockEntity
{
    public FramedStackedSlopeEdgeBlockEntity(class_2338 pos, class_2680 state)
    {
        super(FBContent.BE_TYPE_FRAMED_STACKED_SLOPE_EDGE.get(), pos, state);
    }

    @Override
    protected boolean hitSecondary(class_3965 hit)
    {
        class_2350 side = hit.method_17780();

        class_2350 dir = method_11010().method_11654(FramedProperties.FACING_HOR);
        if (side == dir)
        {
            return false;
        }

        SlopeType type = method_11010().method_11654(PropertyHolder.SLOPE_TYPE);
        class_2350 dirTwo = switch (type)
        {
            case BOTTOM -> class_2350.field_11033;
            case HORIZONTAL -> dir.method_10160();
            case TOP -> class_2350.field_11036;
        };
        if (side == dirTwo)
        {
            return false;
        }

        class_243 hitVec = hit.method_17784();
        if (side == dir.method_10153())
        {
            return Utils.fractionInDir(hitVec, dirTwo.method_10153()) > .5;
        }
        else if (side == dirTwo.method_10153())
        {
            return Utils.fractionInDir(hitVec, dir.method_10153()) > .5;
        }

        double par = Utils.fractionInDir(hitVec, dir.method_10153()) - .5;
        double perp = Utils.fractionInDir(hitVec, dirTwo.method_10153()) - .5;
        return par > 0D && perp > 0D;
    }
}
