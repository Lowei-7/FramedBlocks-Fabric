package xfacthd.framedblocks.common.blockentity.doubled;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.blockentity.FramedDoubleBlockEntity;

public class FramedFlatInverseDoubleSlopePanelCornerBlockEntity extends FramedDoubleBlockEntity
{
    public FramedFlatInverseDoubleSlopePanelCornerBlockEntity(class_2338 pos, class_2680 state)
    {
        super(FBContent.BE_TYPE_FRAMED_FLAT_INVERSE_DOUBLE_SLOPE_PANEL_CORNER.get(), pos, state);
    }

    @Override
    protected boolean hitSecondary(class_3965 hit)
    {
        class_2350 facing = method_11010().method_11654(FramedProperties.FACING_HOR);
        class_2350 side = hit.method_17780();

        if (side == facing)
        {
            return false;
        }
        if (side == facing.method_10153())
        {
            return true;
        }

        class_243 vec = Utils.fraction(hit.method_17784());
        double hor = Utils.isX(facing) ? vec.method_10216() : vec.method_10215();
        if (!Utils.isPositive(facing))
        {
            hor = 1D - hor;
        }
        return hor < .5D;
    }
}
