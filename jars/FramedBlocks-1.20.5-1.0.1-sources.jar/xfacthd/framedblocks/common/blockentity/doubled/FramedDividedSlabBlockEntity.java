package xfacthd.framedblocks.common.blockentity.doubled;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.blockentity.FramedDoubleBlockEntity;

public class FramedDividedSlabBlockEntity extends FramedDoubleBlockEntity
{
    public FramedDividedSlabBlockEntity(class_2338 pos, class_2680 state)
    {
        super(FBContent.BE_TYPE_FRAMED_DIVIDED_SLAB.get(), pos, state);
    }

    @Override
    protected boolean hitSecondary(class_3965 hit)
    {
        class_2350 face = hit.method_17780();
        class_2350 dir = method_11010().method_11654(FramedProperties.FACING_HOR);

        if (face == dir.method_10153())
        {
            return false;
        }
        if (face == dir)
        {
            return true;
        }

        double xz = Utils.fractionInDir(hit.method_17784(), dir);
        return xz > .5D;
    }
}
