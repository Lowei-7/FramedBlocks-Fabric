package xfacthd.framedblocks.common.blockentity.doubled;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.blockentity.FramedDoubleBlockEntity;

public class FramedDividedPanelBlockEntity extends FramedDoubleBlockEntity
{
    private final boolean vertical;

    public FramedDividedPanelBlockEntity(class_2338 pos, class_2680 state)
    {
        super(FBContent.BE_TYPE_FRAMED_DIVIDED_PANEL.get(), pos, state);
        this.vertical = state.method_26204() == FBContent.BLOCK_FRAMED_DIVIDED_PANEL_VERT.get();
    }

    @Override
    protected boolean hitSecondary(class_3965 hit)
    {
        class_2350 face = hit.method_17780();
        if (vertical)
        {
            class_2350 dir = method_11010().method_11654(FramedProperties.FACING_HOR);
            if (face == dir.method_10170())
            {
                return true;
            }
            if (face == dir.method_10160())
            {
                return false;
            }

            double xz = Utils.fractionInDir(hit.method_17784(), dir.method_10170());
            return xz > .5D;
        }
        else
        {
            return switch (face)
            {
                case field_11036 -> true;
                case field_11033 -> false;
                default ->
                {
                    class_243 frac = Utils.fraction(hit.method_17784());
                    yield frac.field_1351 > .5D;
                }
            };
        }
    }
}
