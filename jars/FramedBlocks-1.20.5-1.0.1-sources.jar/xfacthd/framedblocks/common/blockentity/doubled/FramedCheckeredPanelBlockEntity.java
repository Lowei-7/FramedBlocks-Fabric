package xfacthd.framedblocks.common.blockentity.doubled;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.blockentity.FramedDoubleBlockEntity;

public class FramedCheckeredPanelBlockEntity extends FramedDoubleBlockEntity
{
    public FramedCheckeredPanelBlockEntity(class_2338 pos, class_2680 state)
    {
        super(FBContent.BE_TYPE_FRAMED_CHECKERED_PANEL.get(), pos, state);
    }

    @Override
    protected boolean hitSecondary(class_3965 hit)
    {
        class_2350 face = hit.method_17780();
        if (Utils.isY(face))
        {
            class_243 hitVec = Utils.fraction(hit.method_17784());
            boolean down = face == class_2350.field_11033;
            return ((hitVec.field_1352 > .5) == (hitVec.field_1350 > .5)) ^ down;
        }
        else
        {
            class_2350 dir = method_11010().method_11654(FramedProperties.FACING_HOR);
            double y = Utils.fractionInDir(hit.method_17784(), class_2350.field_11036);
            if (face.method_10166() == dir.method_10166())
            {
                class_2350 coordDir = Utils.isX(dir) ? dir.method_10160() : dir.method_10170();
                double xz = Utils.fractionInDir(hit.method_17784(), coordDir);
                return (y > .5) ^ (xz > .5);
            }

            boolean posDir = Utils.isPositive(dir);
            boolean posFace = Utils.isPositive(face);
            return (y > .5) ^ (posFace ^ posDir);
        }
    }
}
