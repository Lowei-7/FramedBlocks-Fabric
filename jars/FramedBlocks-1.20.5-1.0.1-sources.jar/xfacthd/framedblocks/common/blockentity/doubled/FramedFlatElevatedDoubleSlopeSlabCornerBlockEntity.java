package xfacthd.framedblocks.common.blockentity.doubled;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.blockentity.FramedDoubleBlockEntity;
import xfacthd.framedblocks.common.data.BlockType;

public class FramedFlatElevatedDoubleSlopeSlabCornerBlockEntity extends FramedDoubleBlockEntity
{
    private final boolean isInner;

    public FramedFlatElevatedDoubleSlopeSlabCornerBlockEntity(class_2338 pos, class_2680 state)
    {
        super(FBContent.BE_TYPE_FRAMED_FLAT_ELEVATED_DOUBLE_SLOPE_SLAB_CORNER.get(), pos, state);
        this.isInner = getBlockType() == BlockType.FRAMED_FLAT_ELEV_INNER_DOUBLE_SLOPE_SLAB_CORNER;
    }

    @Override
    protected boolean hitSecondary(class_3965 hit)
    {
        class_2350 side = hit.method_17780();
        boolean top = method_11010().method_11654(FramedProperties.TOP);

        if (side == class_2350.field_11036)
        {
            return !top;
        }
        if (side == class_2350.field_11033)
        {
            return top;
        }

        class_2350 facing = method_11010().method_11654(FramedProperties.FACING_HOR);
        if (isInner && (side == facing || side == facing.method_10160()))
        {
            return false;
        }
        else
        {
            class_243 vec = Utils.fraction(hit.method_17784());
            if (!isInner && (side == facing.method_10153() || side == facing.method_10170()))
            {
                return (vec.method_10214() >= .5D) != top;
            }
            else
            {
                class_2350 perpDir;
                if (isInner)
                {
                    perpDir = side == facing.method_10170() ? facing : facing.method_10160();
                }
                else
                {
                    perpDir = side == facing ? facing.method_10160() : facing;
                }

                double hor = Utils.isX(perpDir) ? vec.method_10216() : vec.method_10215();
                if (!Utils.isPositive(perpDir))
                {
                    hor = 1D - hor;
                }

                double y = vec.method_10214();
                if (top)
                {
                    y = 1D - y;
                }
                y -= .5D;
                return (y * 2D) >= hor;
            }
        }
    }
}
