package xfacthd.framedblocks.common.blockentity.doubled;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.blockentity.FramedDoubleBlockEntity;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.HorizontalRotation;

public class FramedFlatDoubleSlopePanelCornerBlockEntity extends FramedDoubleBlockEntity
{
    public FramedFlatDoubleSlopePanelCornerBlockEntity(class_2338 pos, class_2680 state)
    {
        super(FBContent.BE_TYPE_FRAMED_FLAT_DOUBLE_SLOPE_PANEL_CORNER.get(), pos, state);
    }

    @Override
    protected boolean hitSecondary(class_3965 hit)
    {
        class_2350 side = hit.method_17780();

        class_2350 facing = method_11010().method_11654(FramedProperties.FACING_HOR);
        if (side == facing)
        {
            return false;
        }
        if (side == facing.method_10153())
        {
            return true;
        }

        HorizontalRotation rotation = method_11010().method_11654(PropertyHolder.ROTATION);
        class_2350 rotDir = rotation.withFacing(facing);
        class_2350 perpRotDir = rotation.rotate(class_2470.field_11465).withFacing(facing);
        if (side == rotDir.method_10153() || side == perpRotDir.method_10153())
        {
            return false;
        }

        class_243 vec = Utils.fraction(hit.method_17784());

        double hor = Utils.isX(facing) ? vec.method_10216() : vec.method_10215();
        if (!Utils.isPositive(facing))
        {
            hor = 1D - hor;
        }
        if (!method_11010().method_11654(PropertyHolder.FRONT))
        {
            hor -= .5D;
        }

        class_2350 perpDir = side == rotDir ? perpRotDir : rotDir;
        double vert = Utils.isY(perpDir) ? vec.method_10214() : (Utils.isX(facing) ? vec.method_10215() : vec.method_10216());
        if (perpDir == class_2350.field_11033 || (!Utils.isY(perpDir) && !Utils.isPositive(perpDir)))
        {
            vert = 1F - vert;
        }
        return (hor * 2D) < vert;
    }
}
