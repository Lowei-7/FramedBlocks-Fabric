package xfacthd.framedblocks.common.blockentity.doubled;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.blockentity.FramedDoubleBlockEntity;
import xfacthd.framedblocks.common.data.PropertyHolder;

public class FramedVerticalSlicedStairsBlockEntity extends FramedDoubleBlockEntity
{
    public FramedVerticalSlicedStairsBlockEntity(class_2338 pos, class_2680 state)
    {
        super(FBContent.BE_TYPE_FRAMED_VERTICAL_SLICED_STAIRS.get(), pos, state);
    }

    @Override
    protected boolean hitSecondary(class_3965 hit)
    {
        class_2350 dir = method_11010().method_11654(FramedProperties.FACING_HOR);
        boolean right = method_11010().method_11654(PropertyHolder.RIGHT);
        class_2350 dirTwo = right ? dir.method_10160() : dir.method_10170();

        class_2350 face = hit.method_17780();
        class_243 hitVec = hit.method_17784();
        if (face.method_10166() == dir.method_10166() || Utils.isY(face))
        {
            return Utils.fractionInDir(hitVec, dirTwo) > .5;
        }
        else if (face == dirTwo)
        {
            return Utils.fractionInDir(hitVec, dir) > .5;
        }
        return false;
    }
}
