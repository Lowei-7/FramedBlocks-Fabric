package xfacthd.framedblocks.common.blockentity.special;

import net.minecraft.class_1767;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_7225;
import xfacthd.framedblocks.api.block.FramedBlockEntity;
import xfacthd.framedblocks.common.FBContent;

public class FramedTargetBlockEntity extends FramedBlockEntity
{
    private class_1767 overlayColor = class_1767.field_7964;

    public FramedTargetBlockEntity(class_2338 pos, class_2680 state)
    {
        super(FBContent.BE_TYPE_FRAMED_TARGET.get(), pos, state);
    }

    public boolean setOverlayColor(class_1767 overlayColor)
    {
        if (this.overlayColor != overlayColor)
        {
            //noinspection ConstantConditions
            if (!field_11863.method_8608())
            {
                this.overlayColor = overlayColor;

                field_11863.method_8413(field_11867, method_11010(), method_11010(), class_2248.field_31036);
                method_5431();
            }

            return true;
        }
        return false;
    }

    public int getOverlayColor()
    {
        return overlayColor.method_16357();
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registries)
    {
        class_2487 tag = super.method_16887(registries);
        tag.method_10569("overlay_color", overlayColor.method_7789());
        return tag;
    }

    @Override
    public void handleUpdateTag(class_2487 nbt)
    {
        super.handleUpdateTag(nbt);
        if (nbt.method_10545("overlay_color"))
        {
            overlayColor = class_1767.method_7791(nbt.method_10550("overlay_color"));
        }
    }

    @Override
    protected void writeToDataPacket(class_2487 tag)
    {
        super.writeToDataPacket(tag);
        tag.method_10569("overlay_color", overlayColor.method_7789());
    }

    @Override
    protected boolean readFromDataPacket(class_2487 nbt)
    {
        boolean colored = false;
        if (nbt.method_10545("overlay_color"))
        {
            class_1767 color = class_1767.method_7791(nbt.method_10550("overlay_color"));
            if (overlayColor != color)
            {
                overlayColor = color;
                colored = true;
            }
        }
        return super.readFromDataPacket(nbt) || colored;
    }

    @Override
    public void method_11007(class_2487 tag, class_7225.class_7874 registries)
    {
        super.method_11007(tag, registries);
        tag.method_10569("overlay_color", overlayColor.method_7789());
    }

    @Override
    public void method_11014(class_2487 tag, class_7225.class_7874 registries)
    {
        super.method_11014(tag, registries);
        if (tag.method_10545("overlay_color"))
        {
            overlayColor = class_1767.method_7791(tag.method_10550("overlay_color"));
        }
    }
}
