package xfacthd.framedblocks.common.blockentity.special;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.data.property.ChestState;
import xfacthd.framedblocks.common.data.PropertyHolder;

public class FramedChestBlockEntity extends FramedStorageBlockEntity
{
    public static final class_2561 TITLE = Utils.translate("title", "framed_chest");

    private int openCount = 0;
    private long closeStart = 0;

    //Client-only
    private long lastChangeTime = 0;
    private ChestState lastState = ChestState.CLOSED;

    public FramedChestBlockEntity(class_2338 pos, class_2680 state)
    {
        super(FBContent.blockEntityTypeFramedChest.get(), pos, state);
    }

    public static void tick(class_1937 level, class_2338 pos, class_2680 state, FramedChestBlockEntity tile)
    {
        if (!level.method_8608() && (level.method_8510() - tile.closeStart) >= 10 && state.method_11654(PropertyHolder.CHEST_STATE) == ChestState.CLOSING)
        {
            tile.closeStart = 0;
            level.method_8501(pos, state.method_11657(PropertyHolder.CHEST_STATE, ChestState.CLOSED));
        }
    }

    @Override
    public void open(class_3222 player)
    {
        if (method_11010().method_11654(PropertyHolder.CHEST_STATE) != ChestState.OPENING)
        {
            //noinspection ConstantConditions
            field_11863.method_8501(field_11867, method_11010().method_11657(PropertyHolder.CHEST_STATE, ChestState.OPENING));
            field_11863.method_8396(null, field_11867, class_3417.field_14982, class_3419.field_15245, 0.5F, field_11863.field_9229.method_43057() * 0.1F + 0.9F);
        }

        openCount++;

        super.open(player);
    }

    public void close()
    {
        if (openCount > 0)
        {
            openCount--;
            if (openCount == 0)
            {
                //noinspection ConstantConditions
                field_11863.method_8396(null, field_11867, class_3417.field_14823, class_3419.field_15245, 0.5F, field_11863.field_9229.method_43057() * 0.1F + 0.9F);
                field_11863.method_8501(field_11867, method_11010().method_11657(PropertyHolder.CHEST_STATE, ChestState.CLOSING));

                closeStart = field_11863.method_8510();
            }
        }
    }

    public long getLastChangeTime(ChestState state)
    {
        if (lastChangeTime == 0 || state != lastState)
        {
            if ((lastState == ChestState.CLOSING && state == ChestState.OPENING) || (lastState == ChestState.OPENING && state == ChestState.CLOSING))
            {
                //noinspection ConstantConditions
                long diff = field_11863.method_8510() - lastChangeTime;
                lastChangeTime = field_11863.method_8510() - (diff < 10 ? 10 - diff : 0);
            }
            else
            {
                //noinspection ConstantConditions
                lastChangeTime = field_11863.method_8510();
            }
            lastState = state;
        }
        return lastChangeTime;
    }

    @Override
    protected class_2561 getDefaultName()
    {
        return TITLE;
    }
}