package xfacthd.framedblocks.common.blockentity.special;

import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_7225;
import net.minecraft.world.item.*;
import net.minecraftforge.items.ItemStackHandler;
import net.minecraftforge.items.wrapper.RecipeWrapper;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.crafting.*;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.menu.FramingSawMenu;
import xfacthd.framedblocks.common.util.EntityAwareEnergyStorage;

import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;

public class PoweredFramingSawBlockEntity extends class_2586
{
    public static final int ENERGY_CAPACITY = 5000;
    public static final int ENERGY_MAX_INSERT = 250;
    public static final int ENERGY_CONSUMPTION = 50;
    private static final boolean INSERT_ENERGY_DEBUG = false;
    private static final long ACTIVE_TIMEOUT = 40;
    public static final int MAX_PROGRESS = 30;

    private final ItemStackHandler itemHandler = new ItemStackHandler(FramingSawMenu.SLOT_RESULT + 1)
    {
        @Override
        protected void onContentsChanged(int slot)
        {
            PoweredFramingSawBlockEntity.this.onContentsChanged(slot);
        }
    };
    private final RecipeWrapper recipeWrapper = new RecipeWrapper(itemHandler);
    private final EntityAwareEnergyStorage energyStorage = new EntityAwareEnergyStorage(
            ENERGY_CAPACITY, ENERGY_MAX_INSERT, 0, this
    );
    private FramingSawRecipeCache cache = null;
    private class_2960 selectedRecipeId = null;
    private FramingSawRecipe selectedRecipe = null;
    private boolean active = false;
    private long lastActive = 0;
    private boolean recipeSatisfied = false;
    private FramingSawRecipeMatchResult matchResult = null;
    private FramingSawRecipeCalculation calculation = null;
    private int outputCount = 0;
    private int progress = 0;
    private boolean needSaving = false;
    private boolean inhibitUpdate = false;
    private boolean internalAccess = false;

    public PoweredFramingSawBlockEntity(class_2338 pPos, class_2680 pBlockState)
    {
        super(FBContent.BE_TYPE_POWERED_FRAMING_SAW.get(), pPos, pBlockState);
    }

    public static void tick(class_1937 level, class_2338 pos, class_2680 state, PoweredFramingSawBlockEntity be)
    {
        if (!level.method_8608() && INSERT_ENERGY_DEBUG)
        {
            be.energyStorage.receiveEnergy(ENERGY_MAX_INSERT, false);
        }

        if ((be.active || level.method_8510() - be.lastActive > ACTIVE_TIMEOUT) && be.canRun())
        {
            if (!be.active)
            {
                be.active = true;
                level.method_8501(pos, state.method_11657(PropertyHolder.ACTIVE, true));
            }

            be.energyStorage.extractEnergyInternal(ENERGY_CONSUMPTION);
            be.progress++;

            if (be.progress >= MAX_PROGRESS)
            {
                be.progress = 0;

                class_1799 result = be.selectedRecipe.getResult().method_7972();
                result.method_7939(be.outputCount);
                be.internalAccess = true;
                be.inhibitUpdate = true;

                // Extraction des additifs
                for (int i = 0; i < be.selectedRecipe.getAdditives().size(); i++)
                {
                    int slot = i + FramingSawMenu.SLOT_ADDITIVE_FIRST;
                    be.itemHandler.extractItem(slot, 1, false);
                }

                // Extraction de l'entrée
                be.itemHandler.extractItem(FramingSawMenu.SLOT_INPUT, 1, false);

                be.inhibitUpdate = false;

                // Insertion du résultat
                class_1799 remainder = be.itemHandler.insertItem(FramingSawMenu.SLOT_RESULT, result, false);
                be.internalAccess = false;
            }
        }
        else if (be.active)
        {
            be.active = false;
            level.method_8501(pos, state.method_11657(PropertyHolder.ACTIVE, false));
            be.lastActive = level.method_8510();

            if (!be.recipeSatisfied)
            {
                be.progress = 0;
            }
        }

        if (be.needSaving)
        {
            be.method_5431();
            be.needSaving = false;
        }
    }

    private boolean canRun()
    {
        if (selectedRecipe == null || !recipeSatisfied) return false;
        if (energyStorage.getEnergyStored() < ENERGY_CONSUMPTION) return false;

        // Vérification de l'espace de sortie
        class_1799 output = itemHandler.getStackInSlot(FramingSawMenu.SLOT_RESULT);
        if (!output.method_7960() && output.method_7909() != selectedRecipe.getResult().method_7909()) return false;
        if (output.method_7947() + outputCount > output.method_7914()) return false;

        return true;
    }

    private void checkRecipeSatisfied()
    {
        if (selectedRecipe != null)
        {
            matchResult = selectedRecipe.matchWithResult(recipeWrapper, field_11863);
            recipeSatisfied = matchResult.success();
        }
        else
        {
            matchResult = null;
            recipeSatisfied = false;
        }

        if (recipeSatisfied)
        {
            calculation = selectedRecipe.makeCraftingCalculation(recipeWrapper, false);
            outputCount = calculation.getOutputCount();
        }
        else
        {
            calculation = null;
            outputCount = 0;
            progress = 0;
        }
    }

    private void onContentsChanged(int slot)
    {
        needSaving = true;
        if (slot != FramingSawMenu.SLOT_RESULT && !inhibitUpdate)
        {
            checkRecipeSatisfied();
        }
    }

    private boolean isValidItem(int slot, class_1799 stack)
    {
        if (slot == FramingSawMenu.SLOT_INPUT)
        {
            return cache.getMaterialValue(stack.method_7909()) > 0;
        }
        else if (slot < FramingSawMenu.SLOT_RESULT)
        {
            if (selectedRecipe != null)
            {
                int idx = slot - FramingSawMenu.SLOT_ADDITIVE_FIRST;
                List<FramingSawRecipeAdditive> additives = selectedRecipe.getAdditives();
                if (!additives.isEmpty() && idx < additives.size())
                {
                    return additives.get(idx).ingredient().method_8093(stack);
                }
                return false;
            }
            return true;
        }
        else if (slot == FramingSawMenu.SLOT_RESULT)
        {
            return internalAccess;
        }
        throw new IllegalArgumentException("Invalid slot: " + slot);
    }

    public void selectRecipe(FramingSawRecipe recipe)
    {
        class_2960 lastId = selectedRecipeId;
        selectedRecipe = recipe;
        selectedRecipeId = recipe == null ? null : recipe.getId();
        checkRecipeSatisfied();
        if (!Objects.equals(lastId, selectedRecipeId))
        {
            needSaving = true;
        }
    }

    public FramingSawRecipe getSelectedRecipe()
    {
        return selectedRecipe;
    }

    public FramingSawRecipeMatchResult getMatchResult()
    {
        return matchResult;
    }

    public int getProgress()
    {
        return progress;
    }

    public ItemStackHandler getItemHandler()
    {
        return itemHandler;
    }

    public int getEnergy()
    {
        return energyStorage.getEnergyStored();
    }

    public void dropContents(Consumer<class_1799> dropper)
    {
        inhibitUpdate = true;
        for (int i = 0; i < itemHandler.getSlots(); i++)
        {
            class_1799 stack = itemHandler.getStackInSlot(i);
            if (!stack.method_7960())
            {
                dropper.accept(stack);
                itemHandler.setStackInSlot(i, class_1799.field_8037);
            }
        }
        inhibitUpdate = false;
    }

    public void onLoad()
    {
        //noinspection ConstantConditions
        cache = FramingSawRecipeCache.get(field_11863.method_8608());
        if (selectedRecipeId != null && !field_11863.method_8608())
        {
            FramingSawRecipe recipe = field_11863.method_8433().method_8130(selectedRecipeId)
                    .filter(FramingSawRecipe.class::isInstance)
                    .map(FramingSawRecipe.class::cast)
                    .orElse(null);
            selectRecipe(recipe);
        }
    }

    public boolean isUsableByPlayer(class_1657 player)
    {
        //noinspection ConstantConditions
        if (field_11863.method_8321(field_11867) != this)
        {
            return false;
        }
        return !(player.method_5649((double)field_11867.method_10263() + 0.5D, (double)field_11867.method_10264() + 0.5D, (double)field_11867.method_10260() + 0.5D) > 64.0D);
    }

    @Override
    protected void method_11007(class_2487 tag, class_7225.class_7874 registries)
    {
        super.method_11007(tag, registries);
        if (selectedRecipe != null)
        {
            tag.method_10582("recipe", selectedRecipe.getId().toString());
        }
        class_2487 inventoryTag = new class_2487();
        for (int i = 0; i < itemHandler.getSlots(); i++)
        {
            class_1799 stack = itemHandler.getStackInSlot(i);
            if (!stack.method_7960())
            {
                inventoryTag.method_10566("Slot" + i, stack.method_57376(registries, new class_2487()));
            }
        }
        tag.method_10566("inventory", inventoryTag);
        tag.method_10569("energy", energyStorage.getEnergyStored());
        tag.method_10569("progress", progress);
    }

    @Override
    public void method_11014(class_2487 tag, class_7225.class_7874 registries)
    {
        super.method_11014(tag, registries);
        if (tag.method_10545("recipe"))
        {
            selectedRecipeId = new class_2960(tag.method_10558("recipe"));
        }
        class_2487 inventoryTag = tag.method_10562("inventory");
        for (int i = 0; i < itemHandler.getSlots(); i++)
        {
            if (inventoryTag.method_10545("Slot" + i))
            {
                itemHandler.setStackInSlot(i, class_1799.method_57360(registries, inventoryTag.method_10562("Slot" + i)).orElse(class_1799.field_8037));
            }
        }
        energyStorage.setEnergy(tag.method_10550("energy"));
        progress = tag.method_10550("progress");
    }
}
