package xfacthd.framedblocks.common.blockentity.special;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1806;
import net.minecraft.class_19;
import net.minecraft.class_22;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2596;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_7225;
import net.minecraft.class_9209;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import net.minecraft.sounds.*;
import xfacthd.framedblocks.api.block.FramedBlockEntity;
import xfacthd.framedblocks.api.util.FramedConstants;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.data.PropertyHolder;

import java.util.List;
import java.util.Objects;

public class FramedItemFrameBlockEntity extends FramedBlockEntity
{
    public static final int ROTATION_STEPS = 8;
    private static final int MAP_UPDATE_INTERVAL = 10;
    public static final String ITEM_NBT_KEY = "item";
    public static final String NBT_KEY_FRAMED_MAP = FramedConstants.MOD_ID + ":framed";

    private final boolean glowing;
    private class_1799 heldItem = class_1799.field_8037;
    private int rotation = 0;
    private int mapTickOffset = 0;
    private long mapTickCount = 0;

    public FramedItemFrameBlockEntity(class_2338 pos, class_2680 state)
    {
        super(FBContent.BE_TYPE_FRAMED_ITEM_FRAME.get(), pos, state);
        this.glowing = getBlockType() == BlockType.FRAMED_GLOWING_ITEM_FRAME;
    }

    public void tickWithMap()
    {
        if (mapTickCount % MAP_UPDATE_INTERVAL == 0)
        {
            if (mapTickCount == 0)
            {
                // Only start ticking with offset after first tick. Ensures the client will receive the map data ASAP
                mapTickCount = mapTickOffset;
            }

            //noinspection ConstantConditions
            class_22 mapData = class_1806.method_8001(heldItem, field_11863);
            if (mapData != null)
            {
                class_9209 mapId = Objects.requireNonNull(heldItem.method_57824(class_9334.field_49646));
                for (class_1657 player : field_11863.method_18456())
                {
                    mapData.method_102(player, heldItem);
                    class_2596<?> packet = mapData.method_100(mapId, player);
                    if (packet != null)
                    {
                        ((class_3222) player).field_13987.method_14364(packet);
                    }
                }
            }
        }
        mapTickCount++;
    }

    public class_1269 handleFrameInteraction(class_1657 player, class_1268 hand)
    {
        class_1799 stack = player.method_5998(hand);
        if (hasItem())
        {
            //noinspection ConstantConditions
            if (!field_11863.method_8608())
            {
                rotation = (rotation + 1) % ROTATION_STEPS;

                playSound(glowing ? class_3417.field_29192 : class_3417.field_15038);

                method_5431();
                field_11863.method_8413(field_11867, method_11010(), method_11010(), class_2248.field_31036);
            }
            return class_1269.method_29236(field_11863.method_8608());
        }
        else if (!stack.method_7960() && !hasItem())
        {
            //noinspection ConstantConditions
            if (!field_11863.method_8608())
            {
                setItem(stack);
                if (!player.method_7337())
                {
                    stack.method_7934(1);
                }
                player.method_31548().method_5431();

                playSound(glowing ? class_3417.field_29188 : class_3417.field_14667);
            }
            return class_1269.method_29236(field_11863.method_8608());
        }
        return class_1269.field_5811;
    }

    public void removeItem(class_1657 player)
    {
        if (heldItem.method_7909() instanceof class_1806 && heldItem.method_57826(class_9334.field_49628))
        {
            heldItem.method_57381(class_9334.field_49628);
            //noinspection ConstantConditions
            class_22 mapData = class_1806.method_8001(heldItem, field_11863);
            if (mapData instanceof MapMarkerRemover remover)
            {
                remover.framedblocks$removeMapMarker(field_11867);
            }
        }

        if (!player.method_7337() && !player.method_31548().method_7394(heldItem))
        {
            player.method_7328(heldItem, false);
        }

        // Don't clear rotation
        setItem(class_1799.field_8037);

        playSound(glowing ? class_3417.field_29191 : class_3417.field_14770);
    }

    private void setItem(class_1799 item)
    {
        if (item.method_7960())
        {
            heldItem = class_1799.field_8037;
        }
        else
        {
            heldItem = item.method_7972();
            heldItem.method_7939(1);

            if (heldItem.method_7909() instanceof class_1806)
            {
                class_2350 dir = method_11010().method_11654(class_2741.field_12525).method_10153();
                class_2487 tag = new class_2487();
                tag.method_10544("pos", field_11867.method_10063());
                tag.method_10567("y_rot", (byte) dir.method_10161());
                heldItem.method_57379(class_9334.field_49628, class_9279.method_57456(tag));
            }
        }

        method_5431();
        if (!changeMapStateIfNeeded())
        {
            //noinspection ConstantConditions
            field_11863.method_8413(field_11867, method_11010(), method_11010(), class_2248.field_31036);
        }
    }

    public boolean hasItem()
    {
        return !heldItem.method_7960();
    }

    public class_1799 getItem()
    {
        return heldItem;
    }

    public class_1799 getCloneItem()
    {
        class_1799 stack = heldItem.method_7972();
        if (stack.method_57826(class_9334.field_49628))
        {
            stack.method_57381(class_9334.field_49628);
        }
        return stack;
    }

    public int getRotation()
    {
        return rotation;
    }

    public boolean isGlowingFrame()
    {
        return glowing;
    }

    private boolean changeMapStateIfNeeded()
    {
        boolean mapItem = !heldItem.method_7960() && heldItem.method_7909() instanceof class_1806;
        boolean mapState = method_11010().method_11654(PropertyHolder.MAP_FRAME);

        if (mapItem != mapState)
        {
            //noinspection ConstantConditions
            field_11863.method_8501(field_11867, method_11010().method_11657(PropertyHolder.MAP_FRAME, mapItem));
            mapTickCount = mapTickOffset = mapItem ? field_11863.field_9229.method_43048(MAP_UPDATE_INTERVAL) : 0;
            return true;
        }
        return false;
    }

    private void playSound(class_3414 sound)
    {
        //noinspection ConstantConditions
        field_11863.method_43128(null, field_11867.method_10263(), field_11867.method_10264(), field_11867.method_10260(), sound, class_3419.field_15245, 1F, 1F);
    }

    @Override
    public void addAdditionalDrops(List<class_1799> drops, boolean dropCamo)
    {
        super.addAdditionalDrops(drops, dropCamo);
        if (!heldItem.method_7960())
        {
            drops.add(getCloneItem());
        }
    }

    // Network

    private void readFromNetwork(class_2487 tag, class_7225.class_7874 provider)
    {
        heldItem = class_1799.method_57359(provider, tag.method_10562(ITEM_NBT_KEY));
        rotation = tag.method_10571("rotation");
    }

    private void writeToNetwork(class_2487 tag, class_7225.class_7874 provider)
    {
        tag.method_10566(ITEM_NBT_KEY, heldItem.method_57376(provider, new class_2487()));
        tag.method_10567("rotation", (byte) rotation);
    }

    @Override
    protected boolean readFromDataPacket(class_2487 tag)
    {
        readFromNetwork(tag, field_11863.method_30349());
        return super.readFromDataPacket(tag);
    }

    @Override
    protected void writeToDataPacket(class_2487 tag)
    {
        super.writeToDataPacket(tag);
        writeToNetwork(tag, field_11863.method_30349());
    }

    @Override
    public void handleUpdateTag(class_2487 tag)
    {
        super.handleUpdateTag(tag);
        readFromNetwork(tag, field_11863.method_30349());
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 provider)
    {
        class_2487 tag = super.method_16887(provider);
        writeToNetwork(tag, provider);
        return tag;
    }

    // NBT

    @Override
    public void method_11014(class_2487 tag, class_7225.class_7874 provider)
    {
        super.method_11014(tag, provider);

        readFromNetwork(tag, provider);
        mapTickOffset = tag.method_10550("map_tick_offset");
    }

    @Override
    public void method_11007(class_2487 tag, class_7225.class_7874 provider)
    {
        super.method_11007(tag, provider);

        writeToNetwork(tag, provider);
        tag.method_10569("map_tick_offset", mapTickOffset);
    }



    public record FramedMap(class_2338 pos, int yRot)
    {
        public static FramedMap load(class_2487 tag)
        {
            return new FramedMap(
                    class_2338.method_10092(tag.method_10537("pos")),
                    tag.method_10550("y_rot")
            );
        }

        public class_2487 save()
        {
            class_2487 tag = new class_2487();
            tag.method_10544("pos", pos.method_10063());
            tag.method_10569("y_rot", yRot);
            return tag;
        }

        public static String makeFrameId(class_2338 pos)
        {
            return FramedConstants.MOD_ID + ":" + class_19.method_81(pos);
        }
    }

    public interface MapMarkerRemover
    {
        void framedblocks$removeMapMarker(class_2338 pos);
    }
}
