package xfacthd.framedblocks.common.blockentity.special;

import net.minecraft.class_2350;
import net.minecraft.class_2680;

public interface ICollapsibleCopycatBlockEntity
{
    int getFaceOffset(class_2680 state, class_2350 side);

    int getPackedOffsets(class_2680 state);
}
