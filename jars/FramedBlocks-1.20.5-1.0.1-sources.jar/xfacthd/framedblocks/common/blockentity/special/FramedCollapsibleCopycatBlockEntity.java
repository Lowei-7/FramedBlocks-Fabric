package xfacthd.framedblocks.common.blockentity.special;

import net.minecraft.class_1657;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import net.minecraft.class_7225;
import xfacthd.framedblocks.api.block.FramedBlockEntity;
import xfacthd.framedblocks.api.model.data.FramedBlockData;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.data.PropertyHolder;

public class FramedCollapsibleCopycatBlockEntity extends FramedBlockEntity implements ICollapsibleCopycatBlockEntity
{
    private static final class_2350[] DIRECTIONS = class_2350.values();
    private static final class_2350[] HORIZONTAL_DIRECTIONS = class_2350.class_2353.field_11062.method_29716().toArray(class_2350[]::new);
    private static final int MAX_OFFSET_BEACON_OCCLUSION = 5;

    private int packedOffsets = 0;
    private boolean occludesBeacon = true;

    public FramedCollapsibleCopycatBlockEntity(class_2338 pos, class_2680 state)
    {
        super(FBContent.BE_TYPE_FRAMED_COLLAPSIBLE_COPYCAT_BLOCK.get(), pos, state);
    }

    public void handleDeform(class_1657 player)
    {
        class_239 hit = player.method_5745(10D, 1F, false);
        if (!(hit instanceof class_3965 blockHit))
        {
            return;
        }

        class_2350 faceHit = blockHit.method_17780();
        boolean sneak = player.method_5715();
        boolean changed = false;
        int offset = getFaceOffset(faceHit);
        if (sneak && offset > 0)
        {
            setFaceOffset(faceHit, offset - 1);
            changed = true;
        }
        else if (!sneak && offset < 15 - getFaceOffset(faceHit.method_10153()))
        {
            setFaceOffset(faceHit, offset + 1);
            changed = true;
        }
        if (changed)
        {
            updateBeaconOcclusion();
            if (!updateFaceSolidity())
            {
                //noinspection ConstantConditions
                field_11863.method_8413(field_11867, method_11010(), method_11010(), class_2248.field_31036);
            }
            method_5431();
        }
    }


    private void setFaceOffset(class_2350 side, int offset)
    {
        int idx = side.ordinal() * 4;
        int mask = 0x0F << idx;
        packedOffsets = (packedOffsets & ~mask) | (offset << idx);
    }

    public int getFaceOffset(class_2350 side)
    {
        return (byte) (packedOffsets >> (side.ordinal() * 4) & 0xF);
    }

    @Override
    public int getFaceOffset(class_2680 state, class_2350 side)
    {
        return getFaceOffset(side);
    }

    @Override
    public int getPackedOffsets(class_2680 state)
    {
        return packedOffsets;
    }

    @Override
    public Object getRenderAttachmentData()
    {
        getModelDataInternal().setPackedOffsets(packedOffsets);
        return super.getRenderAttachmentData();
    }

    public boolean doesOccludeBeaconBeam()
    {
        return occludesBeacon;
    }

    public boolean updateFaceSolidity()
    {
        class_2680 state = method_11010();
        int solid = computeSolidFaces(packedOffsets);
        if (state.method_11654(PropertyHolder.SOLID_FACES) != solid)
        {
            //noinspection ConstantConditions
            field_11863.method_8501(field_11867, state.method_11657(PropertyHolder.SOLID_FACES, solid));
            return true;
        }
        return false;
    }

    private void updateBeaconOcclusion()
    {
        occludesBeacon = true;
        for (class_2350 face : HORIZONTAL_DIRECTIONS)
        {
            if (getFaceOffset(face) > MAX_OFFSET_BEACON_OCCLUSION)
            {
                occludesBeacon = false;
                break;
            }
        }
    }


    @Override
    protected void writeToDataPacket(class_2487 nbt)
    {
        super.writeToDataPacket(nbt);
        nbt.method_10569("offsets", packedOffsets);
        nbt.method_10556("occludesBeacon", occludesBeacon);
    }

    @Override
    protected boolean readFromDataPacket(class_2487 nbt)
    {
        boolean needUpdate = super.readFromDataPacket(nbt);

        int packed = nbt.method_10550("offsets");
        if (packed != packedOffsets)
        {
            packedOffsets = packed;

            needUpdate = true;
            updateCulling(true, false);
        }

        occludesBeacon = nbt.method_10577("occludesBeacon");

        return needUpdate;
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registries)
    {
        class_2487 nbt = super.method_16887(registries);
        nbt.method_10569("offsets", packedOffsets);
        nbt.method_10556("occludesBeacon", occludesBeacon);
        return nbt;
    }

    @Override
    public void handleUpdateTag(class_2487 nbt)
    {
        packedOffsets = nbt.method_10550("offsets");
        occludesBeacon = nbt.method_10577("occludesBeacon");

        super.handleUpdateTag(nbt);
    }

    @Override
    public void method_11007(class_2487 nbt, class_7225.class_7874 registries)
    {
        super.method_11007(nbt, registries);
        nbt.method_10569("offsets", packedOffsets);
    }

    @Override
    public void method_11014(class_2487 nbt, class_7225.class_7874 registries)
    {
        super.method_11014(nbt, registries);
        packedOffsets = nbt.method_10550("offsets");
        updateBeaconOcclusion();
    }



    public static byte[] unpackOffsets(int packed)
    {
        byte[] offsets = new byte[DIRECTIONS.length];

        for (int i = 0; i < DIRECTIONS.length; i++)
        {
            offsets[i] = (byte) (packed >> (i * 4) & 0xF);
        }

        return offsets;
    }

    public static int computeSolidFaces(int packedOffsets)
    {
        int solid = 0;
        for (class_2350 face : DIRECTIONS)
        {
            if (((packedOffsets >> (face.ordinal() * 4)) & 0xF) == 0)
            {
                solid |= (1 << face.ordinal());
            }
        }
        return solid;
    }
}
