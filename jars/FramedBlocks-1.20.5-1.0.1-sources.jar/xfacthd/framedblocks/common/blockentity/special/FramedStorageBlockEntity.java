package xfacthd.framedblocks.common.blockentity.special;

import net.minecraft.class_1263;
import net.minecraft.class_1275;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3532;
import net.minecraft.class_3829;
import net.minecraft.class_3908;
import net.minecraft.class_7225;
import net.minecraft.world.*;
import xfacthd.framedblocks.api.block.FramedBlockEntity;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.menu.FramedStorageMenu;

import org.jetbrains.annotations.Nullable;
import java.util.ArrayList;
import java.util.List;

public class FramedStorageBlockEntity extends FramedBlockEntity implements class_3908, class_1275, class_3829
{
    public static final class_2561 TITLE = Utils.translate("title", "framed_secret_storage");
    public static final String INVENTORY_NBT_KEY = "inventory";

    public static final int INVENTORY_SIZE = 27;

    // Real inventory backing the FramedStorageMenu. The menu binds directly to this
    // container so every item change is written straight back into the block entity
    // and persisted to NBT on chunk save.
    private final class_1263 inventory = new class_1277(INVENTORY_SIZE)
    {
        @Override
        public void method_5447(int slot, class_1799 stack)
        {
            super.method_5447(slot, stack);
            FramedStorageBlockEntity.this.method_5431();
        }

        @Override
        public class_1799 method_5434(int slot, int amount)
        {
            class_1799 stack = super.method_5434(slot, amount);
            FramedStorageBlockEntity.this.method_5431();
            return stack;
        }
    };
    private class_2561 customName = null;

    public FramedStorageBlockEntity(class_2338 pos, class_2680 state)
    {
        super(FBContent.BE_TYPE_FRAMED_SECRET_STORAGE.get(), pos, state);
    }

    protected FramedStorageBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state)
    {
        super(type, pos, state);
    }

    public class_1263 getInventory()
    {
        return inventory;
    }

    public void open(class_3222 player)
    {
        player.method_17355(this);
    }

    public boolean isUsableByPlayer(class_1657 player)
    {
        //noinspection ConstantConditions
        if (field_11863.method_8321(field_11867) != this)
        {
            return false;
        }
        return !(player.method_5649((double)field_11867.method_10263() + 0.5D, (double)field_11867.method_10264() + 0.5D, (double)field_11867.method_10260() + 0.5D) > 64.0D);
    }

    public List<class_1799> getDrops()
    {
        List<class_1799> drops = new ArrayList<>();
        for (int i = 0; i < inventory.method_5439(); i++)
        {
            class_1799 stack = inventory.method_5438(i);
            if (!stack.method_7960())
            {
                drops.add(stack);
            }
        }
        return drops;
    }

    @Override
    public void method_5448()
    {
        inventory.method_5448();
    }

    public int getAnalogOutputSignal()
    {
        int stacks = 0;
        float fullness = 0;

        for (int i = 0; i < inventory.method_5439(); i++)
        {
            class_1799 stack = inventory.method_5438(i);
            if (!stack.method_7960())
            {
                float sizeLimit = stack.method_7914();
                fullness += (float)stack.method_7947() / sizeLimit;
                stacks++;
            }
        }

        fullness /= (float)inventory.method_5439();
        return class_3532.method_15375(fullness * 14F) + (stacks > 0 ? 1 : 0);
    }

    public void setCustomName(class_2561 customName)
    {
        this.customName = customName;
        method_5431();
    }

    @Override
    public class_2561 method_5477()
    {
        return customName != null ? customName : getDefaultName();
    }

    @Override
    public class_2561 method_5797()
    {
        return customName;
    }

    @Override //Prevent writing inventory contents
    public class_2487 writeToBlueprint()
    {
        class_2487 tag = method_38244(field_11863.method_30349());
        tag.method_10551(INVENTORY_NBT_KEY);
        tag.method_10551("custom_name");
        return tag;
    }

    @Override
    public void method_11007(class_2487 nbt, class_7225.class_7874 registries)
    {
        class_2499 itemsTag = new class_2499();
        for (int i = 0; i < inventory.method_5439(); i++)
        {
            class_1799 stack = inventory.method_5438(i);
            if (!stack.method_7960())
            {
                class_2487 itemTag = new class_2487();
                itemTag.method_10567("Slot", (byte)i);
                stack.method_57376(registries, itemTag);
                itemsTag.add(itemTag);
            }
        }
        if (!itemsTag.isEmpty())
        {
            nbt.method_10566(INVENTORY_NBT_KEY, itemsTag);
        }

        if (customName != null)
        {
            nbt.method_10582("custom_name", class_2561.class_2562.method_10867(customName, registries));
        }
        super.method_11007(nbt, registries);
    }

    @Override
    public void method_11014(class_2487 nbt, class_7225.class_7874 registries)
    {
        super.method_11014(nbt, registries);

        inventory.method_5448();
        if (nbt.method_10573(INVENTORY_NBT_KEY, class_2520.field_33259))
        {
            class_2499 itemsTag = nbt.method_10554(INVENTORY_NBT_KEY, class_2520.field_33260);
            for (int i = 0; i < itemsTag.size(); i++)
            {
                class_2487 itemTag = itemsTag.method_10602(i);
                int slot = itemTag.method_10571("Slot") & 0xFF;
                if (slot >= 0 && slot < inventory.method_5439())
                {
                    inventory.method_5447(slot, class_1799.method_57360(registries, itemTag).orElse(class_1799.field_8037));
                }
            }
        }

        if (nbt.method_10573("custom_name", class_2520.field_33258))
        {
            customName = class_2561.class_2562.method_10877(nbt.method_10558("custom_name"), registries);
        }
    }

    protected class_2561 getDefaultName()
    {
        return TITLE;
    }

    @Override
    public final class_2561 method_5476()
    {
        return method_5477();
    }

    @Override
    public class_1703 createMenu(int windowId, class_1661 inv, class_1657 player)
    {
        return new FramedStorageMenu(windowId, inv, this);
    }
}
