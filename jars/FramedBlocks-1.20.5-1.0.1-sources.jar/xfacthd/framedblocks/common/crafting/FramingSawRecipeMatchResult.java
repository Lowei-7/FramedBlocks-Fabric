package xfacthd.framedblocks.common.crafting;

import xfacthd.framedblocks.api.util.Utils;

import java.util.Locale;
import net.minecraft.class_124;
import net.minecraft.class_2561;

public enum FramingSawRecipeMatchResult
{
    SUCCESS(true),
    MATERIAL_VALUE(false),
    MATERIAL_LCM(false),
    OUTPUT_SIZE(false),
    MISSING_ADDITIVE_0(false, 0),
    MISSING_ADDITIVE_1(false, 1),
    MISSING_ADDITIVE_2(false, 2),
    UNEXPECTED_ADDITIVE_0(false, 0),
    UNEXPECTED_ADDITIVE_1(false, 1),
    UNEXPECTED_ADDITIVE_2(false, 2),
    INCORRECT_ADDITIVE_0(false, 0),
    INCORRECT_ADDITIVE_1(false, 1),
    INCORRECT_ADDITIVE_2(false, 2),
    INSUFFICIENT_ADDITIVE_0(false, 0),
    INSUFFICIENT_ADDITIVE_1(false, 1),
    INSUFFICIENT_ADDITIVE_2(false, 2);

    static final FramingSawRecipeMatchResult[] MISSING_ADDITIVE = new FramingSawRecipeMatchResult[] {
            MISSING_ADDITIVE_0, MISSING_ADDITIVE_1, MISSING_ADDITIVE_2
    };
    static final FramingSawRecipeMatchResult[] UNEXPECTED_ADDITIVE = new FramingSawRecipeMatchResult[] {
            UNEXPECTED_ADDITIVE_0, UNEXPECTED_ADDITIVE_1, UNEXPECTED_ADDITIVE_2
    };
    static final FramingSawRecipeMatchResult[] INCORRECT_ADDITIVE = new FramingSawRecipeMatchResult[] {
            INCORRECT_ADDITIVE_0, INCORRECT_ADDITIVE_1, INCORRECT_ADDITIVE_2
    };
    static final FramingSawRecipeMatchResult[] INSUFFICIENT_ADDITIVE = new FramingSawRecipeMatchResult[] {
            INSUFFICIENT_ADDITIVE_0, INSUFFICIENT_ADDITIVE_1, INSUFFICIENT_ADDITIVE_2
    };
    private static final FramingSawRecipeMatchResult[] VALUES = values();

    private final boolean success;
    private final int additiveSlot;
    private final class_2561 translation;

    FramingSawRecipeMatchResult(boolean success)
    {
        this(success, -1);
    }

    FramingSawRecipeMatchResult(boolean success, int additiveSlot)
    {
        this.success = success;
        this.additiveSlot = additiveSlot;
        this.translation = Utils.translate(
                "msg", "frame_crafter.fail." + toString().toLowerCase(Locale.ROOT)
        ).method_27692(success ? class_124.field_1060 : class_124.field_1061);
    }

    public boolean success()
    {
        return success;
    }

    public int additiveSlot()
    {
        return additiveSlot;
    }

    public class_2561 translation()
    {
        return translation;
    }



    public static FramingSawRecipeMatchResult valueOf(int idx)
    {
        return VALUES[idx];
    }
}
