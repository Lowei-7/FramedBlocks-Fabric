package xfacthd.framedblocks.common.crafting;

import com.google.common.base.Preconditions;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.util.fabric.RegistryObject;

import java.util.List;
import net.minecraft.class_175;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_2960;
import net.minecraft.class_5797;
import net.minecraft.class_8790;

public final class FramingSawRecipeBuilder implements class_5797
{
    private final class_1792 result;
    private final int count;
    private int material = 0;
    private List<FramingSawRecipeAdditive> additives = null;
    private boolean disabled = false;

    private FramingSawRecipeBuilder(class_1935 result, int count)
    {
        this.result = result.method_8389();
        this.count = count;
    }

    public static <T extends class_1935> FramingSawRecipeBuilder builder(RegistryObject<T> result)
    {
        return builder(result.get());
    }

    public static FramingSawRecipeBuilder builder(class_1935 result)
    {
        return builder(result, 1);
    }

    public static <T extends class_1935> FramingSawRecipeBuilder builder(RegistryObject<T> result, int count)
    {
        return builder(result.get(), count);
    }

    public static FramingSawRecipeBuilder builder(class_1935 result, int count)
    {
        Preconditions.checkNotNull(result, "Result must be non-null");
        Preconditions.checkArgument(count > 0, "Result count must be greater than 0");
        return new FramingSawRecipeBuilder(result, count);
    }

    public FramingSawRecipeBuilder material(int material)
    {
        Preconditions.checkArgument(material > 0, "Material value must be greater than 0");
        this.material = material;
        return this;
    }

    public FramingSawRecipeBuilder additive(FramingSawRecipeAdditive additive)
    {
        this.additives = additive != null ? List.of(additive) : null;
        return this;
    }

    public FramingSawRecipeBuilder additives(List<FramingSawRecipeAdditive> additives)
    {
        this.additives = additives;
        return this;
    }

    public FramingSawRecipeBuilder disabled()
    {
        this.disabled = true;
        return this;
    }

    @Override
    public class_5797 method_33530(String criterionName, class_175<?> criterion)
    {
        throw new UnsupportedOperationException("Advancements are not supported");
    }

    @Override
    public class_5797 method_33529(@Nullable String groupName)
    {
        throw new UnsupportedOperationException("Recipe groups are not supported");
    }

    @Override
    public class_1792 method_36441()
    {
        return result;
    }

    @Override
    public void method_17972(class_8790 output, class_2960 recipeId)
    {
        Preconditions.checkState(material > 0, "Material value not set");
        Preconditions.checkState(material / count * count == material, "Material value not divisible by result size");

        recipeId = recipeId.method_45138("framing_saw/");
        FramingSawRecipe recipe = new FramingSawRecipe(
                material,
                additives != null ? additives : List.of(),
                new class_1799(result, count),
                disabled
        );
        recipe.setId(recipeId);
        output.method_53819(recipeId, recipe, null);
    }
}
