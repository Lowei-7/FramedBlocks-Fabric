package xfacthd.framedblocks.common.crafting;

import net.minecraft.class_1263;
import net.minecraft.class_1799;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_7225;
import net.minecraft.world.item.crafting.*;
import net.minecraftforge.common.util.Lazy;
import xfacthd.framedblocks.api.type.IBlockType;
import xfacthd.framedblocks.common.FBContent;

import java.util.*;

public final class FramingSawRecipe implements class_1860<class_1263>
{
    public static final int CUBE_MATERIAL_VALUE = 6144; // Empirically determined value
    public static final int MAX_ADDITIVE_COUNT = 3;
    private static final Lazy<class_1799> TOAST_ICON = Lazy.of(() -> new class_1799(FBContent.BLOCK_FRAMING_SAW.get()));

    private class_2960 id;
    private final int materialAmount;
    private final List<FramingSawRecipeAdditive> additives;
    private final class_1799 result;
    private final IBlockType resultType;
    private final boolean disabled;

    FramingSawRecipe(int materialAmount, List<FramingSawRecipeAdditive> additives, class_1799 result, boolean disabled)
    {
        this.materialAmount = materialAmount;
        this.additives = additives;
        this.result = result;
        this.resultType = FramingSawRecipeSerializer.findResultType(result);
        this.disabled = disabled;
    }

    void setId(class_2960 id)
    {
        this.id = id;
    }

    public class_2960 getId()
    {
        return id;
    }

    @Override
    public boolean method_8115(class_1263 container, class_1937 level)
    {
        return matchWithResult(container, level).success();
    }

    public FramingSawRecipeMatchResult matchWithResult(class_1263 container, class_1937 level)
    {
        class_1799 input = container.method_5438(0);
        if (input.method_7960())
        {
            return FramingSawRecipeMatchResult.MATERIAL_VALUE;
        }

        int inputValue = FramingSawRecipeCalculation.getInputValue(input, level.method_8608());
        int totalInputValue = inputValue * input.method_7947();
        if (totalInputValue < materialAmount)
        {
            return FramingSawRecipeMatchResult.MATERIAL_VALUE;
        }

        long matLcm = FramingSawRecipeCalculation.getMaterialLCM(this, inputValue);
        if (matLcm > totalInputValue)
        {
            return FramingSawRecipeMatchResult.MATERIAL_LCM;
        }

        if (FramingSawRecipeCalculation.getOutputCount(materialAmount, result, matLcm) > result.method_7914())
        {
            return FramingSawRecipeMatchResult.OUTPUT_SIZE;
        }

        for (int idx = 0; idx < MAX_ADDITIVE_COUNT; idx++)
        {
            class_1799 stack = container.method_5438(idx + 1);
            FramingSawRecipeAdditive additive = idx < additives.size() ? additives.get(idx) : null;

            boolean empty = stack.method_7960();

            if (empty && additive == null)
            {
                continue;
            }

            if (!empty && additive == null)
            {
                return FramingSawRecipeMatchResult.UNEXPECTED_ADDITIVE[idx];
            }
            else if (empty /* && additive != null*/)
            {
                return FramingSawRecipeMatchResult.MISSING_ADDITIVE[idx];
            }
            else if (!additive.ingredient().method_8093(stack))
            {
                return FramingSawRecipeMatchResult.INCORRECT_ADDITIVE[idx];
            }

            if (stack.method_7947() < FramingSawRecipeCalculation.getAdditiveCount(this, additive, matLcm))
            {
                return FramingSawRecipeMatchResult.INSUFFICIENT_ADDITIVE[idx];
            }
        }
        return FramingSawRecipeMatchResult.SUCCESS;
    }

    public FramingSawRecipeCalculation makeCraftingCalculation(class_1263 container, boolean client)
    {
        return new FramingSawRecipeCalculation(this, container, client);
    }

    @Override
    public class_1799 method_8116(class_1263 container, class_7225.class_7874 access)
    {
        return result.method_7972();
    }

    @Override
    public boolean method_8113(int width, int height)
    {
        return true;
    }

    public int getMaterialAmount()
    {
        return materialAmount;
    }

    public List<FramingSawRecipeAdditive> getAdditives()
    {
        return additives;
    }

    public class_1799 getResult()
    {
        return result;
    }

    @Override
    public class_1799 method_8110(class_7225.class_7874 registries)
    {
        return result;
    }

    public IBlockType getResultType()
    {
        return resultType;
    }

    public boolean isDisabled()
    {
        return disabled;
    }

    @Override
    public boolean method_8118()
    {
        return true;
    }

    @Override
    public class_1799 method_17447()
    {
        return TOAST_ICON.get();
    }

    @Override
    public class_1865<?> method_8119()
    {
        return FBContent.RECIPE_SERIALIZER_FRAMING_SAW_RECIPE.get();
    }

    @Override
    public class_3956<?> method_17716()
    {
        return FBContent.RECIPE_TYPE_FRAMING_SAW_RECIPE.get();
    }
}
