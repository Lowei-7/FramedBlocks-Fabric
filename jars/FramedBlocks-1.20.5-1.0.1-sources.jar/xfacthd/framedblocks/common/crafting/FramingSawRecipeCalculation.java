package xfacthd.framedblocks.common.crafting;

import net.minecraft.class_1263;
import net.minecraft.class_1799;
import xfacthd.framedblocks.common.util.MathUtils;

public final class FramingSawRecipeCalculation
{
    private final FramingSawRecipe recipe;
    private final int inputValue;
    private final long lcm;

    FramingSawRecipeCalculation(FramingSawRecipe recipe, class_1263 container, boolean client)
    {
        this.recipe = recipe;
        this.inputValue = getInputValue(container.method_5438(0), client);
        this.lcm = getMaterialLCM(recipe, inputValue);
    }

    public int getInputCount()
    {
        return (int) (lcm / inputValue);
    }

    public int getOutputCount()
    {
        return getOutputCount(recipe.getMaterialAmount(), recipe.getResult(), lcm);
    }

    public int getAdditiveCount(int idx)
    {
        return getAdditiveCount(recipe, recipe.getAdditives().get(idx), lcm);
    }



    static int getInputValue(class_1799 input, boolean client)
    {
        FramingSawRecipeCache cache = FramingSawRecipeCache.get(client);
        return cache.getMaterialValue(input.method_7909());
    }

    static long getMaterialLCM(FramingSawRecipe recipe, int inputValue)
    {
        return MathUtils.lcm(inputValue, recipe.getMaterialAmount());
    }

    static int getOutputCount(int materialAmount, class_1799 result, long lcm)
    {
        return (int) (lcm / materialAmount * result.method_7947());
    }

    static int getAdditiveCount(FramingSawRecipe recipe, FramingSawRecipeAdditive additive, long lcm)
    {
        return (int) (lcm / recipe.getMaterialAmount()) * additive.count();
    }
}
