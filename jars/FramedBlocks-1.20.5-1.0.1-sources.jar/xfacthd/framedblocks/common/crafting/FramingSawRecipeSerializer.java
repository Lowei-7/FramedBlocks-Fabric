package xfacthd.framedblocks.common.crafting;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import xfacthd.framedblocks.api.block.IFramedBlock;
import xfacthd.framedblocks.api.type.IBlockType;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public final class FramingSawRecipeSerializer implements class_1865<FramingSawRecipe>
{
    private static final class_9139<class_9129, FramingSawRecipeAdditive> ADDITIVE_STREAM_CODEC = class_9139.method_56435(
            class_1856.field_48355,
            FramingSawRecipeAdditive::ingredient,
            class_9135.field_49675,
            FramingSawRecipeAdditive::count,
            FramingSawRecipeAdditive::new
    );

    private static final class_9139<class_9129, List<FramingSawRecipeAdditive>> ADDITIVES_STREAM_CODEC = class_9135.method_56376(ArrayList::new, ADDITIVE_STREAM_CODEC);

    public static final MapCodec<FramingSawRecipe> CODEC = RecordCodecBuilder.mapCodec(inst -> inst.group(
            Codec.INT.fieldOf("material").forGetter(FramingSawRecipe::getMaterialAmount),
            FramingSawRecipeAdditive.LIST_CODEC.optionalFieldOf("additives", List.of()).forGetter(FramingSawRecipe::getAdditives),
            class_1799.field_24671.fieldOf("result").forGetter(FramingSawRecipe::getResult),
            Codec.BOOL.optionalFieldOf("disabled", false).forGetter(FramingSawRecipe::isDisabled)
    ).apply(inst, FramingSawRecipe::new));

    public static final class_9139<class_9129, FramingSawRecipe> STREAM_CODEC = class_9139.method_56905(
            class_9135.field_49675,
            FramingSawRecipe::getMaterialAmount,
            ADDITIVES_STREAM_CODEC,
            FramingSawRecipe::getAdditives,
            class_1799.field_49268,
            FramingSawRecipe::getResult,
            class_9135.field_48547,
            FramingSawRecipe::isDisabled,
            FramingSawRecipe::new
    );

    @Override
    public MapCodec<FramingSawRecipe> method_53736()
    {
        return CODEC;
    }

    @Override
    public class_9139<class_9129, FramingSawRecipe> method_56104()
    {
        return STREAM_CODEC;
    }

    static IBlockType findResultType(class_1799 result)
    {
        if (!(result.method_7909() instanceof class_1747 item))
        {
            throw new IllegalArgumentException("Result items must be BlockItems");
        }
        if (!(item.method_7711() instanceof IFramedBlock block))
        {
            throw new IllegalArgumentException("Block of result items must be IFramedBlocks");
        }
        return block.getBlockType();
    }
}