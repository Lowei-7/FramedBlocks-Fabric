package xfacthd.framedblocks.common.block.slab;

import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.block.PlacementStateBuilder;
import xfacthd.framedblocks.common.blockentity.doubled.FramedAdjustableDoubleBlockEntity;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.data.doubleblock.*;
import xfacthd.framedblocks.common.util.DoubleBlockTopInteractionMode;

import java.util.function.Function;
import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3545;

public class FramedAdjustableDoublePanelBlock extends FramedAdjustableDoubleBlock
{
    private FramedAdjustableDoublePanelBlock(
            BlockType type,
            Function<class_2680, class_3545<class_2680, class_2680>> statePairBuilder,
            class_2591.class_5559<FramedAdjustableDoubleBlockEntity> beSupplier
    )
    {
        super(type, state -> state.method_11654(FramedProperties.FACING_HOR), statePairBuilder, beSupplier);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(FramedProperties.FACING_HOR);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return PlacementStateBuilder.of(this, ctx)
                .withTargetOrHorizontalFacing()
                .build();
    }

    @Override
    public DoubleBlockTopInteractionMode calculateTopInteractionMode(class_2680 state)
    {
        return DoubleBlockTopInteractionMode.EITHER;
    }

    @Override
    public SolidityCheck calculateSolidityCheck(class_2680 state, class_2350 side)
    {
        class_2350 facing = getFacing(state);
        if (side == facing.method_10153())
        {
            return SolidityCheck.FIRST;
        }
        if (side == facing)
        {
            return SolidityCheck.SECOND;
        }
        return SolidityCheck.BOTH;
    }

    @Override
    public CamoGetter calculateCamoGetter(class_2680 state, class_2350 side, @Nullable class_2350 edge)
    {
        class_2350 facing = getFacing(state);
        if (side == facing.method_10153())
        {
            return CamoGetter.FIRST;
        }
        if (side == facing)
        {
            return CamoGetter.SECOND;
        }
        if (edge == facing.method_10153())
        {
            return CamoGetter.FIRST;
        }
        if (edge == facing)
        {
            return CamoGetter.SECOND;
        }
        return CamoGetter.NONE;
    }



    public static FramedAdjustableDoublePanelBlock standard()
    {
        return new FramedAdjustableDoublePanelBlock(
                BlockType.FRAMED_ADJ_DOUBLE_PANEL,
                FramedAdjustableDoubleBlock::makeStandardStatePair,
                FramedAdjustableDoubleBlockEntity::standard
        );
    }

    public static FramedAdjustableDoublePanelBlock copycat()
    {
        return new FramedAdjustableDoublePanelBlock(
                BlockType.FRAMED_ADJ_DOUBLE_COPYCAT_PANEL,
                FramedAdjustableDoubleBlock::makeCopycatStatePair,
                FramedAdjustableDoubleBlockEntity::copycat
        );
    }
}
