package xfacthd.framedblocks.common.block.slab;

import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3545;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.AbstractFramedDoubleBlock;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.blockentity.doubled.FramedDoubleSlabBlockEntity;
import xfacthd.framedblocks.common.data.doubleblock.CamoGetter;
import xfacthd.framedblocks.common.data.doubleblock.SolidityCheck;
import xfacthd.framedblocks.common.util.DoubleBlockTopInteractionMode;

public class FramedDoubleSlabBlock extends AbstractFramedDoubleBlock
{
    public FramedDoubleSlabBlock()
    {
        super(BlockType.FRAMED_DOUBLE_SLAB);
    }

    public class_1799 getCloneItemStack(class_2680 state, class_239 target, class_1922 level, class_2338 pos, class_1657 player)
    {
        return new class_1799(FBContent.BLOCK_FRAMED_SLAB.get());
    }

    @Override
    public class_3545<class_2680, class_2680> calculateBlockPair(class_2680 state)
    {
        class_2680 defState = FBContent.BLOCK_FRAMED_SLAB.get().method_9564();
        return new class_3545<>(
                defState.method_11657(FramedProperties.TOP, false),
                defState.method_11657(FramedProperties.TOP, true)
        );
    }

    @Override
    public DoubleBlockTopInteractionMode calculateTopInteractionMode(class_2680 state)
    {
        return DoubleBlockTopInteractionMode.SECOND;
    }

    @Override
    public CamoGetter calculateCamoGetter(class_2680 state, class_2350 side, @Nullable class_2350 edge)
    {
        if (side == class_2350.field_11036)
        {
            return CamoGetter.SECOND;
        }
        else if (side == class_2350.field_11033)
        {
            return CamoGetter.FIRST;
        }
        else if (edge == class_2350.field_11036)
        {
            return CamoGetter.SECOND;
        }
        else if (edge == class_2350.field_11033)
        {
            return CamoGetter.FIRST;
        }
        return CamoGetter.NONE;
    }

    @Override
    public SolidityCheck calculateSolidityCheck(class_2680 state, class_2350 side)
    {
        return switch (side)
        {
            case field_11033 -> SolidityCheck.FIRST;
            case field_11036 -> SolidityCheck.SECOND;
            default -> SolidityCheck.BOTH;
        };
    }

    @Override
    public final class_2586 method_10123(class_2338 pos, class_2680 state)
    {
        return new FramedDoubleSlabBlockEntity(pos, state);
    }
}