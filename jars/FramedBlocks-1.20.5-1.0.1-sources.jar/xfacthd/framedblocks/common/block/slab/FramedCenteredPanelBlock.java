package xfacthd.framedblocks.common.block.slab;

import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.block.PlacementStateBuilder;
import xfacthd.framedblocks.common.block.FramedBlock;
import xfacthd.framedblocks.common.data.BlockType;

public class FramedCenteredPanelBlock extends FramedBlock
{
    public FramedCenteredPanelBlock()
    {
        super(BlockType.FRAMED_CENTERED_PANEL);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(FramedProperties.FACING_NE, FramedProperties.SOLID, class_2741.field_12508);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return PlacementStateBuilder.of(this, ctx)
                .withCustom((state, modCtx) ->
                {
                    class_2350 dir = modCtx.method_8042();
                    if (dir == class_2350.field_11035 || dir == class_2350.field_11039)
                    {
                        dir = dir.method_10153();
                    }
                    return state.method_11657(FramedProperties.FACING_NE, dir);
                })
                .withWater()
                .build();
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9598(class_2680 state, class_2470 rot)
    {
        if (rot == class_2470.field_11467 || rot == class_2470.field_11464)
        {
            return state;
        }
        return state.method_28493(FramedProperties.FACING_NE);
    }
}
