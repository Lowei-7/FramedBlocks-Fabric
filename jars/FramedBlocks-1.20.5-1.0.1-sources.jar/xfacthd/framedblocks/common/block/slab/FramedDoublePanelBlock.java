package xfacthd.framedblocks.common.block.slab;

import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3545;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.AbstractFramedDoubleBlock;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.blockentity.doubled.FramedDoublePanelBlockEntity;
import xfacthd.framedblocks.common.data.doubleblock.CamoGetter;
import xfacthd.framedblocks.common.data.doubleblock.SolidityCheck;
import xfacthd.framedblocks.common.util.DoubleBlockTopInteractionMode;

public class FramedDoublePanelBlock extends AbstractFramedDoubleBlock
{
    public FramedDoublePanelBlock()
    {
        super(BlockType.FRAMED_DOUBLE_PANEL);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(FramedProperties.FACING_NE);
    }

    @Override //Used by the blueprint
    public class_2680 method_9605(class_1750 context)
    {
        class_2350 dir = context.method_8042();
        if (dir == class_2350.field_11035 || dir == class_2350.field_11039) { dir = dir.method_10153(); }
        return method_9564().method_11657(FramedProperties.FACING_NE, dir);
    }

    public class_1799 getCloneItemStack(class_2680 state, class_239 target, class_1922 level, class_2338 pos, class_1657 player)
    {
        return new class_1799(FBContent.BLOCK_FRAMED_PANEL.get());
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9598(class_2680 state, class_2470 rot)
    {
        if (rot == class_2470.field_11467 || rot == class_2470.field_11464)
        {
            return state;
        }
        class_2350 dir = state.method_11654(FramedProperties.FACING_NE);
        dir = dir == class_2350.field_11043 ? class_2350.field_11034 : class_2350.field_11043;
        return state.method_11657(FramedProperties.FACING_NE, dir);
    }

    @Override
    public class_3545<class_2680, class_2680> calculateBlockPair(class_2680 state)
    {
        class_2350 facing = state.method_11654(FramedProperties.FACING_NE);

        class_2680 defState = FBContent.BLOCK_FRAMED_PANEL.get().method_9564();
        return new class_3545<>(
                defState.method_11657(FramedProperties.FACING_HOR, facing),
                defState.method_11657(FramedProperties.FACING_HOR, facing.method_10153())
        );
    }

    @Override
    public DoubleBlockTopInteractionMode calculateTopInteractionMode(class_2680 state)
    {
        return DoubleBlockTopInteractionMode.EITHER;
    }

    @Override
    public CamoGetter calculateCamoGetter(class_2680 state, class_2350 side, @Nullable class_2350 edge)
    {
        class_2350 facing = state.method_11654(FramedProperties.FACING_NE);
        boolean notFacingAxis = side.method_10166() != facing.method_10166();
        if (side == facing || (notFacingAxis && edge == facing))
        {
            return CamoGetter.FIRST;
        }
        if (side == facing.method_10153() || (notFacingAxis && edge == facing.method_10153()))
        {
            return CamoGetter.SECOND;
        }
        return CamoGetter.NONE;
    }

    @Override
    public SolidityCheck calculateSolidityCheck(class_2680 state, class_2350 side)
    {
        class_2350 facing = state.method_11654(FramedProperties.FACING_NE);
        if (side == facing)
        {
            return SolidityCheck.FIRST;
        }
        else if (side == facing.method_10153())
        {
            return SolidityCheck.SECOND;
        }
        return SolidityCheck.BOTH;
    }

    @Override
    public final class_2586 method_10123(class_2338 pos, class_2680 state)
    {
        return new FramedDoublePanelBlockEntity(pos, state);
    }
}