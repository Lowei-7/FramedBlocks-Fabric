package xfacthd.framedblocks.common.block.slab;

import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.world.level.block.*;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.block.PlacementStateBuilder;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.block.FramedBlock;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.data.PropertyHolder;

@SuppressWarnings("deprecation")
public class FramedCheckeredSlabSegmentBlock extends FramedBlock
{
    public FramedCheckeredSlabSegmentBlock()
    {
        super(BlockType.FRAMED_CHECKERED_SLAB_SEGMENT);
        method_9590(method_9564()
                .method_11657(FramedProperties.TOP, false)
                .method_11657(PropertyHolder.SECOND, false)
        );
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(FramedProperties.TOP, PropertyHolder.SECOND, class_2741.field_12508);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return PlacementStateBuilder.of(this, ctx)
                .withTop()
                .withCustom((state, modCtx) -> state.method_11657(
                        PropertyHolder.SECOND, Utils.isX(ctx.method_8042())
                ))
                .withWater()
                .build();
    }

    @Override
    public class_2680 rotate(class_2680 state, class_2350 side, class_2470 rot)
    {
        if (Utils.isY(side))
        {
            if (rot != class_2470.field_11467 && rot != class_2470.field_11464)
            {
                return state.method_28493(PropertyHolder.SECOND);
            }
        }
        else
        {
            if (rot != class_2470.field_11467)
            {
                return state.method_28493(FramedProperties.TOP);
            }
        }
        return super.method_9598(state, rot);
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rot)
    {
        return rotate(state, class_2350.field_11036, rot);
    }

    @Override
    public class_2680 method_9569(class_2680 state, class_2415 mirror)
    {
        if (mirror != class_2415.field_11302)
        {
            return state.method_28493(PropertyHolder.SECOND);
        }
        return super.method_9569(state, mirror);
    }
}
