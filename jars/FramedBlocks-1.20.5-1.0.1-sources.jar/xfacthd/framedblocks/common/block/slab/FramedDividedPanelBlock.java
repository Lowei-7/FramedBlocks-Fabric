package xfacthd.framedblocks.common.block.slab;

import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_3545;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.block.PlacementStateBuilder;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.AbstractFramedDoubleBlock;
import xfacthd.framedblocks.common.blockentity.doubled.FramedDividedPanelBlockEntity;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.data.doubleblock.CamoGetter;
import xfacthd.framedblocks.common.data.doubleblock.SolidityCheck;
import xfacthd.framedblocks.common.util.DoubleBlockTopInteractionMode;

public class FramedDividedPanelBlock extends AbstractFramedDoubleBlock
{
    public FramedDividedPanelBlock(BlockType type)
    {
        super(type);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(FramedProperties.FACING_HOR, class_2741.field_12508);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return PlacementStateBuilder.of(this, ctx)
                .withHorizontalFacing()
                .withWater()
                .build();
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9598(class_2680 state, class_2470 rotation)
    {
        class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
        return state.method_11657(FramedProperties.FACING_HOR, rotation.method_10503(dir));
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9569(class_2680 state, class_2415 mirror)
    {
        return Utils.mirrorFaceBlock(state, mirror);
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state)
    {
        return new FramedDividedPanelBlockEntity(pos, state);
    }

    @Override
    public class_3545<class_2680, class_2680> calculateBlockPair(class_2680 state)
    {
        class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
        if (getBlockType() == BlockType.FRAMED_DIVIDED_PANEL_HORIZONTAL)
        {
            class_2680 defState = FBContent.BLOCK_FRAMED_SLAB_EDGE.get()
                    .method_9564()
                    .method_11657(FramedProperties.FACING_HOR, dir);

            return new class_3545<>(defState, defState.method_11657(FramedProperties.TOP, true));
        }
        else
        {
            class_2680 defState = FBContent.BLOCK_FRAMED_CORNER_PILLAR.get().method_9564();
            return new class_3545<>(
                    defState.method_11657(FramedProperties.FACING_HOR, dir),
                    defState.method_11657(FramedProperties.FACING_HOR, dir.method_10170())
            );
        }
    }

    @Override
    public DoubleBlockTopInteractionMode calculateTopInteractionMode(class_2680 state)
    {
        if (getBlockType() == BlockType.FRAMED_DIVIDED_PANEL_HORIZONTAL)
        {
            return DoubleBlockTopInteractionMode.SECOND;
        }
        else
        {
            return DoubleBlockTopInteractionMode.EITHER;
        }
    }

    @Override
    public CamoGetter calculateCamoGetter(class_2680 state, class_2350 side, @Nullable class_2350 edge)
    {
        if (edge == null)
        {
            return CamoGetter.NONE;
        }

        class_2350 facing = state.method_11654(FramedProperties.FACING_HOR);
        boolean vertical = state.method_26204() == FBContent.BLOCK_FRAMED_DIVIDED_PANEL_VERT.get();
        if (edge == facing)
        {
            if ((!vertical && side == class_2350.field_11033) || (vertical && side == facing.method_10160()))
            {
                return CamoGetter.FIRST;
            }
            if ((!vertical && side == class_2350.field_11036) || (vertical && side == facing.method_10170()))
            {
                return CamoGetter.SECOND;
            }
        }
        else if (side == facing)
        {
            if ((!vertical && edge == class_2350.field_11033) || (vertical && edge == facing.method_10160()))
            {
                return CamoGetter.FIRST;
            }
            if ((!vertical && edge == class_2350.field_11036) || (vertical && edge == facing.method_10170()))
            {
                return CamoGetter.SECOND;
            }
        }
        return CamoGetter.NONE;
    }

    @Override
    public SolidityCheck calculateSolidityCheck(class_2680 state, class_2350 side)
    {
        if (side == state.method_11654(FramedProperties.FACING_HOR))
        {
            return SolidityCheck.BOTH;
        }
        return SolidityCheck.NONE;
    }
}
