package xfacthd.framedblocks.common.block.slab;

import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_3419;
import net.minecraft.class_3965;
import net.minecraft.class_9062;
import net.minecraft.world.level.block.*;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.block.PlacementStateBuilder;
import xfacthd.framedblocks.api.util.*;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.FramedBlock;
import xfacthd.framedblocks.common.data.BlockType;

@SuppressWarnings("deprecation")
public class FramedPanelBlock extends FramedBlock
{
    public FramedPanelBlock()
    {
        super(BlockType.FRAMED_PANEL);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(FramedProperties.FACING_HOR, class_2741.field_12508, FramedProperties.SOLID);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return PlacementStateBuilder.of(this, ctx)
                .withTargetOrHorizontalFacing()
                .withWater()
                .build();
    }

    @Override
    protected class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit)
    {
        if (stack.method_7909() == FBContent.BLOCK_FRAMED_PANEL.get().method_8389())
        {
            class_2350 facing = state.method_11654(FramedProperties.FACING_HOR);
            if (hit.method_17780() == facing.method_10153())
            {
                if (!level.method_8608())
                {
                    class_2350 newFacing = (facing == class_2350.field_11043 || facing == class_2350.field_11034) ? facing : facing.method_10153();
                    class_2680 newState = FBContent.BLOCK_FRAMED_DOUBLE_PANEL.get().method_9564();

                    Utils.wrapInStateCopy(level, pos, player, stack, facing != newFacing, true, () ->
                            level.method_8501(pos, newState.method_11657(FramedProperties.FACING_NE, newFacing))
                    );

                    class_2498 sound = FBContent.BLOCK_FRAMED_CUBE.get().method_9564().method_26231();
                    level.method_8396(null, pos, sound.method_10598(), class_3419.field_15245, (sound.method_10597() + 1.0F) / 2.0F, sound.method_10599() * 0.8F);
                }
                return class_9062.method_55644(level.method_8608());
            }
        }
        return class_9062.field_47731;
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rot)
    {
        class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
        return state.method_11657(FramedProperties.FACING_HOR, rot.method_10503(dir));
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9569(class_2680 state, class_2415 mirror)
    {
        return Utils.mirrorFaceBlock(state, mirror);
    }
}