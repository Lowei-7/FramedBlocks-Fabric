package xfacthd.framedblocks.common.block.slab;

import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.world.level.block.*;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.block.PlacementStateBuilder;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.block.FramedBlock;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.data.PropertyHolder;

@SuppressWarnings("deprecation")
public class FramedCheckeredPanelSegmentBlock extends FramedBlock
{
    public FramedCheckeredPanelSegmentBlock()
    {
        super(BlockType.FRAMED_CHECKERED_PANEL_SEGMENT);
        method_9590(method_9564().method_11657(PropertyHolder.SECOND, false));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(FramedProperties.FACING_HOR, PropertyHolder.SECOND, class_2741.field_12508);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return PlacementStateBuilder.of(this, ctx)
                .withTargetOrHorizontalFacing()
                .withCustom((state, modCtx) -> state.method_11657(
                        PropertyHolder.SECOND, Utils.isX(ctx.method_8042())
                ))
                .withWater()
                .build();
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9598(class_2680 state, class_2470 rot)
    {
        if (rot != class_2470.field_11464)
        {
            state = state.method_28493(PropertyHolder.SECOND);
        }
        class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
        return state.method_11657(FramedProperties.FACING_HOR, rot.method_10503(dir));
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9569(class_2680 state, class_2415 mirror)
    {
        return Utils.mirrorFaceBlock(state, mirror).method_28493(PropertyHolder.SECOND);
    }
}
