package xfacthd.framedblocks.common.block.slab;

import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_3545;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.block.PlacementStateBuilder;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.AbstractFramedDoubleBlock;
import xfacthd.framedblocks.common.blockentity.doubled.FramedCheckeredSlabBlockEntity;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.doubleblock.*;
import xfacthd.framedblocks.common.util.DoubleBlockTopInteractionMode;

public class FramedCheckeredSlabBlock extends AbstractFramedDoubleBlock
{
    public FramedCheckeredSlabBlock()
    {
        super(BlockType.FRAMED_CHECKERED_SLAB);
        method_9590(method_9564().method_11657(FramedProperties.TOP, false));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(FramedProperties.TOP, class_2741.field_12508);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return PlacementStateBuilder.of(this, ctx)
                .withTop()
                .withWater()
                .build();
    }

    @Override
    public class_2680 rotate(class_2680 state, class_2350 face, class_2470 rot)
    {
        if (rot != class_2470.field_11467)
        {
            return state.method_28493(FramedProperties.TOP);
        }
        return state;
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state)
    {
        return new FramedCheckeredSlabBlockEntity(pos, state);
    }

    @Override
    public class_3545<class_2680, class_2680> calculateBlockPair(class_2680 state)
    {
        class_2680 segmentState = FBContent.BLOCK_FRAMED_CHECKERED_SLAB_SEGMENT.get()
                .method_9564()
                .method_11657(FramedProperties.TOP, state.method_11654(FramedProperties.TOP));
        return new class_3545<>(segmentState, segmentState.method_11657(PropertyHolder.SECOND, true));
    }

    @Override
    public DoubleBlockTopInteractionMode calculateTopInteractionMode(class_2680 state)
    {
        return DoubleBlockTopInteractionMode.EITHER;
    }

    @Override
    public CamoGetter calculateCamoGetter(class_2680 state, class_2350 side, @Nullable class_2350 edge)
    {
        return CamoGetter.NONE;
    }

    @Override
    public SolidityCheck calculateSolidityCheck(class_2680 state, class_2350 side)
    {
        boolean top = state.method_11654(FramedProperties.TOP);
        if ((!top && side == class_2350.field_11033) || (top && side == class_2350.field_11036))
        {
            return SolidityCheck.BOTH;
        }
        return SolidityCheck.NONE;
    }



    public static class_2680 itemModelSource()
    {
        return FBContent.BLOCK_FRAMED_CHECKERED_SLAB.get().method_9564();
    }
}
