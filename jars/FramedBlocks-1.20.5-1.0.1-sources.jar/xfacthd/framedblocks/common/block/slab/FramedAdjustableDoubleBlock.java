package xfacthd.framedblocks.common.block.slab;

import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.AbstractFramedDoubleBlock;
import xfacthd.framedblocks.common.block.cube.FramedCollapsibleCopycatBlock;
import xfacthd.framedblocks.common.blockentity.doubled.FramedAdjustableDoubleBlockEntity;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.NullableDirection;

import java.util.function.Function;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3545;

public abstract class FramedAdjustableDoubleBlock extends AbstractFramedDoubleBlock
{
    private final Function<class_2680, class_2350> facingGetter;
    private final Function<class_2680, class_3545<class_2680, class_2680>> statePairBuilder;
    private final class_2591.class_5559<FramedAdjustableDoubleBlockEntity> beSupplier;

    protected FramedAdjustableDoubleBlock(
            BlockType type,
            Function<class_2680, class_2350> facingGetter,
            Function<class_2680, class_3545<class_2680, class_2680>> statePairBuilder,
            class_2591.class_5559<FramedAdjustableDoubleBlockEntity> beSupplier
    )
    {
        super(type);
        this.facingGetter = facingGetter;
        this.statePairBuilder = statePairBuilder;
        this.beSupplier = beSupplier;
    }

    @Override
    public boolean handleBlockLeftClick(class_2680 state, class_1937 level, class_2338 pos, class_1657 player)
    {
        if (player.method_6047().method_7909() == FBContent.ITEM_FRAMED_HAMMER.get())
        {
            if (level.method_8321(pos) instanceof FramedAdjustableDoubleBlockEntity be)
            {
                return be.handleDeform(player);
            }
        }
        return false;
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state)
    {
        return beSupplier.create(pos, state);
    }

    @Override
    public class_3545<class_2680, class_2680> calculateBlockPair(class_2680 state)
    {
        return statePairBuilder.apply(state);
    }

    public class_2350 getFacing(class_2680 state)
    {
        return facingGetter.apply(state);
    }



    protected static class_3545<class_2680, class_2680> makeStandardStatePair(class_2680 state)
    {
        class_2350 facing = ((FramedAdjustableDoubleBlock) state.method_26204()).getFacing(state);
        class_2680 defState = FBContent.BLOCK_FRAMED_COLLAPSIBLE_BLOCK.get().method_9564();
        return new class_3545<>(
                defState.method_11657(PropertyHolder.NULLABLE_FACE, NullableDirection.fromDirection(facing)),
                defState.method_11657(PropertyHolder.NULLABLE_FACE, NullableDirection.fromDirection(facing.method_10153()))
        );
    }

    protected static class_3545<class_2680, class_2680> makeCopycatStatePair(class_2680 state)
    {
        class_2350 facing = ((FramedAdjustableDoubleBlock) state.method_26204()).getFacing(state);
        class_2680 defState = FBContent.BLOCK_FRAMED_COLLAPSIBLE_COPYCAT_BLOCK.get().method_9564();
        int solidFirst = ~(1 << facing.ordinal()) & FramedCollapsibleCopycatBlock.ALL_SOLID;
        int solidSecond = ~(1 << facing.method_10153().ordinal()) & FramedCollapsibleCopycatBlock.ALL_SOLID;
        return new class_3545<>(
                defState.method_11657(PropertyHolder.SOLID_FACES, solidFirst),
                defState.method_11657(PropertyHolder.SOLID_FACES, solidSecond)
        );
    }
}
