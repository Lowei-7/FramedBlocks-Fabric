package xfacthd.framedblocks.common.block.slab;

import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.common.blockentity.doubled.FramedAdjustableDoubleBlockEntity;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.data.doubleblock.*;
import xfacthd.framedblocks.common.util.DoubleBlockTopInteractionMode;

import java.util.function.Function;
import net.minecraft.class_2350;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3545;

public class FramedAdjustableDoubleSlabBlock extends FramedAdjustableDoubleBlock
{
    private FramedAdjustableDoubleSlabBlock(
            BlockType type,
            Function<class_2680, class_3545<class_2680, class_2680>> statePairBuilder,
            class_2591.class_5559<FramedAdjustableDoubleBlockEntity> beSupplier
    )
    {
        super(type, state -> class_2350.field_11036, statePairBuilder, beSupplier);
    }

    @Override
    public DoubleBlockTopInteractionMode calculateTopInteractionMode(class_2680 state)
    {
        return DoubleBlockTopInteractionMode.SECOND;
    }

    @Override
    public SolidityCheck calculateSolidityCheck(class_2680 state, class_2350 side)
    {
        return switch (side)
        {
            case field_11033 -> SolidityCheck.FIRST;
            case field_11036 -> SolidityCheck.SECOND;
            case field_11043, field_11035, field_11039, field_11034 -> SolidityCheck.BOTH;
        };
    }

    @Override
    public CamoGetter calculateCamoGetter(class_2680 state, class_2350 side, @Nullable class_2350 edge)
    {
        return switch (side)
        {
            case field_11033 -> CamoGetter.FIRST;
            case field_11036 -> CamoGetter.SECOND;
            case field_11043, field_11035, field_11039, field_11034 ->
            {
                if (edge == class_2350.field_11033) yield CamoGetter.FIRST;
                if (edge == class_2350.field_11036) yield CamoGetter.SECOND;
                yield CamoGetter.NONE;
            }
        };
    }



    public static FramedAdjustableDoubleSlabBlock standard()
    {
        return new FramedAdjustableDoubleSlabBlock(
                BlockType.FRAMED_ADJ_DOUBLE_SLAB,
                FramedAdjustableDoubleBlock::makeStandardStatePair,
                FramedAdjustableDoubleBlockEntity::standard
        );
    }

    public static FramedAdjustableDoubleSlabBlock copycat()
    {
        return new FramedAdjustableDoubleSlabBlock(
                BlockType.FRAMED_ADJ_DOUBLE_COPYCAT_SLAB,
                FramedAdjustableDoubleBlock::makeCopycatStatePair,
                FramedAdjustableDoubleBlockEntity::copycat
        );
    }
}
