package xfacthd.framedblocks.common.block.slab;

import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3545;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.block.PlacementStateBuilder;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.AbstractFramedDoubleBlock;
import xfacthd.framedblocks.common.blockentity.doubled.FramedMasonryCornerBlockEntity;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.data.doubleblock.*;
import xfacthd.framedblocks.common.util.DoubleBlockTopInteractionMode;

@SuppressWarnings("deprecation")
public class FramedMasonryCornerBlock extends AbstractFramedDoubleBlock
{
    public FramedMasonryCornerBlock()
    {
        super(BlockType.FRAMED_MASONRY_CORNER);
        method_9590(method_9564().method_11657(FramedProperties.TOP, false));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(FramedProperties.FACING_HOR, FramedProperties.TOP);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return PlacementStateBuilder.of(this, ctx)
                .withHorizontalFacing()
                .withTop()
                .build();
    }

    @Override
    public class_2680 rotate(class_2680 state, class_2350 face, class_2470 rot)
    {
        if (!Utils.isY(face) && rot != class_2470.field_11467)
        {
            return state.method_28493(FramedProperties.TOP);
        }
        return super.rotate(state, face, rot);
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rot)
    {
        class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
        return state.method_11657(FramedProperties.FACING_HOR, rot.method_10503(dir));
    }

    @Override
    public class_2680 method_9569(class_2680 state, class_2415 mirror)
    {
        return Utils.mirrorCornerBlock(state, mirror);
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state)
    {
        return new FramedMasonryCornerBlockEntity(pos, state);
    }

    @Override
    public DoubleBlockTopInteractionMode calculateTopInteractionMode(class_2680 state)
    {
        return DoubleBlockTopInteractionMode.EITHER;
    }

    @Override
    public class_3545<class_2680, class_2680> calculateBlockPair(class_2680 state)
    {
        class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
        class_2680 edgeState = FBContent.BLOCK_FRAMED_MASONRY_CORNER_SEGMENT.get()
                .method_9564()
                .method_11657(FramedProperties.TOP, state.method_11654(FramedProperties.TOP));

        return new class_3545<>(
                edgeState.method_11657(FramedProperties.FACING_HOR, dir),
                edgeState.method_11657(FramedProperties.FACING_HOR, dir.method_10153())
        );
    }

    @Override
    public SolidityCheck calculateSolidityCheck(class_2680 state, class_2350 side)
    {
        return SolidityCheck.BOTH;
    }

    @Override
    public CamoGetter calculateCamoGetter(class_2680 state, class_2350 side, @Nullable class_2350 edge)
    {
        class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
        boolean top = state.method_11654(FramedProperties.TOP);
        class_2350 bottom = top ? class_2350.field_11036 : class_2350.field_11033;
        if (side == bottom)
        {
            if (edge == dir)
            {
                return CamoGetter.SECOND;
            }
            if (edge == dir.method_10153())
            {
                return CamoGetter.FIRST;
            }
        }
        else if (side == bottom.method_10153())
        {
            if (edge == dir.method_10170())
            {
                return CamoGetter.FIRST;
            }
            if (edge == dir.method_10160())
            {
                return CamoGetter.SECOND;
            }
        }
        else if (side.method_10166() == dir.method_10166())
        {
            if (edge == bottom || edge == side.method_10160())
            {
                return side == dir ? CamoGetter.SECOND : CamoGetter.FIRST;
            }
        }
        else if (side.method_10166() == dir.method_10170().method_10166())
        {
            if (edge == bottom.method_10153() || edge == side.method_10170())
            {
                return side == dir.method_10170() ? CamoGetter.FIRST : CamoGetter.SECOND;
            }
        }
        return CamoGetter.NONE;
    }



    public static class_2680 itemModelSource()
    {
        return FBContent.BLOCK_FRAMED_MASONRY_CORNER.get().method_9564();
    }
}
