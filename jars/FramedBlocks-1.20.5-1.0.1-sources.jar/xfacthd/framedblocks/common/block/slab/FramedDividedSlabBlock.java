package xfacthd.framedblocks.common.block.slab;

import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_3545;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.block.PlacementStateBuilder;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.AbstractFramedDoubleBlock;
import xfacthd.framedblocks.common.blockentity.doubled.FramedDividedSlabBlockEntity;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.data.doubleblock.CamoGetter;
import xfacthd.framedblocks.common.data.doubleblock.SolidityCheck;
import xfacthd.framedblocks.common.util.DoubleBlockTopInteractionMode;

public class FramedDividedSlabBlock extends AbstractFramedDoubleBlock
{
    public FramedDividedSlabBlock()
    {
        super(BlockType.FRAMED_DIVIDED_SLAB);
        method_9590(method_9564().method_11657(FramedProperties.TOP, false));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(FramedProperties.FACING_HOR, FramedProperties.TOP, class_2741.field_12508);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return PlacementStateBuilder.of(this, ctx)
                .withHorizontalFacing()
                .withTop()
                .withWater()
                .build();
    }

    @Override
    public class_2680 rotate(class_2680 state, class_2350 face, class_2470 rot)
    {
        if (Utils.isY(face))
        {
            class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
            return state.method_11657(FramedProperties.FACING_HOR, rot.method_10503(dir));
        }
        else if (rot != class_2470.field_11467)
        {
            boolean top = state.method_11654(FramedProperties.TOP);
            return state.method_11657(FramedProperties.TOP, !top);
        }
        return state;
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9598(class_2680 state, class_2470 rotation)
    {
        return rotate(state, class_2350.field_11036, rotation);
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9569(class_2680 state, class_2415 mirror)
    {
        return Utils.mirrorFaceBlock(state, mirror);
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state)
    {
        return new FramedDividedSlabBlockEntity(pos, state);
    }

    @Override
    public class_3545<class_2680, class_2680> calculateBlockPair(class_2680 state)
    {
        class_2680 defState = FBContent.BLOCK_FRAMED_SLAB_EDGE.get()
                .method_9564()
                .method_11657(FramedProperties.TOP, state.method_11654(FramedProperties.TOP));
        class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
        return new class_3545<>(
                defState.method_11657(FramedProperties.FACING_HOR, dir.method_10153()),
                defState.method_11657(FramedProperties.FACING_HOR, dir)
        );
    }

    @Override
    public DoubleBlockTopInteractionMode calculateTopInteractionMode(class_2680 state)
    {
        return DoubleBlockTopInteractionMode.EITHER;
    }

    @Override
    public CamoGetter calculateCamoGetter(class_2680 state, class_2350 side, @Nullable class_2350 edge)
    {
        if (edge == null)
        {
            return CamoGetter.NONE;
        }

        class_2350 dirOne = state.method_11654(FramedProperties.FACING_HOR);
        class_2350 dirTwo = state.method_11654(FramedProperties.TOP) ? class_2350.field_11036 : class_2350.field_11033;
        if (edge == dirTwo)
        {
            if (side == dirOne)
            {
                return CamoGetter.FIRST;
            }
            if (side == dirOne.method_10153())
            {
                return CamoGetter.SECOND;
            }
        }
        else if (side == dirTwo)
        {
            if (edge == dirOne)
            {
                return CamoGetter.FIRST;
            }
            if (edge == dirOne.method_10153())
            {
                return CamoGetter.SECOND;
            }
        }
        return CamoGetter.NONE;
    }

    @Override
    public SolidityCheck calculateSolidityCheck(class_2680 state, class_2350 side)
    {
        boolean top = state.method_11654(FramedProperties.TOP);
        if ((!top && side == class_2350.field_11033) || (top && side == class_2350.field_11036))
        {
            return SolidityCheck.BOTH;
        }
        return SolidityCheck.NONE;
    }
}
