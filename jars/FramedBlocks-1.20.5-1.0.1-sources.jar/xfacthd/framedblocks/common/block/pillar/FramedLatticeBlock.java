package xfacthd.framedblocks.common.block.pillar;

import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.block.PlacementStateBuilder;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.FramedBlock;
import xfacthd.framedblocks.common.data.BlockType;

import java.util.function.BiPredicate;
import net.minecraft.class_1750;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_3481;

public class FramedLatticeBlock extends FramedBlock
{
    private final BiPredicate<class_2350, class_2680> connectionTest;

    public FramedLatticeBlock(BlockType type)
    {
        super(type);
        method_9590(method_9564()
                .method_11657(FramedProperties.X_AXIS, false)
                .method_11657(FramedProperties.Y_AXIS, false)
                .method_11657(FramedProperties.Z_AXIS, false)
                .method_11657(FramedProperties.STATE_LOCKED, false)
        );
        this.connectionTest = switch (type)
        {
            case FRAMED_LATTICE_BLOCK -> FramedLatticeBlock::canConnectThin;
            case FRAMED_THICK_LATTICE -> FramedLatticeBlock::canConnectThick;
            default -> throw new IllegalArgumentException("Unexpected lattice type: " + type);
        };
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(
                FramedProperties.X_AXIS, FramedProperties.Y_AXIS, FramedProperties.Z_AXIS,
                class_2741.field_12508, FramedProperties.STATE_LOCKED
        );
    }

    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return PlacementStateBuilder.of(this, ctx)
                .withCustom((state, modCtx) ->
                {
                    class_1937 level = modCtx.method_8045();
                    class_2338 pos = modCtx.method_8037();

                    state = state.method_11657(
                            FramedProperties.X_AXIS,
                            canConnectTo(level, pos, class_2350.field_11034) || canConnectTo(level, pos, class_2350.field_11039)
                    );
                    state = state.method_11657(
                            FramedProperties.Y_AXIS,
                            canConnectTo(level, pos, class_2350.field_11036) || canConnectTo(level, pos, class_2350.field_11033)
                    );
                    state = state.method_11657(
                            FramedProperties.Z_AXIS,
                            canConnectTo(level, pos, class_2350.field_11043) || canConnectTo(level, pos, class_2350.field_11035)
                    );

                    return state;
                })
                .withWater()
                .build();
    }

    @Override
    public class_2680 method_9559(
            class_2680 state,
            class_2350 facing,
            class_2680 facingState,
            class_1936 level,
            class_2338 pos,
            class_2338 facingPos
    )
    {
        if (!state.method_11654(FramedProperties.STATE_LOCKED))
        {
            class_2350 opposite = facing.method_10153();
            state = state.method_11657(
                    getPropFromAxis(facing),
                    canConnectTo(facingState, facing) || canConnectTo(level, pos, opposite)
            );
        }

        return super.method_9559(state, facing, facingState, level, pos, facingPos);
    }

    private boolean canConnectTo(class_1936 level, class_2338 pos, class_2350 side)
    {
        class_2680 state = level.method_8320(pos.method_10093(side));
        return canConnectTo(state, side);
    }

    private boolean canConnectTo(class_2680 state, class_2350 side)
    {
        return state.method_27852(this) || connectionTest.test(side, state);
    }

    @Override
    public class_2680 rotate(class_2680 state, class_2350 face, class_2470 rot)
    {
        //Not rotatable by wrench
        return state;
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9598(class_2680 state, class_2470 rot)
    {
        if (rot != class_2470.field_11467 && rot != class_2470.field_11464)
        {
            boolean xAxis = state.method_11654(FramedProperties.Z_AXIS);
            boolean zAxis = state.method_11654(FramedProperties.X_AXIS);

            return state.method_11657(FramedProperties.X_AXIS, xAxis)
                    .method_11657(FramedProperties.Z_AXIS, zAxis);
        }

        return state;
    }



    public static class_2680 itemModelSourceThin()
    {
        return FBContent.BLOCK_FRAMED_LATTICE.get()
                .method_9564()
                .method_11657(FramedProperties.X_AXIS, true)
                .method_11657(FramedProperties.Y_AXIS, true)
                .method_11657(FramedProperties.Z_AXIS, true);
    }

    public static class_2746 getPropFromAxis(class_2350 dir)
    {
        return switch (dir.method_10166())
        {
            case field_11048 -> FramedProperties.X_AXIS;
            case field_11052 -> FramedProperties.Y_AXIS;
            case field_11051 -> FramedProperties.Z_AXIS;
        };
    }

    private static boolean canConnectThin(class_2350 side, class_2680 state)
    {
        if (state.method_27852(FBContent.BLOCK_FRAMED_POST.get()))
        {
            return side.method_10166() == state.method_11654(class_2741.field_12496);
        }
        return Utils.isY(side) && state.method_26164(class_3481.field_16584);
    }

    private static boolean canConnectThick(class_2350 side, class_2680 state)
    {
        if (state.method_26164(class_3481.field_15504))
        {
            // Work around mods incorrectly tagging non-WallBlock blocks as walls
            if (!state.method_28498(class_2741.field_12519))
            {
                return false;
            }
            return side == class_2350.field_11033 || (side == class_2350.field_11036 && state.method_11654(class_2741.field_12519));
        }
        if (state.method_27852(FBContent.BLOCK_FRAMED_PILLAR.get()))
        {
            return side.method_10166() == state.method_11654(class_2741.field_12496);
        }
        if (state.method_27852(FBContent.BLOCK_FRAMED_HALF_PILLAR.get()))
        {
            return side == state.method_11654(class_2741.field_12525).method_10153();
        }
        return false;
    }
}