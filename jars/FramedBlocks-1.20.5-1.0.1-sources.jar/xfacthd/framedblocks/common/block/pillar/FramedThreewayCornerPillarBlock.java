package xfacthd.framedblocks.common.block.pillar;

import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.world.level.block.*;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.block.PlacementStateBuilder;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.FramedBlock;
import xfacthd.framedblocks.common.data.BlockType;

public class FramedThreewayCornerPillarBlock extends FramedBlock
{
    public FramedThreewayCornerPillarBlock()
    {
        super(BlockType.FRAMED_THREEWAY_CORNER_PILLAR);
        method_9590(method_9564().method_11657(FramedProperties.TOP, false));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(FramedProperties.FACING_HOR, FramedProperties.TOP, class_2741.field_12508);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return PlacementStateBuilder.of(this, ctx)
                .withHalfFacing()
                .withTop()
                .withWater()
                .build();
    }

    @Override
    public class_2680 rotate(class_2680 state, class_2350 face, class_2470 rot)
    {
        if (Utils.isY(face))
        {
            class_2350 dir = rot.method_10503(state.method_11654(FramedProperties.FACING_HOR));
            return state.method_11657(FramedProperties.FACING_HOR, dir);
        }
        else if (rot != class_2470.field_11467)
        {
            return state.method_28493(FramedProperties.TOP);
        }
        return state;
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9598(class_2680 state, class_2470 rot)
    {
        return rotate(state, class_2350.field_11036, rot);
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9569(class_2680 state, class_2415 mirror)
    {
        return Utils.mirrorCornerBlock(state, mirror);
    }

    public static class_2680 itemModelSource()
    {
        return FBContent.BLOCK_FRAMED_THREEWAY_CORNER_PILLAR.get()
                .method_9564()
                .method_11657(FramedProperties.FACING_HOR, class_2350.field_11039);
    }
}
