package xfacthd.framedblocks.common.block.pillar;

import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3545;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.block.PlacementStateBuilder;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.AbstractFramedDoubleBlock;
import xfacthd.framedblocks.common.blockentity.doubled.FramedDoubleThreewayCornerPillarBlockEntity;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.data.doubleblock.*;
import xfacthd.framedblocks.common.util.DoubleBlockTopInteractionMode;

public class FramedDoubleThreewayCornerPillarBlock extends AbstractFramedDoubleBlock
{
    public FramedDoubleThreewayCornerPillarBlock()
    {
        super(BlockType.FRAMED_DOUBLE_THREEWAY_CORNER_PILLAR);
        method_9590(method_9564().method_11657(FramedProperties.TOP, false));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(FramedProperties.FACING_HOR, FramedProperties.TOP);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return PlacementStateBuilder.of(this, ctx)
                .withHalfFacing()
                .withTop()
                .build();
    }

    @Override
    public class_2680 rotate(class_2680 state, class_2350 face, class_2470 rot)
    {
        if (Utils.isY(face))
        {
            class_2350 dir = rot.method_10503(state.method_11654(FramedProperties.FACING_HOR));
            return state.method_11657(FramedProperties.FACING_HOR, dir);
        }
        else if (rot != class_2470.field_11467)
        {
            return state.method_28493(FramedProperties.TOP);
        }
        return state;
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9598(class_2680 state, class_2470 rot)
    {
        return rotate(state, class_2350.field_11036, rot);
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9569(class_2680 state, class_2415 mirror)
    {
        return Utils.mirrorCornerBlock(state, mirror);
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state)
    {
        return new FramedDoubleThreewayCornerPillarBlockEntity(pos, state);
    }

    @Override
    public DoubleBlockTopInteractionMode calculateTopInteractionMode(class_2680 state)
    {
        return DoubleBlockTopInteractionMode.EITHER;
    }

    @Override
    public class_3545<class_2680, class_2680> calculateBlockPair(class_2680 state)
    {
        class_2680 partState = FBContent.BLOCK_FRAMED_THREEWAY_CORNER_PILLAR.get().method_9564();
        class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
        boolean top = state.method_11654(FramedProperties.TOP);
        return new class_3545<>(
                partState.method_11657(FramedProperties.FACING_HOR, dir)
                        .method_11657(FramedProperties.TOP, top),
                partState.method_11657(FramedProperties.FACING_HOR, dir.method_10153())
                        .method_11657(FramedProperties.TOP, !top)
        );
    }

    @Override
    public SolidityCheck calculateSolidityCheck(class_2680 state, class_2350 side)
    {
        return SolidityCheck.BOTH;
    }

    @Override
    public CamoGetter calculateCamoGetter(class_2680 state, class_2350 side, @Nullable class_2350 edge)
    {
        if (edge == null)
        {
            return CamoGetter.NONE;
        }

        class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
        boolean top = state.method_11654(FramedProperties.TOP);
        class_2350 dirTwo = top ? class_2350.field_11036 : class_2350.field_11033;
        if (side == dirTwo && (edge == dir || edge == dir.method_10160()))
        {
            return CamoGetter.FIRST;
        }
        else if (side == dirTwo.method_10153() && (edge == dir.method_10153() || edge == dir.method_10170()))
        {
            return CamoGetter.SECOND;
        }
        else if (side == dir && (edge == dir.method_10160() || edge == dirTwo))
        {
            return CamoGetter.FIRST;
        }
        else if (side == dir.method_10160() && (edge == dir || edge == dirTwo))
        {
            return CamoGetter.FIRST;
        }
        else if (side == dir.method_10153() && (edge == dir.method_10170() || edge == dirTwo.method_10153()))
        {
            return CamoGetter.SECOND;
        }
        else if (side == dir.method_10170() && (edge == dir.method_10153() || edge == dirTwo.method_10153()))
        {
            return CamoGetter.SECOND;
        }
        return CamoGetter.NONE;
    }

    public static class_2680 itemModelSource()
    {
        return FBContent.BLOCK_FRAMED_DOUBLE_THREEWAY_CORNER_PILLAR.get()
                .method_9564()
                .method_11657(FramedProperties.FACING_HOR, class_2350.field_11039);
    }
}
