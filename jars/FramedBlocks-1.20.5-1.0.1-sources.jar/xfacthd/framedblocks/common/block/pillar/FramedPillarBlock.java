package xfacthd.framedblocks.common.block.pillar;

import xfacthd.framedblocks.api.block.PlacementStateBuilder;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.FramedBlock;
import xfacthd.framedblocks.common.data.BlockType;

import javax.annotation.Nullable;
import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;

public class FramedPillarBlock extends FramedBlock
{
    public FramedPillarBlock(BlockType blockType)
    {
        super(blockType);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(class_2741.field_12496, class_2741.field_12508);
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return PlacementStateBuilder.of(this, ctx)
                .withCustom((state, modCtx) ->
                        state.method_11657(class_2741.field_12496, modCtx.method_8038().method_10166())
                )
                .withWater()
                .build();
    }

    @Override
    public class_2680 rotate(class_2680 state, class_2350 side, class_2470 rot)
    {
        if (rot != class_2470.field_11467)
        {
            return state.method_28493(class_2741.field_12496);
        }
        return state;
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9598(class_2680 state, class_2470 rot)
    {
        class_2350.class_2351 axis = state.method_11654(class_2741.field_12496);
        if (axis != class_2350.class_2351.field_11052 && rot != class_2470.field_11467 && rot != class_2470.field_11464)
        {
            axis = Utils.nextAxisNotEqualTo(axis, class_2350.class_2351.field_11052);
            return state.method_11657(class_2741.field_12496, axis);
        }
        return state;
    }



    public static class_2680 itemModelSourcePost()
    {
        return FBContent.BLOCK_FRAMED_POST.get().method_9564().method_11657(class_2741.field_12496, class_2350.class_2351.field_11052);
    }
}