package xfacthd.framedblocks.common.block;

import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.block.IFramedBlock;
import xfacthd.framedblocks.api.block.cache.StateCache;
import xfacthd.framedblocks.api.block.render.ParticleHelper;
import xfacthd.framedblocks.api.camo.CamoContainer;
import xfacthd.framedblocks.api.predicate.cull.SideSkipPredicate;
import xfacthd.framedblocks.api.model.data.FramedDoubleBlockData;
import xfacthd.framedblocks.common.blockentity.FramedDoubleBlockEntity;
import xfacthd.framedblocks.common.data.doubleblock.*;
import xfacthd.framedblocks.common.item.FramedBlueprintItem;
import xfacthd.framedblocks.common.util.DoubleBlockTopInteractionMode;

import java.util.Objects;
import java.util.Optional;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3545;
import net.minecraft.class_5250;

public interface IFramedDoubleBlock extends IFramedBlock
{
    @ApiStatus.OverrideOnly
    DoubleBlockTopInteractionMode calculateTopInteractionMode(class_2680 state);

    @ApiStatus.OverrideOnly
    class_3545<class_2680, class_2680> calculateBlockPair(class_2680 state);

    @ApiStatus.OverrideOnly
    SolidityCheck calculateSolidityCheck(class_2680 state, class_2350 side);

    @ApiStatus.OverrideOnly
    CamoGetter calculateCamoGetter(class_2680 state, class_2350 side, @Nullable class_2350 edge);

    @ApiStatus.NonExtendable
    default DoubleBlockTopInteractionMode getTopInteractionMode(class_2680 state)
    {
        return getCache(state).getTopInteractionMode();
    }

    @ApiStatus.NonExtendable
    default class_3545<class_2680, class_2680> getBlockPair(class_2680 state)
    {
        return getCache(state).getBlockPair();
    }

    @ApiStatus.NonExtendable
    default SolidityCheck getSolidityCheck(class_2680 state, class_2350 side)
    {
        return getCache(state).getSolidityCheck(side);
    }

    @ApiStatus.NonExtendable
    default CamoGetter getCamoGetter(class_2680 state, class_2350 side, @Nullable class_2350 edge)
    {
        return getCache(state).getCamoGetter(side, edge);
    }

    @Override
    default StateCache initCache(class_2680 state)
    {
        return new DoubleBlockStateCache(state, getBlockType());
    }

    @Override
    default DoubleBlockStateCache getCache(class_2680 state)
    {
        return (DoubleBlockStateCache) IFramedBlock.super.getCache(state);
    }

    @Override
    @Nullable
    default class_2680 runOcclusionTestAndGetLookupState(
            SideSkipPredicate pred, class_1922 level, class_2338 pos, class_2680 state, class_2680 adjState, class_2350 side
    )
    {
        class_3545<class_2680, class_2680> statePair = getBlockPair(adjState);
        if (pred.test(level, pos, state, statePair.method_15442(), side))
        {
            return statePair.method_15442();
        }
        if (pred.test(level, pos, state, statePair.method_15441(), side))
        {
            return statePair.method_15441();
        }
        return null;
    }

    @Override
    @Nullable
    default class_2680 getComponentAtEdge(
            class_1922 level, class_2338 pos, class_2680 state, class_2350 side, @Nullable class_2350 edge
    )
    {
        DoubleBlockStateCache cache = getCache(state);
        return cache.getCamoGetter(side, edge).getComponent(cache.getBlockPair());
    }

    @Override
    @Nullable
    default class_2680 getComponentBySkipPredicate(
            class_1922 level, class_2338 pos, class_2680 state, class_2680 neighborState, class_2350 side
    )
    {
        class_3545<class_2680, class_2680> blockPair = getBlockPair(state);
        class_2680 compA = blockPair.method_15442();
        if (testComponent(level, pos, compA, neighborState, side))
        {
            return compA;
        }
        class_2680 compB = blockPair.method_15441();
        if (testComponent(level, pos, compB, neighborState, side))
        {
            return compB;
        }
        return null;
    }

    static boolean testComponent(
            class_1922 ctLevel, class_2338 pos, class_2680 component, class_2680 neighborState, class_2350 side
    )
    {
        IFramedBlock block = (IFramedBlock) component.method_26204();
        return block.getBlockType().getSideSkipPredicate().test(ctLevel, pos, component, neighborState, side);
    }

    default Object unpackNestedModelData(Object data, class_2680 state, class_2680 componentState)
    {
        class_3545<class_2680, class_2680> blockPair = getBlockPair(state);
        if (data instanceof FramedDoubleBlockData doubleData)
        {
            if (componentState == blockPair.method_15442())
            {
                return doubleData.getLeft();
            }
            if (componentState == blockPair.method_15441())
            {
                return doubleData.getRight();
            }
        }
        return data;
    }

    @Override
    default boolean addRunningEffects(class_2680 state, class_1937 level, class_2338 pos, class_1297 entity)
    {
        if (level.method_8321(pos) instanceof FramedDoubleBlockEntity be)
        {
            class_3545<class_2680, class_2680> statePair = getBlockPair(state);
            switch (getTopInteractionMode(state))
            {
                case FIRST -> ParticleHelper.spawnRunningParticles(
                        be.getCamo(statePair.method_15442()).getState(), level, pos, entity
                );
                case SECOND -> ParticleHelper.spawnRunningParticles(
                        be.getCamo(statePair.method_15441()).getState(), level, pos, entity
                );
                case EITHER ->
                {
                    ParticleHelper.spawnRunningParticles(
                            be.getCamo(statePair.method_15442()).getState(), level, pos, entity
                    );
                    ParticleHelper.spawnRunningParticles(
                            be.getCamo(statePair.method_15441()).getState(), level, pos, entity
                    );
                }
            }
            return true;
        }
        return false;
    }

    @Override
    default boolean addLandingEffects(
            class_2680 state, class_3218 level, class_2338 pos, class_2680 sameState, class_1309 entity, int count
    )
    {
        if (level.method_8321(pos) instanceof FramedDoubleBlockEntity be)
        {
            class_3545<class_2680, class_2680> statePair = getBlockPair(state);
            switch (getTopInteractionMode(state))
            {
                case FIRST -> ParticleHelper.spawnLandingParticles(
                        be.getCamo(statePair.method_15442()).getState(), level, pos, entity, count
                );
                case SECOND -> ParticleHelper.spawnLandingParticles(
                        be.getCamo(statePair.method_15441()).getState(), level, pos, entity, count
                );
                case EITHER ->
                {
                    ParticleHelper.spawnLandingParticles(
                            be.getCamo(statePair.method_15442()).getState(), level, pos, entity, count
                    );
                    ParticleHelper.spawnLandingParticles(
                            be.getCamo(statePair.method_15441()).getState(), level, pos, entity, count
                    );
                }
            }
            return true;
        }
        return false;
    }

    @Override
    default Optional<class_5250> printCamoBlock(class_2487 beTag)
    {
        class_2680 camoState = CamoContainer.load(beTag.method_10562("camo")).getState();
        class_2680 camoStateTwo = CamoContainer.load(beTag.method_10562("camo_two")).getState();

        class_5250 component = getCamoComponent(camoState);
        component.method_10852(class_2561.method_43470(" | ").method_27692(class_124.field_1065));
        component.method_10852(getCamoComponent(camoStateTwo));

        return Optional.of(component);
    }

    private static class_5250 getCamoComponent(class_2680 camoState)
    {
        if (!camoState.method_26215())
        {
            return camoState.method_26204().method_9518().method_27692(class_124.field_1068);
        }
        return FramedBlueprintItem.BLOCK_NONE.method_27661();
    }
}
