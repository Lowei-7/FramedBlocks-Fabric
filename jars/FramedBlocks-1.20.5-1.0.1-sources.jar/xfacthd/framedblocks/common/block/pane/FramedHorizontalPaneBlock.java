package xfacthd.framedblocks.common.block.pane;

import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import xfacthd.framedblocks.api.block.*;
import xfacthd.framedblocks.common.block.FramedBlock;
import xfacthd.framedblocks.common.data.BlockType;

public class FramedHorizontalPaneBlock extends FramedBlock
{
    public FramedHorizontalPaneBlock()
    {
        super(BlockType.FRAMED_HORIZONTAL_PANE, IFramedBlock.createProperties(BlockType.FRAMED_HORIZONTAL_PANE).method_51369());
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(FramedProperties.SOLID, class_2741.field_12508);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return PlacementStateBuilder.of(this, ctx).withWater().build();
    }
}
