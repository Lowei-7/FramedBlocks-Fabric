package xfacthd.framedblocks.common.block.prism;

import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_243;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.world.level.block.*;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.block.PlacementStateBuilder;
import xfacthd.framedblocks.api.util.*;
import xfacthd.framedblocks.common.block.FramedBlock;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.DirectionAxis;

public class FramedPrismBlock extends FramedBlock
{
    public FramedPrismBlock(BlockType type)
    {
        super(type);
        method_9590(method_9564().method_11657(FramedProperties.Y_SLOPE, false));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(
                PropertyHolder.FACING_AXIS, class_2741.field_12508,
                FramedProperties.SOLID, FramedProperties.Y_SLOPE
        );
    }

    @Override
    public class_2680 method_9605(class_1750 context)
    {
        return getStateForPlacement(context, this);
    }

    public static class_2680 getStateForPlacement(class_1750 ctx, class_2248 block)
    {
        return PlacementStateBuilder.of(block, ctx)
                .withCustom((state, modCtx) ->
                {
                    class_2350 face = modCtx.method_8038();
                    class_2350.class_2351 axis = modCtx.method_8042().method_10166();
                    if (!Utils.isY(face))
                    {
                        class_243 subHit = Utils.fraction(modCtx.method_17698());

                        double xz = (Utils.isX(face) ? subHit.method_10215() : subHit.method_10216()) - .5;
                        double y = subHit.method_10214() - .5;

                        if (Math.max(Math.abs(xz), Math.abs(y)) == Math.abs(xz))
                        {
                            axis = face.method_10170().method_10166();
                        }
                        else
                        {
                            axis = class_2350.class_2351.field_11052;
                        }
                    }
                    return state.method_11657(PropertyHolder.FACING_AXIS, DirectionAxis.of(face, axis));
                })
                .withYSlope(Utils.isY(ctx.method_8038()))
                .tryWithWater()
                .build();
    }

    @Override
    public boolean handleBlockLeftClick(class_2680 state, class_1937 level, class_2338 pos, class_1657 player)
    {
        if (player.method_6047().method_31573(Utils.WRENCH))
        {
            level.method_8501(pos, state.method_11657(FramedProperties.Y_SLOPE, !state.method_11654(FramedProperties.Y_SLOPE)));
            return true;
        }
        return false;
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9598(class_2680 state, class_2470 rot)
    {
        DirectionAxis dirAxis = state.method_11654(PropertyHolder.FACING_AXIS);
        return state.method_11657(PropertyHolder.FACING_AXIS, dirAxis.rotate(rot));
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9569(class_2680 state, class_2415 mirror)
    {
        DirectionAxis dirAxis = state.method_11654(PropertyHolder.FACING_AXIS);
        return state.method_11657(PropertyHolder.FACING_AXIS, dirAxis.mirror(mirror));
    }
}
