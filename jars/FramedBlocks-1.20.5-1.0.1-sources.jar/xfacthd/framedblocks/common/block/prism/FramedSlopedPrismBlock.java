package xfacthd.framedblocks.common.block.prism;

import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_243;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.world.level.block.*;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.block.PlacementStateBuilder;
import xfacthd.framedblocks.api.type.IBlockType;
import xfacthd.framedblocks.api.util.*;
import xfacthd.framedblocks.common.block.FramedBlock;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.CompoundDirection;

public class FramedSlopedPrismBlock extends FramedBlock
{
    public FramedSlopedPrismBlock(BlockType type)
    {
        super(type);
        method_9590(method_9564()
                .method_11657(PropertyHolder.FACING_DIR, CompoundDirection.NORTH_UP)
                .method_11657(FramedProperties.Y_SLOPE, false)
        );
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(
                PropertyHolder.FACING_DIR, class_2741.field_12508,
                FramedProperties.SOLID, FramedProperties.Y_SLOPE
        );
    }

    @Override
    public class_2680 method_9605(class_1750 context)
    {
        return getStateForPlacement(context, this, getBlockType());
    }

    public static class_2680 getStateForPlacement(class_1750 context, class_2248 block, IBlockType blockType)
    {
        return PlacementStateBuilder.of(block, context)
                .withCustom((state, modCtx) ->
                {
                    class_2350 face = modCtx.method_8038();
                    class_2350 orientation;
                    if (Utils.isY(face))
                    {
                        orientation = modCtx.method_8042();
                        if (blockType == BlockType.FRAMED_INNER_SLOPED_PRISM || blockType == BlockType.FRAMED_DOUBLE_SLOPED_PRISM)
                        {
                            orientation = orientation.method_10153();
                        }
                    }
                    else
                    {
                        class_243 subHit = Utils.fraction(modCtx.method_17698());

                        double xz = (Utils.isX(face) ? subHit.method_10215() : subHit.method_10216()) - .5;
                        double y = subHit.method_10214() - .5;

                        if (Math.max(Math.abs(xz), Math.abs(y)) == Math.abs(xz))
                        {
                            if (Utils.isX(face))
                            {
                                orientation = xz < 0 ? class_2350.field_11035 : class_2350.field_11043;
                            }
                            else
                            {
                                orientation = xz < 0 ? class_2350.field_11034 : class_2350.field_11039;
                            }
                        }
                        else
                        {
                            orientation = y < 0 ? class_2350.field_11036 : class_2350.field_11033;
                        }
                    }
                    return state.method_11657(PropertyHolder.FACING_DIR, CompoundDirection.of(face, orientation));
                })
                .withYSlope(Utils.isY(context.method_8038()))
                .tryWithWater()
                .build();
    }

    @Override
    public boolean handleBlockLeftClick(class_2680 state, class_1937 level, class_2338 pos, class_1657 player)
    {
        if (player.method_6047().method_31573(Utils.WRENCH))
        {
            level.method_8501(pos, state.method_11657(FramedProperties.Y_SLOPE, !state.method_11654(FramedProperties.Y_SLOPE)));
            return true;
        }
        return false;
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9598(class_2680 state, class_2470 rot)
    {
        CompoundDirection cmpDir = state.method_11654(PropertyHolder.FACING_DIR);
        return state.method_11657(PropertyHolder.FACING_DIR, cmpDir.rotate(rot));
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9569(class_2680 state, class_2415 mirror)
    {
        CompoundDirection cmpDir = state.method_11654(PropertyHolder.FACING_DIR);
        return state.method_11657(PropertyHolder.FACING_DIR, cmpDir.mirror(mirror));
    }
}
