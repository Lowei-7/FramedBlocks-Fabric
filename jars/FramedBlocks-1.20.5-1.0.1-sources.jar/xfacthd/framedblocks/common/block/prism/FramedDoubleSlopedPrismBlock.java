package xfacthd.framedblocks.common.block.prism;

import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3545;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.AbstractFramedDoubleBlock;
import xfacthd.framedblocks.common.blockentity.doubled.FramedDoubleSlopedPrismBlockEntity;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.doubleblock.CamoGetter;
import xfacthd.framedblocks.common.data.doubleblock.SolidityCheck;
import xfacthd.framedblocks.common.data.property.CompoundDirection;
import xfacthd.framedblocks.common.util.DoubleBlockTopInteractionMode;

public class FramedDoubleSlopedPrismBlock extends AbstractFramedDoubleBlock
{
    public FramedDoubleSlopedPrismBlock()
    {
        super(BlockType.FRAMED_DOUBLE_SLOPED_PRISM);
        method_9590(method_9564().method_11657(FramedProperties.Y_SLOPE, false));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(PropertyHolder.FACING_DIR, FramedProperties.Y_SLOPE);
    }

    @Override
    public class_2680 method_9605(class_1750 context)
    {
        return FramedSlopedPrismBlock.getStateForPlacement(context, this, getBlockType());
    }

    @Override
    public boolean handleBlockLeftClick(class_2680 state, class_1937 level, class_2338 pos, class_1657 player)
    {
        if (player.method_6047().method_31573(Utils.WRENCH))
        {
            level.method_8501(pos, state.method_11657(FramedProperties.Y_SLOPE, !state.method_11654(FramedProperties.Y_SLOPE)));
            return true;
        }
        return false;
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9598(class_2680 state, class_2470 rot)
    {
        CompoundDirection cmpDir = state.method_11654(PropertyHolder.FACING_DIR);
        return state.method_11657(PropertyHolder.FACING_DIR, cmpDir.rotate(rot));
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9569(class_2680 state, class_2415 mirror)
    {
        CompoundDirection cmpDir = state.method_11654(PropertyHolder.FACING_DIR);
        return state.method_11657(PropertyHolder.FACING_DIR, cmpDir.mirror(mirror));
    }

    @Override
    public class_3545<class_2680, class_2680> calculateBlockPair(class_2680 state)
    {
        CompoundDirection cmpDir = state.method_11654(PropertyHolder.FACING_DIR);
        boolean ySlope = state.method_11654(FramedProperties.Y_SLOPE);

        return new class_3545<>(
                FBContent.BLOCK_FRAMED_INNER_SLOPED_PRISM.get()
                        .method_9564()
                        .method_11657(PropertyHolder.FACING_DIR, cmpDir)
                        .method_11657(FramedProperties.Y_SLOPE, ySlope),
                FBContent.BLOCK_FRAMED_SLOPED_PRISM.get()
                        .method_9564()
                        .method_11657(PropertyHolder.FACING_DIR, CompoundDirection.of(
                                cmpDir.direction().method_10153(),
                                cmpDir.orientation()
                        ))
                        .method_11657(FramedProperties.Y_SLOPE, ySlope)
        );
    }

    @Override
    public DoubleBlockTopInteractionMode calculateTopInteractionMode(class_2680 state)
    {
        CompoundDirection cmpDir = state.method_11654(PropertyHolder.FACING_DIR);
        if (cmpDir.direction() == class_2350.field_11036)
        {
            return DoubleBlockTopInteractionMode.SECOND;
        }
        else if (cmpDir.direction() == class_2350.field_11033 || cmpDir.orientation() != class_2350.field_11036)
        {
            return DoubleBlockTopInteractionMode.FIRST;
        }
        return DoubleBlockTopInteractionMode.EITHER;
    }

    @Override
    public CamoGetter calculateCamoGetter(class_2680 state, class_2350 side, @Nullable class_2350 edge)
    {
        CompoundDirection cmpDir = state.method_11654(PropertyHolder.FACING_DIR);
        class_2350 facing = cmpDir.direction();
        if (side == facing)
        {
            return CamoGetter.SECOND;
        }
        if (side == cmpDir.orientation())
        {
            if (edge == facing)
            {
                return CamoGetter.SECOND;
            }
            else if (edge != null)
            {
                return CamoGetter.FIRST;
            }
            return CamoGetter.NONE;
        }
        return CamoGetter.FIRST;
    }

    @Override
    public SolidityCheck calculateSolidityCheck(class_2680 state, class_2350 side)
    {
        CompoundDirection cmpDir = state.method_11654(PropertyHolder.FACING_DIR);
        class_2350 facing = cmpDir.direction();
        if (side == facing)
        {
            return SolidityCheck.SECOND;
        }
        if (side == cmpDir.orientation())
        {
            return SolidityCheck.BOTH;
        }
        return SolidityCheck.FIRST;
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state)
    {
        return new FramedDoubleSlopedPrismBlockEntity(pos, state);
    }



    public static class_2680 itemModelSource()
    {
        return FBContent.BLOCK_FRAMED_DOUBLE_SLOPED_PRISM.get()
                .method_9564()
                .method_11657(PropertyHolder.FACING_DIR, CompoundDirection.UP_EAST);
    }
}
