package xfacthd.framedblocks.common.block.cube;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3218;
import net.minecraft.class_3965;
import net.minecraft.class_702;
import net.minecraft.world.level.block.*;
import net.minecraftforge.client.extensions.common.IClientBlockExtensions;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.block.FramedBlockEntity;
import xfacthd.framedblocks.api.block.render.FramedBlockRenderProperties;
import xfacthd.framedblocks.api.block.render.ParticleHelper;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.FramedBlock;
import xfacthd.framedblocks.common.blockentity.special.FramedOwnableBlockEntity;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.NullableDirection;
import xfacthd.framedblocks.common.util.ServerConfig;

import java.util.function.Consumer;

public class FramedOneWayWindowBlock extends FramedBlock
{
    public FramedOneWayWindowBlock()
    {
        super(BlockType.FRAMED_ONE_WAY_WINDOW);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(PropertyHolder.NULLABLE_FACE);
    }

    @Override
    public void method_9567(class_1937 level, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 stack)
    {
        super.method_9567(level, pos, state, placer, stack);
        if (placer instanceof class_1657 player && level.method_8321(pos) instanceof FramedOwnableBlockEntity be)
        {
            be.setOwner(player.method_5667(), true);
        }
    }

    @Override
    public boolean handleBlockLeftClick(class_2680 state, class_1937 level, class_2338 pos, class_1657 player)
    {
        if (player.method_6047().method_31574(FBContent.ITEM_FRAMED_WRENCH.get()) && isOwnedBy(level, pos, player))
        {
            if (!level.method_8608())
            {
                if (player.method_5715())
                {
                    level.method_8501(pos, state.method_11657(PropertyHolder.NULLABLE_FACE, NullableDirection.NONE));
                }
                else
                {
                    class_239 hit = player.method_5745(10D, 0, false);
                    if (!(hit instanceof class_3965 blockHit))
                    {
                        return false;
                    }

                    NullableDirection face =  NullableDirection.fromDirection(blockHit.method_17780());
                    level.method_8501(pos, state.method_11657(PropertyHolder.NULLABLE_FACE, face));
                }
            }
            return true;
        }
        return false;
    }

    @Override
    public class_265 method_9571(class_2680 state, class_1922 level, class_2338 pos)
    {
        if (state.method_11654(PropertyHolder.NULLABLE_FACE) != NullableDirection.NONE)
        {
            return class_259.method_1073();
        }
        return super.method_9571(state, level, pos);
    }

    @Override
    public boolean shouldPreventNeighborCulling(
            class_1922 level, class_2338 pos, class_2680 state, class_2338 adjPos, class_2680 adjState
    )
    {
        if (adjState.method_26204() != FBContent.BLOCK_FRAMED_ONE_WAY_WINDOW.get())
        {
            return true;
        }
        return state.method_11654(PropertyHolder.NULLABLE_FACE) != adjState.method_11654(PropertyHolder.NULLABLE_FACE);
    }

    @Override
    public boolean addRunningEffects(class_2680 state, class_1937 level, class_2338 pos, class_1297 entity)
    {
        if (state.method_11654(PropertyHolder.NULLABLE_FACE) == NullableDirection.UP)
        {
            ParticleHelper.spawnRunningParticles(class_2246.field_27115.method_9564(), level, pos, entity);
            return true;
        }
        return super.addRunningEffects(state, level, pos, entity);
    }

    @Override
    public boolean addLandingEffects(
            class_2680 state, class_3218 level, class_2338 pos, class_2680 sameState, class_1309 entity, int count
    )
    {
        if (state.method_11654(PropertyHolder.NULLABLE_FACE) == NullableDirection.UP)
        {
            ParticleHelper.spawnLandingParticles(class_2246.field_27115.method_9564(), level, pos, entity, count);
            return true;
        }
        return super.addLandingEffects(state, level, pos, sameState, entity, count);
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9598(class_2680 state, class_2470 rotation)
    {
        class_2350 dir = state.method_11654(PropertyHolder.NULLABLE_FACE).toDirection();
        if (dir != null && !Utils.isY(dir))
        {
            dir = rotation.method_10503(dir);
            state = state.method_11657(PropertyHolder.NULLABLE_FACE, NullableDirection.fromDirection(dir));
        }
        return state;
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9569(class_2680 state, class_2415 mirror)
    {
        class_2350 dir = state.method_11654(PropertyHolder.NULLABLE_FACE).toDirection();
        if (dir != null && !Utils.isY(dir))
        {
            dir = mirror.method_10343(dir);
            state = state.method_11657(PropertyHolder.NULLABLE_FACE, NullableDirection.fromDirection(dir));
        }
        return state;
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state)
    {
        return new FramedOwnableBlockEntity(pos, state);
    }

    public void initializeClient(Consumer<IClientBlockExtensions> consumer)
    {
        consumer.accept(new FramedBlockRenderProperties()
        {
            @Override
            protected boolean addHitEffectsUnsuppressed(
                    class_2680 state, class_1937 level, class_3965 hit, FramedBlockEntity be, class_702 engine
            )
            {
                if (state.method_11654(PropertyHolder.NULLABLE_FACE) != NullableDirection.NONE)
                {
                    ParticleHelper.Client.addHitEffects(state, level, hit, class_2246.field_27115.method_9564(), engine);
                }
                return super.addHitEffectsUnsuppressed(state, level, hit, be, engine);
            }

            @Override
            protected boolean addDestroyEffectsUnsuppressed(
                    class_2680 state, class_1937 level, class_2338 pos, FramedBlockEntity be, class_702 engine
            )
            {
                if (state.method_11654(PropertyHolder.NULLABLE_FACE) != NullableDirection.NONE)
                {
                    ParticleHelper.Client.addDestroyEffects(state, level, pos, class_2246.field_27115.method_9564(), engine);
                }
                return super.addDestroyEffectsUnsuppressed(state, level, pos, be, engine);
            }
        });
    }



    public static boolean isOwnedBy(class_1922 level, class_2338 pos, class_1657 player)
    {
        if (!ServerConfig.oneWayWindowOwnable)
        {
            return true;
        }
        if (level.method_8321(pos) instanceof FramedOwnableBlockEntity be)
        {
            return player.method_5667().equals(be.getOwner());
        }
        return false;
    }
}
