package xfacthd.framedblocks.common.block.cube;

import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_7718;
import net.minecraft.world.level.block.*;
import xfacthd.framedblocks.api.block.PlacementStateBuilder;
import xfacthd.framedblocks.common.block.FramedBlock;
import xfacthd.framedblocks.common.data.BlockType;

@SuppressWarnings("deprecation")
public class FramedMiniCubeBlock extends FramedBlock
{
    public FramedMiniCubeBlock()
    {
        super(BlockType.FRAMED_MINI_CUBE);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(class_2741.field_12532, class_2741.field_12508);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return PlacementStateBuilder.of(this, ctx)
                .withCustom((state, modCtx) -> state.method_11657(
                        class_2741.field_12532,
                        class_7718.method_45479(modCtx.method_8044() + 180F)
                ))
                .withWater()
                .build();
    }

    @Override
    public class_2680 rotate(class_2680 state, class_2350 face, class_2470 rotation)
    {
        int rot = state.method_11654(class_2741.field_12532);
        if (rotation == class_2470.field_11463)
        {
            rot = (rot + 1) % 16;
        }
        else
        {
            rot = (rot + 15) % 16;
        }
        return state.method_11657(class_2741.field_12532, rot);
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rotation)
    {
        int rot = state.method_11654(class_2741.field_12532);
        return state.method_11657(class_2741.field_12532, rotation.method_10502(rot, 16));
    }

    @Override
    public class_2680 method_9569(class_2680 state, class_2415 mirror)
    {
        int rot = state.method_11654(class_2741.field_12532);
        return state.method_11657(class_2741.field_12532, mirror.method_10344(rot, 16));
    }
}
