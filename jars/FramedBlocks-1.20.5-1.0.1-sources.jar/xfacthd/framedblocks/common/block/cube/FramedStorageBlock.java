package xfacthd.framedblocks.common.block.cube;

import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.common.block.FramedBlock;
import xfacthd.framedblocks.common.blockentity.special.FramedStorageBlockEntity;
import xfacthd.framedblocks.common.data.BlockType;

import javax.annotation.Nullable;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3222;
import net.minecraft.class_3965;
import net.minecraft.class_9062;
import net.minecraft.class_9334;

public class FramedStorageBlock extends FramedBlock
{
    public FramedStorageBlock(BlockType type) { super(type); }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(FramedProperties.SOLID);
    }

    @Override
    protected class_9062 method_55765(
            class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit
    )
    {
        if (!level.method_8608())
        {
            if (level.method_8321(pos) instanceof FramedStorageBlockEntity be)
            {
                be.open((class_3222) player);
            }
        }
        return convertUseResult(class_1269.method_29236(level.method_8608()), level);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void method_9536(class_2680 state, class_1937 level, class_2338 pos, class_2680 newState, boolean isMoving)
    {
        if (newState.method_26204() != state.method_26204() && level.method_8321(pos) instanceof FramedStorageBlockEntity be)
        {
            be.getDrops().forEach(stack -> method_9577(level, pos, stack));
            be.method_5448();
            level.method_8455(pos, this);
        }

        super.method_9536(state, level, pos, newState, isMoving);
    }

    @Override
    public void method_9567(class_1937 level, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 stack)
    {
        super.method_9567(level, pos, state, placer, stack);

        if (stack.method_57826(class_9334.field_49631) && level.method_8321(pos) instanceof FramedStorageBlockEntity be)
        {
            be.setCustomName(stack.method_7964());
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public boolean method_9498(class_2680 state)
    {
        return true;
    }

    @Override
    @SuppressWarnings("deprecation")
    public int method_9572(class_2680 state, class_1937 level, class_2338 pos)
    {
        if (level.method_8321(pos) instanceof FramedStorageBlockEntity be)
        {
            return be.getAnalogOutputSignal();
        }
        return 0;
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state)
    {
        return new FramedStorageBlockEntity(pos, state);
    }
}
