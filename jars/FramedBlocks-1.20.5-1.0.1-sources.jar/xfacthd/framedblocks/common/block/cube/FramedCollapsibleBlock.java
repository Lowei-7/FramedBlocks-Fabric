package xfacthd.framedblocks.common.block.cube;

import com.google.common.cache.*;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_3532;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import net.minecraft.class_9334;
import net.minecraft.world.level.*;
import net.minecraft.world.phys.shapes.*;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.block.IFramedBlock;
import xfacthd.framedblocks.api.block.PlacementStateBuilder;
import xfacthd.framedblocks.api.shapes.ShapeUtils;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.FramedBlock;
import xfacthd.framedblocks.common.blockentity.special.FramedCollapsibleBlockEntity;
import xfacthd.framedblocks.common.data.*;
import xfacthd.framedblocks.common.data.property.NullableDirection;

public class FramedCollapsibleBlock extends FramedBlock
{
    private static final LoadingCache<Integer, class_265> SHAPE_CACHE = CacheBuilder.newBuilder()
            .maximumSize(1024)
            .build(new ShapeLoader());

    public FramedCollapsibleBlock(BlockType blockType)
    {
        super(blockType, IFramedBlock.createProperties(BlockType.FRAMED_COLLAPSIBLE_BLOCK).method_9624());
        method_9590(method_9564()
                .method_11657(class_2741.field_12508, false)
                .method_11657(PropertyHolder.ROTATE_SPLIT_LINE, false)
        );
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(PropertyHolder.NULLABLE_FACE, class_2741.field_12508, PropertyHolder.ROTATE_SPLIT_LINE);
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return PlacementStateBuilder.of(this, ctx).withWater().build();
    }

    @Override
    public boolean handleBlockLeftClick(class_2680 state, class_1937 level, class_2338 pos, class_1657 player)
    {
        class_1799 heldItem = player.method_6047();
        if (heldItem.method_31573(Utils.WRENCH))
        {
            boolean rotSplitLine = state.method_11654(PropertyHolder.ROTATE_SPLIT_LINE);
            level.method_8501(pos, state.method_11657(PropertyHolder.ROTATE_SPLIT_LINE, !rotSplitLine));
            return true;
        }
        else if (heldItem.method_7909() == FBContent.ITEM_FRAMED_HAMMER.get())
        {
            if (level.method_8321(pos) instanceof FramedCollapsibleBlockEntity be)
            {
                if (!level.method_8608())
                {
                    be.handleDeform(player);
                }
                return true;
            }
        }
        return false;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 ctx)
    {
        if (isIntangible(state, level, pos, ctx))
        {
            return class_259.method_1073();
        }

        NullableDirection face = state.method_11654(PropertyHolder.NULLABLE_FACE);
        if (face != NullableDirection.NONE)
        {
            if (level.method_8321(pos) instanceof FramedCollapsibleBlockEntity be)
            {
                int offsets = be.getPackedOffsets();
                offsets |= (face.toDirection().method_10146() << 20);
                return SHAPE_CACHE.getUnchecked(offsets);
            }
        }
        return class_259.method_1077();
    }

    @Override
    public class_265 method_9571(class_2680 state, class_1922 level, class_2338 pos)
    {
        return getCamoOcclusionShape(state, level, pos, null);
    }

    @Override
    public void method_9567(class_1937 level, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 stack)
    {
        super.method_9567(level, pos, state, placer, stack);

        //noinspection ConstantConditions
        if (!level.method_8608() && stack.method_57826(class_9334.field_49611))
        {
            //Properly set collapsed face when placed from a stack with BE NBT data
            if (level.method_8321(pos) instanceof FramedCollapsibleBlockEntity be)
            {
                class_2350 collapseFace = be.getCollapsedFace();
                if (state.method_11654(PropertyHolder.NULLABLE_FACE).toDirection() != collapseFace)
                {
                    level.method_8501(pos, state.method_11657(PropertyHolder.NULLABLE_FACE, NullableDirection.fromDirection(collapseFace)));
                }
            }
        }
    }

    @Override
    public boolean doesBlockOccludeBeaconBeam(class_2680 state, class_4538 level, class_2338 pos)
    {
        NullableDirection face = state.method_11654(PropertyHolder.NULLABLE_FACE);
        return face == NullableDirection.NONE || Utils.isY(face.toDirection());
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state)
    {
        return new FramedCollapsibleBlockEntity(pos, state);
    }



    private static class ShapeLoader extends CacheLoader<Integer, class_265>
    {
        @Override
        @SuppressWarnings("SuspiciousNameCombination")
        public class_265 load(Integer packedData)
        {
            class_2350 face = class_2350.method_10143(packedData >> 20);
            byte[] offsets = FramedCollapsibleBlockEntity.unpackOffsets(packedData & 0xFFFFF);

            boolean positive = Utils.isPositive(face);
            boolean flipX = face == class_2350.field_11043 || face == class_2350.field_11034;
            boolean flipZ = face != class_2350.field_11036;

            class_265 result = class_259.method_1073();
            for (int x = 0; x < 4; x++)
            {
                for (int z = 0; z < 4; z++)
                {
                    double x0 = flipX ? (1D - x / 4D) : (x / 4D);
                    double x1 = flipX ? (1D - (x + 1) / 4D) : ((x + 1) / 4D);
                    double z0 = flipZ ? (1D - z / 4D) : (z / 4D);
                    double z1 = flipZ ? (1D - (z + 1) / 4D) : ((z + 1) / 4D);

                    double y0 = class_3532.method_16437(x0, z0, offsets[0], offsets[3], offsets[1], offsets[2]);
                    double y1 = class_3532.method_16437(x1, z1, offsets[0], offsets[3], offsets[1], offsets[2]);

                    double y = positive ?
                            Math.max(16D - Math.min(y0, y1), class_3532.field_29849 * 2D) :
                            Math.min(Math.min(y0, y1), 16D - (class_3532.field_29849 * 2D));

                    class_265 shape = switch (face)
                    {
                        case field_11043 -> method_9541(x * 4, z * 4, y, (x + 1) * 4, (z + 1) * 4, 16);
                        case field_11034 -> method_9541(0, z * 4, x * 4, y, (z + 1) * 4, (x + 1) * 4);
                        case field_11035 -> method_9541(x * 4, z * 4, 0, (x + 1) * 4, (z + 1) * 4, y);
                        case field_11039 -> method_9541(y, z * 4, x * 4, 16, (z + 1) * 4, (x + 1) * 4);
                        case field_11036 -> method_9541(x * 4, 0, z * 4, (x + 1) * 4, y, (z + 1) * 4);
                        case field_11033 -> method_9541(x * 4, y, z * 4, (x + 1) * 4, 16, (z + 1) * 4);
                    };

                    result = ShapeUtils.orUnoptimized(result, shape);
                }
            }

            return result.method_1097();
        }
    }
}