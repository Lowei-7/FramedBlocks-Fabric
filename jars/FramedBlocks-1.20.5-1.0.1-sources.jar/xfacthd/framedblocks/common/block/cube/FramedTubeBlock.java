package xfacthd.framedblocks.common.block.cube;

import net.minecraft.class_1309;
import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_4538;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.block.PlacementStateBuilder;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.FramedBlock;
import xfacthd.framedblocks.common.data.BlockType;

public class FramedTubeBlock extends FramedBlock
{
    public FramedTubeBlock()
    {
        super(BlockType.FRAMED_TUBE);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(class_2741.field_12496, FramedProperties.SOLID, class_2741.field_12508);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return PlacementStateBuilder.of(this, ctx)
                .withClickedAxis()
                .withWater()
                .build();
    }

    public boolean isLadder(class_2680 state, class_4538 level, class_2338 pos, class_1309 entity)
    {
        return state.method_11654(class_2741.field_12496) == class_2350.class_2351.field_11052;
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9598(class_2680 state, class_2470 rotation)
    {
        class_2350.class_2351 axis = state.method_11654(class_2741.field_12496);
        if (axis != class_2350.class_2351.field_11052 && (rotation == class_2470.field_11463 || rotation == class_2470.field_11465))
        {
            axis = axis == class_2350.class_2351.field_11048 ? class_2350.class_2351.field_11051 : class_2350.class_2351.field_11048;
        }
        return state.method_11657(class_2741.field_12496, axis);
    }



    public static class_2680 itemModelSource()
    {
        return FBContent.BLOCK_FRAMED_TUBE.get()
                .method_9564()
                .method_11657(class_2741.field_12496, class_2350.class_2351.field_11052);
    }
}
