package xfacthd.framedblocks.common.block.slopepanel;

import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_243;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_3545;
import net.minecraft.class_3965;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.block.IFramedBlock;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.AbstractFramedDoubleBlock;
import xfacthd.framedblocks.common.blockentity.doubled.FramedStackedSlopePanelBlockEntity;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.doubleblock.CamoGetter;
import xfacthd.framedblocks.common.data.doubleblock.SolidityCheck;
import xfacthd.framedblocks.common.data.property.HorizontalRotation;
import xfacthd.framedblocks.common.util.DoubleBlockTopInteractionMode;

public class FramedFlatStackedSlopePanelCornerBlock extends AbstractFramedDoubleBlock
{
    private final boolean corner;

    public FramedFlatStackedSlopePanelCornerBlock(BlockType type)
    {
        super(type);
        this.corner = type == BlockType.FRAMED_FLAT_STACKED_SLOPE_PANEL_CORNER;
        method_9590(method_9564().method_11657(FramedProperties.Y_SLOPE, false));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(
                FramedProperties.FACING_HOR, PropertyHolder.ROTATION,
                class_2741.field_12508, FramedProperties.Y_SLOPE
        );
    }

    @Override
    public class_2680 method_9605(class_1750 context)
    {
        return FramedFlatSlopePanelCornerBlock.getStateForPlacement(this, false, context);
    }

    @Override
    public boolean handleBlockLeftClick(class_2680 state, class_1937 level, class_2338 pos, class_1657 player)
    {
        return IFramedBlock.toggleYSlope(state, level, pos, player);
    }

    @Override
    public class_2680 rotate(class_2680 state, class_3965 hit, class_2470 rot)
    {
        class_2350 face = hit.method_17780();

        class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
        HorizontalRotation rotation = state.method_11654(PropertyHolder.ROTATION);
        class_2350 rotDir = rotation.withFacing(dir);
        class_2350 perpRotDir = rotation.rotate(class_2470.field_11465).withFacing(dir);

        if (face == rotDir || face == perpRotDir)
        {
            if (getBlockType() == BlockType.FRAMED_FLAT_EXT_SLOPE_PANEL_CORNER)
            {
                double xz = Utils.fractionInDir(hit.method_17784(), dir.method_10153());
                if (xz > .5)
                {
                    face = dir.method_10153();
                }
            }
            else //FRAMED_FLAT_EXT_INNER_SLOPE_PANEL_CORNER
            {
                class_243 vec = Utils.fraction(hit.method_17784());

                double hor = Utils.isX(dir) ? vec.method_10216() : vec.method_10215();
                if (!Utils.isPositive(dir))
                {
                    hor = 1D - hor;
                }

                class_2350 perpDir = face == rotDir ? perpRotDir : rotDir;
                double perpHor = Utils.isY(perpDir) ? vec.method_10214() : (Utils.isX(dir) ? vec.method_10215() : vec.method_10216());
                if (perpDir == class_2350.field_11033 || (!Utils.isY(perpDir) && !Utils.isPositive(perpDir)))
                {
                    perpHor = 1F - perpHor;
                }
                if ((hor * 2D) < perpHor)
                {
                    face = dir.method_10153();
                }
            }
        }

        return rotate(state, face, rot);
    }

    @Override
    public class_2680 rotate(class_2680 state, class_2350 face, class_2470 rot)
    {
        class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
        if (face.method_10166() == dir.method_10166())
        {
            HorizontalRotation rotation = state.method_11654(PropertyHolder.ROTATION);
            return state.method_11657(PropertyHolder.ROTATION, rotation.rotate(rot));
        }
        else if (Utils.isY(face))
        {
            return state.method_11657(FramedProperties.FACING_HOR, rot.method_10503(dir));
        }
        return state;
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9598(class_2680 state, class_2470 rot)
    {
        return rotate(state, class_2350.field_11036, rot);
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9569(class_2680 state, class_2415 mirror)
    {
        return FramedFlatSlopePanelCornerBlock.mirrorCorner(state, mirror);
    }

    @Override
    public DoubleBlockTopInteractionMode calculateTopInteractionMode(class_2680 state)
    {
        return DoubleBlockTopInteractionMode.EITHER;
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state)
    {
        return new FramedStackedSlopePanelBlockEntity(pos, state);
    }

    @Override
    public class_3545<class_2680, class_2680> calculateBlockPair(class_2680 state)
    {
        class_2350 facing = state.method_11654(FramedProperties.FACING_HOR);
        HorizontalRotation rotation = state.method_11654(PropertyHolder.ROTATION);
        boolean ySlope = state.method_11654(FramedProperties.Y_SLOPE);

        class_2248 topBlock;
        if (getBlockType() == BlockType.FRAMED_FLAT_STACKED_INNER_SLOPE_PANEL_CORNER)
        {
            topBlock = FBContent.BLOCK_FRAMED_FLAT_INNER_SLOPE_PANEL_CORNER.get();
        }
        else
        {
            topBlock = FBContent.BLOCK_FRAMED_FLAT_SLOPE_PANEL_CORNER.get();
        }

        return new class_3545<>(
                FBContent.BLOCK_FRAMED_PANEL.get()
                        .method_9564()
                        .method_11657(FramedProperties.FACING_HOR, facing),
                topBlock.method_9564()
                        .method_11657(FramedProperties.FACING_HOR, facing)
                        .method_11657(PropertyHolder.ROTATION, rotation)
                        .method_11657(PropertyHolder.FRONT, true)
                        .method_11657(FramedProperties.Y_SLOPE, ySlope)
        );
    }

    @Override
    public CamoGetter calculateCamoGetter(class_2680 state, class_2350 side, @Nullable class_2350 edge)
    {
        class_2350 facing = state.method_11654(FramedProperties.FACING_HOR);
        if (side == facing || (side.method_10166() != facing.method_10166() && edge == facing))
        {
            return CamoGetter.FIRST;
        }

        if (!corner && edge == facing.method_10153())
        {
            HorizontalRotation rot = state.method_11654(PropertyHolder.ROTATION);
            class_2350 rotDir = rot.withFacing(facing);
            class_2350 perpRotDir = rot.rotate(class_2470.field_11465).withFacing(facing);

            if (side == rotDir.method_10153() || side == perpRotDir.method_10153())
            {
                return CamoGetter.SECOND;
            }
        }
        return CamoGetter.NONE;
    }

    @Override
    public SolidityCheck calculateSolidityCheck(class_2680 state, class_2350 side)
    {
        class_2350 facing = state.method_11654(FramedProperties.FACING_HOR);
        if (side == facing)
        {
            return SolidityCheck.FIRST;
        }

        if (!corner)
        {
            HorizontalRotation rot = state.method_11654(PropertyHolder.ROTATION);
            class_2350 rotDir = rot.withFacing(facing);
            class_2350 perpRotDir = rot.rotate(class_2470.field_11465).withFacing(facing);

            if (side == rotDir.method_10153() || side == perpRotDir.method_10153())
            {
                return SolidityCheck.BOTH;
            }
        }
        return SolidityCheck.NONE;
    }



    public static class_2680 itemModelSource()
    {
        return FBContent.BLOCK_FRAMED_FLAT_STACKED_SLOPE_PANEL_CORNER.get()
                .method_9564()
                .method_11657(FramedProperties.FACING_HOR, class_2350.field_11035);
    }

    public static class_2680 itemModelSourceInner()
    {
        return FBContent.BLOCK_FRAMED_FLAT_STACKED_INNER_SLOPE_PANEL_CORNER.get()
                .method_9564()
                .method_11657(FramedProperties.FACING_HOR, class_2350.field_11035);
    }
}
