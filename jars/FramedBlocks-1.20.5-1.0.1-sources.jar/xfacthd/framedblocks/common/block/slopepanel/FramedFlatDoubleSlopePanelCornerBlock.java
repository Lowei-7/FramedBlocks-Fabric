package xfacthd.framedblocks.common.block.slopepanel;

import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_3545;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.block.IFramedBlock;
import xfacthd.framedblocks.api.util.*;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.AbstractFramedDoubleBlock;
import xfacthd.framedblocks.common.blockentity.doubled.FramedFlatDoubleSlopePanelCornerBlockEntity;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.doubleblock.CamoGetter;
import xfacthd.framedblocks.common.data.doubleblock.SolidityCheck;
import xfacthd.framedblocks.common.data.property.HorizontalRotation;
import xfacthd.framedblocks.common.util.DoubleBlockTopInteractionMode;

public class FramedFlatDoubleSlopePanelCornerBlock extends AbstractFramedDoubleBlock
{
    public FramedFlatDoubleSlopePanelCornerBlock()
    {
        super(BlockType.FRAMED_FLAT_DOUBLE_SLOPE_PANEL_CORNER);
        method_9590(method_9564()
                .method_11657(PropertyHolder.FRONT, false)
                .method_11657(FramedProperties.Y_SLOPE, false)
        );
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(
                FramedProperties.FACING_HOR, PropertyHolder.ROTATION, PropertyHolder.FRONT,
                class_2741.field_12508, FramedProperties.Y_SLOPE
        );
    }

    @Override
    public class_2680 method_9605(class_1750 context)
    {
        return FramedFlatSlopePanelCornerBlock.getStateForPlacement(this, true, context);
    }

    @Override
    public boolean handleBlockLeftClick(class_2680 state, class_1937 level, class_2338 pos, class_1657 player)
    {
        return IFramedBlock.toggleYSlope(state, level, pos, player);
    }

    @Override
    public class_2680 rotate(class_2680 state, class_2350 face, class_2470 rot)
    {
        class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);

        if (Utils.isY(face))
        {
            return state.method_11657(FramedProperties.FACING_HOR, rot.method_10503(dir));
        }
        else if (face.method_10166() == dir.method_10166())
        {
            HorizontalRotation rotation = state.method_11654(PropertyHolder.ROTATION);
            return state.method_11657(PropertyHolder.ROTATION, rotation.rotate(rot));
        }
        else
        {
            return state.method_28493(PropertyHolder.FRONT);
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9598(class_2680 state, class_2470 rotation)
    {
        return rotate(state, class_2350.field_11036, rotation);
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9569(class_2680 state, class_2415 mirror)
    {
        return FramedFlatSlopePanelCornerBlock.mirrorCorner(state, mirror);
    }

    @Override
    public class_3545<class_2680, class_2680> calculateBlockPair(class_2680 state)
    {
        class_2350 facing = state.method_11654(FramedProperties.FACING_HOR);
        HorizontalRotation rotation = state.method_11654(PropertyHolder.ROTATION);
        boolean front = state.method_11654(PropertyHolder.FRONT);
        HorizontalRotation backRot = rotation.rotate(rotation.isVertical() ? class_2470.field_11465 : class_2470.field_11463);
        boolean ySlope = state.method_11654(FramedProperties.Y_SLOPE);

        return new class_3545<>(
                FBContent.BLOCK_FRAMED_FLAT_INNER_SLOPE_PANEL_CORNER.get()
                        .method_9564()
                        .method_11657(FramedProperties.FACING_HOR, facing)
                        .method_11657(PropertyHolder.ROTATION, rotation)
                        .method_11657(PropertyHolder.FRONT, front)
                        .method_11657(FramedProperties.Y_SLOPE, ySlope),
                FBContent.BLOCK_FRAMED_FLAT_SLOPE_PANEL_CORNER.get()
                        .method_9564()
                        .method_11657(FramedProperties.FACING_HOR, facing.method_10153())
                        .method_11657(PropertyHolder.ROTATION, backRot)
                        .method_11657(PropertyHolder.FRONT, !front)
                        .method_11657(FramedProperties.Y_SLOPE, ySlope)
        );
    }

    @Override
    public DoubleBlockTopInteractionMode calculateTopInteractionMode(class_2680 state)
    {
        HorizontalRotation rotation = state.method_11654(PropertyHolder.ROTATION);
        if (rotation == HorizontalRotation.DOWN || rotation == HorizontalRotation.LEFT)
        {
            return DoubleBlockTopInteractionMode.FIRST;
        }
        return DoubleBlockTopInteractionMode.EITHER;
    }

    @Override
    public CamoGetter calculateCamoGetter(class_2680 state, class_2350 side, @Nullable class_2350 edge)
    {
        class_2350 facing = state.method_11654(FramedProperties.FACING_HOR);
        boolean front = state.method_11654(PropertyHolder.FRONT);
        if (side == facing)
        {
            return front ? CamoGetter.NONE : CamoGetter.FIRST;
        }
        else if (side == facing.method_10153())
        {
            return front ? CamoGetter.SECOND : CamoGetter.NONE;
        }

        HorizontalRotation rotation = state.method_11654(PropertyHolder.ROTATION);
        class_2350 rotDir = rotation.withFacing(facing);
        class_2350 perpRotDir = rotation.rotate(class_2470.field_11465).withFacing(facing);
        if (side == rotDir || side == perpRotDir)
        {
            if (edge == facing && !front)
            {
                return CamoGetter.FIRST;
            }
            else if (edge == facing.method_10153() && front)
            {
                return CamoGetter.SECOND;
            }
        }
        else if ((!front && edge == facing) || (front && edge == facing.method_10153()))
        {
            return CamoGetter.FIRST;
        }

        return CamoGetter.NONE;
    }

    @Override
    public SolidityCheck calculateSolidityCheck(class_2680 state, class_2350 side)
    {
        class_2350 facing = state.method_11654(FramedProperties.FACING_HOR);
        boolean front = state.method_11654(PropertyHolder.FRONT);
        if (side == facing && !front)
        {
            return SolidityCheck.FIRST;
        }
        else if (side == facing.method_10153() && front)
        {
            return SolidityCheck.SECOND;
        }
        return SolidityCheck.NONE;
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state)
    {
        return new FramedFlatDoubleSlopePanelCornerBlockEntity(pos, state);
    }



    public static class_2680 itemSource()
    {
        return FBContent.BLOCK_FRAMED_FLAT_DOUBLE_SLOPE_PANEL_CORNER.get()
                .method_9564()
                .method_11657(FramedProperties.FACING_HOR, class_2350.field_11035)
                .method_11657(PropertyHolder.ROTATION, HorizontalRotation.RIGHT);
    }
}
