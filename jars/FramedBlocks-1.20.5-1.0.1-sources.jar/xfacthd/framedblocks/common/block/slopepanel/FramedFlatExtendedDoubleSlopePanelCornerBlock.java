package xfacthd.framedblocks.common.block.slopepanel;

import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3545;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.block.IFramedBlock;
import xfacthd.framedblocks.api.util.*;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.AbstractFramedDoubleBlock;
import xfacthd.framedblocks.common.blockentity.doubled.FramedFlatExtendedDoubleSlopePanelCornerBlockEntity;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.doubleblock.CamoGetter;
import xfacthd.framedblocks.common.data.doubleblock.SolidityCheck;
import xfacthd.framedblocks.common.data.property.HorizontalRotation;
import xfacthd.framedblocks.common.util.DoubleBlockTopInteractionMode;

public class FramedFlatExtendedDoubleSlopePanelCornerBlock extends AbstractFramedDoubleBlock
{
    private final boolean isInner;

    public FramedFlatExtendedDoubleSlopePanelCornerBlock(BlockType blockType)
    {
        super(blockType);
        this.isInner = blockType == BlockType.FRAMED_FLAT_EXT_INNER_DOUBLE_SLOPE_PANEL_CORNER;
        method_9590(method_9564().method_11657(FramedProperties.Y_SLOPE, false));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(FramedProperties.FACING_HOR, PropertyHolder.ROTATION, FramedProperties.Y_SLOPE);
    }

    @Override
    public class_2680 method_9605(class_1750 context)
    {
        return FramedFlatSlopePanelCornerBlock.getStateForPlacement(this, false, context);
    }

    @Override
    public boolean handleBlockLeftClick(class_2680 state, class_1937 level, class_2338 pos, class_1657 player)
    {
        return IFramedBlock.toggleYSlope(state, level, pos, player);
    }

    @Override
    public class_2680 rotate(class_2680 state, class_2350 face, class_2470 rot)
    {
        class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);

        if (Utils.isY(face))
        {
            return state.method_11657(FramedProperties.FACING_HOR, rot.method_10503(dir));
        }
        else if (face.method_10166() == dir.method_10166())
        {
            HorizontalRotation rotation = state.method_11654(PropertyHolder.ROTATION);
            return state.method_11657(PropertyHolder.ROTATION, rotation.rotate(rot));
        }

        return state;
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9598(class_2680 state, class_2470 rotation)
    {
        return rotate(state, class_2350.field_11036, rotation);
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9569(class_2680 state, class_2415 mirror)
    {
        return FramedFlatSlopePanelCornerBlock.mirrorCorner(state, mirror);
    }

    @Override
    public class_3545<class_2680, class_2680> calculateBlockPair(class_2680 state)
    {
        class_2350 facing = state.method_11654(FramedProperties.FACING_HOR);
        HorizontalRotation rotation = state.method_11654(PropertyHolder.ROTATION);
        HorizontalRotation backRot = rotation.rotate(rotation.isVertical() ? class_2470.field_11465 : class_2470.field_11463);
        boolean ySlope = state.method_11654(FramedProperties.Y_SLOPE);

        if (getBlockType() == BlockType.FRAMED_FLAT_EXT_INNER_DOUBLE_SLOPE_PANEL_CORNER)
        {
            return new class_3545<>(
                    FBContent.BLOCK_FRAMED_FLAT_EXTENDED_INNER_SLOPE_PANEL_CORNER.get()
                            .method_9564()
                            .method_11657(FramedProperties.FACING_HOR, facing)
                            .method_11657(PropertyHolder.ROTATION, rotation)
                            .method_11657(FramedProperties.Y_SLOPE, ySlope),
                    FBContent.BLOCK_FRAMED_FLAT_SLOPE_PANEL_CORNER.get()
                            .method_9564()
                            .method_11657(FramedProperties.FACING_HOR, facing.method_10153())
                            .method_11657(PropertyHolder.ROTATION, backRot)
                            .method_11657(FramedProperties.Y_SLOPE, ySlope)
            );
        }
        else
        {
            return new class_3545<>(
                    FBContent.BLOCK_FRAMED_FLAT_EXTENDED_SLOPE_PANEL_CORNER.get()
                            .method_9564()
                            .method_11657(FramedProperties.FACING_HOR, facing)
                            .method_11657(PropertyHolder.ROTATION, rotation)
                            .method_11657(FramedProperties.Y_SLOPE, ySlope),
                    FBContent.BLOCK_FRAMED_FLAT_INNER_SLOPE_PANEL_CORNER.get()
                            .method_9564()
                            .method_11657(FramedProperties.FACING_HOR, facing.method_10153())
                            .method_11657(PropertyHolder.ROTATION, backRot)
                            .method_11657(FramedProperties.Y_SLOPE, ySlope)
            );
        }
    }

    @Override
    public DoubleBlockTopInteractionMode calculateTopInteractionMode(class_2680 state)
    {
        if (getBlockType() == BlockType.FRAMED_FLAT_EXT_INNER_DOUBLE_SLOPE_PANEL_CORNER)
        {
            HorizontalRotation rotation = state.method_11654(PropertyHolder.ROTATION);
            if (rotation == HorizontalRotation.UP || rotation == HorizontalRotation.RIGHT)
            {
                return DoubleBlockTopInteractionMode.FIRST;
            }
        }
        return DoubleBlockTopInteractionMode.EITHER;
    }

    @Override
    public CamoGetter calculateCamoGetter(class_2680 state, class_2350 side, @Nullable class_2350 edge)
    {
        class_2350 facing = state.method_11654(FramedProperties.FACING_HOR);
        if (side == facing)
        {
            return CamoGetter.FIRST;
        }
        if (side == facing.method_10153())
        {
            return CamoGetter.SECOND;
        }

        HorizontalRotation rotation = state.method_11654(PropertyHolder.ROTATION);
        class_2350 rotDir = rotation.withFacing(facing);
        class_2350 perpRotDir = rotation.rotate(class_2470.field_11465).withFacing(facing);
        if (isInner && (side == rotDir.method_10153() || side == perpRotDir.method_10153()))
        {
            return CamoGetter.FIRST;
        }
        else if (side.method_10166() != facing.method_10166())
        {
            if (edge == facing)
            {
                return CamoGetter.FIRST;
            }
            else if (edge == facing.method_10153())
            {
                return CamoGetter.SECOND;
            }
        }

        return CamoGetter.NONE;
    }

    @Override
    public SolidityCheck calculateSolidityCheck(class_2680 state, class_2350 side)
    {
        class_2350 facing = state.method_11654(FramedProperties.FACING_HOR);

        if (side == facing)
        {
            return SolidityCheck.FIRST;
        }
        else if (side == facing.method_10153())
        {
            return SolidityCheck.SECOND;
        }

        if (isInner)
        {
            HorizontalRotation rotation = state.method_11654(PropertyHolder.ROTATION);
            class_2350 rotDir = rotation.withFacing(facing);
            class_2350 perpRotDir = rotation.rotate(class_2470.field_11465).withFacing(facing);
            if (side == rotDir.method_10153() || side == perpRotDir.method_10153())
            {
                return SolidityCheck.FIRST;
            }
        }
        return SolidityCheck.BOTH;
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state)
    {
        return new FramedFlatExtendedDoubleSlopePanelCornerBlockEntity(pos, state);
    }



    public static class_2680 itemModelSource()
    {
        return FBContent.BLOCK_FRAMED_FLAT_EXTENDED_DOUBLE_SLOPE_PANEL_CORNER.get()
                .method_9564()
                .method_11657(FramedProperties.FACING_HOR, class_2350.field_11035)
                .method_11657(PropertyHolder.ROTATION, HorizontalRotation.RIGHT);
    }

    public static class_2680 itemModelSourceInner()
    {
        return FBContent.BLOCK_FRAMED_FLAT_EXTENDED_INNER_DOUBLE_SLOPE_PANEL_CORNER.get()
                .method_9564()
                .method_11657(FramedProperties.FACING_HOR, class_2350.field_11035)
                .method_11657(PropertyHolder.ROTATION, HorizontalRotation.RIGHT);
    }
}
