package xfacthd.framedblocks.common.block.slopepanel;

import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_3965;
import net.minecraft.world.level.block.*;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.block.IFramedBlock;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.ExtPlacementStateBuilder;
import xfacthd.framedblocks.common.block.FramedBlock;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.HorizontalRotation;

public class FramedCompoundSlopePanelBlock extends FramedBlock
{
    public FramedCompoundSlopePanelBlock()
    {
        super(BlockType.FRAMED_COMPOUND_SLOPE_PANEL);
        method_9590(method_9564().method_11657(FramedProperties.Y_SLOPE, false));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(
                FramedProperties.FACING_HOR, PropertyHolder.ROTATION, class_2741.field_12508,
                FramedProperties.Y_SLOPE, FramedProperties.SOLID
        );
    }

    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return ExtPlacementStateBuilder.of(this, ctx)
                .withHorizontalFacing()
                .withCrossOrSideRotation()
                .withWater()
                .build();
    }

    @Override
    public boolean handleBlockLeftClick(class_2680 state, class_1937 level, class_2338 pos, class_1657 player)
    {
        return IFramedBlock.toggleYSlope(state, level, pos, player);
    }

    @Override
    public class_2680 rotate(class_2680 state, class_3965 hit, class_2470 rot)
    {
        class_2350 face = hit.method_17780();

        class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
        HorizontalRotation rotation = state.method_11654(PropertyHolder.ROTATION);
        if (face == rotation.withFacing(dir))
        {
            double xz = Utils.fractionInDir(hit.method_17784(), dir.method_10153());
            if (xz > .5)
            {
                face = dir.method_10153();
            }
        }
        else if (face == rotation.withFacing(dir).method_10153())
        {
            double xz = Utils.fractionInDir(hit.method_17784(), dir);
            if (xz > .5)
            {
                face = dir;
            }
        }

        return rotate(state, face, rot);
    }

    @Override
    public class_2680 rotate(class_2680 state, class_2350 face, class_2470 rot)
    {
        class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
        if (face.method_10166() == dir.method_10166())
        {
            HorizontalRotation rotation = state.method_11654(PropertyHolder.ROTATION);
            return state.method_11657(PropertyHolder.ROTATION, rotation.rotate(rot));
        }
        else if (Utils.isY(face))
        {
            return state.method_11657(FramedProperties.FACING_HOR, rot.method_10503(dir));
        }
        return state;
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9598(class_2680 state, class_2470 rot)
    {
        return rotate(state, class_2350.field_11036, rot);
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9569(class_2680 state, class_2415 mirror)
    {
        return FramedSlopePanelBlock.mirrorPanel(state, mirror);
    }

    public static class_2680 itemModelSource()
    {
        return FBContent.BLOCK_FRAMED_COMPOUND_SLOPE_PANEL.get().method_9564();
    }
}
