package xfacthd.framedblocks.common.block.slopeslab;

import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_3545;
import net.minecraft.class_3965;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.block.*;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.AbstractFramedDoubleBlock;
import xfacthd.framedblocks.common.blockentity.doubled.FramedStackedSlopeSlabBlockEntity;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.doubleblock.CamoGetter;
import xfacthd.framedblocks.common.data.doubleblock.SolidityCheck;
import xfacthd.framedblocks.common.util.DoubleBlockTopInteractionMode;

public class FramedStackedSlopeSlabBlock extends AbstractFramedDoubleBlock
{
    public FramedStackedSlopeSlabBlock()
    {
        super(BlockType.FRAMED_STACKED_SLOPE_SLAB);
        method_9590(method_9564()
                .method_11657(FramedProperties.TOP, false)
                .method_11657(FramedProperties.Y_SLOPE, true)
        );
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(FramedProperties.FACING_HOR, FramedProperties.TOP, FramedProperties.Y_SLOPE, class_2741.field_12508);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return PlacementStateBuilder.of(this, ctx)
                .withTargetOrHorizontalFacing()
                .withTop()
                .withWater()
                .build();
    }

    @Override
    public boolean handleBlockLeftClick(class_2680 state, class_1937 level, class_2338 pos, class_1657 player)
    {
        return IFramedBlock.toggleYSlope(state, level, pos, player);
    }

    @Override
    public class_2680 rotate(class_2680 state, class_3965 hit, class_2470 rot)
    {
        class_2350 face = hit.method_17780();
        if (face == state.method_11654(FramedProperties.FACING_HOR).method_10153())
        {
            double y = Utils.fraction(hit.method_17784()).field_1351;
            boolean top = state.method_11654(FramedProperties.TOP);
            if ((y > .5) != top)
            {
                face = top ? class_2350.field_11033 : class_2350.field_11036;
            }
        }
        return rotate(state, face, rot);
    }

    @Override
    public class_2680 rotate(class_2680 state, class_2350 face, class_2470 rot)
    {
        if (Utils.isY(face))
        {
            class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
            return state.method_11657(FramedProperties.FACING_HOR, rot.method_10503(dir));
        }
        else if (rot != class_2470.field_11467)
        {
            return state.method_28493(FramedProperties.TOP);
        }
        return state;
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9598(class_2680 state, class_2470 rot)
    {
        return rotate(state, class_2350.field_11036, rot);
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9569(class_2680 state, class_2415 mirror)
    {
        return Utils.mirrorFaceBlock(state, mirror);
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state)
    {
        return new FramedStackedSlopeSlabBlockEntity(pos, state);
    }

    @Override
    public class_3545<class_2680, class_2680> calculateBlockPair(class_2680 state)
    {
        class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
        boolean top = state.method_11654(FramedProperties.TOP);
        boolean ySlope = state.method_11654(FramedProperties.Y_SLOPE);

        return new class_3545<>(
                FBContent.BLOCK_FRAMED_SLAB.get()
                        .method_9564()
                        .method_11657(FramedProperties.TOP, top),
                FBContent.BLOCK_FRAMED_SLOPE_SLAB.get()
                        .method_9564()
                        .method_11657(FramedProperties.FACING_HOR, dir)
                        .method_11657(FramedProperties.TOP, top)
                        .method_11657(PropertyHolder.TOP_HALF, !top)
                        .method_11657(FramedProperties.Y_SLOPE, ySlope)
        );
    }

    @Override
    public DoubleBlockTopInteractionMode calculateTopInteractionMode(class_2680 state)
    {
        if (state.method_11654(FramedProperties.TOP))
        {
            return DoubleBlockTopInteractionMode.FIRST;
        }
        return DoubleBlockTopInteractionMode.SECOND;
    }

    @Override
    public CamoGetter calculateCamoGetter(class_2680 state, class_2350 side, @Nullable class_2350 edge)
    {
        boolean top = state.method_11654(FramedProperties.TOP);
        class_2350 dirTwo = top ? class_2350.field_11036 : class_2350.field_11033;

        if (side == dirTwo || (!Utils.isY(side) && edge == dirTwo))
        {
            return CamoGetter.FIRST;
        }
        else if (edge == dirTwo.method_10153())
        {
            if (side == state.method_11654(FramedProperties.FACING_HOR))
            {
                return CamoGetter.SECOND;
            }
        }

        return CamoGetter.NONE;
    }

    @Override
    public SolidityCheck calculateSolidityCheck(class_2680 state, class_2350 side)
    {
        boolean top = state.method_11654(FramedProperties.TOP);
        if ((!top && side == class_2350.field_11033) || (top && side == class_2350.field_11036))
        {
            return SolidityCheck.FIRST;
        }

        if (side == state.method_11654(FramedProperties.FACING_HOR))
        {
            return SolidityCheck.BOTH;
        }
        return SolidityCheck.NONE;
    }



    public static class_2680 itemModelSource()
    {
        return FBContent.BLOCK_FRAMED_STACKED_SLOPE_SLAB.get()
                .method_9564()
                .method_11657(FramedProperties.FACING_HOR, class_2350.field_11035);
    }
}
