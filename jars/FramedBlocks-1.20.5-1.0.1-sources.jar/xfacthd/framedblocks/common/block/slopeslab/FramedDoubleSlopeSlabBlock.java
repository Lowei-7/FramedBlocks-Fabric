package xfacthd.framedblocks.common.block.slopeslab;

import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_3545;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.phys.shapes.*;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.block.*;
import xfacthd.framedblocks.api.util.*;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.AbstractFramedDoubleBlock;
import xfacthd.framedblocks.common.blockentity.doubled.FramedDoubleSlopeSlabBlockEntity;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.doubleblock.CamoGetter;
import xfacthd.framedblocks.common.data.doubleblock.SolidityCheck;
import xfacthd.framedblocks.common.util.DoubleBlockTopInteractionMode;

public class FramedDoubleSlopeSlabBlock extends AbstractFramedDoubleBlock
{
    private static final class_265 SHAPE_BOTTOM = class_2248.method_9541(0.0D, 0.0D, 0.0D, 16.0D, 8.0D, 16.0D);
    private static final class_265 SHAPE_TOP = class_2248.method_9541(0.0D, 8.0D, 0.0D, 16.0D, 16.0D, 16.0D);

    public FramedDoubleSlopeSlabBlock()
    {
        super(BlockType.FRAMED_DOUBLE_SLOPE_SLAB);
        method_9590(method_9564()
                .method_11657(PropertyHolder.TOP_HALF, false)
                .method_11657(FramedProperties.Y_SLOPE, true)
        );
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(
                FramedProperties.FACING_HOR, PropertyHolder.TOP_HALF, class_2741.field_12508,
                FramedProperties.Y_SLOPE
        );
    }

    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return PlacementStateBuilder.of(this, ctx)
                .withTargetOrHorizontalFacing()
                .withTop(PropertyHolder.TOP_HALF)
                .withWater()
                .build();
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 ctx)
    {
        if (isIntangible(state, level, pos, ctx))
        {
            return class_259.method_1073();
        }
        return state.method_11654(PropertyHolder.TOP_HALF) ? SHAPE_TOP : SHAPE_BOTTOM;
    }

    @Override
    public boolean doesBlockOccludeBeaconBeam(class_2680 state, class_4538 level, class_2338 pos)
    {
        return true;
    }

    @Override
    public boolean handleBlockLeftClick(class_2680 state, class_1937 level, class_2338 pos, class_1657 player)
    {
        return IFramedBlock.toggleYSlope(state, level, pos, player);
    }

    @Override
    public class_2680 rotate(class_2680 state, class_2350 face, class_2470 rot)
    {
        if (Utils.isY(face))
        {
            class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
            return state.method_11657(FramedProperties.FACING_HOR, rot.method_10503(dir));
        }
        else if (rot != class_2470.field_11467)
        {
            return state.method_28493(PropertyHolder.TOP_HALF);
        }
        return state;
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9598(class_2680 state, class_2470 rot)
    {
        return rotate(state, class_2350.field_11036, rot);
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9569(class_2680 state, class_2415 mirror)
    {
        return Utils.mirrorFaceBlock(state, mirror);
    }

    @Override
    public class_3545<class_2680, class_2680> calculateBlockPair(class_2680 state)
    {
        class_2350 facing = state.method_11654(FramedProperties.FACING_HOR);
        boolean topHalf = state.method_11654(PropertyHolder.TOP_HALF);
        boolean ySlope = state.method_11654(FramedProperties.Y_SLOPE);

        class_2680 defState = FBContent.BLOCK_FRAMED_SLOPE_SLAB.get().method_9564();
        return new class_3545<>(
                defState.method_11657(FramedProperties.FACING_HOR, facing)
                        .method_11657(PropertyHolder.TOP_HALF, topHalf)
                        .method_11657(FramedProperties.TOP, false)
                        .method_11657(FramedProperties.Y_SLOPE, ySlope),
                defState.method_11657(FramedProperties.FACING_HOR, facing.method_10153())
                        .method_11657(PropertyHolder.TOP_HALF, topHalf)
                        .method_11657(FramedProperties.TOP, true)
                        .method_11657(FramedProperties.Y_SLOPE, ySlope)
        );
    }

    @Override
    public DoubleBlockTopInteractionMode calculateTopInteractionMode(class_2680 state)
    {
        return DoubleBlockTopInteractionMode.SECOND;
    }

    @Override
    public CamoGetter calculateCamoGetter(class_2680 state, class_2350 side, @Nullable class_2350 edge)
    {
        class_2350 facing = state.method_11654(FramedProperties.FACING_HOR);
        boolean top = state.method_11654(PropertyHolder.TOP_HALF);
        class_2350 dirTwo = top ? class_2350.field_11036 : class_2350.field_11033;

        if ((side == class_2350.field_11036 && top) || (side == facing.method_10153() && edge == dirTwo))
        {
            return CamoGetter.SECOND;
        }
        else if ((side == class_2350.field_11033 && !top) || (side == facing && edge == dirTwo))
        {
            return CamoGetter.FIRST;
        }
        else if (side.method_10166() == facing.method_10170().method_10166() && edge == dirTwo)
        {
            return top ? CamoGetter.SECOND : CamoGetter.FIRST;
        }

        return CamoGetter.NONE;
    }

    @Override
    public SolidityCheck calculateSolidityCheck(class_2680 state, class_2350 side)
    {
        boolean topHalf = state.method_11654(PropertyHolder.TOP_HALF);
        if (topHalf && side == class_2350.field_11036)
        {
            return SolidityCheck.SECOND;
        }
        else if (!topHalf && side == class_2350.field_11033)
        {
            return SolidityCheck.FIRST;
        }
        return SolidityCheck.NONE;
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state)
    {
        return new FramedDoubleSlopeSlabBlockEntity(pos, state);
    }



    public static class_2680 itemModelSource()
    {
        return FBContent.BLOCK_FRAMED_DOUBLE_SLOPE_SLAB.get().method_9564();
    }
}
