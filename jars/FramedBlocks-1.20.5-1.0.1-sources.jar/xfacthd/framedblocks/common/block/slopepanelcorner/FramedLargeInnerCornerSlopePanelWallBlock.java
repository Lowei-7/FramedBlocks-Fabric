package xfacthd.framedblocks.common.block.slopepanelcorner;

import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.common.data.BlockType;

public class FramedLargeInnerCornerSlopePanelWallBlock extends FramedCornerSlopePanelWallBlock
{
    public FramedLargeInnerCornerSlopePanelWallBlock(BlockType type)
    {
        super(type);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(FramedProperties.SOLID);
    }
}
