package xfacthd.framedblocks.common.block.slopepanelcorner;

import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_243;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_3545;
import net.minecraft.class_3965;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.block.IFramedBlock;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.AbstractFramedDoubleBlock;
import xfacthd.framedblocks.common.blockentity.doubled.FramedInverseDoubleCornerSlopePanelBlockEntity;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.data.doubleblock.CamoGetter;
import xfacthd.framedblocks.common.data.doubleblock.SolidityCheck;
import xfacthd.framedblocks.common.item.VerticalAndWallBlockItem;
import xfacthd.framedblocks.common.util.DoubleBlockTopInteractionMode;

@SuppressWarnings("deprecation")
public class FramedInverseDoubleCornerSlopePanelBlock extends AbstractFramedDoubleBlock
{
    public FramedInverseDoubleCornerSlopePanelBlock()
    {
        super(BlockType.FRAMED_INV_DOUBLE_CORNER_SLOPE_PANEL);
        method_9590(method_9564()
                .method_11657(FramedProperties.TOP, false)
                .method_11657(FramedProperties.Y_SLOPE, false)
        );
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(
                FramedProperties.FACING_HOR, FramedProperties.TOP,
                FramedProperties.Y_SLOPE, class_2741.field_12508
        );
    }

    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return FramedCornerSlopePanelBlock.getStateForPlacement(this, ctx, false, true);
    }

    @Override
    public boolean handleBlockLeftClick(class_2680 state, class_1937 level, class_2338 pos, class_1657 player)
    {
        return IFramedBlock.toggleYSlope(state, level, pos, player);
    }

    @Override
    public class_2680 rotate(class_2680 state, class_3965 hit, class_2470 rot)
    {
        class_2350 side = hit.method_17780();
        class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
        if (side == dir.method_10153() || side == dir.method_10170())
        {
            side = class_2350.field_11036;
        }
        else if (side == dir || side == dir.method_10160())
        {
            boolean top = state.method_11654(FramedProperties.TOP);
            class_243 hitVec = hit.method_17784();
            double y = Utils.fractionInDir(hitVec, top ? class_2350.field_11033 : class_2350.field_11036);
            double xz = Utils.fractionInDir(hitVec, side == dir ? dir.method_10160() : dir) - .5;
            if (xz * 2D > y)
            {
                side = class_2350.field_11036;
            }
        }
        return rotate(state, side, rot);
    }

    @Override
    public class_2680 rotate(class_2680 state, class_2350 face, class_2470 rot)
    {
        if (Utils.isY(face))
        {
            class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
            return state.method_11657(FramedProperties.FACING_HOR, rot.method_10503(dir));
        }
        return state.method_28493(FramedProperties.TOP);
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rotation)
    {
        return rotate(state, class_2350.field_11036, rotation);
    }

    @Override
    public class_2680 method_9569(class_2680 state, class_2415 mirror)
    {
        return Utils.mirrorCornerBlock(state, mirror);
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state)
    {
        return new FramedInverseDoubleCornerSlopePanelBlockEntity(pos, state);
    }

    @Override
    public class_3545<class_2680, class_2680> calculateBlockPair(class_2680 state)
    {
        class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
        boolean top = state.method_11654(FramedProperties.TOP);
        boolean ySlope = state.method_11654(FramedProperties.Y_SLOPE);

        return new class_3545<>(
                FBContent.BLOCK_FRAMED_LARGE_CORNER_SLOPE_PANEL.get()
                        .method_9564()
                        .method_11657(FramedProperties.FACING_HOR, dir)
                        .method_11657(FramedProperties.TOP, top)
                        .method_11657(FramedProperties.Y_SLOPE, ySlope),
                FBContent.BLOCK_FRAMED_SMALL_INNER_CORNER_SLOPE_PANEL.get()
                        .method_9564()
                        .method_11657(FramedProperties.FACING_HOR, dir)
                        .method_11657(FramedProperties.TOP, !top)
                        .method_11657(FramedProperties.Y_SLOPE, ySlope)
        );
    }

    @Override
    public DoubleBlockTopInteractionMode calculateTopInteractionMode(class_2680 state)
    {
        return DoubleBlockTopInteractionMode.EITHER;
    }

    @Override
    public CamoGetter calculateCamoGetter(class_2680 state, class_2350 side, @Nullable class_2350 edge)
    {
        class_2350 facing = state.method_11654(FramedProperties.FACING_HOR);
        class_2350 dirTwo = state.method_11654(FramedProperties.TOP) ? class_2350.field_11036 : class_2350.field_11033;
        if (side == dirTwo && (edge == facing.method_10153() || edge == facing.method_10170()))
        {
            return CamoGetter.FIRST;
        }
        return CamoGetter.NONE;
    }

    @Override
    public SolidityCheck calculateSolidityCheck(class_2680 state, class_2350 side)
    {
        return SolidityCheck.NONE;
    }

    @Override
    public class_1747 createBlockItem()
    {
        return new VerticalAndWallBlockItem(
                this,
                FBContent.BLOCK_FRAMED_INVERSE_DOUBLE_CORNER_SLOPE_PANEL_WALL.get(),
                new class_1792.class_1793()
        );
    }



    public static class_2680 itemModelSource()
    {
        return FBContent.BLOCK_FRAMED_INVERSE_DOUBLE_CORNER_SLOPE_PANEL.get().method_9564();
    }
}
