package xfacthd.framedblocks.common.block.slopepanelcorner;

import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.util.FramedUtils;

public class FramedSmallDoubleCornerSlopePanelBlock extends FramedDoubleCornerSlopePanelBlock
{
    public FramedSmallDoubleCornerSlopePanelBlock(BlockType blockType)
    {
        super(blockType);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        FramedUtils.removeProperty(builder, FramedProperties.SOLID);
    }
}
