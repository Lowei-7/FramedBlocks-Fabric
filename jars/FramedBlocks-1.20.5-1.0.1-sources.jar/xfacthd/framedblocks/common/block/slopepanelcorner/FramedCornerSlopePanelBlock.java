package xfacthd.framedblocks.common.block.slopepanelcorner;

import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_243;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_3965;
import net.minecraft.world.level.block.*;
import xfacthd.framedblocks.api.block.*;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.FramedBlock;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.item.VerticalAndWallBlockItem;

@SuppressWarnings("deprecation")
public class FramedCornerSlopePanelBlock extends FramedBlock
{
    private final boolean inner;
    private final boolean frontEdge;

    public FramedCornerSlopePanelBlock(BlockType type)
    {
        super(type);
        method_9590(method_9564()
                .method_11657(FramedProperties.TOP, false)
                .method_11657(FramedProperties.Y_SLOPE, false)
        );
        this.inner = type == BlockType.FRAMED_SMALL_INNER_CORNER_SLOPE_PANEL ||
                     type == BlockType.FRAMED_LARGE_INNER_CORNER_SLOPE_PANEL;
        this.frontEdge = type == BlockType.FRAMED_LARGE_CORNER_SLOPE_PANEL ||
                         type == BlockType.FRAMED_SMALL_INNER_CORNER_SLOPE_PANEL;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(
                FramedProperties.FACING_HOR, FramedProperties.TOP,
                FramedProperties.Y_SLOPE, class_2741.field_12508
        );
    }

    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return getStateForPlacement(this, ctx, inner, frontEdge);
    }

    public static class_2680 getStateForPlacement(
            class_2248 block, class_1750 ctx, boolean invert, boolean invertFracDir
    )
    {
        return PlacementStateBuilder.of(block, ctx)
                .withCustom((state, modCtx) ->
                {
                    class_2350 dir = modCtx.method_8042();
                    if (invert)
                    {
                        dir = dir.method_10153();
                    }
                    class_2350 fracDir = modCtx.method_8042();
                    if (invertFracDir)
                    {
                        fracDir = fracDir.method_10153();
                    }
                    if (Utils.fractionInDir(modCtx.method_17698(), fracDir.method_10170()) > .5)
                    {
                        dir = dir.method_10170();
                    }
                    return state.method_11657(FramedProperties.FACING_HOR, dir);
                })
                .withTop()
                .tryWithWater()
                .build();
    }

    @Override
    public boolean handleBlockLeftClick(class_2680 state, class_1937 level, class_2338 pos, class_1657 player)
    {
        return IFramedBlock.toggleYSlope(state, level, pos, player);
    }

    @Override
    public class_2680 rotate(class_2680 state, class_3965 hit, class_2470 rot)
    {
        class_2350 side = hit.method_17780();
        class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
        switch ((BlockType) getBlockType())
        {
            case FRAMED_SMALL_CORNER_SLOPE_PANEL, FRAMED_LARGE_CORNER_SLOPE_PANEL ->
            {
                if (side == dir.method_10153() || side == dir.method_10170())
                {
                    side = class_2350.field_11036;
                }
            }
            case FRAMED_SMALL_INNER_CORNER_SLOPE_PANEL, FRAMED_LARGE_INNER_CORNER_SLOPE_PANEL ->
            {
                if (side == dir || side == dir.method_10160())
                {
                    boolean top = state.method_11654(FramedProperties.TOP);
                    class_243 hitVec = hit.method_17784();
                    double y = Utils.fractionInDir(hitVec, top ? class_2350.field_11036 : class_2350.field_11033);
                    double xz = Utils.fractionInDir(hitVec, side == dir ? dir.method_10160() : dir) - .5;
                    if (xz * 2D > y)
                    {
                        side = class_2350.field_11036;
                    }
                }
            }
            default -> {}
        }
        return rotate(state, side, rot);
    }

    @Override
    public class_2680 rotate(class_2680 state, class_2350 face, class_2470 rot)
    {
        if (Utils.isY(face))
        {
            class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
            return state.method_11657(FramedProperties.FACING_HOR, rot.method_10503(dir));
        }
        return state.method_28493(FramedProperties.TOP);
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rotation)
    {
        return rotate(state, class_2350.field_11036, rotation);
    }

    @Override
    public class_2680 method_9569(class_2680 state, class_2415 mirror)
    {
        return Utils.mirrorCornerBlock(state, mirror);
    }

    @Override
    public class_1747 createBlockItem()
    {
        class_2248 other = switch ((BlockType) getBlockType())
        {
            case FRAMED_SMALL_CORNER_SLOPE_PANEL -> FBContent.BLOCK_FRAMED_SMALL_CORNER_SLOPE_PANEL_WALL.get();
            case FRAMED_LARGE_CORNER_SLOPE_PANEL -> FBContent.BLOCK_FRAMED_LARGE_CORNER_SLOPE_PANEL_WALL.get();
            case FRAMED_SMALL_INNER_CORNER_SLOPE_PANEL -> FBContent.BLOCK_FRAMED_SMALL_INNER_CORNER_SLOPE_PANEL_WALL.get();
            case FRAMED_LARGE_INNER_CORNER_SLOPE_PANEL -> FBContent.BLOCK_FRAMED_LARGE_INNER_CORNER_SLOPE_PANEL_WALL.get();
            default -> throw new IllegalStateException("Unexpected type: " + getBlockType());
        };
        return new VerticalAndWallBlockItem(this, other, new class_1792.class_1793());
    }
}
