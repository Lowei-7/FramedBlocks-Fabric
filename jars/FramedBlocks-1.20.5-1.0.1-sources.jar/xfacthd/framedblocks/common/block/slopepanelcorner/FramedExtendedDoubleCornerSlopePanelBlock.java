package xfacthd.framedblocks.common.block.slopepanelcorner;

import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3545;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.block.IFramedBlock;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.AbstractFramedDoubleBlock;
import xfacthd.framedblocks.common.blockentity.doubled.FramedExtendedDoubleCornerSlopePanelBlockEntity;
import xfacthd.framedblocks.common.blockentity.doubled.FramedExtendedInnerDoubleCornerSlopePanelBlockEntity;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.data.doubleblock.CamoGetter;
import xfacthd.framedblocks.common.data.doubleblock.SolidityCheck;
import xfacthd.framedblocks.common.item.VerticalAndWallBlockItem;
import xfacthd.framedblocks.common.util.DoubleBlockTopInteractionMode;

@SuppressWarnings("deprecation")
public class FramedExtendedDoubleCornerSlopePanelBlock extends AbstractFramedDoubleBlock
{
    public FramedExtendedDoubleCornerSlopePanelBlock(BlockType blockType)
    {
        super(blockType);
        method_9590(method_9564()
                .method_11657(FramedProperties.TOP, false)
                .method_11657(FramedProperties.Y_SLOPE, false)
        );
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(
                FramedProperties.FACING_HOR, FramedProperties.TOP, FramedProperties.Y_SLOPE
        );
    }

    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return FramedCornerSlopePanelBlock.getStateForPlacement(
                this, ctx, getBlockType() == BlockType.FRAMED_EXT_INNER_DOUBLE_CORNER_SLOPE_PANEL, true
        );
    }

    @Override
    public boolean handleBlockLeftClick(class_2680 state, class_1937 level, class_2338 pos, class_1657 player)
    {
        return IFramedBlock.toggleYSlope(state, level, pos, player);
    }

    @Override
    public class_2680 rotate(class_2680 state, class_2350 face, class_2470 rot)
    {
        if (Utils.isY(face))
        {
            class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
            return state.method_11657(FramedProperties.FACING_HOR, rot.method_10503(dir));
        }
        return state.method_28493(FramedProperties.TOP);
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rot)
    {
        return rotate(state, class_2350.field_11036, rot);
    }

    @Override
    public class_2680 method_9569(class_2680 state, class_2415 mirror)
    {
        return Utils.mirrorCornerBlock(state, mirror);
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state)
    {
        return switch ((BlockType) getBlockType())
        {
            case FRAMED_EXT_DOUBLE_CORNER_SLOPE_PANEL -> new FramedExtendedDoubleCornerSlopePanelBlockEntity(pos, state);
            case FRAMED_EXT_INNER_DOUBLE_CORNER_SLOPE_PANEL -> new FramedExtendedInnerDoubleCornerSlopePanelBlockEntity(pos, state);
            default -> throw new IllegalStateException("Unexpected type: " + getBlockType());
        };
    }

    @Override
    public class_3545<class_2680, class_2680> calculateBlockPair(class_2680 state)
    {
        class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
        boolean top = state.method_11654(FramedProperties.TOP);
        boolean ySlope = state.method_11654(FramedProperties.Y_SLOPE);

        return switch ((BlockType) getBlockType())
        {
            case FRAMED_EXT_DOUBLE_CORNER_SLOPE_PANEL -> new class_3545<>(
                    FBContent.BLOCK_FRAMED_EXTENDED_CORNER_SLOPE_PANEL.get()
                            .method_9564()
                            .method_11657(FramedProperties.FACING_HOR, dir)
                            .method_11657(FramedProperties.TOP, top)
                            .method_11657(FramedProperties.Y_SLOPE, ySlope),
                    FBContent.BLOCK_FRAMED_LARGE_INNER_CORNER_SLOPE_PANEL.get()
                            .method_9564()
                            .method_11657(FramedProperties.FACING_HOR, dir)
                            .method_11657(FramedProperties.TOP, !top)
                            .method_11657(FramedProperties.Y_SLOPE, ySlope)
            );
            case FRAMED_EXT_INNER_DOUBLE_CORNER_SLOPE_PANEL -> new class_3545<>(
                    FBContent.BLOCK_FRAMED_EXTENDED_INNER_CORNER_SLOPE_PANEL.get()
                            .method_9564()
                            .method_11657(FramedProperties.FACING_HOR, dir)
                            .method_11657(FramedProperties.TOP, top)
                            .method_11657(FramedProperties.Y_SLOPE, ySlope),
                    FBContent.BLOCK_FRAMED_SMALL_CORNER_SLOPE_PANEL.get()
                            .method_9564()
                            .method_11657(FramedProperties.FACING_HOR, dir)
                            .method_11657(FramedProperties.TOP, !top)
                            .method_11657(FramedProperties.Y_SLOPE, ySlope)
            );
            default -> throw new IllegalArgumentException("Unexpected type: " + getBlockType());
        };
    }

    @Override
    public DoubleBlockTopInteractionMode calculateTopInteractionMode(class_2680 state)
    {
        boolean top = state.method_11654(FramedProperties.TOP);
        return top ? DoubleBlockTopInteractionMode.FIRST : DoubleBlockTopInteractionMode.EITHER;
    }

    @Override
    public CamoGetter calculateCamoGetter(class_2680 state, class_2350 side, @Nullable class_2350 edge)
    {
        return switch ((BlockType) getBlockType())
        {
            case FRAMED_EXT_DOUBLE_CORNER_SLOPE_PANEL ->
            {
                class_2350 facing = state.method_11654(FramedProperties.FACING_HOR);
                boolean top = state.method_11654(FramedProperties.TOP);
                class_2350 dirTwo = top ? class_2350.field_11036 : class_2350.field_11033;
                if (side == dirTwo)
                {
                    yield CamoGetter.FIRST;
                }
                else if (side == facing.method_10153() || side == facing.method_10170())
                {
                    yield CamoGetter.SECOND;
                }
                else if (side == facing)
                {
                    if (edge == facing.method_10160() || edge == dirTwo)
                    {
                        yield CamoGetter.FIRST;
                    }
                    else if (edge == facing.method_10170())
                    {
                        yield CamoGetter.SECOND;
                    }
                }
                else if (side == facing.method_10160())
                {
                    if (edge == facing || edge == dirTwo)
                    {
                        yield CamoGetter.FIRST;
                    }
                    else if (edge == facing.method_10153())
                    {
                        yield CamoGetter.SECOND;
                    }
                }
                else if (side == dirTwo.method_10153() && (edge == facing.method_10170() || edge == facing.method_10153()))
                {
                    yield CamoGetter.SECOND;
                }
                yield CamoGetter.NONE;
            }
            case FRAMED_EXT_INNER_DOUBLE_CORNER_SLOPE_PANEL ->
            {
                class_2350 facing = state.method_11654(FramedProperties.FACING_HOR);
                boolean top = state.method_11654(FramedProperties.TOP);
                class_2350 dirTwo = top ? class_2350.field_11036 : class_2350.field_11033;
                if (side == facing.method_10153() || side == facing.method_10170() || side == dirTwo)
                {
                    yield CamoGetter.FIRST;
                }
                else if (side == dirTwo.method_10153() && (edge == facing.method_10153() || edge == facing.method_10170()))
                {
                    yield CamoGetter.FIRST;
                }
                else if (side == facing)
                {
                    if (edge == dirTwo || edge == facing.method_10170())
                    {
                        yield CamoGetter.FIRST;
                    }
                    else if (edge == facing.method_10160())
                    {
                        yield CamoGetter.SECOND;
                    }
                }
                else if (side == facing.method_10160())
                {
                    if (edge == dirTwo || edge == facing.method_10153())
                    {
                        yield CamoGetter.FIRST;
                    }
                    else if (edge == facing)
                    {
                        yield CamoGetter.SECOND;
                    }
                }
                yield CamoGetter.NONE;
            }
            default -> throw new IllegalArgumentException("Unexpected type: " + getBlockType());
        };
    }

    @Override
    public SolidityCheck calculateSolidityCheck(class_2680 state, class_2350 side)
    {
        return switch ((BlockType) getBlockType())
        {
            case FRAMED_EXT_DOUBLE_CORNER_SLOPE_PANEL ->
            {
                if (Utils.isY(side))
                {
                    boolean top = state.method_11654(FramedProperties.TOP);
                    if (top ? (side == class_2350.field_11036) : (side == class_2350.field_11033))
                    {
                        yield SolidityCheck.FIRST;
                    }
                }

                class_2350 facing = state.method_11654(FramedProperties.FACING_HOR);
                if (side == facing.method_10153() || side == facing.method_10170())
                {
                    yield SolidityCheck.SECOND;
                }
                yield SolidityCheck.BOTH;
            }
            case FRAMED_EXT_INNER_DOUBLE_CORNER_SLOPE_PANEL ->
            {
                boolean primaryYFace = false;
                if (Utils.isY(side))
                {
                    boolean top = state.method_11654(FramedProperties.TOP);
                    primaryYFace = top ? (side == class_2350.field_11036) : (side == class_2350.field_11033);
                }

                class_2350 facing = state.method_11654(FramedProperties.FACING_HOR);
                if (primaryYFace || side == facing.method_10153() || side == facing.method_10170())
                {
                    yield SolidityCheck.FIRST;
                }
                yield SolidityCheck.BOTH;
            }
            default -> throw new IllegalArgumentException("Unexpected type: " + getBlockType());
        };
    }

    @Override
    public class_1747 createBlockItem()
    {
        class_2248 other = switch ((BlockType) getBlockType())
        {
            case FRAMED_EXT_DOUBLE_CORNER_SLOPE_PANEL -> FBContent.BLOCK_FRAMED_EXTENDED_DOUBLE_CORNER_SLOPE_PANEL_WALL.get();
            case FRAMED_EXT_INNER_DOUBLE_CORNER_SLOPE_PANEL -> FBContent.BLOCK_FRAMED_EXTENDED_INNER_DOUBLE_CORNER_SLOPE_PANEL_WALL.get();
            default -> throw new IllegalStateException("Unexpected type: " + getBlockType());
        };
        return new VerticalAndWallBlockItem(this, other, new class_1792.class_1793());
    }



    public static class_2680 itemModelSource()
    {
        return FBContent.BLOCK_FRAMED_EXTENDED_DOUBLE_CORNER_SLOPE_PANEL.get().method_9564();
    }

    public static class_2680 itemModelSourceInner()
    {
        return FBContent.BLOCK_FRAMED_EXTENDED_INNER_DOUBLE_CORNER_SLOPE_PANEL.get()
                .method_9564()
                .method_11657(FramedProperties.FACING_HOR, class_2350.field_11034);
    }
}
