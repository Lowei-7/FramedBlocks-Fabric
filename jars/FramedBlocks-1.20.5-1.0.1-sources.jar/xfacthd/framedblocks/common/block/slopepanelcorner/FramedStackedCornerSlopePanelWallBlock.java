package xfacthd.framedblocks.common.block.slopepanelcorner;

import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_243;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2760;
import net.minecraft.class_3545;
import net.minecraft.class_3965;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.block.IFramedBlock;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.AbstractFramedDoubleBlock;
import xfacthd.framedblocks.common.blockentity.doubled.FramedStackedCornerSlopePanelWallBlockEntity;
import xfacthd.framedblocks.common.blockentity.doubled.FramedStackedInnerCornerSlopePanelWallBlockEntity;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.doubleblock.CamoGetter;
import xfacthd.framedblocks.common.data.doubleblock.SolidityCheck;
import xfacthd.framedblocks.common.data.property.HorizontalRotation;
import xfacthd.framedblocks.common.util.DoubleBlockTopInteractionMode;

@SuppressWarnings("deprecation")
public class FramedStackedCornerSlopePanelWallBlock extends AbstractFramedDoubleBlock
{
    public FramedStackedCornerSlopePanelWallBlock(BlockType blockType)
    {
        super(blockType);
        method_9590(method_9564().method_11657(FramedProperties.Y_SLOPE, true));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(
                FramedProperties.FACING_HOR, PropertyHolder.ROTATION,
                FramedProperties.Y_SLOPE, class_2741.field_12508
        );
    }

    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return FramedCornerSlopePanelWallBlock.getStateForPlacement(
                this, ctx, getBlockType() == BlockType.FRAMED_STACKED_CORNER_SLOPE_PANEL_W
        );
    }

    @Override
    public boolean handleBlockLeftClick(class_2680 state, class_1937 level, class_2338 pos, class_1657 player)
    {
        return IFramedBlock.toggleYSlope(state, level, pos, player);
    }

    @Override
    public class_2680 rotate(class_2680 state, class_3965 hit, class_2470 rot)
    {
        class_2350 side = hit.method_17780();

        class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
        HorizontalRotation rotation = state.method_11654(PropertyHolder.ROTATION);
        class_2350 rotDir = rotation.withFacing(dir);
        class_2350 perpRotDir = rotation.rotate(class_2470.field_11465).withFacing(dir);
        switch ((BlockType) getBlockType())
        {
            case FRAMED_STACKED_CORNER_SLOPE_PANEL_W ->
            {
                if (side == rotDir.method_10153() || side == perpRotDir.method_10153())
                {
                    side = dir;
                }
            }
            case FRAMED_STACKED_INNER_CORNER_SLOPE_PANEL_W ->
            {
                if (side == rotDir || side == perpRotDir)
                {
                    class_243 hitVec = hit.method_17784();
                    double paralell = Utils.fractionInDir(hitVec, dir);
                    double perp = Utils.fractionInDir(hitVec, side == rotDir ? perpRotDir : rotDir) - .5;
                    if (perp * 2D > paralell)
                    {
                        side = dir;
                    }
                }
            }
        }
        return rotate(state, side, rot);
    }

    @Override
    public class_2680 rotate(class_2680 state, class_2350 face, class_2470 rot)
    {
        class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
        if (face.method_10166() == dir.method_10166())
        {
            HorizontalRotation rotation = state.method_11654(PropertyHolder.ROTATION);
            return state.method_11657(PropertyHolder.ROTATION, rotation.rotate(rot));
        }
        else if (Utils.isY(face))
        {
            return state.method_11657(FramedProperties.FACING_HOR, rot.method_10503(dir));
        }
        return state;
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rot)
    {
        return rotate(state, state.method_11654(FramedProperties.FACING_HOR), rot);
    }

    @Override
    public class_2680 method_9569(class_2680 state, class_2415 mirror)
    {
        return FramedCornerSlopePanelWallBlock.mirrorCornerPanel(state, mirror);
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state)
    {
        return switch ((BlockType) getBlockType())
        {
            case FRAMED_STACKED_CORNER_SLOPE_PANEL_W -> new FramedStackedCornerSlopePanelWallBlockEntity(pos, state);
            case FRAMED_STACKED_INNER_CORNER_SLOPE_PANEL_W -> new FramedStackedInnerCornerSlopePanelWallBlockEntity(pos, state);
            default -> throw new IllegalStateException("Unexpected type: " + getBlockType());
        };
    }

    @Override
    public class_3545<class_2680, class_2680> calculateBlockPair(class_2680 state)
    {
        class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
        HorizontalRotation rot = state.method_11654(PropertyHolder.ROTATION);
        boolean ySlope = state.method_11654(FramedProperties.Y_SLOPE);

        class_2350 otherDir;
        boolean top;
        switch (rot)
        {
            case UP ->
            {
                otherDir = dir.method_10160();
                top = true;
            }
            case DOWN ->
            {
                otherDir = dir.method_10170();
                top = false;
            }
            case RIGHT ->
            {
                otherDir = dir.method_10170();
                top = true;
            }
            case LEFT ->
            {
                otherDir = dir.method_10160();
                top = false;
            }
            default -> throw new IncompatibleClassChangeError();
        }

        return switch ((BlockType) getBlockType())
        {
            case FRAMED_STACKED_CORNER_SLOPE_PANEL_W -> new class_3545<>(
                    FBContent.BLOCK_FRAMED_SLAB_EDGE.get()
                            .method_9564()
                            .method_11657(FramedProperties.FACING_HOR, otherDir)
                            .method_11657(FramedProperties.TOP, top),
                    FBContent.BLOCK_FRAMED_LARGE_CORNER_SLOPE_PANEL_WALL.get()
                            .method_9564()
                            .method_11657(FramedProperties.FACING_HOR, dir)
                            .method_11657(PropertyHolder.ROTATION, rot)
                            .method_11657(FramedProperties.Y_SLOPE, ySlope)
            );
            case FRAMED_STACKED_INNER_CORNER_SLOPE_PANEL_W -> new class_3545<>(
                    FBContent.BLOCK_FRAMED_STAIRS.get()
                            .method_9564()
                            .method_11657(class_2741.field_12481, otherDir.method_10153())
                            .method_11657(class_2741.field_12518, top ? class_2760.field_12617 : class_2760.field_12619),
                    FBContent.BLOCK_FRAMED_SMALL_INNER_CORNER_SLOPE_PANEL_WALL.get()
                            .method_9564()
                            .method_11657(FramedProperties.FACING_HOR, dir)
                            .method_11657(PropertyHolder.ROTATION, rot)
                            .method_11657(FramedProperties.Y_SLOPE, ySlope)
            );
            default -> throw new IllegalArgumentException("Invalid type for this block: " + getBlockType());
        };
    }

    @Override
    public DoubleBlockTopInteractionMode calculateTopInteractionMode(class_2680 state)
    {
        HorizontalRotation rot = state.method_11654(PropertyHolder.ROTATION);
        if (rot == HorizontalRotation.UP || rot == HorizontalRotation.RIGHT)
        {
            return DoubleBlockTopInteractionMode.EITHER;
        }
        return DoubleBlockTopInteractionMode.SECOND;
    }

    @Override
    public CamoGetter calculateCamoGetter(class_2680 state, class_2350 side, @Nullable class_2350 edge)
    {
        return switch ((BlockType) getBlockType())
        {
            case FRAMED_STACKED_CORNER_SLOPE_PANEL_W ->
            {
                class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
                HorizontalRotation rot = state.method_11654(PropertyHolder.ROTATION);
                class_2350 rotDir = rot.withFacing(dir);
                class_2350 perpRotDir = rot.rotate(class_2470.field_11465).withFacing(dir);
                if ((side == rotDir && edge == perpRotDir) || (side == perpRotDir && edge == rotDir))
                {
                    yield CamoGetter.FIRST;
                }
                else if (side == dir && (edge == rotDir.method_10153() || edge == perpRotDir.method_10153()))
                {
                    yield CamoGetter.SECOND;
                }
                yield CamoGetter.NONE;
            }
            case FRAMED_STACKED_INNER_CORNER_SLOPE_PANEL_W ->
            {
                class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
                HorizontalRotation rot = state.method_11654(PropertyHolder.ROTATION);
                class_2350 rotDir = rot.withFacing(dir);
                class_2350 perpRotDir = rot.rotate(class_2470.field_11465).withFacing(dir);
                if (side.method_10166() == dir.method_10166() && (edge == rotDir.method_10153() || edge == perpRotDir.method_10153()))
                {
                    yield CamoGetter.FIRST;
                }
                else if (side == rotDir.method_10153() || side == perpRotDir.method_10153())
                {
                    yield CamoGetter.FIRST;
                }
                else if (side == rotDir && edge == perpRotDir.method_10153())
                {
                    yield CamoGetter.FIRST;
                }
                else if (side == perpRotDir && edge == rotDir.method_10153())
                {
                    yield CamoGetter.FIRST;
                }
                yield CamoGetter.NONE;
            }
            default -> throw new IllegalStateException("Unexpected type: " + getBlockType());
        };
    }

    @Override
    public SolidityCheck calculateSolidityCheck(class_2680 state, class_2350 side)
    {
        return switch ((BlockType) getBlockType())
        {
            case FRAMED_STACKED_CORNER_SLOPE_PANEL_W ->
            {
                class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
                if (side == dir)
                {
                    yield SolidityCheck.BOTH;
                }
                yield SolidityCheck.NONE;
            }
            case FRAMED_STACKED_INNER_CORNER_SLOPE_PANEL_W ->
            {
                class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
                if (side == dir)
                {
                    yield SolidityCheck.BOTH;
                }

                HorizontalRotation rot = state.method_11654(PropertyHolder.ROTATION);
                class_2350 perpRotDir = rot.rotate(class_2470.field_11465).withFacing(dir);
                if (side == rot.withFacing(dir).method_10153() || side == perpRotDir.method_10153())
                {
                    yield SolidityCheck.FIRST;
                }
                yield SolidityCheck.NONE;
            }
            default -> throw new IllegalStateException("Unexpected type: " + getBlockType());
        };
    }
}
