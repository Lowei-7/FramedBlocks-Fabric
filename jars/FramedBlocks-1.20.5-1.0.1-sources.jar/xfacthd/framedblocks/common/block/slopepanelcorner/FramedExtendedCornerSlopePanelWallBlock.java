package xfacthd.framedblocks.common.block.slopepanelcorner;

import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_243;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_3965;
import net.minecraft.world.level.block.*;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.block.IFramedBlock;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.block.FramedBlock;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.property.HorizontalRotation;

@SuppressWarnings("deprecation")
public class FramedExtendedCornerSlopePanelWallBlock extends FramedBlock
{
    public FramedExtendedCornerSlopePanelWallBlock(BlockType blockType)
    {
        super(blockType);
        method_9590(method_9564().method_11657(FramedProperties.Y_SLOPE, true));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(
                FramedProperties.FACING_HOR, PropertyHolder.ROTATION, FramedProperties.Y_SLOPE,
                FramedProperties.SOLID, class_2741.field_12508
        );
    }

    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return FramedCornerSlopePanelWallBlock.getStateForPlacement(
                this, ctx, getBlockType() == BlockType.FRAMED_EXT_CORNER_SLOPE_PANEL
        );
    }

    @Override
    public boolean handleBlockLeftClick(class_2680 state, class_1937 level, class_2338 pos, class_1657 player)
    {
        return IFramedBlock.toggleYSlope(state, level, pos, player);
    }

    @Override
    public class_2680 rotate(class_2680 state, class_3965 hit, class_2470 rot)
    {
        class_2350 side = hit.method_17780();

        class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
        HorizontalRotation rotation = state.method_11654(PropertyHolder.ROTATION);
        class_2350 rotDir = rotation.withFacing(dir);
        class_2350 perpRotDir = rotation.rotate(class_2470.field_11465).withFacing(dir);
        switch ((BlockType) getBlockType())
        {
            case FRAMED_EXT_CORNER_SLOPE_PANEL_W ->
            {
                if (side == rotDir.method_10153() || side == perpRotDir.method_10153())
                {
                    side = dir;
                }
            }
            case FRAMED_EXT_INNER_CORNER_SLOPE_PANEL_W ->
            {
                if (side == rotDir || side == perpRotDir)
                {
                    class_243 hitVec = hit.method_17784();
                    double paralell = Utils.fractionInDir(hitVec, dir);
                    double perp = Utils.fractionInDir(hitVec, side == rotDir ? perpRotDir : rotDir) - .5;
                    if (perp * 2D > paralell)
                    {
                        side = dir;
                    }
                }
            }
        }
        return rotate(state, side, rot);
    }

    @Override
    public class_2680 rotate(class_2680 state, class_2350 face, class_2470 rot)
    {
        class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
        if (face.method_10166() == dir.method_10166())
        {
            HorizontalRotation rotation = state.method_11654(PropertyHolder.ROTATION);
            return state.method_11657(PropertyHolder.ROTATION, rotation.rotate(rot));
        }
        else if (Utils.isY(face))
        {
            return state.method_11657(FramedProperties.FACING_HOR, rot.method_10503(dir));
        }
        return state;
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rot)
    {
        return rotate(state, state.method_11654(FramedProperties.FACING_HOR), rot);
    }

    @Override
    public class_2680 method_9569(class_2680 state, class_2415 mirror)
    {
        return FramedCornerSlopePanelWallBlock.mirrorCornerPanel(state, mirror);
    }
}
