package xfacthd.framedblocks.common.block.sign;

import net.minecraft.class_10;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_174;
import net.minecraft.class_1769;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_3486;
import net.minecraft.class_3612;
import net.minecraft.class_3965;
import net.minecraft.class_5244;
import net.minecraft.class_5558;
import net.minecraft.class_6088;
import net.minecraft.class_8242;
import net.minecraft.class_8828;
import net.minecraft.class_9062;
import net.minecraft.world.item.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.entity.*;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import xfacthd.framedblocks.FramedBlocks;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.FramedBlock;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.blockentity.special.FramedSignBlockEntity;
import xfacthd.framedblocks.common.net.OpenSignScreenPacket;

import java.util.Arrays;
import java.util.UUID;

public abstract class AbstractFramedSignBlock extends FramedBlock
{
    private static final class_243 HITBOX_CENTER = new class_243(.5, .5, .5);

    protected AbstractFramedSignBlock(BlockType type, class_2251 props)
    {
        super(type, props);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(class_2741.field_12508);
    }

    @Override
    protected class_9062 method_55765(
            class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit
    )
    {
        //Makes sure the block can have a camo applied, even when the sign can execute a command
        class_1269 result = handleUse(state, level, pos, player, hand, hit);
        if (result != class_1269.field_5811 || preventUse(state, level, pos, player, hand, hit))
        {
            return convertUseResult(result, level);
        }

        SignInteraction interaction = SignInteraction.from(stack);
        boolean canInteract = interaction != null && player.method_31549().field_7476;

        if (level.method_8321(pos) instanceof FramedSignBlockEntity sign)
        {
            if (level.method_8608())
            {
                return canInteract || sign.isWaxed() ? class_9062.field_47728 : class_9062.field_47729;
            }

            boolean front = sign.isFacingFrontText(player);
            if (sign.isWaxed() && interaction != SignInteraction.REMOVE_WAX)
            {
                if (sign.canExecuteCommands(front, player) && sign.tryExecuteCommands(player, level, pos, front))
                {
                    return class_9062.field_47728;
                }
                return class_9062.field_47731;
            }
            else if (canInteract && notBlockedByOtherPlayer(player, sign) && interaction.interact(level, pos, player, stack, front, sign))
            {
                if (!player.method_7337())
                {
                    stack.method_7934(1);
                    player.method_31548().method_5431();
                }
                player.method_7259(class_3468.field_15372.method_14956(stack.method_7909()));

                return class_9062.field_47728;
            }
            else if (notBlockedByOtherPlayer(player, sign) && canEdit(player, sign, front))
            {
                openEditScreen(player, sign, front);
                return class_9062.field_47728;
            }
        }

        return class_9062.field_47731;
    }

    protected boolean preventUse(
            class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit
    )
    {
        return false;
    }

    @Override
    public class_2680 method_9559(class_2680 state, class_2350 dir, class_2680 facingState, class_1936 level, class_2338 pos, class_2338 facingPos)
    {
        if (state.method_11654(class_2741.field_12508))
        {
            level.method_39281(pos, class_3612.field_15910, class_3612.field_15910.method_15789(level));
        }
        return super.method_9559(state, dir, facingState, level, pos, facingPos);
    }

    @Override
    public boolean method_9516(class_2680 state, class_10 type)
    {
        return type != class_10.field_48 || state.method_26227().method_15767(class_3486.field_15517);
    }

    @Override
    public boolean method_9538(class_2680 state)
    {
        return true;
    }

    public abstract float getYRotationDegrees(class_2680 state);

    public class_243 getSignHitboxCenterPosition(class_2680 state)
    {
        return HITBOX_CENTER;
    }

    public int getTextLineHeight()
    {
        return 10;
    }

    public int getMaxTextLineWidth()
    {
        return 90;
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state)
    {
        return FramedSignBlockEntity.normalSign(pos, state);
    }

    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 level, class_2680 state, class_2591<T> type)
    {
        return Utils.createBlockEntityTicker(type, FBContent.BE_TYPE_FRAMED_SIGN.get(), FramedSignBlockEntity::tick);
    }



    private static boolean notBlockedByOtherPlayer(class_1657 player, FramedSignBlockEntity sign)
    {
        UUID uuid = sign.getEditingPlayer();
        return uuid == null || uuid.equals(player.method_5667());
    }

    private static boolean canEdit(class_1657 player, FramedSignBlockEntity sign, boolean frontText)
    {
        class_8242 text = sign.getText(frontText);
        return Arrays.stream(text.method_49877(player.method_33793())).allMatch(line ->
                line.equals(class_5244.field_39003) || line.method_10851() instanceof class_8828.class_2585
        );
    }

    public static void openEditScreen(class_1657 player, FramedSignBlockEntity sign, boolean frontText)
    {
        sign.setEditingPlayer(player.method_5667());
        ServerPlayNetworking.send(
                (class_3222) player,
                new OpenSignScreenPacket(sign.method_11016(), frontText)
        );
    }



    private enum SignInteraction
    {
        APPLY_DYE((level, pos, player, stack, front, sign) ->
        {
            level.method_8396(null, pos, class_3417.field_28391, class_3419.field_15245, 1.0F, 1.0F);
            return sign.updateText(text -> text.method_49862(((class_1769) stack.method_7909()).method_7802()), front);
        }),
        APPLY_INK((level, pos, player, stack, front, sign) ->
        {
            level.method_8396(null, pos, class_3417.field_28397, class_3419.field_15245, 1.0F, 1.0F);
            return sign.updateText(text -> text.method_49867(false), front);
        }),
        APPLY_GLOW_INK((level, pos, player, stack, front, sign) ->
        {
            level.method_8396(null, pos, class_3417.field_28392, class_3419.field_15245, 1.0F, 1.0F);
            if (player instanceof class_3222)
            {
                class_174.field_24478.method_23889((class_3222)player, pos, stack);
            }
            return sign.updateText(text -> text.method_49867(true), front);
        }),
        APPLY_WAX((level, pos, player, stack, front, sign) ->
        {
            if (sign.setWaxed(true))
            {
                level.method_20290(class_6088.field_31156, sign.method_11016(), 0);
                return true;
            }
            return false;
        }),
        REMOVE_WAX((level, pos, player, stack, front, sign) ->
        {
            if (sign.setWaxed(false))
            {
                level.method_20290(class_6088.field_31157, sign.method_11016(), 0);
                return true;
            }
            return false;
        });

        private final Action action;

        SignInteraction(Action action)
        {
            this.action = action;
        }

        public boolean interact(
                class_1937 level, class_2338 pos, class_1657 player, class_1799 stack, boolean front, FramedSignBlockEntity sign
        )
        {
            return action.apply(level, pos, player, stack, front, sign);
        }



        public static SignInteraction from(class_1799 stack)
        {
            if (stack.method_7909() instanceof class_1769)
            {
                return APPLY_DYE;
            }
            else if (stack.method_31574(class_1802.field_8794))
            {
                return APPLY_INK;
            }
            else if (stack.method_31574(class_1802.field_28410))
            {
                return APPLY_GLOW_INK;
            }
            else if (stack.method_31574(class_1802.field_20414))
            {
                return APPLY_WAX;
            }
            else if (stack.method_31573(net.minecraft.class_3489.field_42612)) // TODO: proper tool check
            {
                return REMOVE_WAX;
            }
            return null;
        }
    }

    private interface Action
    {
        boolean apply(class_1937 level, class_2338 pos, class_1657 player, class_1799 stack, boolean front, FramedSignBlockEntity sign);
    }
}