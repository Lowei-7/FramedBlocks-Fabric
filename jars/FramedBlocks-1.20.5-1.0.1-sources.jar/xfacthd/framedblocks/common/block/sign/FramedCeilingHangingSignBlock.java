package xfacthd.framedblocks.common.block.sign;

import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5431;
import net.minecraft.class_5558;
import net.minecraft.class_7718;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.*;
import xfacthd.framedblocks.api.block.*;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.blockentity.special.FramedSignBlockEntity;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.item.FramedHangingSignItem;

import java.util.Optional;

@SuppressWarnings("deprecation")
public class FramedCeilingHangingSignBlock extends AbstractFramedHangingSignBlock
{
    public FramedCeilingHangingSignBlock()
    {
        super(BlockType.FRAMED_HANGING_SIGN, IFramedBlock.createProperties(BlockType.FRAMED_HANGING_SIGN)
                .method_9634()
        );
        method_9590(method_9564().method_11657(class_2741.field_12493, false));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(class_2741.field_12532, class_2741.field_12493);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return PlacementStateBuilder.of(this, ctx)
                .withCustom((state, modCtx) ->
                {
                    class_1937 level = modCtx.method_8045();
                    class_2338 adjPos = modCtx.method_8037().method_10084();
                    class_2680 adjState = level.method_8320(adjPos);
                    class_2350 dir = class_2350.method_10150(modCtx.method_8044());
                    boolean attached = !class_2248.method_9501(adjState.method_26220(level, adjPos), class_2350.field_11033) || modCtx.method_8046();
                    if (adjState.method_26204() instanceof AbstractFramedHangingSignBlock && !modCtx.method_8046())
                    {
                        if (adjState.method_28498(FramedProperties.FACING_HOR))
                        {
                            class_2350 adjDir = adjState.method_11654(FramedProperties.FACING_HOR);
                            if (adjDir.method_10166().method_10176(dir))
                            {
                                attached = false;
                            }
                        }
                        else if (adjState.method_28498(class_2741.field_12532))
                        {
                            int adjRot = adjState.method_11654(class_2741.field_12532);
                            Optional<class_2350> optDir = class_7718.method_45480(adjRot);
                            if (optDir.isPresent() && optDir.get().method_10166().method_10176(dir))
                            {
                                attached = false;
                            }
                        }
                    }

                    int rotation;
                    if (attached)
                    {
                        rotation = class_7718.method_45479(modCtx.method_8044() + 180.0F);
                    }
                    else
                    {
                        rotation = class_7718.method_45481(dir.method_10153());
                    }
                    return state.method_11657(class_2741.field_12532, rotation)
                            .method_11657(class_2741.field_12493, attached);
                })
                .withWater()
                .build();
    }

    @Override
    protected boolean preventUse(
            class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit
    )
    {
        if (level.method_8321(pos) instanceof FramedSignBlockEntity sign)
        {
            boolean front = sign.isFacingFrontText(player);
            class_1799 stack = player.method_5998(hand);
            return !sign.canExecuteCommands(front, player) && stack.method_7909() == method_8389() && hit.method_17780() == class_2350.field_11033;
        }
        return false;
    }

    @Override
    public class_2680 method_9559(
            class_2680 state,
            class_2350 dir,
            class_2680 facingState,
            class_1936 level,
            class_2338 pos,
            class_2338 facingPos
    )
    {
        if (dir == class_2350.field_11036 && !method_9558(state, level, pos))
        {
            return class_2246.field_10124.method_9564();
        }
        return super.method_9559(state, dir, facingState, level, pos, facingPos);
    }

    @Override
    public boolean method_9558(class_2680 state, class_4538 level, class_2338 pos)
    {
        class_2338 above = pos.method_10084();
        return level.method_8320(above).method_30368(level, above, class_2350.field_11033, class_5431.field_25823);
    }

    @Override
    public class_265 method_25959(class_2680 state, class_1922 level, class_2338 pos)
    {
        return method_9530(state, level, pos, class_3726.method_16194());
    }

    @Override
    public float getYRotationDegrees(class_2680 state)
    {
        return class_7718.method_45482(state.method_11654(class_2741.field_12532));
    }

    @Override
    public class_2680 rotate(class_2680 state, class_2350 face, class_2470 rot)
    {
        int rotation = state.method_11654(class_2741.field_12532);
        if (rot == class_2470.field_11465)
        {
            rotation += 15;
        }
        else
        {
            rotation += 1;
        }
        return state.method_11657(class_2741.field_12532, rotation % 16);
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rot)
    {
        int rotation = state.method_11654(class_2741.field_12532);
        return state.method_11657(class_2741.field_12532, rot.method_10502(rotation, 16));
    }

    @Override
    public class_2680 method_9569(class_2680 state, class_2415 mirror)
    {
        int rotation = state.method_11654(class_2741.field_12532);
        return state.method_11657(class_2741.field_12532, mirror.method_10344(rotation, 16));
    }

    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 level, class_2680 state, class_2591<T> type)
    {
        return Utils.createBlockEntityTicker(type, FBContent.BE_TYPE_FRAMED_HANGING_SIGN.get(), FramedSignBlockEntity::tick);
    }

    @Override
    public class_1747 createBlockItem()
    {
        return new FramedHangingSignItem();
    }
}
