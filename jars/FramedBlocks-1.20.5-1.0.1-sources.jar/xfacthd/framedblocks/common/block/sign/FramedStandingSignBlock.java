package xfacthd.framedblocks.common.block.sign;

import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import net.minecraft.class_7718;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.phys.shapes.*;
import xfacthd.framedblocks.api.block.IFramedBlock;
import xfacthd.framedblocks.api.block.PlacementStateBuilder;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.item.FramedSignItem;

@SuppressWarnings("deprecation")
public class FramedStandingSignBlock extends AbstractFramedSignBlock
{
    private static final class_265 SHAPE = class_2248.method_9541(4.0D, 0.0D, 4.0D, 12.0D, 16.0D, 12.0D);

    public FramedStandingSignBlock()
    {
        super(BlockType.FRAMED_SIGN, IFramedBlock.createProperties(BlockType.FRAMED_SIGN).method_9634());
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(class_2741.field_12532);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return PlacementStateBuilder.of(this, ctx)
                .withCustom((state, modCtx) ->
                {
                    int rotation = class_7718.method_45479(modCtx.method_8044() + 180.0F);
                    return state.method_11657(class_2741.field_12532, rotation);
                })
                .withWater()
                .build();
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 ctx)
    {
        return SHAPE;
    }

    @Override
    public class_265 method_9571(class_2680 state, class_1922 level, class_2338 pos)
    {
        return class_259.method_1073();
    }

    @Override
    public class_2680 method_9559(
            class_2680 state,
            class_2350 dir,
            class_2680 facingState,
            class_1936 level,
            class_2338 pos,
            class_2338 facingPos
    )
    {
        if (dir == class_2350.field_11033 && !method_9558(state, level, pos))
        {
            return class_2246.field_10124.method_9564();
        }
        return super.method_9559(state, dir, facingState, level, pos, facingPos);
    }

    @Override
    public boolean method_9558(class_2680 state, class_4538 level, class_2338 pos)
    {
        return level.method_8320(pos.method_10074()).method_51367();
    }

    @Override
    public boolean doesBlockOccludeBeaconBeam(class_2680 state, class_4538 level, class_2338 pos)
    {
        return false;
    }

    @Override
    public class_2680 rotate(class_2680 state, class_2350 face, class_2470 rot)
    {
        int rotation = state.method_11654(class_2741.field_12532);
        if (rot == class_2470.field_11465)
        {
            rotation += 15;
        }
        else
        {
            rotation += 1;
        }
        return state.method_11657(class_2741.field_12532, rotation % 16);
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rot)
    {
        int rotation = state.method_11654(class_2741.field_12532);
        return state.method_11657(class_2741.field_12532, rot.method_10502(rotation, 16));
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_2680 method_9569(class_2680 state, class_2415 mirror)
    {
        int rot = state.method_11654(class_2741.field_12532);
        return state.method_11657(class_2741.field_12532, mirror.method_10344(rot, 16));
    }

    @Override
    public float getYRotationDegrees(class_2680 state)
    {
        return class_7718.method_45482(state.method_11654(class_2741.field_12532));
    }

    @Override
    public class_1747 createBlockItem()
    {
        return new FramedSignItem();
    }
}