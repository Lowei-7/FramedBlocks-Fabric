package xfacthd.framedblocks.common.block.sign;

import net.minecraft.class_156;
import net.minecraft.class_1750;
import net.minecraft.class_1936;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_4538;
import net.minecraft.world.level.block.*;
import xfacthd.framedblocks.api.block.*;
import xfacthd.framedblocks.common.data.BlockType;

@SuppressWarnings("deprecation")
public class FramedWallSignBlock extends AbstractFramedSignBlock
{
    private static final class_243[] HITBOX_CENTERS = class_156.method_654(new class_243[4], arr ->
    {
        arr[class_2350.field_11043.method_10161()] = new class_243(.5, .5, 15D/16D);
        arr[class_2350.field_11034.method_10161()] = new class_243(1D/16D, .5, .5);
        arr[class_2350.field_11035.method_10161()] = new class_243(.5, .5, 1D/16D);
        arr[class_2350.field_11039.method_10161()] = new class_243(15D/16D, .5, .5);
    });

    public FramedWallSignBlock()
    {
        super(BlockType.FRAMED_WALL_SIGN, IFramedBlock.createProperties(BlockType.FRAMED_WALL_SIGN).method_9634());
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(FramedProperties.FACING_HOR);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return PlacementStateBuilder.of(this, ctx)
                .withCustom((state, modCtx) ->
                {
                    class_4538 level = modCtx.method_8045();
                    class_2338 pos = modCtx.method_8037();
                    class_2350[] dirs = modCtx.method_7718();

                    for (class_2350 direction : dirs)
                    {
                        if (direction.method_10166().method_10179())
                        {
                            class_2350 dir = direction.method_10153();
                            state = state.method_11657(FramedProperties.FACING_HOR, dir);
                            if (state.method_26184(level, pos))
                            {
                                return state;
                            }
                        }
                    }

                    return null;
                })
                .withWater()
                .build();
    }

    @Override
    public class_2680 method_9559(
            class_2680 state,
            class_2350 dir,
            class_2680 facingState,
            class_1936 level,
            class_2338 pos,
            class_2338 facingPos
    )
    {
        if (dir.method_10153() == state.method_11654(FramedProperties.FACING_HOR) && !state.method_26184(level, pos))
        {
            return class_2246.field_10124.method_9564();
        }
        return super.method_9559(state, dir, facingState, level, pos, facingPos);
    }

    @Override
    public boolean method_9558(class_2680 state, class_4538 level, class_2338 pos)
    {
        class_2350 dir = state.method_11654(FramedProperties.FACING_HOR).method_10153();
        return level.method_8320(pos.method_10093(dir)).method_51367();
    }

    @Override
    public class_2680 rotate(class_2680 state, class_2350 face, class_2470 rot)
    {
        //Not rotatable by wrench
        return state;
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rot)
    {
        class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
        return state.method_11657(FramedProperties.FACING_HOR, rot.method_10503(dir));
    }

    @Override
    public float getYRotationDegrees(class_2680 state)
    {
        return state.method_11654(FramedProperties.FACING_HOR).method_10144();
    }

    @Override
    public class_243 getSignHitboxCenterPosition(class_2680 state)
    {
        return HITBOX_CENTERS[state.method_11654(FramedProperties.FACING_HOR).method_10161()];
    }
}