package xfacthd.framedblocks.common.block.sign;

import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5431;
import net.minecraft.class_7715;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.phys.shapes.*;
import xfacthd.framedblocks.api.block.*;
import xfacthd.framedblocks.common.blockentity.special.FramedSignBlockEntity;
import xfacthd.framedblocks.common.data.BlockType;

@SuppressWarnings("deprecation")
public class FramedWallHangingSignBlock extends AbstractFramedHangingSignBlock
{
    public FramedWallHangingSignBlock()
    {
        super(BlockType.FRAMED_WALL_HANGING_SIGN, IFramedBlock.createProperties(BlockType.FRAMED_WALL_HANGING_SIGN)
                .method_9634()
        );
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(FramedProperties.FACING_HOR);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return PlacementStateBuilder.of(this, ctx)
                .withCustom((state, modCtx) ->
                {
                    class_1937 level = modCtx.method_8045();
                    class_2338 pos = modCtx.method_8037();
                    class_2350 face = modCtx.method_8038();

                    for (class_2350 dir : modCtx.method_7718())
                    {
                        if (dir.method_10166().method_10179() && !dir.method_10166().method_10176(face))
                        {
                            state = state.method_11657(FramedProperties.FACING_HOR, dir.method_10153());
                            if (state.method_26184(level, pos) && canPlace(state, level, pos))
                            {
                                return state;
                            }
                        }
                    }

                    return null;
                })
                .withWater()
                .build();
    }

    @Override
    protected boolean preventUse(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit)
    {
        if (level.method_8321(pos) instanceof FramedSignBlockEntity sign)
        {
            boolean front = sign.isFacingFrontText(player);
            class_1799 stack = player.method_5998(hand);
            if (!sign.canExecuteCommands(front, player) && stack.method_7909() == method_8389())
            {
                return hit.method_17780().method_10166() == state.method_11654(FramedProperties.FACING_HOR).method_10166();
            }
        }
        return false;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 ctx)
    {
        return switch (state.method_11654(FramedProperties.FACING_HOR))
        {
            case field_11043, field_11035 -> class_7715.field_40322;
            case field_11034, field_11039 -> class_7715.field_40323;
            default -> throw new IncompatibleClassChangeError();
        };
    }

    @Override
    public class_265 method_9571(class_2680 state, class_1922 level, class_2338 pos)
    {
        return class_259.method_1073();
    }

    @Override
    public class_265 method_25959(class_2680 state, class_1922 level, class_2338 pos)
    {
        return method_9530(state, level, pos, class_3726.method_16194());
    }

    @Override
    public class_265 method_9549(class_2680 state, class_1922 level, class_2338 pos, class_3726 ctx)
    {
        return switch (state.method_11654(FramedProperties.FACING_HOR))
        {
            case field_11043, field_11035 -> class_7715.field_40320;
            case field_11034, field_11039 -> class_7715.field_40321;
            default -> throw new IncompatibleClassChangeError();
        };
    }

    @Override
    public float getYRotationDegrees(class_2680 state)
    {
        return state.method_11654(FramedProperties.FACING_HOR).method_10144();
    }

    @Override
    public class_2680 rotate(class_2680 state, class_2350 face, class_2470 rot)
    {
        //Not rotatable by wrench
        return state;
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rot)
    {
        return state.method_11657(FramedProperties.FACING_HOR, rot.method_10503(state.method_11654(FramedProperties.FACING_HOR)));
    }

    @Override
    public class_2680 method_9569(class_2680 state, class_2415 mirror)
    {
        return state.method_26186(mirror.method_10345(state.method_11654(FramedProperties.FACING_HOR)));
    }

    @Override
    public boolean doesBlockOccludeBeaconBeam(class_2680 state, class_4538 level, class_2338 pos)
    {
        return false;
    }



    public static boolean canPlace(class_2680 state, class_4538 level, class_2338 pos)
    {
        class_2350 dir = state.method_11654(FramedProperties.FACING_HOR);
        class_2350 dirCw = dir.method_10170();
        class_2350 dirCcw = dir.method_10160();
        return canAttachTo(level, state, pos.method_10093(dirCw), dirCcw) || canAttachTo(level, state, pos.method_10093(dirCcw), dirCw);
    }

    private static boolean canAttachTo(class_4538 level, class_2680 state, class_2338 pos, class_2350 side)
    {
        class_2680 adjState = level.method_8320(pos);
        if (adjState.method_26204() instanceof FramedWallHangingSignBlock)
        {
            return adjState.method_11654(FramedProperties.FACING_HOR).method_10166().method_10176(state.method_11654(FramedProperties.FACING_HOR));
        }
        return adjState.method_30368(level, pos, side, class_5431.field_25822);
    }
}
