package xfacthd.framedblocks.common.block.sign;

import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import xfacthd.framedblocks.common.blockentity.special.FramedSignBlockEntity;
import xfacthd.framedblocks.common.data.BlockType;

public abstract class AbstractFramedHangingSignBlock extends AbstractFramedSignBlock
{
    protected AbstractFramedHangingSignBlock(BlockType type, class_2251 props)
    {
        super(type, props);
    }

    @Override
    public int getTextLineHeight()
    {
        return 9;
    }

    @Override
    public int getMaxTextLineWidth()
    {
        return 60;
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state)
    {
        return FramedSignBlockEntity.hangingSign(pos, state);
    }
}
