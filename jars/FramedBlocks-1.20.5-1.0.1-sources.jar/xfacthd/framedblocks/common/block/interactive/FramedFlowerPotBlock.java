package xfacthd.framedblocks.common.block.interactive;

import net.minecraft.class_10;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3468;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5712;
import net.minecraft.class_9062;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import xfacthd.framedblocks.common.block.FramedBlock;
import xfacthd.framedblocks.common.blockentity.special.FramedFlowerPotBlockEntity;
import xfacthd.framedblocks.common.util.compat.SupplementariesCompat;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.data.PropertyHolder;

import java.util.Map;
import java.util.function.Supplier;

public class FramedFlowerPotBlock extends FramedBlock
{
    public FramedFlowerPotBlock()
    {
        super(BlockType.FRAMED_FLOWER_POT);
        method_9590(method_9564().method_11657(PropertyHolder.HANGING, false));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(PropertyHolder.HANGING);
    }

    @Override
    public class_2680 method_9605(class_1750 context)
    {
        class_2680 state = super.method_9605(context);
        if (state != null && SupplementariesCompat.isLoaded())
        {
            state = state.method_11657(
                    PropertyHolder.HANGING,
                    context.method_8038() == class_2350.field_11033
            );
        }
        return state;
    }

    @Override
    public class_2680 method_9559(
            class_2680 state,
            class_2350 side,
            class_2680 sideState,
            class_1936 level,
            class_2338 pos,
            class_2338 sidePos
    )
    {
        if (state.method_11654(PropertyHolder.HANGING) && side == class_2350.field_11036 && !state.method_26184(level, pos))
        {
            return class_2246.field_10124.method_9564();
        }
        return super.method_9559(state, side, sideState, level, pos, sidePos);
    }

    @Override
    @SuppressWarnings("deprecation")
    public boolean method_9558(class_2680 state, class_4538 level, class_2338 pos)
    {
        if (state.method_11654(PropertyHolder.HANGING))
        {
            return SupplementariesCompat.canSurviveHanging(level, pos.method_10093(class_2350.field_11036));
        }
        return true;
    }

    @Override
    protected class_9062 method_55765(
            class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit
    )
    {
        if (level.method_8321(pos) instanceof FramedFlowerPotBlockEntity be)
        {
            boolean isFlower = stack.method_7909() instanceof class_1747 item && !getFlowerPotState(item.method_7711()).method_26215();

            if (isFlower != be.hasFlowerBlock())
            {
                if (!level.method_8608())
                {
                    if (isFlower && !be.hasFlowerBlock())
                    {
                        be.setFlowerBlock(((class_1747) stack.method_7909()).method_7711());

                        player.method_7281(class_3468.field_15412);
                        if (!player.method_31549().field_7477)
                        {
                            stack.method_7934(1);
                        }
                    }
                    else
                    {
                        class_1799 flowerStack = new class_1799(be.getFlowerBlock());
                        if (stack.method_7960())
                        {
                            player.method_6122(hand, flowerStack);
                        }
                        else if (!player.method_7270(flowerStack))
                        {
                            player.method_7328(flowerStack, false);
                        }

                        be.setFlowerBlock(class_2246.field_10124);
                    }
                }

                level.method_33596(player, class_5712.field_28733, pos);
                return convertUseResult(class_1269.method_29236(level.method_8608()), level);
            }
            else
            {
                return convertUseResult(class_1269.field_21466, level);
            }
        }

        return class_9062.field_47731;
    }

    @Override
    public boolean method_9516(class_2680 state, class_10 type)
    {
        return false;
    }

    @Override
    public boolean doesBlockOccludeBeaconBeam(class_2680 state, class_4538 level, class_2338 pos)
    {
        //It technically does occlude the beam, but it looks stupid, so we disable it :D
        return false;
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state)
    {
        return new FramedFlowerPotBlockEntity(pos, state);
    }



    public static class_2680 getFlowerPotState(class_2248 flower)
    {
        // In Fabric/vanilla, the full pot mapping is not publicly accessible
        // The hanging flower pot feature depends on Supplementaries compatibility
        // For now, always indicate no specific pot state is available
        return class_2246.field_10124.method_9564();
    }
}