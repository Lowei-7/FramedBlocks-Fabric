package xfacthd.framedblocks.common.block.interactive;

import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3737;
import net.minecraft.class_8177;
import xfacthd.framedblocks.common.data.BlockType;

public class FramedWaterloggablePressurePlateBlock extends FramedPressurePlateBlock implements class_3737
{
    FramedWaterloggablePressurePlateBlock(BlockType type, boolean playerOnly, class_2251 props, class_8177 blockSet)
    {
        super(type, playerOnly, props, blockSet);
        method_9590(method_9564().method_11657(class_2741.field_12508, false));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(class_2741.field_12508);
    }

    @Override
    public class_2680 method_9605(class_1750 context)
    {
        class_3610 fluidState = context.method_8045().method_8316(context.method_8037());
        return method_9564().method_11657(class_2741.field_12508, fluidState.method_15772() == class_3612.field_15910);
    }

    @Override
    public class_2680 method_9559(
            class_2680 state,
            class_2350 facing,
            class_2680 facingState,
            class_1936 level,
            class_2338 pos,
            class_2338 facingPos
    )
    {
        class_2680 newState = super.method_9559(state, facing, facingState, level, pos, facingPos);
        if (!newState.method_26215() && state.method_11654(class_2741.field_12508))
        {
            level.method_39281(pos, class_3612.field_15910, class_3612.field_15910.method_15789(level));
        }
        return newState;
    }

    @Override
    @SuppressWarnings("deprecation")
    public class_3610 method_9545(class_2680 state)
    {
        if (state.method_11654(class_2741.field_12508))
        {
            return class_3612.field_15910.method_15729(false);
        }
        return class_3612.field_15906.method_15785();
    }

    public class_1799 getCloneItemStack(class_2680 state, class_239 target, class_1922 level, class_2338 pos, class_1657 player)
    {
        return new class_1799(getCounterpart());
    }
}
