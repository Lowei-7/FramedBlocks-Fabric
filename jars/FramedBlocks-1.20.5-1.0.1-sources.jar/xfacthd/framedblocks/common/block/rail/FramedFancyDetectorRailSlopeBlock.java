package xfacthd.framedblocks.common.block.rail;

import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2768;
import net.minecraft.class_3545;
import net.minecraftforge.client.extensions.common.IClientBlockExtensions;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.block.FramedBlockEntity;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.predicate.cull.SideSkipPredicate;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.*;
import xfacthd.framedblocks.api.model.data.FramedDoubleBlockData;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.data.doubleblock.*;
import xfacthd.framedblocks.common.data.property.SlopeType;
import xfacthd.framedblocks.common.util.DoubleBlockTopInteractionMode;
import xfacthd.framedblocks.common.util.FramedUtils;

import java.util.Objects;
import java.util.function.BiFunction;
import java.util.function.Consumer;

class FramedFancyDetectorRailSlopeBlock extends FramedDetectorRailSlopeBlock implements IFramedDoubleBlock, ISlopeBlock.IRailSlopeBlock
{
    FramedFancyDetectorRailSlopeBlock(BlockType type, BiFunction<class_2338, class_2680, FramedBlockEntity> beFactory)
    {
        super(type, beFactory);
    }

    @Override
    @Nullable
    public class_2680 runOcclusionTestAndGetLookupState(
            SideSkipPredicate pred, class_1922 level, class_2338 pos, class_2680 state, class_2680 adjState, class_2350 side
    )
    {
        class_3545<class_2680, class_2680> statePair = getBlockPair(adjState);
        return super.runOcclusionTestAndGetLookupState(pred, level, pos, state, statePair.method_15442(), side);
    }

    @Override
    @Nullable
    public class_2680 getComponentBySkipPredicate(
            class_1922 level, class_2338 pos, class_2680 state, class_2680 neighborState, class_2350 side
    )
    {
        class_2680 slopeState = getBlockPair(state).method_15442();
        if (IFramedDoubleBlock.testComponent(level, pos, slopeState, neighborState, side))
        {
            return slopeState;
        }
        return null;
    }

    @Override
    public Object unpackNestedModelData(Object data, class_2680 state, class_2680 componentState)
    {
        if (data instanceof FramedDoubleBlockData doubleData)
        {
            return doubleData.getLeft();
        }
        return data;
    }

    @Override
    public DoubleBlockTopInteractionMode calculateTopInteractionMode(class_2680 state)
    {
        return DoubleBlockTopInteractionMode.FIRST;
    }

    @Override
    public class_3545<class_2680, class_2680> calculateBlockPair(class_2680 state)
    {
        class_2768 shape = state.method_11654(PropertyHolder.ASCENDING_RAIL_SHAPE);
        boolean ySlope = state.method_11654(FramedProperties.Y_SLOPE);

        class_2350 facing = FramedUtils.getDirectionFromAscendingRailShape(shape);

        return new class_3545<>(
                FBContent.BLOCK_FRAMED_SLOPE.get().method_9564()
                        .method_11657(PropertyHolder.SLOPE_TYPE, SlopeType.BOTTOM)
                        .method_11657(FramedProperties.FACING_HOR, facing)
                        .method_11657(FramedProperties.Y_SLOPE, ySlope),
                FBContent.BLOCK_FRAMED_FANCY_DETECTOR_RAIL.get().method_9564()
                        .method_11657(class_2741.field_12542, shape)
        );
    }

    @Override
    public CamoGetter calculateCamoGetter(class_2680 state, class_2350 side, @Nullable class_2350 edge)
    {
        class_2350 facing = getFacing(state);
        if (side == facing || side == class_2350.field_11033)
        {
            return CamoGetter.FIRST;
        }
        else if (side.method_10166() != facing.method_10166() && !Utils.isY(side))
        {
            if (edge == facing || edge == class_2350.field_11033)
            {
                return CamoGetter.FIRST;
            }
        }
        return CamoGetter.NONE;
    }

    @Override
    public SolidityCheck calculateSolidityCheck(class_2680 state, class_2350 side)
    {
        if (side == class_2350.field_11033 || side == getFacing(state))
        {
            return SolidityCheck.FIRST;
        }
        return SolidityCheck.NONE;
    }

    public void initializeClient(Consumer<IClientBlockExtensions> consumer)
    {
        consumer.accept(FramedDoubleBlockRenderProperties.INSTANCE);
    }
}
