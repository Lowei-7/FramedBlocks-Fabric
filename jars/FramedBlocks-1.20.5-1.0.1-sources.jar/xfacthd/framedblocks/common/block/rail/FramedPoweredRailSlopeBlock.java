package xfacthd.framedblocks.common.block.rail;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1688;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2442;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2768;
import net.minecraft.class_2769;
import net.minecraft.class_3726;
import net.minecraft.class_3727;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_8567;
import net.minecraft.class_9062;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.properties.*;
import net.minecraft.world.phys.shapes.*;
import net.minecraftforge.client.extensions.common.IClientBlockExtensions;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.block.*;
import xfacthd.framedblocks.api.block.render.FramedBlockRenderProperties;
import xfacthd.framedblocks.api.shapes.ShapeProvider;
import xfacthd.framedblocks.api.type.IBlockType;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.ISlopeBlock;
import xfacthd.framedblocks.common.blockentity.doubled.FramedFancyRailSlopeBlockEntity;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.data.PropertyHolder;
import xfacthd.framedblocks.common.util.FramedUtils;

import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Consumer;

@SuppressWarnings("deprecation")
public class FramedPoweredRailSlopeBlock extends class_2442 implements IFramedBlock, ISlopeBlock.IRailSlopeBlock
{
    private final BlockType type;
    private final ShapeProvider shapes;
    private final ShapeProvider occlusionShapes;
    private final BiFunction<class_2338, class_2680, FramedBlockEntity> beFactory;
    private final boolean isPoweredRail;

    protected FramedPoweredRailSlopeBlock(BlockType type, boolean isPoweredRail, BiFunction<class_2338, class_2680, FramedBlockEntity> beFactory)
    {
        super(IFramedBlock.createProperties(type));
        this.type = type;
        this.isPoweredRail = isPoweredRail;
        this.shapes = type.generateShapes(method_9595().method_11662());
        this.occlusionShapes = type.generateOcclusionShapes(method_9595().method_11662(), shapes);
        this.beFactory = beFactory;
        method_9590(method_9564()
                .method_11657(class_2741.field_12508, false)
                .method_11657(FramedProperties.SOLID, false)
                .method_11657(FramedProperties.GLOWING, false)
                .method_11657(field_11364, false)
                .method_11657(FramedProperties.Y_SLOPE, false)
                .method_11657(FramedProperties.PROPAGATES_SKYLIGHT, false)
        );
    }

    protected void registerDefaultState() { }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        builder.method_11667(
                PropertyHolder.ASCENDING_RAIL_SHAPE, class_2741.field_12484, class_2741.field_12508,
                FramedProperties.SOLID, FramedProperties.GLOWING, FramedProperties.Y_SLOPE,
                FramedProperties.PROPAGATES_SKYLIGHT
        );
    }

    @Override
    public class_2680 method_9605(class_1750 ctx)
    {
        return PlacementStateBuilder.of(this, ctx)
                .withCustom((state, modCtx) -> state.method_11657(
                        PropertyHolder.ASCENDING_RAIL_SHAPE,
                        FramedUtils.getAscendingRailShapeFromDirection(modCtx.method_8042())
                ))
                .withWater()
                .build();
    }

    @Override
    public class_2680 method_9559(
            class_2680 state,
            class_2350 direction,
            class_2680 neighborState,
            class_1936 level,
            class_2338 currentPos,
            class_2338 neighborPos
    )
    {
        class_2680 newState = super.method_9559(state, direction, neighborState, level, currentPos, neighborPos);
        if (newState == state)
        {
            updateCulling(level, currentPos);
        }
        return newState;
    }

    @Override
    public boolean method_9558(class_2680 state, class_4538 level, class_2338 pos)
    {
        return true;
    }

    @Override //Copy of AbstractRailBlock#neighborChanged() to disable removal
    public void method_9612(
            class_2680 state, class_1937 level, class_2338 pos, class_2248 block, class_2338 pFromPos, boolean isMoving
    )
    {
        updateCulling(level, pos);
        if (!level.method_8608() && level.method_8320(pos).method_27852(this))
        {
            method_9477(state, level, pos, block);
        }
    }

    @Override
    protected void method_9477(class_2680 state, class_1937 level, class_2338 pos, class_2248 block)
    {
        boolean wasPowered = state.method_11654(field_11364);
        boolean isPowered = level.method_49803(pos) ||
                method_10413(level, pos, state, true, 0) ||
                method_10413(level, pos, state, false, 0);
        if (isPowered != wasPowered)
        {
            level.method_8652(pos, state.method_11657(field_11364, isPowered), field_31036);
            level.method_8452(pos.method_10074(), this);
            level.method_8452(pos.method_10084(), this);
        }
    }

    @Override
    public class_2769<class_2768> method_9474()
    {
        return PropertyHolder.ASCENDING_RAIL_SHAPE;
    }

    public boolean isValidRailShape(class_2768 shape)
    {
        return shape.method_11897();
    }

    @Override
    protected class_9062 method_55765(
            class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit
    )
    {
        class_1269 result = handleUse(state, level, pos, player, hand, hit);
        return result.method_23665() ? convertUseResult(result, level) : class_9062.field_47731;
    }

    @Override
    public void method_9567(class_1937 level, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 stack)
    {
        tryApplyCamoImmediately(level, pos, placer, stack);
    }

    @Override
    public boolean method_9526(class_2680 state)
    {
        return useCamoOcclusionShapeForLightOcclusion(state);
    }

    @Override
    public class_265 method_9571(class_2680 state, class_1922 level, class_2338 pos)
    {
        return getCamoOcclusionShape(state, level, pos, occlusionShapes);
    }

    @Override
    public class_265 method_26159(class_2680 state, class_1922 level, class_2338 pos, class_3726 ctx)
    {
        return getCamoVisualShape(state, level, pos, ctx);
    }

    @Override
    public float method_9575(class_2680 state, class_1922 level, class_2338 pos)
    {
        return getCamoShadeBrightness(state, level, pos, super.method_9575(state, level, pos));
    }

    @Override
    public boolean method_9579(class_2680 state, class_1922 level, class_2338 pos)
    {
        return state.method_11654(FramedProperties.PROPAGATES_SKYLIGHT);
    }

    @Override
    public List<class_1799> method_9560(class_2680 state, class_8567.class_8568 builder)
    {
        return getCamoDrops(super.method_9560(state, builder), builder);
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 ctx)
    {
        return shapes.get(state);
    }

    @Override //The default implementation defers to the AbstractBlock#getShape() overload without ISelectionContext argument
    public class_265 method_9549(class_2680 state, class_1922 worldIn, class_2338 pos, class_3726 context)
    {
        if (context instanceof class_3727 ctx && ctx.method_32480() instanceof class_1688)
        {
            return class_259.method_1073();
        }
        return method_9530(state, worldIn, pos, context);
    }

    @Override
    public boolean handleBlockLeftClick(class_2680 state, class_1937 level, class_2338 pos, class_1657 player)
    {
        return IFramedBlock.toggleYSlope(state, level, pos, player);
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rot)
    {
        class_2350 dir = FramedUtils.getDirectionFromAscendingRailShape(state.method_11654(PropertyHolder.ASCENDING_RAIL_SHAPE));
        dir = rot.method_10503(dir);
        return state.method_11657(PropertyHolder.ASCENDING_RAIL_SHAPE, FramedUtils.getAscendingRailShapeFromDirection(dir));
    }

    @Override
    public class_2680 method_9569(class_2680 state, class_2415 mirror)
    {
        if (mirror == class_2415.field_11302) { return state; }

        class_2350 dir = FramedUtils.getDirectionFromAscendingRailShape(state.method_11654(PropertyHolder.ASCENDING_RAIL_SHAPE));

        if ((mirror == class_2415.field_11301 && Utils.isZ(dir)) || (mirror == class_2415.field_11300 && Utils.isX(dir)))
        {
            dir = dir.method_10153();
            return state.method_11657(PropertyHolder.ASCENDING_RAIL_SHAPE, FramedUtils.getAscendingRailShapeFromDirection(dir));
        }
        return state;
    }

    @Override
    public boolean doesBlockOccludeBeaconBeam(class_2680 state, class_4538 level, class_2338 pos)
    {
        return true;
    }

    @Override
    public final class_2586 method_10123(class_2338 pos, class_2680 state)
    {
        return beFactory.apply(pos, state);
    }

    @Override
    public IBlockType getBlockType()
    {
        return type;
    }

    public void initializeClient(Consumer<IClientBlockExtensions> consumer)
    {
        consumer.accept(FramedBlockRenderProperties.INSTANCE);
    }



    public static FramedPoweredRailSlopeBlock powered()
    {
        return new FramedPoweredRailSlopeBlock(
                BlockType.FRAMED_POWERED_RAIL_SLOPE,
                true,
                FramedBlockEntity::new
        );
    }

    public static FramedPoweredRailSlopeBlock poweredFancy()
    {
        return new FramedFancyPoweredRailSlopeBlock(
                BlockType.FRAMED_FANCY_POWERED_RAIL_SLOPE,
                true,
                FramedFancyRailSlopeBlockEntity::new
        );
    }

    public static FramedPoweredRailSlopeBlock activator()
    {
        return new FramedPoweredRailSlopeBlock(
                BlockType.FRAMED_ACTIVATOR_RAIL_SLOPE,
                false,
                FramedBlockEntity::new
        );
    }

    public static FramedPoweredRailSlopeBlock activatorFancy()
    {
        return new FramedFancyPoweredRailSlopeBlock(
                BlockType.FRAMED_FANCY_ACTIVATOR_RAIL_SLOPE,
                false,
                FramedFancyRailSlopeBlockEntity::new
        );
    }



    public static class_2680 itemModelSourceFancyPowered()
    {
        return FBContent.BLOCK_FRAMED_FANCY_POWERED_RAIL_SLOPE.get()
                .method_9564()
                .method_11657(PropertyHolder.ASCENDING_RAIL_SHAPE, class_2768.field_12668);
    }

    public static class_2680 itemModelSourceFancyActivator()
    {
        return FBContent.BLOCK_FRAMED_FANCY_ACTIVATOR_RAIL_SLOPE.get()
                .method_9564()
                .method_11657(PropertyHolder.ASCENDING_RAIL_SHAPE, class_2768.field_12668);
    }
}
