package xfacthd.framedblocks.common.block.rail;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2443;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_8567;
import net.minecraft.class_9062;
import net.minecraft.world.level.*;
import net.minecraftforge.client.extensions.common.IClientBlockExtensions;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.api.block.IFramedBlock;
import xfacthd.framedblocks.api.block.render.FramedBlockRenderProperties;
import xfacthd.framedblocks.api.type.IBlockType;
import xfacthd.framedblocks.common.data.BlockType;

import javax.annotation.Nullable;
import java.util.List;
import java.util.function.Consumer;

@SuppressWarnings("deprecation")
public class FramedFancyRailBlock extends class_2443 implements IFramedBlock
{
    public FramedFancyRailBlock()
    {
        super(IFramedBlock.createProperties(BlockType.FRAMED_FANCY_RAIL)
                .method_9634()
        );
        method_9590(method_9564()
                .method_11657(FramedProperties.GLOWING, false)
                .method_11657(FramedProperties.PROPAGATES_SKYLIGHT, false)
        );
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(FramedProperties.GLOWING, FramedProperties.PROPAGATES_SKYLIGHT);
    }

    @Override
    public class_2680 method_9559(
            class_2680 state,
            class_2350 direction,
            class_2680 neighborState,
            class_1936 level,
            class_2338 currentPos,
            class_2338 neighborPos
    )
    {
        class_2680 newState = super.method_9559(state, direction, neighborState, level, currentPos, neighborPos);
        if (newState == state)
        {
            updateCulling(level, currentPos);
        }
        return newState;
    }

    @Override
    public void method_9612(
            class_2680 state, class_1937 level, class_2338 pos, class_2248 block, class_2338 fromPos, boolean isMoving
    )
    {
        super.method_9612(state, level, pos, block, fromPos, isMoving);
        updateCulling(level, pos);
    }

    @Override
    protected class_9062 method_55765(
            class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit
    )
    {
        class_1269 result = handleUse(state, level, pos, player, hand, hit);
        return result.method_23665() ? convertUseResult(result, level) : class_9062.field_47731;
    }

    @Override
    public void method_9567(class_1937 level, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 stack)
    {
        tryApplyCamoImmediately(level, pos, placer, stack);
    }

    @Override
    public boolean method_9526(class_2680 state)
    {
        return useCamoOcclusionShapeForLightOcclusion(state);
    }

    @Override
    public class_265 method_9571(class_2680 state, class_1922 level, class_2338 pos)
    {
        return getCamoOcclusionShape(state, level, pos);
    }

    @Override
    public class_265 method_26159(class_2680 state, class_1922 level, class_2338 pos, class_3726 ctx)
    {
        return getCamoVisualShape(state, level, pos, ctx);
    }

    @Override
    public float method_9575(class_2680 state, class_1922 level, class_2338 pos)
    {
        return getCamoShadeBrightness(state, level, pos, super.method_9575(state, level, pos));
    }

    @Override
    public boolean method_9579(class_2680 state, class_1922 level, class_2338 pos)
    {
        return state.method_11654(FramedProperties.PROPAGATES_SKYLIGHT);
    }

    @Override
    public List<class_1799> method_9560(class_2680 state, class_8567.class_8568 builder)
    {
        return getCamoDrops(super.method_9560(state, builder), builder);
    }

    @Override
    public IBlockType getBlockType()
    {
        return BlockType.FRAMED_FANCY_RAIL;
    }

    public void initializeClient(Consumer<IClientBlockExtensions> consumer)
    {
        consumer.accept(FramedBlockRenderProperties.INSTANCE);
    }
}
