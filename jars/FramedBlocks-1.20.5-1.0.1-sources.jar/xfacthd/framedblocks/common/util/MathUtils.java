package xfacthd.framedblocks.common.util;

import com.google.common.math.IntMath;
import net.minecraft.class_243;

public final class MathUtils
{
    public static class_243 wrapVector(class_243 vec, double min, double max)
    {
        return new class_243(
                wrap(vec.method_10216(), min, max),
                wrap(vec.method_10214(), min, max),
                wrap(vec.method_10215(), min, max)
        );
    }

    public static double wrap(double val, double min, double max)
    {
        double dist = max - min;
        if (val > max)
        {
            return val - dist;
        }
        else if (val < min)
        {
            return val + dist;
        }
        else
        {
            return val;
        }
    }

    public static long lcm(int a, int b)
    {
        return (long) a * (long) (b / IntMath.gcd(a, b));
    }



    private MathUtils() { }
}