package xfacthd.framedblocks.common.util;

import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.world.item.*;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.data.BlockType;
import xfacthd.framedblocks.common.data.FramedToolType;

public final class FramedCreativeTab
{
    public static class_1761 makeTab()
    {
        return net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup.builder()
                .method_47321(class_2561.method_43471("itemGroup.framed_blocks"))
                .method_47320(() -> new class_1799(FBContent.BLOCK_FRAMED_CUBE.get()))
                .method_47317((params, output) ->
                {
                    for (BlockType type : BlockType.values())
                    {
                        // Simple workaround for these two needing dedicated items for blueprint purposes
                        if (type == BlockType.FRAMED_DOUBLE_SLAB || type == BlockType.FRAMED_DOUBLE_PANEL)
                        {
                            continue;
                        }

                        if (type.hasBlockItem())
                        {
                            output.method_45421(FBContent.byType(type));
                        }
                    }

                    output.method_45421(FBContent.BLOCK_FRAMING_SAW.get());
                    output.method_45421(FBContent.BLOCK_POWERED_FRAMING_SAW.get());

                    for (FramedToolType tool : FramedToolType.values())
                    {
                        output.method_45421(FBContent.toolByType(tool));
                    }

                    output.method_45421(FBContent.ITEM_FRAMED_REINFORCEMENT.get());
                })
                .method_47324();
    }

    private FramedCreativeTab() { }
}
