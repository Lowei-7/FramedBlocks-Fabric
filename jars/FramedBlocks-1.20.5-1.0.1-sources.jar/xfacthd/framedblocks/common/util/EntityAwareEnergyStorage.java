package xfacthd.framedblocks.common.util;

import net.minecraft.class_2586;
import net.minecraftforge.energy.EnergyStorage;

public class EntityAwareEnergyStorage extends EnergyStorage
{
    private final class_2586 be;

    public EntityAwareEnergyStorage(int capacity, int maxReceive, int maxExtract, class_2586 be)
    {
        super(capacity, maxReceive, maxExtract);
        this.be = be;
    }

    @Override
    public int receiveEnergy(int maxReceive, boolean simulate)
    {
        int received = super.receiveEnergy(maxReceive, simulate);
        onContentsChanged(received, simulate);
        return received;
    }

    @Override
    public int extractEnergy(int maxExtract, boolean simulate)
    {
        int extracted = super.extractEnergy(maxExtract, simulate);
        onContentsChanged(extracted, simulate);
        return extracted;
    }

    public void extractEnergyInternal(int maxExtract)
    {
        energy -= maxExtract;
        onContentsChanged(maxExtract, false);
    }

    private void onContentsChanged(int diff, boolean simulate)
    {
        if (!simulate && diff > 0)
        {
            be.method_5431();
        }
    }
}
