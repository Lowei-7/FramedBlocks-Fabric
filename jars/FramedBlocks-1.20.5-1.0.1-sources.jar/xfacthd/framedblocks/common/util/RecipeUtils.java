package xfacthd.framedblocks.common.util;

import xfacthd.framedblocks.api.util.Utils;

import java.lang.invoke.MethodHandle;
import net.minecraft.class_1792;
import net.minecraft.class_1856;
import net.minecraft.class_6862;

public final class RecipeUtils
{
    private static final MethodHandle INGREDIENT_GET_VALUES = Utils.unreflectField(class_1856.class, "field_9019", "values");
    private static final MethodHandle INGREDIENT_TAGVALUE_GET_TAG;
    
    static
    {
        Class<?> tagValueClass = null;
        for (Class<?> clazz : class_1856.class.getDeclaredClasses())
        {
            if (clazz.getSimpleName().equals("TagValue"))
            {
                tagValueClass = clazz;
                break;
            }
        }
        if (tagValueClass == null)
        {
            throw new RuntimeException("Failed to find Ingredient$TagValue class");
        }
        INGREDIENT_TAGVALUE_GET_TAG = Utils.unreflectField(tagValueClass, "field_9022", "tag");
    }

    public static Object getSingleIngredientValue(class_1856 ing)
    {
        Object[] values;
        try
        {
            values = (Object[]) INGREDIENT_GET_VALUES.invoke(ing);
        }
        catch (Throwable e)
        {
            throw new RuntimeException(e);
        }
        return values.length == 1 ? values[0] : null;
    }

    @SuppressWarnings("unchecked")
    public static class_6862<class_1792> getItemTagFromValue(Object value)
    {
        try
        {
            return (class_6862<class_1792>) INGREDIENT_TAGVALUE_GET_TAG.invoke(value);
        }
        catch (Throwable e)
        {
            throw new RuntimeException(e);
        }
    }



    private RecipeUtils() { }
}
