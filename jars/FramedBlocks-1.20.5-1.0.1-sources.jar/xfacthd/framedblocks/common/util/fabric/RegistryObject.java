package xfacthd.framedblocks.common.util.fabric;

import java.util.function.Supplier;
import net.minecraft.class_2960;

public class RegistryObject<T> implements Supplier<T> {
    private final class_2960 id;
    private final Supplier<? extends T> sup;
    private T instance;

    public RegistryObject(class_2960 id, Supplier<? extends T> sup) {
        this.id = id;
        this.sup = sup;
    }

    public class_2960 getId() {
        return id;
    }

    @Override
    public T get() {
        if (instance == null) {
            instance = sup.get();
        }
        return instance;
    }
}
