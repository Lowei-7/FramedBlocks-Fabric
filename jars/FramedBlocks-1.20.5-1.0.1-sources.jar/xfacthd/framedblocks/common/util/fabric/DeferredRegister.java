package xfacthd.framedblocks.common.util.fabric;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_2378;
import net.minecraft.class_2960;

public class DeferredRegister<T> {
    private final class_2378<T> registry;
    private final String modid;
    private final List<RegistryObject<T>> entries = new ArrayList<>();

    public static <T> DeferredRegister<T> create(class_2378<T> registry, String modid) {
        return new DeferredRegister<>(registry, modid);
    }

    private DeferredRegister(class_2378<T> registry, String modid) {
        this.registry = registry;
        this.modid = modid;
    }

    public <I extends T> RegistryObject<I> register(String name, Supplier<? extends I> sup) {
        class_2960 id = new class_2960(modid, name);
        RegistryObject<I> ro = new RegistryObject<>(id, sup);
        entries.add((RegistryObject<T>) ro);
        return ro;
    }

    public Collection<RegistryObject<T>> getEntries() {
        return entries;
    }

    public void register() {
        for (RegistryObject<T> entry : entries) {
            class_2378.method_10230(registry, entry.getId(), entry.get());
        }
    }
}
