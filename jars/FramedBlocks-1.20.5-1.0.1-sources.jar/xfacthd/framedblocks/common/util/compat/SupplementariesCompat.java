package xfacthd.framedblocks.common.util.compat;

import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_4538;

public final class SupplementariesCompat
{
    public static final class_2960 HANGING_MODEL_LOCATION = new class_2960("supplementaries", "block/hanging_flower_pot_rope");
    private static boolean loaded = false;

    public static void init()
    {
        loaded = false;
    }

    public static boolean isLoaded()
    {
        return loaded;
    }

    public static boolean canSurviveHanging(class_4538 level, class_2338 pos)
    {
        return false;
    }

    private SupplementariesCompat() { }
}
