package xfacthd.framedblocks.common.util.compat;

import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import org.jetbrains.annotations.Nullable;

public final class StarlightCompat
{
    @Nullable
    public static class_2586 getBlockEntityForLight(class_1922 level, class_2338 pos)
    {
        return level.method_8321(pos);
    }

    private StarlightCompat() { }
}
