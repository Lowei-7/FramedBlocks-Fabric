package xfacthd.framedblocks.common.util.compat;

import net.minecraft.class_1922;

public final class FlywheelCompat
{
    public static boolean isVirtualLevel(class_1922 level)
    {
        return false;
    }

    private FlywheelCompat() { }
}
