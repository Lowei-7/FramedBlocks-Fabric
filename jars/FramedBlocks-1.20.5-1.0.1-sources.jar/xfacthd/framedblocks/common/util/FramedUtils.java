package xfacthd.framedblocks.common.util;

import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2768;
import net.minecraft.class_2769;
import net.minecraft.class_3218;
import net.minecraft.class_3738;
import net.minecraft.server.MinecraftServer;
import net.minecraftforge.common.util.Lazy;
import net.minecraftforge.items.IItemHandlerModifiable;
import net.minecraftforge.items.ItemStackHandler;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.mixin.AccessorStateDefinitionBuilder;

import java.util.*;
import java.util.function.Consumer;

public final class FramedUtils
{
    private static final Lazy<Set<class_1792>> RAIL_ITEMS = Lazy.concurrentOf(() ->
    {
        Set<class_1792> items = Collections.newSetFromMap(new IdentityHashMap<>());
        items.addAll(Set.of(
                class_1802.field_8129,
                class_1802.field_8848,
                class_1802.field_8211,
                class_1802.field_8655,
                FBContent.BLOCK_FRAMED_FANCY_RAIL.get().method_8389(),
                FBContent.BLOCK_FRAMED_FANCY_POWERED_RAIL.get().method_8389(),
                FBContent.BLOCK_FRAMED_FANCY_DETECTOR_RAIL.get().method_8389(),
                FBContent.BLOCK_FRAMED_FANCY_ACTIVATOR_RAIL.get().method_8389()
        ));
        return items;
    });
    private static final Lazy<Map<class_1792, class_2248>> RAIL_SLOPE_BLOCKS = Lazy.concurrentOf(() -> new IdentityHashMap<>(Map.of(
            class_1802.field_8129, FBContent.BLOCK_FRAMED_RAIL_SLOPE.get(),
            class_1802.field_8848, FBContent.BLOCK_FRAMED_POWERED_RAIL_SLOPE.get(),
            class_1802.field_8211, FBContent.BLOCK_FRAMED_DETECTOR_RAIL_SLOPE.get(),
            class_1802.field_8655, FBContent.BLOCK_FRAMED_ACTIVATOR_RAIL_SLOPE.get(),
            FBContent.BLOCK_FRAMED_FANCY_RAIL.get().method_8389(), FBContent.BLOCK_FRAMED_FANCY_RAIL_SLOPE.get(),
            FBContent.BLOCK_FRAMED_FANCY_POWERED_RAIL.get().method_8389(), FBContent.BLOCK_FRAMED_FANCY_POWERED_RAIL_SLOPE.get(),
            FBContent.BLOCK_FRAMED_FANCY_DETECTOR_RAIL.get().method_8389(), FBContent.BLOCK_FRAMED_FANCY_DETECTOR_RAIL_SLOPE.get(),
            FBContent.BLOCK_FRAMED_FANCY_ACTIVATOR_RAIL.get().method_8389(), FBContent.BLOCK_FRAMED_FANCY_ACTIVATOR_RAIL_SLOPE.get()
    )));

    public static boolean isRailItem(class_1792 item)
    {
        return RAIL_ITEMS.get().contains(item);
    }

    public static class_2248 getRailSlopeBlock(class_1792 item)
    {
        class_2248 railSlope = RAIL_SLOPE_BLOCKS.get().get(item);
        if (railSlope == null)
        {
            throw new IllegalStateException("Invalid rail item: " + item);
        }
        return railSlope;
    }

    public static class_2768 getAscendingRailShapeFromDirection(class_2350 dir)
    {
        return switch (dir)
        {
            case field_11043 -> class_2768.field_12670;
            case field_11034 -> class_2768.field_12667;
            case field_11035 -> class_2768.field_12668;
            case field_11039 -> class_2768.field_12666;
            default -> throw new IllegalArgumentException("Invalid facing " + dir);
        };
    }

    public static class_2350 getDirectionFromAscendingRailShape(class_2768 shape)
    {
        return switch (shape)
        {
            case field_12670 -> class_2350.field_11043;
            case field_12667 -> class_2350.field_11034;
            case field_12668 -> class_2350.field_11035;
            case field_12666 -> class_2350.field_11039;
            default -> throw new IllegalArgumentException("Invalid shape " + shape);
        };
    }

    public static void enqueueImmediateTask(class_1936 level, Runnable task, boolean allowClient)
    {
        if (level.method_8608() && allowClient)
        {
            task.run();
        }
        else
        {
            enqueueTask(level, task, 0);
        }
    }

    public static void enqueueTask(class_1936 level, Runnable task, int delay)
    {
        if (!(level instanceof class_3218 slevel))
        {
            throw new IllegalArgumentException("Utils#enqueueTask() called with a non-ServerWorld");
        }

        MinecraftServer server = slevel.method_8503();
        server.method_18858(new class_3738(server.method_3780() + delay, task));
    }

    public static void addPlayerInvSlots(Consumer<class_1735> slotConsumer, class_1661 playerInv, int x, int y)
    {
        for (int row = 0; row < 3; ++row)
        {
            for (int col = 0; col < 9; ++col)
            {
                slotConsumer.accept(new class_1735(playerInv, col + row * 9 + 9, x + col * 18, y));
            }
            y += 18;
        }

        for (int col = 0; col < 9; ++col)
        {
            slotConsumer.accept(new class_1735(playerInv, col, x + col * 18, y + 4));
        }
    }

    @SuppressWarnings("unchecked")
    public static void removeProperty(class_2689.class_2690<class_2248, class_2680> builder, class_2769<?> property)
    {
        AccessorStateDefinitionBuilder accessor = (AccessorStateDefinitionBuilder) builder;
        accessor.framedblocks$getProperties().remove(property.method_11899());
    }

    public static IItemHandlerModifiable makeMenuItemHandler(IItemHandlerModifiable handler, class_1937 level)
    {
        if (level.method_8608())
        {
            handler = new ItemStackHandler(handler.getSlots());
        }
        return handler;
    }



    private FramedUtils() { }
}