package xfacthd.framedblocks.common.util;

import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3481;
import net.minecraft.world.item.*;
import xfacthd.framedblocks.api.FramedBlocksAPI;
import xfacthd.framedblocks.api.block.FramedBlockEntity;
import xfacthd.framedblocks.api.blueprint.BlueprintCopyBehaviour;
import xfacthd.framedblocks.api.camo.CamoContainer;
import xfacthd.framedblocks.api.util.CamoMessageVerbosity;
import xfacthd.framedblocks.client.util.ClientConfig;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.util.compat.FlywheelCompat;
import xfacthd.framedblocks.common.util.compat.NoCubesCompat;
import xfacthd.framedblocks.common.data.camo.CamoFactories;
import xfacthd.framedblocks.common.item.FramedBlueprintItem;

@SuppressWarnings("unused")
public final class ApiImpl implements FramedBlocksAPI
{
    @Override
    public class_2591<FramedBlockEntity> defaultBlockEntity()
    {
        return FBContent.BE_TYPE_FRAMED_BLOCK.get();
    }

    @Override
    public class_2680 defaultModelState()
    {
        return FBContent.BLOCK_FRAMED_CUBE.get().method_9564();
    }

    @Override
    public class_1761 defaultCreativeTab()
    {
        return FBContent.MAIN_TAB.get();
    }

    @Override
    public boolean areBlocksFireproof()
    {
        return CommonConfig.fireproofBlocks;
    }

    @Override
    public boolean detailedCullingEnabled()
    {
        return ClientConfig.INSTANCE.detailedCulling();
    }

    @Override
    public boolean allowBlockEntities()
    {
        return ServerConfig.allowBlockEntities;
    }

    @Override
    public boolean enableIntangibility()
    {
        return ServerConfig.enableIntangibleFeature;
    }

    @Override
    public class_1792 getIntangibilityMarkerItem()
    {
        return ServerConfig.intangibleMarkerItem;
    }

    @Override
    public Object getCamoContainerFactoryRegistry()
    {
        return FBContent.CAMO_CONTAINER_FACTORY_REGISTRY;
    }

    @Override
    public void registerCamoContainerFactory(class_1792 item, CamoContainer.Factory factory)
    {
        CamoFactories.registerCamoFactory(item, factory);
    }

    @Override
    public CamoContainer.Factory emptyCamoContainerFactory()
    {
        return FBContent.FACTORY_EMPTY.get();
    }

    @Override
    public CamoContainer.Factory getCamoContainerFactory(class_1799 stack)
    {
        return CamoFactories.getFactory(stack);
    }

    @Override
    public void registerBlueprintCopyBehaviour(BlueprintCopyBehaviour behaviour, class_2248... blocks)
    {
        FramedBlueprintItem.registerBehaviour(behaviour, blocks);
    }

    @Override
    public boolean canHideNeighborFaceInLevel(class_1922 level)
    {
        return !FlywheelCompat.isVirtualLevel(level);
    }

    @Override
    public boolean canCullBlockNextTo(class_2680 state, class_2680 adjState)
    {
        return !state.method_26164(class_3481.field_15503) && NoCubesCompat.mayCullNextTo(adjState);
    }

    @Override
    public boolean shouldConsumeCamo()
    {
        return ServerConfig.consumeCamoItem;
    }

    @Override
    public int getGlowstoneLightLevel()
    {
        return ServerConfig.glowstoneLightLevel;
    }

    @Override
    public CamoMessageVerbosity getCamoMessageVerbosity()
    {
        return ClientConfig.INSTANCE.camoMessageVerbosity();
    }
}
