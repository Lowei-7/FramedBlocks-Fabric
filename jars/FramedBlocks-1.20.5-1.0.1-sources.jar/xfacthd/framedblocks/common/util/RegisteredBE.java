package xfacthd.framedblocks.common.util;

import xfacthd.framedblocks.common.util.fabric.RegistryObject;

import java.util.function.Supplier;
import net.minecraft.class_2586;
import net.minecraft.class_2591;

public record RegisteredBE<T extends class_2586>(RegistryObject<class_2591<T>> value) implements Supplier<class_2591<T>>
{
    @Override
    public class_2591<T> get()
    {
        return value.get();
    }
}
