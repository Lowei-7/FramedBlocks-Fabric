package xfacthd.framedblocks.common.util;

import net.minecraft.class_2498;
import net.minecraft.class_3414;
import xfacthd.framedblocks.api.camo.CamoContainer;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.blockentity.FramedDoubleBlockEntity;

public final class DoubleBlockSoundType extends class_2498
{
    private final FramedDoubleBlockEntity be;

    public DoubleBlockSoundType(FramedDoubleBlockEntity be)
    {
        //noinspection deprecation, ConstantConditions
        super(0, 0, null, null, null, null, null);
        this.be = be;
    }

    @Override
    public float method_10597()
    {
        return getSoundType(be.getTopInteractionMode()).method_10597();
    }

    @Override
    public float method_10599()
    {
        return getSoundType(be.getTopInteractionMode()).method_10599();
    }

    // This is only called when no camo is applied and should therefore return the default break sound
    @Override
    public class_3414 method_10595()
    {
        return be.method_11010().method_26231().method_10595();
    }

    @Override
    public class_3414 method_10594()
    {
        return getSoundType(be.getTopInteractionMode()).method_10594();
    }

    @Override
    public class_3414 method_10598()
    {
        return FBContent.BLOCK_FRAMED_CUBE.get().method_9564().method_26231().method_10598();
    }

    @Override
    public class_3414 method_10596()
    {
        return getEitherSoundType().method_10596();
    }

    @Override
    public class_3414 method_10593()
    {
        return getSoundType(be.getTopInteractionMode()).method_10593();
    }



    private class_2498 getSoundType(DoubleBlockTopInteractionMode mode)
    {
        if (mode == DoubleBlockTopInteractionMode.EITHER)
        {
            return getEitherSoundType();
        }

        CamoContainer camo = mode == DoubleBlockTopInteractionMode.SECOND ? be.getCamoTwo() : be.getCamo();
        if (!camo.isEmpty())
        {
            return camo.getSoundType();
        }

        // Default to no-camo sound
        return be.method_11010().method_26231();
    }

    private class_2498 getEitherSoundType()
    {
        CamoContainer camo = be.getCamo();
        if (!camo.isEmpty())
        {
            return camo.getSoundType();
        }

        camo = be.getCamoTwo();
        if (!camo.isEmpty())
        {
            return camo.getSoundType();
        }

        // Default to no-camo sound
        return be.method_11010().method_26231();
    }
}
