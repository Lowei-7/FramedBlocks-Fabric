package xfacthd.framedblocks.common.util;

import net.minecraft.class_1799;
import net.minecraftforge.items.IItemHandler;
import org.jetbrains.annotations.NotNull;

public abstract class ExternalItemHandler implements IItemHandler
{
    private final IItemHandler wrapped;

    public ExternalItemHandler(IItemHandler wrapped)
    {
        this.wrapped = wrapped;
    }

    @Override
    public final int getSlots()
    {
        return wrapped.getSlots();
    }

    @Override
    public final class_1799 getStackInSlot(int slot)
    {
        return wrapped.getStackInSlot(slot);
    }

    @Override
    public final class_1799 insertItem(int slot, @NotNull class_1799 stack, boolean simulate)
    {
        return wrapped.insertItem(slot, stack, simulate);
    }

    @Override
    public final class_1799 extractItem(int slot, int amount, boolean simulate)
    {
        if (!canExtract(slot))
        {
            return class_1799.field_8037;
        }
        return wrapped.extractItem(slot, amount, simulate);
    }

    @Override
    public final int getSlotLimit(int slot)
    {
        return wrapped.getSlotLimit(slot);
    }

    @Override
    public final boolean isItemValid(int slot, @NotNull class_1799 stack)
    {
        return wrapped.isItemValid(slot, stack);
    }

    protected abstract boolean canExtract(int slot);
}
