package xfacthd.framedblocks.common.util;

import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2802;
import net.minecraft.class_2818;
import net.minecraft.class_2821;
import net.minecraft.class_4076;
import net.minecraft.class_8527;
import org.jetbrains.annotations.Nullable;
import xfacthd.framedblocks.api.internal.InternalAPI;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.util.compat.FlywheelCompat;
import xfacthd.framedblocks.common.util.compat.StarlightCompat;

public final class InternalApiImpl implements InternalAPI
{
    @Override
    @Nullable
    public class_2586 getExistingBlockEntity(class_1922 level, class_2338 pos)
    {
        if (FlywheelCompat.isVirtualLevel(level))
        {
            return level.method_8321(pos);
        }
        return getExistingBlockEntity0(level, pos);
    }

    @Override
    public class_2586 getBlockEntityForLight(class_1922 level, class_2338 pos)
    {
        return StarlightCompat.getBlockEntityForLight(level, pos);
    }

    @Override
    public void updateCamoNbt(class_2487 tag, String stateKey, String stackKey, String camoKey)
    {
        if (tag.method_10545(stateKey))
        {
            class_2487 stateTag = tag.method_10562(stateKey);
            tag.method_10551(stateKey);
            tag.method_10551(stackKey);
            class_2487 camoTag = new class_2487();
            camoTag.method_10582("type", FBContent.FACTORY_BLOCK.getId().toString());
            camoTag.method_10566("state", stateTag);
            tag.method_10566(camoKey, camoTag);
        }
    }

    @Nullable
    private static class_2586 getExistingBlockEntity0(class_1922 blockGetter, class_2338 pos)
    {
        if (blockGetter instanceof class_1937 level)
        {
            int chunkX = class_4076.method_18675(pos.method_10263());
            int chunkZ = class_4076.method_18675(pos.method_10260());
            class_2802 chunkSource;
            try
            {
                chunkSource = level.method_8398();
            }
            catch (Throwable t)
            {
                // Some mods' fake levels think they are funny for throwing in getChunkSource()
                return null;
            }
            class_8527 chunk = chunkSource.method_12246(chunkX, chunkZ);
            return chunk != null ? getExistingBlockEntity0(chunk, pos) : null;
        }
        else if (blockGetter instanceof class_2818 chunk)
        {
            return chunk.method_12214().get(pos);
        }
        else if (blockGetter instanceof class_2821 chunk)
        {
            return getExistingBlockEntity0(chunk.method_12240(), pos);
        }
        return blockGetter.method_8321(pos);
    }
}
