package xfacthd.framedblocks.common.util;

import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import xfacthd.framedblocks.api.block.FramedBlockEntity;
import xfacthd.framedblocks.api.block.IFramedBlock;
import xfacthd.framedblocks.api.block.update.CullingUpdateTracker;
import xfacthd.framedblocks.common.crafting.FramingSawRecipeCache;

public final class EventHandler
{
    public static void init()
    {
        AttackBlockCallback.EVENT.register(EventHandler::onBlockLeftClick);
        ServerLifecycleEvents.SERVER_STOPPED.register(EventHandler::onServerShutdown);
        ServerLifecycleEvents.SERVER_STARTED.register(EventHandler::onServerStarted);
        ServerTickEvents.END_SERVER_TICK.register(EventHandler::onServerTick);
    }

    public static void onServerStarted(net.minecraft.server.MinecraftServer server)
    {
        xfacthd.framedblocks.common.data.StateCacheBuilder.ensureStateCachesInitialized();
        FramingSawRecipeCache.get(false).update(server.method_3772());
    }

    public static void onServerTick(net.minecraft.server.MinecraftServer server)
    {
        for (class_3218 level : server.method_3738())
        {
            CullingUpdateTracker.onServerLevelTick(level);
        }
    }

    public static class_1269 onBlockLeftClick(class_1657 player, class_1937 level, class_1268 hand, class_2338 pos, class_2350 direction)
    {
        class_2680 state = level.method_8320(pos);

        if (state.method_26204() instanceof IFramedBlock block)
        {
            if (block.handleBlockLeftClick(state, level, pos, player))
            {
                if (level.method_8608())
                {
                    // ClientAccess.resetDestroyDelay() - pending Fabric port
                }
                return class_1269.field_21466;
            }

            if (ServerConfig.INSTANCE.enableIntangibleFeature() && block.getBlockType().allowMakingIntangible())
            {
                if (level.method_8321(pos) instanceof FramedBlockEntity be && be.isIntangible(null))
                {
                    return class_1269.field_5814;
                }
            }
        }
        return class_1269.field_5811;
    }

    public static void onServerShutdown(net.minecraft.server.MinecraftServer server)
    {
        FramingSawRecipeCache.get(false).clear();
    }



    private EventHandler() { }
}