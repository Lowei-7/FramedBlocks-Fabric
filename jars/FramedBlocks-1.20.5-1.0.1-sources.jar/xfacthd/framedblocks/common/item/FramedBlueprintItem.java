package xfacthd.framedblocks.common.item;

import com.google.common.base.Preconditions;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3965;
import net.minecraft.class_5250;
import net.minecraft.class_7923;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import net.minecraft.network.chat.*;
import net.minecraft.world.*;
import net.minecraft.world.item.*;
import xfacthd.framedblocks.api.blueprint.BlueprintCopyBehaviour;
import xfacthd.framedblocks.api.camo.CamoContainer;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.api.block.IFramedBlock;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.data.*;
import xfacthd.framedblocks.api.block.FramedBlockEntity;
import xfacthd.framedblocks.common.util.ServerConfig;

import java.util.*;

public class FramedBlueprintItem extends FramedToolItem
{
    public static final String CONTAINED_BLOCK = "desc.framedblocks.blueprint_block";
    public static final String CAMO_BLOCK = "desc.framedblocks.blueprint_camo";
    public static final String IS_ILLUMINATED = "desc.framedblocks.blueprint_illuminated";
    public static final String IS_INTANGIBLE = "desc.framedblocks.blueprint_intangible";
    public static final String IS_REINFORCED = "desc.framedblocks.blueprint_reinforced";
    public static final String MISSING_MATERIALS = Utils.translationKey("desc", "blueprint_missing_materials");
    public static final class_5250 BLOCK_NONE = Utils.translate("desc", "blueprint_none").method_27692(class_124.field_1061);
    public static final class_5250 BLOCK_INVALID = Utils.translate("desc", "blueprint_invalid").method_27692(class_124.field_1061);
    public static final class_5250 FALSE = Utils.translate("desc", "blueprint_false").method_27692(class_124.field_1061);
    public static final class_5250 TRUE = Utils.translate("desc", "blueprint_true").method_27692(class_124.field_1060);
    public static final class_5250 CANT_COPY = Utils.translate("desc", "blueprint_cant_copy").method_27692(class_124.field_1061);
    public static final class_2561 CANT_PLACE_FLUID_CAMO = Utils.translate("desc", "blueprint_cant_place_fluid_camo").method_27692(class_124.field_1061);
    private static final String MATERIAL_LIST_PREFIX = "\n  - ";

    private static final Map<class_2248, BlueprintCopyBehaviour> COPY_BEHAVIOURS = new IdentityHashMap<>();
    private static final BlueprintCopyBehaviour NO_OP_BEHAVIOUR = new BlueprintCopyBehaviour(){};
    private static boolean locked = false;

    public FramedBlueprintItem(FramedToolType type)
    {
        super(type);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand)
    {
        class_1799 stack = player.method_5998(hand);
        if (player.method_5715())
        {
            if (!level.method_8608())
            {
                class_9279.method_57452(class_9334.field_49628, stack, tag ->
                {
                    tag.method_10551("framed_block");
                    tag.method_10551("camo_data");
                    tag.method_10551("camo_data_two");
                });
            }
            return class_1271.method_29237(stack, level.method_8608());
        }
        return super.method_7836(level, player, hand);
    }

    @Override
    public class_1269 method_7884(class_1838 context)
    {
        class_1657 player = context.method_8036();
        if (player == null)
        {
            return class_1269.field_5814;
        }

        class_1937 level = context.method_8045();
        class_2338 pos = context.method_8037();

        class_1799 stack = context.method_8041();
        class_2487 tag = stack.method_57825(class_9334.field_49628, class_9279.field_49302).method_57461();

        if (player.method_5715())
        {
            class_1269 result = writeBlueprint(level, pos, tag);
            if (!tag.method_33133())
            {
                stack.method_57379(class_9334.field_49628, class_9279.method_57456(tag));
            }
            return result;
        }
        else if (!tag.method_33133())
        {
            return readBlueprint(context, player, tag);
        }
        return super.method_7884(context);
    }

    private static class_1269 writeBlueprint(class_1937 level, class_2338 pos, class_2487 tag)
    {
        if (!(level.method_8321(pos) instanceof FramedBlockEntity be))
        {
            return class_1269.field_5814;
        }

        if (!level.method_8608())
        {
            class_2680 state = level.method_8320(pos);
            //noinspection ConstantConditions
            String blockName = class_7923.field_41175.method_10221(state.method_26204()).toString();
            tag.method_10582("framed_block", blockName);

            class_2248 block = state.method_26204();
            if (!getBehaviour(block).writeToBlueprint(level, pos, state, be, tag))
            {
                tag.method_10566("camo_data", be.writeToBlueprint());
            }
        }
        return class_1269.method_29236(level.method_8608());
    }

    private static class_1269 readBlueprint(class_1838 context, class_1657 player, class_2487 tag)
    {
        class_2248 block = getTargetBlock(context.method_8041());

        if (block.method_9564().method_26215())
        {
            return class_1269.field_5814;
        }

        class_1792 item = block.method_8389();
        if (!(item instanceof class_1747 blockItem))
        {
            return class_1269.field_5814;
        }

        if (checkMissingMaterials(player, blockItem, tag))
        {
            return class_1269.field_5814;
        }

        return tryPlace(context, player, blockItem, tag);
    }

    private static boolean checkMissingMaterials(class_1657 player, class_1747 item, class_2487 tag)
    {
        if (player.method_31549().field_7477)
        {
            //Creative mode can always build
            return false;
        }

        Set<CamoContainer> camos = getCamoContainers(item, tag);

        //Copying fluid camos is currently not possible
        if (ServerConfig.consumeCamoItem && camos.stream().anyMatch(camo -> camo.getType().isFluid()))
        {
            if (player.method_37908().method_8608())
            {
                player.method_43496(CANT_PLACE_FLUID_CAMO);
            }
            return true;
        }

        List<class_1799> materials = new ArrayList<>();
        materials.add(getBlockItem(item));
        if (ServerConfig.consumeCamoItem)
        {
            materials.addAll(getCamoStacksMerged(camos));
        }

        BlueprintCopyBehaviour behaviour = getBehaviour(item.method_7711());

        int glowstone = behaviour.getGlowstoneCount(tag);
        if (glowstone > 0)
        {
            materials.add(new class_1799(class_1802.field_8601, glowstone));
        }
        int intangible = behaviour.getIntangibleCount(tag);
        if (intangible > 0)
        {
            materials.add(new class_1799(ServerConfig.intangibleMarkerItem, glowstone));
        }
        int reinforcement = behaviour.getReinforcementCount(tag);
        if (reinforcement > 0)
        {
            materials.add(new class_1799(FBContent.ITEM_FRAMED_REINFORCEMENT.get(), reinforcement));
        }

        List<class_1799> missingMaterials = new ArrayList<>();
        for (class_1799 stack : materials)
        {
            if (stack.method_7960())
            {
                continue;
            }

            if (player.method_31548().method_18861(stack.method_7909()) < stack.method_7947())
            {
                missingMaterials.add(stack);
            }
        }

        if (!missingMaterials.isEmpty())
        {
            if (player.method_37908().method_8608())
            {
                List<String> names = missingMaterials.stream()
                        .map(s -> s.method_7964().getString())
                        .toList();
                String list = MATERIAL_LIST_PREFIX + String.join(MATERIAL_LIST_PREFIX, names);
                player.method_43496(class_2561.method_43471(MISSING_MATERIALS).method_27693(list));
            }
            return true;
        }

        return false;
    }

    private static class_1269 tryPlace(class_1838 context, class_1657 player, class_1747 item, class_2487 tag)
    {
        class_1799 dummyStack = new class_1799(item, 1);
        dummyStack.method_57379(class_9334.field_49611, class_9279.method_57456(tag.method_10562("camo_data")));

        class_1838 placeContext = new class_1838(
                context.method_8045(),
                context.method_8036(),
                context.method_20287(),
                dummyStack,
                new class_3965(context.method_17698(), context.method_8038(), context.method_8037(), context.method_17699())
        );
        //Needs to happen before placing to make sure we really get the target pos, especially in case of replacing stuff like grass
        class_2338 pos = new class_1750(placeContext).method_8037();
        class_1269 result = item.method_7884(placeContext);

        if (!context.method_8045().method_8608() && result.method_23665())
        {
            getBehaviour(item.method_7711()).postProcessPaste(context.method_8045(), pos, context.method_8036(), tag, dummyStack);

            if (!player.method_31549().field_7477)
            {
                consumeItems(player, item, tag);
            }
        }

        return result;
    }

    private static void consumeItems(class_1657 player, class_1747 item, class_2487 tag)
    {
        Set<CamoContainer> camos = getCamoContainers(item, tag);

        //Copying fluid camos is currently not possible
        if (ServerConfig.consumeCamoItem && camos.stream().anyMatch(camo -> camo.getType().isFluid()))
        {
            return;
        }

        List<class_1799> materials = new ArrayList<>();
        materials.add(getBlockItem(item));
        if (ServerConfig.consumeCamoItem)
        {
            materials.addAll(getCamoStacksMerged(camos));
        }

        BlueprintCopyBehaviour behaviour = getBehaviour(item.method_7711());

        int glowstone = behaviour.getGlowstoneCount(tag);
        if (glowstone > 0)
        {
            materials.add(new class_1799(class_1802.field_8601, glowstone));
        }
        int intangible = behaviour.getIntangibleCount(tag);
        if (intangible > 0)
        {
            materials.add(new class_1799(ServerConfig.intangibleMarkerItem, glowstone));
        }
        int reinforcement = behaviour.getReinforcementCount(tag);
        if (reinforcement > 0)
        {
            materials.add(new class_1799(FBContent.ITEM_FRAMED_REINFORCEMENT.get(), reinforcement));
        }

        class_1661 inv = player.method_31548();
        for (int i = 0; i < inv.method_5439(); i++)
        {
            class_1799 stack = inv.method_5438(i);
            for (class_1799 material : materials)
            {
                if (!material.method_7960() && stack.method_31574(material.method_7909()))
                {
                    int size = stack.method_7947();
                    stack.method_7934(Math.min(material.method_7947(), size));
                    material.method_7934(size - stack.method_7947());

                    inv.method_5431();
                }
            }
            materials.removeIf(class_1799::method_7960);

            if (materials.isEmpty())
            {
                break;
            }
        }
    }

    private static BlueprintCopyBehaviour getBehaviour(class_2248 block)
    {
        return COPY_BEHAVIOURS.getOrDefault(block, NO_OP_BEHAVIOUR);
    }

    public static Set<CamoContainer> getCamoContainers(class_1747 item, class_2487 tag)
    {
        return getBehaviour(item.method_7711())
                .getCamos(tag)
                .orElseGet(() ->
                        Set.of(CamoContainer.load(tag.method_10562("camo_data").method_10562("camo")))
                );
    }

    private static class_1799 getBlockItem(class_1747 item)
    {
        return getBehaviour(item.method_7711())
                .getBlockItem()
                .orElse(new class_1799(item));
    }

    private static List<class_1799> getCamoStacksMerged(Set<CamoContainer> camos)
    {
        List<class_1799> camoStacks = new ArrayList<>();
        for (CamoContainer camo : camos)
        {
            class_1799 stack = camo.toItemStack(class_1799.field_8037);
            if (stack.method_7960())
            {
                continue;
            }

            for (class_1799 existing : camoStacks)
            {
                if (class_1799.method_7984(existing, stack))
                {
                    int size = existing.method_7947();
                    existing.method_7933(Math.min(existing.method_7914() - size, stack.method_7947()));
                    stack.method_7934(existing.method_7947() - size);

                    if (stack.method_7960())
                    {
                        break;
                    }
                }
            }

            if (!stack.method_7960())
            {
                camoStacks.add(stack);
            }
        }
        return camoStacks;
    }

    public static class_2248 getTargetBlock(class_1799 stack)
    {
        class_2487 tag = stack.method_57825(class_9334.field_49628, class_9279.field_49302).method_57461();
        class_2248 block = class_7923.field_41175.method_10223(new class_2960(tag.method_10558("framed_block")));
        Objects.requireNonNull(block);
        return block;
    }

    @Override
    public void method_7851(class_1799 stack, class_1792.class_9635 context, List<class_2561> components, class_1836 flag)
    {
        class_2487 tag = stack.method_57825(class_9334.field_49628, class_9279.field_49302).method_57461();
        if (tag.method_33133())
        {
            components.add(class_2561.method_43469(CONTAINED_BLOCK, BLOCK_NONE).method_27692(class_124.field_1065));
        }
        else
        {
            class_2248 block = class_7923.field_41175.method_10223(new class_2960(tag.method_10558("framed_block")));
            class_2561 blockName = block == null ? BLOCK_INVALID : block.method_9518().method_27692(class_124.field_1068);

            class_2487 beTag = tag.method_10562("camo_data");
            class_2561 camoName = !(block instanceof IFramedBlock fb) ? BLOCK_NONE : fb.printCamoBlock(beTag).orElse(BLOCK_NONE);
            class_2561 illuminated = beTag.method_10577("glowing") ? TRUE : FALSE;
            class_2561 intangible = beTag.method_10577("intangible") ? TRUE : FALSE;
            class_2561 reinforced = beTag.method_10577("reinforced") ? TRUE : FALSE;

            class_2561 lineOne = class_2561.method_43469(CONTAINED_BLOCK, blockName).method_27692(class_124.field_1065);
            class_2561 lineTwo = class_2561.method_43469(CAMO_BLOCK, camoName).method_27692(class_124.field_1065);
            class_2561 lineThree = class_2561.method_43469(IS_ILLUMINATED, illuminated).method_27692(class_124.field_1065);
            class_2561 lineFour = class_2561.method_43469(IS_INTANGIBLE, intangible).method_27692(class_124.field_1065);
            class_2561 lineFive = class_2561.method_43469(IS_REINFORCED, reinforced).method_27692(class_124.field_1065);

            components.addAll(Arrays.asList(lineOne, lineTwo, lineThree, lineFour, lineFive));
        }
    }



    public static synchronized void registerBehaviour(BlueprintCopyBehaviour behaviour, class_2248... blocks)
    {
        Preconditions.checkState(!locked, "BlueprintCopyBehaviour registry is locked!");

        Preconditions.checkNotNull(behaviour, "BlueprintCopyBehaviour must be non-null");
        Preconditions.checkNotNull(blocks, "Blocks array must be non-null to register a BlueprintCopyBehaviour");
        Preconditions.checkState(blocks.length > 0, "At least one block must be provided to register a BlueprintCopyBehaviour");

        for (class_2248 block : blocks)
        {
            COPY_BEHAVIOURS.put(block, behaviour);
        }
    }

    public static void lockRegistration()
    {
        locked = true;
    }
}