package xfacthd.framedblocks.common.item;

import xfacthd.framedblocks.api.util.Utils;

import java.util.Map;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2680;

public class VerticalAndWallBlockItem extends class_1747
{
    private final class_2248 wallBlock;

    public VerticalAndWallBlockItem(class_2248 verticalBlock, class_2248 wallBlock, class_1792.class_1793 props)
    {
        super(verticalBlock, props);
        this.wallBlock = wallBlock;
    }

    @Override
    protected class_2680 method_7707(class_1750 context)
    {
        if (Utils.isY(context.method_8038()))
        {
            return method_7711().method_9605(context);
        }
        else
        {
            return wallBlock.method_9605(context);
        }
    }

    @Override
    public void method_7713(Map<class_2248, class_1792> blockToItemMap, class_1792 item)
    {
        super.method_7713(blockToItemMap, item);
        blockToItemMap.put(wallBlock, item);
    }

    public void removeFromBlockToItemMap(Map<class_2248, class_1792> blockToItemMap, class_1792 item)
    {
        blockToItemMap.remove(wallBlock);
    }
}
