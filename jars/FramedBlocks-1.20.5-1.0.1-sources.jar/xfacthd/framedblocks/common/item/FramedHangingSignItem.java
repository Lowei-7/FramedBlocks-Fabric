package xfacthd.framedblocks.common.item;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_4538;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.sign.FramedWallHangingSignBlock;

public class FramedHangingSignItem extends FramedSignItem
{
    public FramedHangingSignItem()
    {
        super(FBContent.BLOCK_FRAMED_HANGING_SIGN.get(), FBContent.BLOCK_FRAMED_WALL_HANGING_SIGN.get(), class_2350.field_11036);
    }

    @Override
    protected boolean method_45431(class_4538 level, class_2680 state, class_2338 pos)
    {
        if (state.method_26204() instanceof FramedWallHangingSignBlock && !FramedWallHangingSignBlock.canPlace(state, level, pos))
        {
            return false;
        }
        return super.method_45431(level, state, pos);
    }
}
