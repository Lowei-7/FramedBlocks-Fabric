package xfacthd.framedblocks.common.item;

import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.sign.AbstractFramedSignBlock;
import xfacthd.framedblocks.common.blockentity.special.FramedSignBlockEntity;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1827;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;

public class FramedSignItem extends class_1827
{
    public FramedSignItem()
    {
        this(FBContent.BLOCK_FRAMED_SIGN.get(), FBContent.BLOCK_FRAMED_WALL_SIGN.get(), class_2350.field_11033);
    }

    public FramedSignItem(class_2248 standing, class_2248 wall, class_2350 attachmentDirection)
    {
        super(standing, wall, new class_1793(), attachmentDirection);
    }

    @Override
    protected boolean method_7710(
            class_2338 pos, class_1937 level, @Nullable class_1657 player, class_1799 stack, class_2680 state
    )
    {
        boolean hadNBT = super.method_7710(pos, level, player, stack, state);
        if (!level.method_8608() && !hadNBT && player != null)
        {
            if (level.method_8321(pos) instanceof FramedSignBlockEntity be)
            {
                AbstractFramedSignBlock.openEditScreen(player, be, true);
            }
        }
        return hadNBT;
    }
}