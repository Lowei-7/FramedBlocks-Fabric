package xfacthd.framedblocks.common.item;

import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_4538;
import xfacthd.framedblocks.common.data.FramedToolType;

public class FramedToolItem extends class_1792
{
    private final FramedToolType type;

    public FramedToolItem(FramedToolType type)
    {
        super(new class_1793().method_7889(1));
        this.type = type;
    }

    public boolean hasCraftingRemainingItem(class_1799 stack)
    {
        return true;
    }

    public class_1799 getCraftingRemainingItem(class_1799 stack)
    {
        return stack.method_7972();
    }

    public boolean doesSneakBypassUse(class_1799 stack, class_4538 level, class_2338 pos, class_1657 player)
    {
        return true;
    }

    public final FramedToolType getType()
    {
        return type;
    }
}