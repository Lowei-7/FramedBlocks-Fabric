package xfacthd.framedblocks.common.compat.emi;

import dev.emi.emi.api.recipe.EmiRecipeCategory;
import dev.emi.emi.api.render.EmiRenderable;
import net.minecraft.class_2561;
import xfacthd.framedblocks.common.block.special.FramingSawBlock;

public final class FramingSawRecipeCategory extends EmiRecipeCategory
{
    public FramingSawRecipeCategory(EmiRenderable icon, EmiRenderable simplified)
    {
        super(EmiCompat.SAW_ID, icon, simplified, FramedEmiPlugin::compareRecipes);
    }

    @Override
    public class_2561 getName()
    {
        return FramingSawBlock.SAW_MENU_TITLE;
    }
}
