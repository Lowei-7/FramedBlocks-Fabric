package xfacthd.framedblocks.common.compat.emi;

import net.minecraft.class_2960;
import net.minecraftforge.fml.ModList;

import xfacthd.framedblocks.api.util.Utils;

public final class EmiCompat
{
    public static final class_2960 SAW_ID = Utils.rl("framing_saw");

    private static boolean loadedClient = false;

    public static void init()
    {
        if (net.fabricmc.loader.api.FabricLoader.getInstance().getEnvironmentType() == net.fabricmc.api.EnvType.CLIENT && ModList.get().isLoaded("emi"))
        {
            loadedClient = true;
        }
    }

    public static boolean isLoaded()
    {
        return loadedClient;
    }



    private EmiCompat() { }
}
