package xfacthd.framedblocks.common.compat.emi;

import dev.emi.emi.api.recipe.EmiRecipe;
import dev.emi.emi.api.recipe.handler.*;
import xfacthd.framedblocks.common.crafting.FramingSawRecipe;
import xfacthd.framedblocks.common.crafting.FramingSawRecipeCache;
import xfacthd.framedblocks.common.menu.*;
import xfacthd.framedblocks.common.net.NetworkingHandler;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_310;

public final class FramedEmiRecipeHandler<T extends class_1703 & IFramingSawMenu> implements StandardRecipeHandler<T>
{
    @Override
    public List<class_1735> getInputSources(T menu)
    {
        List<class_1735> list = new ArrayList<>(FramingSawMenu.TOTAL_SLOT_COUNT - 1);
        for (int i = 0; i < FramingSawMenu.SLOT_RESULT; i++)
        {
            list.add(menu.method_7611(i));
        }
        for (int i = FramingSawMenu.SLOT_INV_FIRST; i < FramingSawMenu.TOTAL_SLOT_COUNT; i++)
        {
            list.add(menu.method_7611(i));
        }
        return list;
    }

    @Override
    public List<class_1735> getCraftingSlots(T menu)
    {
        List<class_1735> list = new ArrayList<>(FramingSawRecipe.MAX_ADDITIVE_COUNT + 1);
        for (int i = 0; i < FramingSawMenu.SLOT_RESULT; i++)
        {
            list.add(menu.method_7611(i));
        }
        return list;
    }

    @Override
    public class_1735 getOutputSlot(T menu)
    {
        return menu.method_7611(FramingSawMenu.SLOT_RESULT);
    }

    @Override
    public boolean supportsRecipe(EmiRecipe recipe)
    {
        return recipe.getCategory() == FramedEmiPlugin.SAW_CATEGORY.get();
    }

    @Override
    public boolean craft(EmiRecipe recipe, EmiCraftContext<T> context)
    {
        if (!(recipe instanceof FramingSawEmiRecipe sawRecipe) || !StandardRecipeHandler.super.craft(recipe, context))
        {
            return false;
        }

        int idx = FramingSawRecipeCache.get(true).getRecipes().indexOf(sawRecipe.getRecipe());
        T menu = context.getScreenHandler();
        if (idx != -1 && menu.isValidRecipeIndex(idx))
        {
            //noinspection ConstantConditions
            if (menu.method_7604(class_310.method_1551().field_1724, idx))
            {
                NetworkingHandler.sendSelectFramingSawRecipe(menu.field_7763, idx);
            }
        }
        return true;
    }
}
