package xfacthd.framedblocks.common.compat.create.schematic.nbt;

import net.minecraft.class_2487;
import xfacthd.framedblocks.api.block.FramedBlockEntity;
import xfacthd.framedblocks.api.compat.create.FramedBlockSafeNbtWriter;
import xfacthd.framedblocks.common.blockentity.special.FramedChiseledBookshelfBlockEntity;

public final class FramedChiseledBookshelfSafeNbtWriter extends FramedBlockSafeNbtWriter
{
    @Override
    protected void cleanupTag(FramedBlockEntity fbe, class_2487 tag)
    {
        tag.method_10551(FramedChiseledBookshelfBlockEntity.INVENTORY_NBT_KEY);
        tag.method_10569(FramedChiseledBookshelfBlockEntity.LAST_SLOT_NBT_KEY, -1);
    }
}
