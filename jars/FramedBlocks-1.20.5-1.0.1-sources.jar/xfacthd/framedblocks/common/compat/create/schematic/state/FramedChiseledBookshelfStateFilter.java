package xfacthd.framedblocks.common.compat.create.schematic.state;

import com.simibubi.create.api.schematic.state.SchematicStateFilterRegistry;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2746;
import net.minecraft.class_7714;
import org.jetbrains.annotations.Nullable;

public final class FramedChiseledBookshelfStateFilter implements SchematicStateFilterRegistry.StateFilter
{
    @Override
    public class_2680 filterStates(@Nullable class_2586 be, class_2680 state)
    {
        for (class_2746 property : class_7714.field_41308)
        {
            state = state.method_11657(property, false);
        }
        return state;
    }
}
