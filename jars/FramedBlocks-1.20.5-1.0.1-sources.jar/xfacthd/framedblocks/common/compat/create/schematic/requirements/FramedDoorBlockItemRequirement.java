package xfacthd.framedblocks.common.compat.create.schematic.requirements;

import com.simibubi.create.api.schematic.requirement.SchematicRequirementRegistries;
import com.simibubi.create.content.schematics.requirement.ItemRequirement;
import net.minecraft.class_1799;
import net.minecraft.class_2323;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2756;
import org.jetbrains.annotations.Nullable;

public final class FramedDoorBlockItemRequirement implements SchematicRequirementRegistries.BlockRequirement
{
    public static final FramedDoorBlockItemRequirement INSTANCE = new FramedDoorBlockItemRequirement();

    private FramedDoorBlockItemRequirement() { }

    @Override
    public ItemRequirement getRequiredItems(class_2680 state, @Nullable class_2586 blockEntity)
    {
        if (state.method_11654(class_2323.field_10946) == class_2756.field_12607)
        {
            return new ItemRequirement(ItemRequirement.ItemUseType.CONSUME, new class_1799(state.method_26204()));
        }
        return ItemRequirement.NONE;
    }
}
