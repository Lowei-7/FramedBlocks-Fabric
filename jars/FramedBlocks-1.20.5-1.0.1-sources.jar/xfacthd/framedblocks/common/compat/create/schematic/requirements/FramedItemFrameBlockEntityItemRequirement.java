package xfacthd.framedblocks.common.compat.create.schematic.requirements;

import com.simibubi.create.content.schematics.requirement.ItemRequirement;
import net.createmod.catnip.nbt.NBTProcessors;
import net.minecraft.class_1799;
import xfacthd.framedblocks.api.block.FramedBlockEntity;
import xfacthd.framedblocks.api.compat.create.FramedBlockEntityItemRequirement;
import xfacthd.framedblocks.common.blockentity.special.FramedItemFrameBlockEntity;

import java.util.List;

public final class FramedItemFrameBlockEntityItemRequirement extends FramedBlockEntityItemRequirement
{
    @Override
    protected void collectAdditionalRequirements(FramedBlockEntity blockEntity, List<ItemRequirement.StackRequirement> requirements)
    {
        if (blockEntity instanceof FramedItemFrameBlockEntity itemFrame && itemFrame.hasItem())
        {
            class_1799 stack = NBTProcessors.withUnsafeNBTDiscarded(itemFrame.getItem().method_7972());
            requirements.add(consumeStrict(stack));
        }
    }
}
