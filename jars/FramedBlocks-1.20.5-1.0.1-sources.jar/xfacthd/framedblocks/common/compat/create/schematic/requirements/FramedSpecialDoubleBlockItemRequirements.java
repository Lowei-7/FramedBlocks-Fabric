package xfacthd.framedblocks.common.compat.create.schematic.requirements;

import com.simibubi.create.api.schematic.requirement.SchematicRequirementRegistries;
import com.simibubi.create.content.schematics.requirement.ItemRequirement;
import org.jetbrains.annotations.Nullable;

import java.util.function.Supplier;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

public final class FramedSpecialDoubleBlockItemRequirements implements SchematicRequirementRegistries.BlockRequirement
{
    private final Supplier<class_2248> itemBlock;

    public FramedSpecialDoubleBlockItemRequirements(Supplier<class_2248> itemBlock)
    {
        this.itemBlock = itemBlock;
    }

    @Override
    public ItemRequirement getRequiredItems(class_2680 state, @Nullable class_2586 blockEntity)
    {
        return new ItemRequirement(ItemRequirement.ItemUseType.CONSUME, new class_1799(itemBlock.get()));
    }
}
