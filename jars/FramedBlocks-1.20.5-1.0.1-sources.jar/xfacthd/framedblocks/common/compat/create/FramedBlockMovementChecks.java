package xfacthd.framedblocks.common.compat.create;

import com.simibubi.create.api.contraption.BlockMovementChecks;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import xfacthd.framedblocks.api.block.IFramedBlock;
import xfacthd.framedblocks.api.block.FramedProperties;
import xfacthd.framedblocks.common.block.sign.AbstractFramedSignBlock;
import xfacthd.framedblocks.common.data.BlockType;

public final class FramedBlockMovementChecks implements
        BlockMovementChecks.MovementNecessaryCheck,
        BlockMovementChecks.MovementAllowedCheck,
        BlockMovementChecks.BrittleCheck,
        BlockMovementChecks.AttachedCheck,
        BlockMovementChecks.NotSupportiveCheck
{
    @Override
    public BlockMovementChecks.CheckResult isBlockAttachedTowards(class_2680 state, class_1937 level, class_2338 pos, class_2350 side)
    {
        if (state.method_26204() instanceof IFramedBlock block && block.getBlockType() instanceof BlockType type)
        {
            return switch (type)
            {
                case FRAMED_SIGN, FRAMED_FLOWER_POT -> result(side == class_2350.field_11033);
                case FRAMED_FLOOR_BOARD -> result(side == (state.method_11654(FramedProperties.TOP) ? class_2350.field_11036 : class_2350.field_11033));
                case FRAMED_WALL_SIGN -> result(state.method_11654(FramedProperties.FACING_HOR) == side.method_10153());
                case FRAMED_WALL_BOARD -> result(state.method_11654(FramedProperties.FACING_HOR) == side);
                default -> BlockMovementChecks.CheckResult.PASS;
            };
        }
        return BlockMovementChecks.CheckResult.PASS;
    }

    @Override
    public BlockMovementChecks.CheckResult isBrittle(class_2680 state)
    {
        class_2248 block = state.method_26204();
        if (block instanceof AbstractFramedSignBlock)
        {
            return BlockMovementChecks.CheckResult.SUCCESS;
        }
        return BlockMovementChecks.CheckResult.PASS;
    }

    @Override
    public BlockMovementChecks.CheckResult isMovementAllowed(class_2680 state, class_1937 level, class_2338 pos)
    {
        return BlockMovementChecks.CheckResult.PASS;
    }

    @Override
    public BlockMovementChecks.CheckResult isMovementNecessary(class_2680 state, class_1937 level, class_2338 pos)
    {
        return BlockMovementChecks.CheckResult.PASS;
    }

    @Override
    public BlockMovementChecks.CheckResult isNotSupportive(class_2680 state, class_2350 side)
    {
        return BlockMovementChecks.CheckResult.PASS;
    }



    private static BlockMovementChecks.CheckResult result(boolean value)
    {
        return BlockMovementChecks.CheckResult.of(value);
    }
}
