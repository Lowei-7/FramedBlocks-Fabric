package xfacthd.framedblocks.common.compat.rei;

import me.shedaniel.rei.api.client.registry.display.DynamicDisplayGenerator;
import me.shedaniel.rei.api.client.view.ViewSearchBuilder;
import me.shedaniel.rei.api.common.entry.EntryIngredient;
import me.shedaniel.rei.api.common.entry.EntryStack;
import me.shedaniel.rei.api.common.entry.type.VanillaEntryTypes;
import me.shedaniel.rei.api.common.util.EntryStacks;
import net.minecraft.class_1277;
import net.minecraft.class_1799;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.crafting.*;

import java.util.*;
import java.util.stream.Stream;

public final class FramingSawDisplayGenerator implements DynamicDisplayGenerator<FramingSawDisplay>
{
    @Override
    public Optional<List<FramingSawDisplay>> getRecipeFor(EntryStack<?> entry)
    {
        if (!entry.isEmpty() && entry.getType() == VanillaEntryTypes.ITEM)
        {
            class_1799 input = new class_1799(FBContent.BLOCK_FRAMED_CUBE.get());
            class_1799 output = entry.castValue();
            FramingSawRecipe recipe = FramingSawRecipeCache.get(true).findRecipeFor(output);
            if (recipe != null)
            {
                return Optional.of(List.of(makeDisplay(recipe, input)));
            }
        }
        return Optional.empty();
    }

    @Override
    public Optional<List<FramingSawDisplay>> getUsageFor(EntryStack<?> entry)
    {
        if (!entry.isEmpty() && entry.getType() == VanillaEntryTypes.ITEM)
        {
            class_1799 input = entry.castValue();
            if (input.method_31574(FBContent.BLOCK_FRAMING_SAW.get().method_8389()) || input.method_31574(FBContent.BLOCK_POWERED_FRAMING_SAW.get().method_8389()))
            {
                return getUsageFor(EntryStacks.of(FBContent.BLOCK_FRAMED_CUBE.get()));
            }

            FramingSawRecipeCache cache = FramingSawRecipeCache.get(true);
            if (cache.getMaterialValue(input.method_7909()) > -1)
            {
                List<FramingSawRecipe> recipes = cache.getRecipes();
                List<FramingSawDisplay> displays = new ArrayList<>(recipes.size());
                for (FramingSawRecipe recipe : recipes)
                {
                    displays.add(makeDisplay(recipe, input));
                }
                return Optional.of(displays);
            }

            List<FramingSawRecipe> recipes = cache.getRecipesWithAdditive(input);
            if (!recipes.isEmpty())
            {
                List<FramingSawDisplay> displays = new ArrayList<>(recipes.size());
                input = new class_1799(FBContent.BLOCK_FRAMED_CUBE.get());
                for (FramingSawRecipe recipe : recipes)
                {
                    displays.add(makeDisplay(recipe, input));
                }
                return Optional.of(displays);
            }
        }
        return Optional.empty();
    }

    @Override
    public Optional<List<FramingSawDisplay>> generate(ViewSearchBuilder builder)
    {
        if (builder.getUsagesFor().isEmpty() && builder.getRecipesFor().isEmpty() && builder.getCategories().contains(FramingSawRecipeCategory.SAW_CATEGORY))
        {
            return getUsageFor(EntryStacks.of(FBContent.BLOCK_FRAMED_CUBE.get()));
        }
        return Optional.empty();
    }



    private static FramingSawDisplay makeDisplay(FramingSawRecipe recipe, class_1799 input)
    {
        boolean inputWithAdditives = FramingSawRecipeCache.get(true).containsAdditive(input.method_7909());

        List<FramingSawRecipeAdditive> additives = recipe.getAdditives();
        List<EntryIngredient> inputs = new ArrayList<>(additives.size() + 1);
        FramingSawRecipeCalculation calc = recipe.makeCraftingCalculation(
                new class_1277(input), true
        );
        int outputCount = calc.getOutputCount();

        class_1799 inputStack = input.method_7972();
        inputStack.method_7939(calc.getInputCount());
        inputs.add(EntryIngredient.of(EntryStacks.of(inputStack)));

        for (FramingSawRecipeAdditive additive : additives)
        {
            int addCount = additive.count() * (outputCount / recipe.getResult().method_7947());
            List<EntryStack<class_1799>> additiveStacks = Stream.of(additive.ingredient().method_8105())
                    .map(class_1799::method_7972)
                    .peek(s -> s.method_7939(addCount))
                    .map(EntryStacks::of)
                    .toList();
            inputs.add(EntryIngredient.of(additiveStacks));
        }

        class_1799 result = recipe.getResult().method_7972();
        result.method_7939(outputCount);
        EntryIngredient output = EntryIngredient.of(EntryStacks.of(result));

        return new FramingSawDisplay(recipe, inputs, output, inputWithAdditives);
    }
}
