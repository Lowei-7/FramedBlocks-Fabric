package xfacthd.framedblocks.common.compat.rei;

import me.shedaniel.math.Point;
import me.shedaniel.math.Rectangle;
import me.shedaniel.rei.api.client.gui.drag.*;
import net.minecraft.class_1799;
import net.minecraft.class_437;
import xfacthd.framedblocks.client.screen.PoweredFramingSawScreen;
import xfacthd.framedblocks.common.crafting.FramingSawRecipeCache;

import java.util.stream.Stream;

public final class PoweredFramingSawDraggableStackVisitor implements DraggableStackVisitor<PoweredFramingSawScreen>
{
    @Override
    public <R extends class_437> boolean isHandingScreen(R screen)
    {
        return screen instanceof PoweredFramingSawScreen;
    }

    @Override
    public Stream<BoundsProvider> getDraggableAcceptingBounds(
            DraggingContext<PoweredFramingSawScreen> context, DraggableStack draggableStack
    )
    {
        if (draggableStack.getStack().getValue() instanceof class_1799 stack)
        {
            if (FramingSawRecipeCache.get(true).getMaterialValue(stack.method_7909()) > 0)
            {
                PoweredFramingSawScreen screen = context.getScreen();
                return Stream.of(BoundsProvider.ofRectangle(new Rectangle(
                        screen.getTargetStackX() - 1, screen.getTargetStackY() - 1, 18, 18
                )));
            }
        }
        return Stream.empty();
    }

    @Override
    public DraggedAcceptorResult acceptDraggedStack(
            DraggingContext<PoweredFramingSawScreen> context, DraggableStack draggableStack
    )
    {
        PoweredFramingSawScreen screen = context.getScreen();
        int sx = screen.getTargetStackX();
        int sy = screen.getTargetStackY();
        Point pos = context.getCurrentPosition();
        if (pos == null || (pos.x < sx || pos.x >= sx + 18 || pos.y < sy || pos.y >= sy + 18))
        {
            return DraggedAcceptorResult.PASS;
        }

        if (draggableStack.getStack().getValue() instanceof class_1799 stack)
        {
            if (FramingSawRecipeCache.get(true).getMaterialValue(stack.method_7909()) > 0)
            {
                context.getScreen().selectRecipe(stack);
                return DraggedAcceptorResult.ACCEPTED;
            }
        }
        return DraggedAcceptorResult.PASS;
    }
}
