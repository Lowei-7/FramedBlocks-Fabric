package xfacthd.framedblocks.common.compat.rei;

import me.shedaniel.rei.api.common.category.CategoryIdentifier;
import me.shedaniel.rei.api.common.display.Display;
import me.shedaniel.rei.api.common.entry.EntryIngredient;
import net.minecraft.class_2960;
import xfacthd.framedblocks.common.crafting.FramingSawRecipe;

import java.util.List;
import java.util.Optional;

public final class FramingSawDisplay implements Display
{
    private final FramingSawRecipe recipe;
    @SuppressWarnings("OptionalUsedAsFieldOrParameterType")
    private final Optional<class_2960> location;
    private final List<EntryIngredient> inputs;
    private final List<EntryIngredient> output;
    private final boolean inputWithAdditives;

    public FramingSawDisplay(
            FramingSawRecipe recipe,
            List<EntryIngredient> inputs,
            EntryIngredient output,
            boolean inputWithAdditives
    )
    {
        this.recipe = recipe;
        this.location = Optional.of(recipe.getId());
        this.inputs = inputs;
        this.output = List.of(output);
        this.inputWithAdditives = inputWithAdditives;
    }

    @Override
    public List<EntryIngredient> getInputEntries()
    {
        return inputs;
    }

    @Override
    public List<EntryIngredient> getOutputEntries()
    {
        return output;
    }

    @Override
    public CategoryIdentifier<?> getCategoryIdentifier()
    {
        return FramingSawRecipeCategory.SAW_CATEGORY;
    }

    @Override
    public Optional<class_2960> getDisplayLocation()
    {
        return location;
    }

    public FramingSawRecipe getRecipe()
    {
        return recipe;
    }

    public boolean hasInputWithAdditives()
    {
        return inputWithAdditives;
    }
}
