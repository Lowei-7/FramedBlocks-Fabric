package xfacthd.framedblocks.common.compat.nocubes;

import net.minecraft.class_2680;

public final class NoCubesCompat
{
    public static boolean mayCullNextTo(class_2680 state)
    {
        return true;
    }

    private NoCubesCompat() { }
}
