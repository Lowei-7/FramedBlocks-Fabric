package xfacthd.framedblocks.common.compat.supplementaries;

import net.mehvahdjukaar.supplementaries.common.block.IRopeConnection;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_4538;
import net.minecraftforge.fml.ModList;
import xfacthd.framedblocks.FramedBlocks;

public final class SupplementariesCompat
{
    public static final class_2960 HANGING_MODEL_LOCATION = new class_2960("supplementaries", "block/hanging_flower_pot_rope");
    private static boolean loaded = false;

    public static void init()
    {
        loaded = ModList.get().isLoaded("supplementaries");
    }

    public static boolean isLoaded()
    {
        return loaded;
    }

    public static boolean canSurviveHanging(class_4538 level, class_2338 pos)
    {
        if (loaded)
        {
            return GuardedAccess.canSurviveHanging(level, pos);
        }
        return false;
    }



    private static final class GuardedAccess
    {
        private static boolean failedPreviously = false;

        public static boolean canSurviveHanging(class_4538 level, class_2338 pos)
        {
            if (failedPreviously)
            {
                return true;
            }

            try
            {
                return IRopeConnection.isSupportingCeiling(pos, level);
            }
            catch (Throwable e)
            {
                if (!failedPreviously)
                {
                    failedPreviously = true;
                    FramedBlocks.LOGGER.error("[SupplementariesCompat] Encountered an error while checking hanging pot surviving", e);
                }
                return true;
            }
        }
    }



    private SupplementariesCompat() { }
}
