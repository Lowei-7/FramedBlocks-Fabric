package xfacthd.framedblocks.common.compat.jei;

import mezz.jei.api.constants.VanillaTypes;
import mezz.jei.api.gui.handlers.IGuiClickableArea;
import mezz.jei.api.gui.handlers.IGuiContainerHandler;
import mezz.jei.api.ingredients.ITypedIngredient;
import mezz.jei.api.recipe.IFocusFactory;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.runtime.IIngredientManager;
import mezz.jei.api.runtime.IRecipesGui;
import net.minecraft.class_1799;
import net.minecraft.class_768;
import xfacthd.framedblocks.client.screen.PoweredFramingSawScreen;
import xfacthd.framedblocks.common.FBContent;

import java.util.*;

public final class PoweredFramingSawGuiContainerHandler implements IGuiContainerHandler<PoweredFramingSawScreen>
{
    @Override
    public Collection<IGuiClickableArea> getGuiClickableAreas(PoweredFramingSawScreen screen, double mouseX, double mouseY)
    {
        int minX = PoweredFramingSawScreen.PROGRESS_X;
        int minY = PoweredFramingSawScreen.PROGRESS_Y;
        int maxX = minX + PoweredFramingSawScreen.PROGRESS_WIDTH;
        int maxY = minY + PoweredFramingSawScreen.PROGRESS_HEIGHT;
        if (mouseX >= minX && mouseX < maxX && mouseY >= minY && mouseY < maxY)
        {
            return List.of(new ClickableArea(new class_768(
                    minX, minY, PoweredFramingSawScreen.PROGRESS_WIDTH, PoweredFramingSawScreen.PROGRESS_HEIGHT
            )));
        }
        return List.of();
    }



    private record ClickableArea(class_768 area) implements IGuiClickableArea
    {
        @Override
        public class_768 getArea()
        {
            return area;
        }

        @Override
        public void onClick(IFocusFactory focusFactory, IRecipesGui recipesGui)
        {
            IIngredientManager ingredients = JeiCompat.GuardedAccess.getRuntime().getIngredientManager();
            Optional<ITypedIngredient<class_1799>> optIng = ingredients.createTypedIngredient(
                    VanillaTypes.ITEM_STACK, new class_1799(FBContent.BLOCK_POWERED_FRAMING_SAW.get())
            );
            optIng.ifPresent(ing -> recipesGui.show(focusFactory.createFocus(RecipeIngredientRole.CATALYST, ing)));
        }
    }
}
