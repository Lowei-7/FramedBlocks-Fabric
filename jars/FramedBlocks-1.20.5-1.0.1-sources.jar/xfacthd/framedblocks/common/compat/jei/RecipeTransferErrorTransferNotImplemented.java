package xfacthd.framedblocks.common.compat.jei;

import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import mezz.jei.api.recipe.transfer.IRecipeTransferError;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import java.util.List;
import java.util.Optional;

public final class RecipeTransferErrorTransferNotImplemented implements IRecipeTransferError
{
    @Override
    public Type getType()
    {
        return Type.COSMETIC;
    }

    @Override
    public void showError(class_332 graphics, int mouseX, int mouseY, IRecipeSlotsView recipeSlotsView, int recipeX, int recipeY)
    {
        class_437 screen = class_310.method_1551().field_1755;
        if (screen != null)
        {
            graphics.method_51437(
                    class_310.method_1551().field_1772,
                    List.of(JeiCompat.MSG_TRANSFER_NOT_IMPLEMENTED),
                    Optional.empty(),
                    mouseX,
                    mouseY
            );
        }
    }
}
