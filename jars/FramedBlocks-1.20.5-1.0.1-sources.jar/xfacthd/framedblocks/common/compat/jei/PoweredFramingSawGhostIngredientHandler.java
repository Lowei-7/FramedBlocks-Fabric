package xfacthd.framedblocks.common.compat.jei;

import mezz.jei.api.constants.VanillaTypes;
import mezz.jei.api.gui.handlers.IGhostIngredientHandler;
import mezz.jei.api.ingredients.ITypedIngredient;
import net.minecraft.class_1799;
import net.minecraft.class_768;
import xfacthd.framedblocks.client.screen.PoweredFramingSawScreen;
import xfacthd.framedblocks.common.crafting.FramingSawRecipeCache;

import java.util.List;

public final class PoweredFramingSawGhostIngredientHandler implements IGhostIngredientHandler<PoweredFramingSawScreen>
{
    @Override
    @SuppressWarnings("unchecked")
    public <I> List<Target<I>> getTargetsTyped(PoweredFramingSawScreen screen, ITypedIngredient<I> ingredient, boolean doStart)
    {
        if (ingredient.getType() == VanillaTypes.ITEM_STACK)
        {
            class_1799 stack = ingredient.getItemStack().orElseThrow();
            if (FramingSawRecipeCache.get(true).getMaterialValue(stack.method_7909()) > 0)
            {
                return List.of((Target<I>) new SawTarget(screen));
            }
        }
        return List.of();
    }

    @Override
    public void onComplete() { }



    private record SawTarget(PoweredFramingSawScreen screen, class_768 area) implements Target<class_1799>
    {
        private SawTarget(PoweredFramingSawScreen screen)
        {
            this(screen, new class_768(screen.getTargetStackX() - 1, screen.getTargetStackY() - 1, 18, 18));
        }

        @Override
        public class_768 getArea()
        {
            return area;
        }

        @Override
        public void accept(class_1799 stack)
        {
            screen.selectRecipe(stack);
        }
    }
}
