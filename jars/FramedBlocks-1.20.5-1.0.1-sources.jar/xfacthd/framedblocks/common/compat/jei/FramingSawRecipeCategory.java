package xfacthd.framedblocks.common.compat.jei;

import com.google.common.collect.Lists;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.builder.IRecipeSlotBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.*;
import mezz.jei.api.recipe.category.IRecipeCategory;
import net.minecraft.class_1277;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import xfacthd.framedblocks.api.util.Utils;
import xfacthd.framedblocks.client.screen.FramingSawScreen;
import xfacthd.framedblocks.common.FBContent;
import xfacthd.framedblocks.common.block.special.FramingSawBlock;
import xfacthd.framedblocks.common.crafting.*;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public final class FramingSawRecipeCategory implements IRecipeCategory<FramingSawRecipe>
{
    private static final class_2960 BACKGROUND = Utils.rl("textures/gui/framing_saw_jei.png");
    private static final int WIDTH = 118;
    private static final int HEIGHT = 41;
    private static final int WARNING_X = 38;
    private static final int WARNING_Y = 3;
    private static final int WARNING_SIZE = 16;
    private static final float WARNING_SCALE = .75F;
    private static final int WARNING_DRAW_SIZE = (int) (WARNING_SIZE * WARNING_SCALE);

    private final IDrawable background;
    private final IDrawable icon;
    private final IDrawable warning;

    public FramingSawRecipeCategory(IGuiHelper guiHelper)
    {
        this.background = guiHelper.createDrawable(BACKGROUND, 0, 0, WIDTH, HEIGHT);
        this.icon = guiHelper.createDrawableItemStack(new class_1799(FBContent.BLOCK_FRAMING_SAW.get()));
        this.warning = guiHelper.drawableBuilder(FramingSawScreen.WARNING_ICON, 8, 8, WARNING_SIZE, WARNING_SIZE).setTextureSize(32, 32).build();
    }

    @Override
    public RecipeType<FramingSawRecipe> getRecipeType()
    {
        return FramedJeiPlugin.FRAMING_SAW_RECIPE_TYPE;
    }

    @Override
    public class_2561 getTitle()
    {
        return FramingSawBlock.SAW_MENU_TITLE;
    }

    @Override
    public IDrawable getBackground()
    {
        return background;
    }

    @Override
    public IDrawable getIcon()
    {
        return icon;
    }

    @Override
    public void setRecipe(IRecipeLayoutBuilder builder, FramingSawRecipe recipe, IFocusGroup focuses)
    {
        FramingSawRecipeCache cache = FramingSawRecipeCache.get(true);
        List<FramingSawRecipeAdditive> additives = recipe.getAdditives();

        IRecipeSlotBuilder inputSlot = builder.addSlot(RecipeIngredientRole.INPUT, 19, 1).setSlotName("input");
        IRecipeSlotBuilder[] additiveSlots = null;
        if (!additives.isEmpty())
        {
            additiveSlots = new IRecipeSlotBuilder[additives.size()];
            for (int i = 0; i < additives.size(); i++)
            {
                int x = 1 + (i * 18);
                additiveSlots[i] = builder.addSlot(RecipeIngredientRole.INPUT, x, 24);
            }
        }
        IRecipeSlotBuilder outputSlot = builder.addSlot(RecipeIngredientRole.OUTPUT, 97, 13);

        if (focuses.isEmpty())
        {
            for (class_1792 input : cache.getKnownItems())
            {
                setRecipe(input, recipe, inputSlot, additiveSlots, outputSlot);
            }

            if (additiveSlots != null)
            {
                IRecipeSlotBuilder[] slots = new IRecipeSlotBuilder[additives.size() + 2];
                slots[0] = inputSlot;
                slots[slots.length - 1] = outputSlot;
                System.arraycopy(additiveSlots, 0, slots, 1, additiveSlots.length);
                builder.createFocusLink(slots);
            }
            else
            {
                builder.createFocusLink(inputSlot, outputSlot);
            }
            return;
        }

        class_1799 inputStack = focuses.getItemStackFocuses(RecipeIngredientRole.INPUT)
                .map(focus -> focus.getTypedValue().getIngredient())
                .filter(stack -> cache.getMaterialValue(stack.method_7909()) > 0)
                .findFirst()
                .orElse(class_1799.field_8037);

        if (!inputStack.method_7960())
        {
            setRecipe(inputStack.method_7909(), recipe, inputSlot, additiveSlots, outputSlot);
        }
        else
        {
            setRecipe(FBContent.BLOCK_FRAMED_CUBE.get().method_8389(), recipe, inputSlot, additiveSlots, outputSlot);
        }
    }

    private static void setRecipe(
            class_1792 input,
            FramingSawRecipe recipe,
            IRecipeSlotBuilder inputSlot,
            IRecipeSlotBuilder[] additiveSlots,
            IRecipeSlotBuilder outputSlot
    )
    {
        FramingSawRecipeCalculation calc = recipe.makeCraftingCalculation(
                new class_1277(new class_1799(input)), true
        );

        class_1799 inputStack = new class_1799(input, calc.getInputCount());
        class_1799 outputStack = recipe.getResult().method_7972();
        int outputCount = calc.getOutputCount();
        outputStack.method_7939(outputCount);

        List<FramingSawRecipeAdditive> additives = recipe.getAdditives();
        List<List<class_1799>> flatAdditives = new ArrayList<>(FramingSawRecipe.MAX_ADDITIVE_COUNT);
        for (FramingSawRecipeAdditive additive : additives)
        {
            int addCount = additive.count() * (outputCount / recipe.getResult().method_7947());
            List<class_1799> additiveStacks = Stream.of(additive.ingredient().method_8105())
                    .map(class_1799::method_7972)
                    .peek(s -> s.method_7939(addCount))
                    .toList();
            flatAdditives.add(additiveStacks);
        }
        List<List<class_1799>> combinations = Lists.cartesianProduct(flatAdditives);
        combinations.forEach(stacks ->
        {
            inputSlot.addItemStack(inputStack);
            outputSlot.addItemStack(outputStack);
            for (int i = 0; i < stacks.size(); i++)
            {
                additiveSlots[i].addItemStack(stacks.get(i));
            }
        });
    }

    @Override
    public void draw(FramingSawRecipe recipe, IRecipeSlotsView slots, class_332 graphics, double mouseX, double mouseY)
    {
        class_1799 input = slots.findSlotByName("input")
                .orElseThrow()
                .getDisplayedItemStack()
                .orElseThrow();

        if (FramingSawRecipeCache.get(true).containsAdditive(input.method_7909()))
        {
            graphics.method_51448().method_22903();
            graphics.method_51448().method_22905(WARNING_SCALE, WARNING_SCALE, 1F);
            graphics.method_51448().method_46416(WARNING_X * (1F / WARNING_SCALE), WARNING_Y * (1F / WARNING_SCALE), 0);
            warning.draw(graphics);
            graphics.method_51448().method_22909();
        }
    }

    @Override
    public List<class_2561> getTooltipStrings(FramingSawRecipe recipe, IRecipeSlotsView slots, double mouseX, double mouseY)
    {
        if (mouseX >= WARNING_X && mouseY >= WARNING_Y && mouseX <= (WARNING_X + WARNING_DRAW_SIZE) && mouseY <= (WARNING_Y + WARNING_DRAW_SIZE))
        {
            class_1799 input = slots.findSlotByName("input")
                    .orElseThrow()
                    .getDisplayedItemStack()
                    .orElseThrow();

            if (FramingSawRecipeCache.get(true).containsAdditive(input.method_7909()))
            {
                return List.of(FramingSawScreen.TOOLTIP_LOOSE_ADDITIVE);
            }
        }

        return List.of();
    }
}
