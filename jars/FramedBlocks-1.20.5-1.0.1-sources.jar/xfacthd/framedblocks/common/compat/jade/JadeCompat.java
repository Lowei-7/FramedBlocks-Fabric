package xfacthd.framedblocks.common.compat.jade;

import net.minecraft.class_2561;
import net.minecraft.class_2960;
import xfacthd.framedblocks.api.util.Utils;

public final class JadeCompat
{
    public static final class_2960 ID_ITEM_FRAME = Utils.rl("framed_item_frame");

    public static class_2561 configTranslation(class_2960 id)
    {
        return class_2561.method_43471("config.jade.plugin_%s.%s".formatted(id.method_12836(), id.method_12832()));
    }



    private JadeCompat() { }
}
