package xfacthd.framedblocks.common.compat.jade;

import net.minecraft.class_2960;
import snownee.jade.api.*;
import snownee.jade.api.config.IPluginConfig;
import snownee.jade.api.ui.IDisplayHelper;
import xfacthd.framedblocks.common.blockentity.special.FramedItemFrameBlockEntity;

final class FramedItemFrameComponentProvider implements IBlockComponentProvider
{
    @Override
    public void appendTooltip(ITooltip tooltip, BlockAccessor blockAccessor, IPluginConfig config)
    {
        if (blockAccessor.getBlockEntity() instanceof FramedItemFrameBlockEntity be && be.hasItem())
        {
            tooltip.add(IDisplayHelper.get().stripColor(be.getItem().method_7964()));
        }
    }

    @Override
    public class_2960 getUid()
    {
        return JadeCompat.ID_ITEM_FRAME;
    }
}
