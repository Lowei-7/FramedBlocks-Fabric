package xfacthd.framedblocks.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;
import net.minecraft.class_2689;
import net.minecraft.class_2769;

@Mixin(class_2689.class_2690.class)
public interface AccessorStateDefinitionBuilder
{
    @Accessor("properties")
    Map<String, class_2769<?>> framedblocks$getProperties();
}
