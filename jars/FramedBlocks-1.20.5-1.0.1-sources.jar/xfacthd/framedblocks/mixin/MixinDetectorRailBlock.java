package xfacthd.framedblocks.mixin;

import net.minecraft.class_2313;
import net.minecraft.class_2680;
import net.minecraft.class_2769;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_2313.class)
public abstract class MixinDetectorRailBlock
{
    /**
     * The vanilla constructor registers a default state that hardcodes the vanilla {@code SHAPE} property.
     * Framed rail-slope variants replace that property with a custom ascending-only shape property, so
     * {@code setValue(SHAPE, ...)} would throw. Skip setting the property when it isn't present on the block.
     */
    @Redirect(
            method = "<init>",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/level/block/state/BlockState;setValue(Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Comparable;)Ljava/lang/Object;"
            )
    )
    private static Object framedblocks$guardSetValue(
            class_2680 state, class_2769<?> property, Comparable<?> value,
            net.minecraft.class_4970.class_2251 props
    )
    {
        return state.method_28498(property) ? state.method_11657((class_2769) property, (Comparable) value) : state;
    }
}