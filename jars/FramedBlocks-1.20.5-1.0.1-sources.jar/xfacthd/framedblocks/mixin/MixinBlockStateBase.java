package xfacthd.framedblocks.mixin;

import com.google.common.base.Preconditions;
import org.spongepowered.asm.mixin.*;
import xfacthd.framedblocks.api.block.IFramedBlock;
import xfacthd.framedblocks.api.block.cache.IStateCacheAccessor;
import xfacthd.framedblocks.api.block.cache.StateCache;

import java.util.*;
import net.minecraft.class_2680;
import net.minecraft.class_4970;

@Mixin(class_4970.class_4971.class)
public abstract class MixinBlockStateBase implements IStateCacheAccessor
{
    @Unique
    private StateCache framedblocks$cache = null;

    @Shadow
    abstract class_2680 asState();

    @Override
    public void framedblocks$initCache(StateCache cache)
    {
        Preconditions.checkState(
                asState().method_26204() instanceof IFramedBlock,
                "IStateCacheAccessor#initCache() must only be called on blocks implementing IFramedBlock"
        );
        framedblocks$cache = cache;
    }

    @Override
    public StateCache framedblocks$getCache()
    {
        return Objects.requireNonNull(framedblocks$cache, "IStateCacheAccessor#framedblocks$getCache() called too early");
    }
}
