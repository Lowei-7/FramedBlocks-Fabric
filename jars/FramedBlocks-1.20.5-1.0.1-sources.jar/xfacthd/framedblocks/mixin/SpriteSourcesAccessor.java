package xfacthd.framedblocks.mixin;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_7948;
import net.minecraft.class_7951;
import net.minecraft.class_7952;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_7952.class)
public interface SpriteSourcesAccessor
{
    @Invoker("register")
    static class_7951 register(String name, MapCodec<? extends class_7948> codec)
    {
        throw new AssertionError("Mixin not applied");
    }
}