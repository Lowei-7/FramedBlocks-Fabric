package xfacthd.framedblocks.mixin;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2442;
import net.minecraft.class_2680;
import net.minecraft.class_2768;
import net.minecraft.class_2769;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_2442.class)
public abstract class MixinPoweredRailBlock
{
    /**
     * The vanilla constructor registers a default state that hardcodes the vanilla {@code SHAPE} property.
     * Framed rail-slope variants replace that property with a custom ascending-only shape property, so
     * {@code setValue(SHAPE, ...)} would throw. Skip setting the property when it isn't present on the block.
     */
    @Redirect(
            method = "<init>",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/level/block/state/BlockState;setValue(Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Comparable;)Ljava/lang/Object;"
            )
    )
    private static Object framedblocks$guardSetValue(
            class_2680 state, class_2769<?> property, Comparable<?> value,
            net.minecraft.class_4970.class_2251 props
    )
    {
        return state.method_28498(property) ? state.method_11657((class_2769) property, (Comparable) value) : state;
    }

    /**
     * Forge patch: route shape lookups through {@code getShapeProperty()} so the framed variants, which use a
     * custom ascending-only shape property, work with the vanilla powered-rail signal logic
     */
    @Redirect(
            method = "findPoweredRailSignal",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/level/block/state/BlockState;getValue(Lnet/minecraft/world/level/block/state/properties/Property;)Ljava/lang/Comparable;"
            )
    )
    private Comparable<?> framedblocks$redirectShapeLookupFind(
            class_2680 state, class_2769<?> property, class_1937 level, class_2338 pos, class_2680 adjState, boolean powered, int depth
    )
    {
        if (property == class_2442.field_11365)
        {
            class_2442 self = (class_2442) (Object) this;
            return state.method_11654(self.method_9474());
        }
        return state.method_11654(property);
    }

    /**
     * Forge patch: same redirect as above for {@code isSameRailWithPower}
     */
    @Redirect(
            method = "isSameRailWithPower",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/level/block/state/BlockState;getValue(Lnet/minecraft/world/level/block/state/properties/Property;)Ljava/lang/Comparable;"
            )
    )
    private Comparable<?> framedblocks$redirectShapeLookupSame(
            class_2680 state, class_2769<?> property, class_1937 level, class_2338 pos, boolean powered, int depth, class_2768 shape
    )
    {
        if (property == class_2442.field_11365)
        {
            class_2442 self = (class_2442) (Object) this;
            return state.method_11654(self.method_9474());
        }
        return state.method_11654(property);
    }
}
