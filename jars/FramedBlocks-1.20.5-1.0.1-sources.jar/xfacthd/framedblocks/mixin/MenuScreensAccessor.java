package xfacthd.framedblocks.mixin;

import net.minecraft.class_1703;
import net.minecraft.class_3917;
import net.minecraft.class_3929;
import net.minecraft.class_3936;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_3929.class)
public interface MenuScreensAccessor
{
    @Invoker("register")
    static <M extends class_1703, U extends class_437 & class_3936<M>> void framedblocks$register(
            class_3917<? extends M> type, class_3929.class_3930<M, U> factory
    )
    {
        throw new AssertionError("Mixin not applied");
    }
}