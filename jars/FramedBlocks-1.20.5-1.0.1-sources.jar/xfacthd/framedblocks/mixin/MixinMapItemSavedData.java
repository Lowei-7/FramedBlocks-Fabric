package xfacthd.framedblocks.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_20;
import net.minecraft.class_21;
import net.minecraft.class_22;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import net.minecraft.nbt.*;
import net.minecraft.world.level.saveddata.maps.*;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import xfacthd.framedblocks.common.blockentity.special.FramedItemFrameBlockEntity;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Mixin(class_22.class)
@SuppressWarnings("MethodMayBeStatic")
public abstract class MixinMapItemSavedData implements FramedItemFrameBlockEntity.MapMarkerRemover
{
    @Unique
    private final Map<String, FramedItemFrameBlockEntity.FramedMap> framedblocks$frameMarkers = new HashMap<>();

    @Shadow @Final private boolean trackingPosition;

    @Shadow @Final private Map<String, class_20> decorations;

    @ModifyExpressionValue(method = "tickCarriedBy", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;isFramed()Z", ordinal = 0))
    private boolean framedblocks$checkVanillaFramedOrCustomFramed(boolean isFramed, class_1657 player, class_1799 stack)
    {
        //noinspection ConstantConditions
        return isFramed || framedblocks$getFramedMapData(stack) != null;
    }

    @ModifyExpressionValue(method = "tickCarriedBy", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;isFramed()Z", ordinal = 1))
    private boolean framedblocks$checkNotVanillaFramedAndNotCustomFramed(boolean isFramed, class_1657 player, class_1799 stack)
    {
        //noinspection ConstantConditions
        return isFramed || framedblocks$getFramedMapData(stack) != null;
    }

    @Inject(method = "tickCarriedBy", at = @At("RETURN"))
    private void framedblocks$updateFramedItemFrameMarker(class_1657 player, class_1799 mapStack, CallbackInfo ci)
    {
        class_2487 tag = framedblocks$getFramedMapData(mapStack);
        if (trackingPosition && tag != null)
        {
            class_2338 pos = class_2338.method_10092(tag.method_10537("pos"));
            String frameId = FramedItemFrameBlockEntity.FramedMap.makeFrameId(pos);
            if (!framedblocks$frameMarkers.containsKey(frameId))
            {
                int rot = tag.method_10571("y_rot") * 90;
                FramedItemFrameBlockEntity.FramedMap framedMap = new FramedItemFrameBlockEntity.FramedMap(pos, rot);
                framedblocks$addMapMarker(player.method_37908(), frameId, framedMap);
            }
        }
    }

    @Inject(method = "load", at = @At("TAIL"))
    private static void framedblocks$loadCustomMapMarkers(class_2487 tag, CallbackInfoReturnable<class_22> cir)
    {
        class_2499 frames = tag.method_10554("framedblocks:frames", class_2520.field_33260);
        for (int i = 0; i < frames.size(); i++)
        {
            class_2487 frameTag = frames.method_10602(i);
            FramedItemFrameBlockEntity.FramedMap map = FramedItemFrameBlockEntity.FramedMap.load(frameTag);
            String frameId = FramedItemFrameBlockEntity.FramedMap.makeFrameId(map.pos());
            ((MixinMapItemSavedData)(Object) cir.getReturnValue()).framedblocks$addMapMarker(null, frameId, map);
        }
    }

    @Inject(method = "save", at = @At("TAIL"))
    private void framedblocks$saveCustomMapMarkers(class_2487 tag, CallbackInfoReturnable<class_2487> cir)
    {
        if (!framedblocks$frameMarkers.isEmpty())
        {
            class_2499 frames = new class_2499();
            framedblocks$frameMarkers.forEach((id, marker) -> frames.add(marker.save()));
            tag.method_10566("framedblocks:frames", frames);
        }
    }

    @Override
    public void framedblocks$removeMapMarker(class_2338 pos)
    {
        String frameId = FramedItemFrameBlockEntity.FramedMap.makeFrameId(pos);
        decorations.remove(frameId);
        framedblocks$frameMarkers.remove(frameId);
    }

    @Unique
    private void framedblocks$addMapMarker(
            class_1936 level, String frameId, FramedItemFrameBlockEntity.FramedMap framedMap
    )
    {
        class_2338 pos = framedMap.pos();
        int rot = framedMap.yRot();
        decorations.put(frameId, new class_20(class_21.field_95, (byte) pos.method_10263(), (byte) pos.method_10260(), (byte) rot, Optional.empty()));
        framedblocks$frameMarkers.put(frameId, framedMap);
    }

    @Unique
    private static class_2487 framedblocks$getFramedMapData(class_1799 stack)
    {
        class_9279 customData = stack.method_57824(class_9334.field_49628);
        return customData != null ? customData.method_57463() : null;
    }
}
