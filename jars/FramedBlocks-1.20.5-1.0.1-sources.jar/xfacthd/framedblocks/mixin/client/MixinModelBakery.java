package xfacthd.framedblocks.mixin.client;

import net.minecraft.class_1088;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import xfacthd.framedblocks.client.model.FramedModelBaking;

@Mixin(class_1088.class)
public abstract class MixinModelBakery
{
    @Inject(method = "bakeModels", at = @At("RETURN"))
    private void framedblocks$onModelsBaked(CallbackInfo ci)
    {
        class_1088 self = (class_1088) (Object) this;
        FramedModelBaking.onModelsBaked(self.method_4734());
    }
}
