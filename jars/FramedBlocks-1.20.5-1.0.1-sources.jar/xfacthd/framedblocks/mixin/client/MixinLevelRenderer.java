package xfacthd.framedblocks.mixin.client;

import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4599;
import net.minecraft.class_5365;
import net.minecraft.class_638;
import net.minecraft.class_761;
import net.minecraft.class_824;
import net.minecraft.class_898;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import xfacthd.framedblocks.api.block.IFramedBlock;
import xfacthd.framedblocks.client.util.FramedClientUtils;

// Break sounds are not important, apply after other mixins and bail if someone else already modified the target
@Mixin(value = class_761.class, priority = 10000)
public class MixinLevelRenderer
{
    @Shadow
    private class_638 level;
    @Shadow
    @Final
    private class_310 minecraft;

    @Unique
    private class_5365 framedblocks$lastGraphicsMode;

    @Redirect(
            method = "levelEvent",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/level/block/state/BlockState;isAir()Z"
            ),
            require = 0
    )
    private boolean framedblocks$playCustomBreakSound(class_2680 state, int type, class_2338 pos, int data)
    {
        if (state.method_26204() instanceof IFramedBlock block && block.playBreakSound(state, level, pos))
        {
            return true;
        }
        return state.method_26215();
    }

    @Inject(method = "<init>", at = @At("RETURN"))
    private void framedblocks$captureInitialGraphicsMode(class_310 mc, class_898 entityRenderDispatcher, class_824 blockEntityRenderDispatcher, class_4599 buffers, CallbackInfo ci)
    {
        framedblocks$lastGraphicsMode = mc.field_1690.method_42534().method_41753();
    }

    @Inject(method = "allChanged", at = @At("HEAD"))
    private void framedblocks$handleRedrawOnGraphicsModeChange(CallbackInfo ci)
    {
        class_5365 graphicsMode = minecraft.field_1690.method_42534().method_41753();
        if (graphicsMode != framedblocks$lastGraphicsMode)
        {
            framedblocks$lastGraphicsMode = graphicsMode;
            FramedClientUtils.clearModelCaches();
        }
    }
}
