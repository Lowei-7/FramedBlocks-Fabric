package xfacthd.framedblocks.mixin.client;

import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2818;
import net.minecraft.class_7225;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import xfacthd.framedblocks.api.block.FramedBlockEntity;

/**
 * Mirrors the Forge patch in LevelChunk.replaceWithPacketData, which handles the block entity
 * data sent in the chunk packet with {@link class_2586#handleUpdateTag(CompoundTag)} instead of
 * {@link class_2586#load(CompoundTag)}. The update tag uses the network serialization format
 * which is not load()-compatible for FramedBlockEntity and its subclasses (the camo "type" is a
 * sync ID int instead of a registry name string). On Forge this method is supplied by the
 * IForgeBlockEntity interface; on Fabric it only exists on the FramedBlockEntity hierarchy.
 */
@Mixin(class_2818.class)
public abstract class MixinLevelChunk
{
    @Redirect(
            method = "method_31716",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/level/block/entity/BlockEntity;loadWithComponents(Lnet/minecraft/nbt/CompoundTag;Lnet/minecraft/core/HolderLookup$Provider;)V"
            )
    )
    private void framedblocks$redirectChunkDataLoad(class_2586 blockEntity, class_2487 tag, class_7225.class_7874 registries)
    {
        if (blockEntity instanceof FramedBlockEntity framedBe)
        {
            framedBe.handleUpdateTag(tag);
        }
        else
        {
            blockEntity.method_58690(tag, registries);
        }
    }
}
