package xfacthd.framedblocks.mixin;

import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_5272;
import net.minecraft.class_6395;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_5272.class)
public interface ItemPropertiesInvoker
{
    @Invoker("register")
    static void framedblocks$register(class_1792 item, class_2960 name, class_6395 function) { throw new AssertionError(); }
}